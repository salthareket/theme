<?php
namespace NSLPro\JWT;

class BeforeValidException extends \UnexpectedValueException
{

}
