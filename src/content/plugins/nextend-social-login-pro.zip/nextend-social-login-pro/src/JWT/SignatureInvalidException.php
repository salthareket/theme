<?php

namespace NSLPro\JWT;

class SignatureInvalidException extends \UnexpectedValueException {

}
