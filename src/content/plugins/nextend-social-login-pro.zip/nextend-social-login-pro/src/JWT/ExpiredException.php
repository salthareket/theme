<?php
namespace NSLPro\JWT;

class ExpiredException extends \UnexpectedValueException
{

}
