<div class="nsl-clear"></div>
<h3><?php _e('Social accounts', 'nextend-facebook-connect'); ?></h3>
<div>
    <?php
    echo $buttons;
    ?>
</div>