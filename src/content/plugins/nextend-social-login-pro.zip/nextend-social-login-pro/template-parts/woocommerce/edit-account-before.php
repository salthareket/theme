<h3><?php _e('Social accounts', 'nextend-facebook-connect'); ?></h3>
<div style="padding-bottom:20px;margin-bottom:20px;border-bottom: 1px solid rgba(0,0,0,.05)">
    <?php
    echo $buttons;
    ?>
</div>