<div style="padding:20px 0;">
    <?php
    echo $buttons;
    ?>
</div>
