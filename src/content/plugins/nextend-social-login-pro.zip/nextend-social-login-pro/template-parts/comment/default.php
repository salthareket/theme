<div style="margin:20px 0;">
    <?php
    echo $buttons;
    ?>
</div>
