<?php
defined('ABSPATH') || die();
/** @var $this NextendSocialProviderAdmin */

$provider = $this->getProvider();

function nslGetReversedDomain($domain) {
    return implode('.', array_reverse(explode('.', (str_replace('www.', '', trim($domain))))));
}

$protocol        = parse_url(site_url(), PHP_URL_SCHEME);
$domain          = parse_url(site_url(), PHP_URL_HOST);
$clean_domain    = str_replace('www.', '', $domain);
$reversed_domain = nslGetReversedDomain($clean_domain);
$url_domain      = $protocol . '://' . $clean_domain;


?>
<div class="nsl-admin-sub-content">
    <?php if (substr($provider->getLoginUrl(), 0, 8) !== 'https://') { ?>
        <div class="error">
            <p><?php printf(__('%1$s allows HTTPS OAuth Redirects only. You must move your site to HTTPS in order to allow login with %1$s.', 'nextend-facebook-connect'), $provider->getLabel()); ?></p>
            <p>
                <a href="https://social-login.nextendweb.com/documentation/providers/facebook/#how-to-add-ssl-to-wordpress"><?php _e("How to get SSL for my WordPress site?", 'nextend-facebook-connect'); ?></a>
            </p>
        </div>
    <?php } else {
        $this->renderGettingStartedHead();
        ?>

        <ul>
            <li>
                <b>Return URLs:</b>
                <ul class='nsl-list-disc'>
                    <?php
                    $loginUrls = $provider->getAllRedirectUrisForAppCreation();
                    foreach ($loginUrls as $loginUrl) {
                        echo "<li>" . $loginUrl . "</li>";
                    }
                    ?>
                </ul>
            </li>
            <li>
                <b>Bundle ID:</b>
                <ul class='nsl-list-disc'>
                    <li><?php echo $reversed_domain; ?>.nslapp</li>
                </ul>
            </li>
            <li>
                <b>Identifier:</b>
                <ul class='nsl-list-disc'>
                    <li><?php echo $reversed_domain; ?>.nslclient</li>
                </ul>
            </li>
            <li>
                <b>Domains and Subdomains::</b>
                <ul class='nsl-list-disc'>
                    <li><?php echo $clean_domain; ?></li>
                </ul>
            </li>
        </ul>

        <?php
        $this->renderGettingStartedFooter();
    } ?>

</div>