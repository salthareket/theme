<?php
defined('ABSPATH') || die();
/** @var $this NextendSocialProviderAdmin */

$provider = $this->getProvider();

function nslGetReversedDomain($domain) {
    return implode('.', array_reverse(explode('.', (str_replace('www.', '', trim($domain))))));
}

$protocol        = parse_url(site_url(), PHP_URL_SCHEME);
$domain          = parse_url(site_url(), PHP_URL_HOST);
$clean_domain    = str_replace('www.', '', $domain);
$reversed_domain = nslGetReversedDomain($clean_domain);
$url_domain      = $protocol . '://' . $clean_domain;

$this->renderFixRedirectUriHead();
?>
<ul>
    <li>
        <b>Service ID:</b>
        <ul class='nsl-list-disc'>
            <li><?php echo $provider->settings->get('service_identifier'); ?></li>
        </ul>
    </li>
    <li>
        <b>Return URLs:</b>
        <ul class='nsl-list-disc'>
            <?php
            $loginUrls = $provider->getAllRedirectUrisForAppCreation();
            foreach ($loginUrls as $loginUrl) {
                echo "<li>" . $loginUrl . "</li>";
            }
            ?>
        </ul>
    </li>
    <li>
        <b>Domains and Subdomains::</b>
        <ul class='nsl-list-disc'>
            <li><?php echo $clean_domain; ?></li>
        </ul>
    </li>
</ul>