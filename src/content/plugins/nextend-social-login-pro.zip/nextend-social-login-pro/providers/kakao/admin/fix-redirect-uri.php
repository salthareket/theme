<?php
defined('ABSPATH') || die();
/** @var $this NextendSocialProviderAdmin */

$provider = $this->getProvider();


/**
 * @var $client NextendSocialProviderKakaoClient
 */
$client = $provider->getClient();

$this->renderFixRedirectUriHead();
?>
<ul>
    <li>
        <b>REST API Key:</b>
        <ul class='nsl-list-disc'>
            <li><?php echo $client->getClientId(); ?></li>
        </ul>
    </li>
    <li>
        <b>Kakao Login Redirect URI:</b>
        <ul class='nsl-list-disc'>
            <?php
            $loginUrls = $provider->getAllRedirectUrisForAppCreation();
            foreach ($loginUrls as $loginUrl) {
                echo "<li>" . $loginUrl . "</li>";
            }
            ?>
        </ul>
    </li>
</ul>