<?php
defined('ABSPATH') || die();
/** @var $this NextendSocialProviderAdmin */

$provider = $this->getProvider();
?>
<div class="nsl-admin-sub-content">
    <?php $this->renderGettingStartedHead(); ?>

    <ul>
        <li>
            <b>Kakao Login Redirect URI:</b>
            <ul class='nsl-list-disc'>
                <?php
                $loginUrls = $provider->getAllRedirectUrisForAppCreation();
                foreach ($loginUrls as $loginUrl) {
                    echo "<li>" . $loginUrl . "</li>";
                }
                ?>
            </ul>
        </li>
        <li>
            <b>App primary domain:</b>
            <ul class='nsl-list-disc'>
                <li><?php echo set_url_scheme('http://' . $_SERVER['HTTP_HOST']); ?></li>
            </ul>
        </li>
    </ul>

    <?php $this->renderGettingStartedFooter(); ?>
</div>