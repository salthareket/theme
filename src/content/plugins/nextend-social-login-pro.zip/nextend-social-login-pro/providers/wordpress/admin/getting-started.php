<?php
defined('ABSPATH') || die();
/** @var $this NextendSocialProviderAdmin */

$provider = $this->getProvider();
?>
<div class="nsl-admin-sub-content">
    <?php $this->renderGettingStartedHead(); ?>

    <ul>
        <li>
            <b>Redirect URLs:</b>
            <ul class='nsl-list-disc'>
                <?php
                $loginUrls = $provider->getAllRedirectUrisForAppCreation();
                foreach ($loginUrls as $loginUrl) {
                    echo "<li>" . $loginUrl . "</li>";
                }
                ?>
            </ul>
        </li>
        <li>
            <b>Website URL:</b>
            <ul class='nsl-list-disc'>
                <li><?php echo site_url(); ?></li>
            </ul>
        </li>
    </ul>

    <?php $this->renderGettingStartedFooter(); ?>
</div>