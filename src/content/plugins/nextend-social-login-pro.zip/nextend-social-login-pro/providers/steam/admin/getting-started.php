<?php
defined('ABSPATH') || die();
/** @var $this NextendSocialProviderAdmin */

$provider = $this->getProvider();
?>
<div class="nsl-admin-sub-content">

    <?php if (substr($provider->getLoginUrl(), 0, 8) !== 'https://'): ?>
        <div class="error">
            <p><?php printf(__('%1$s allows HTTPS OAuth Redirects only. You must move your site to HTTPS in order to allow login with %1$s.', 'nextend-facebook-connect'), 'Steam'); ?></p>
            <p>
                <a href="https://social-login.nextendweb.com/documentation/providers/facebook/#how-to-add-ssl-to-wordpress"><?php _e("How to get SSL for my WordPress site?", 'nextend-facebook-connect'); ?></a>
            </p>
        </div>
    <?php else: ?>
        <?php $this->renderGettingStartedHead(); ?>

        <ul>
            <li><?php
                echo "<b>Domain Name:</b>";
                echo "<ul class='nsl-list-disc'>";
                echo "<li>" . str_replace('www.', '', $_SERVER['HTTP_HOST']) . "</li>";
                echo "</ul>";
                ?>
            </li>
        </ul>

        <?php $this->renderGettingStartedFooter(); ?>
    <?php endif; ?>

</div>