<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Class Iconic_WSSV_Core_Uplink_Helper
 *
 * @class    Iconic_WSSV_Core_Uplink_Helper
 * @version  1.0.0
 */
class Iconic_WSSV_Core_Uplink_Helper {
    const DATA = '23c44bf8024816e3439b11388f30fbeffc0535d8';
}
