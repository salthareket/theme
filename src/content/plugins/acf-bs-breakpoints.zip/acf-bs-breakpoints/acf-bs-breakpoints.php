<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( ! class_exists('acf_bs_breakpoints') ) :

	/**
	 * PREFIX_acf_field_FIELD_NAME class.
	 */
	class acf_bs_breakpoints extends \acf_field {
		/**
		 * Controls field type visibilty in REST requests.
		 *
		 * @var bool
		 */
		public $show_in_rest = true;

		/**
		 * Environment values relating to the theme or plugin.
		 *
		 * @var array $env Plugin or theme context such as 'url' and 'version'.
		 */
		private $env;

		/**
		 * Constructor.
		 */
		public function __construct() {
			/**
			 * Field type reference used in PHP and JS code.
			 *
			 * No spaces. Underscores allowed.
			 */
			$this->name = 'acf_bs_breakpoints';

			/**
			 * Field type label.
			 *
			 * For public-facing UI. May contain spaces.
			 */
			$this->label = __( 'Breakpoints', 'acf_bs_breakpoints' );

			$this->type = "";

			/**
			 * The category the field appears within in the field type picker.
			 */
			$this->category = 'layout'; // basic | content | choice | relational | jquery | layout | CUSTOM GROUP NAME

			/**
			 * Field type Description.
			 *
			 * For field descriptions. May contain spaces.
			 */
			$this->description = __( 'FIELD_DESCRIPTION', 'acf_bs_breakpoints' );

			/**
			 * Field type Doc URL.
			 *
			 * For linking to a documentation page. Displayed in the field picker modal.
			 */
			$this->doc_url = 'FIELD_DOC_URL';

			/**
			 * Field type Tutorial URL.
			 *
			 * For linking to a tutorial resource. Displayed in the field picker modal.
			 */
			$this->tutorial_url = 'FIELD_TUTORIAL_URL';

			/**
			 * Defaults for your custom user-facing settings for this field type.
			 */
			$this->defaults = array(
				'font_size'	=> 14
			);

			//$this->breakpoints = array("xxxl", "xxl", "xl", "lg", "md", "sm", "xs");
			$this->breakpoints = array(
				"xxxl" => "(>=1600px)<br>Desktop PC, TV",
				"xxl" => "(>=1400px)<br>Desktop PC",
				"xl" => "(>=1200px)<br>Large Laptop",
				"lg" => "(>=992px)<br>Laptop",
				"md" => "(>=758px)<br>Large Tablet",
				"sm" => "(>=576px)<br>Tablet, Phone",
				"xs" => "(<575px)<br>Phone"
			);

			$this->types = array(
				"text" => "Text",
				"number" => "Number",
				"units" => "Units",
				"true_false" => "True / false",
				"select" => "Select",
				"color_picker" => "Color Picker",
				"image" => "Image"
			);
			if( class_exists('acf_field_units') ){
				//$this->types["units"] = "Units";
			}

			/**
			 * Strings used in JavaScript code.
			 *
			 * Allows JS strings to be translated in PHP and loaded in JS via:
			 *
			 * ```js
			 * const errorMessage = acf._e("FIELD_NAME", "error");
			 * ```
			 */
			$this->l10n = array(
				'error'	=> __( 'Error! Please enter a higher value', 'acf_bs_breakpoints' ),
			);

			$this->env = array(
				'url'     => plugins_url().'/acf-bs-breakpoints/',//get_template_directory_uri() . '/includes/acf-bs-breakpoints/',//site_url( str_replace( ABSPATH, '', __DIR__ ) ), // URL to the acf-FIELD-NAME directory.
				'version' => '1.0', // Replace this with your theme or plugin version constant.
			);

			/**
			 * Field type preview image.
			 *
			 * A preview image for the field type in the picker modal.
			 */
			$this->preview_image = $this->env['url'] . '/assets/images/field-preview-custom.png';

			//add_filter('intermediate_image_sizes_advanced', [$this, 'disable_breakpoint_image_sizes'], 10, 2);

			//add_filter('intermediate_image_sizes_advanced', [$this, 'disable_all_image_sizes'], 10, 2);
			//add_filter('acf/format_value', [$this, 'acf_bs_format_value'], 10, 3);
			//add_action('save_post', [$this, 'handle_breakpoint_image_sizes'], 10, 3);
			add_filter('acf/update_value/type='.$this->name, [$this, 'acf_bs_breakpoints_update_value'], 10, 3);
			add_filter('acf/format_value/type='.$this->name, [$this, 'acf_bs_breakpoints_format_value'], 10, 3);

			parent::__construct();
		}




		/**
		 * Settings to display when users configure a field of this type.
		 *
		 * These settings appear on the ACF “Edit Field Group” admin page when
		 * setting up the field.
		 *
		 * @param array $field
		 * @return void
		 */
		function render_field_settings( $field ) {
			/*
			 * Repeat for each setting you wish to display for this field type.
			 */
			if(is_admin()){
				acf_render_field_setting( $field, array(
					'label'			=> __('Field Type','acf_bs_breakpoints'),
					'type'			=> 'select',
					'name'			=> 'acf_bs_breakpoints_type',
					'choices'       => $this->types,
					'layout'        => 'horizontal',
					'wrapper'       => array(
		                'class' => 'bs-breakpoints-type-setting'
		            )
				));
				acf_render_field_setting( $field, array(
				    'label'         => __('Responsive', 'acf_bs_breakpoints'),
				    'type'          => 'true_false',
				    'name'          => 'show_description',
				    'layout'        => 'horizontal',
				    'wrapper'       => array(
				        'class' => 'show-description-setting'
				    )
				));
				acf_render_field_setting( $field, array(
				    'label'         => __('Default Value', 'acf_bs_breakpoints'),
				    'type'          => 'text',
				    'name'          => 'default_value',
				    'layout'        => 'horizontal',
				    'wrapper'       => array(
				        'class' => 'default_value-setting'
				    )
				));
				acf_render_field_setting( $field, array(
					'label'			=> __('Choices','acf_bs_breakpoints'),
					'type'			=> 'textarea',
					'name'			=> 'acf_bs_breakpoints_choices',
					'layout'        => 'horizontal',
					'wrapper'       => array(
		                'class' => 'bs-breakpoints-choices-setting'
		            )
				));
				foreach($this->breakpoints as $key => $breakpoint){
					acf_render_field_setting(
						$field,
						array(
							'label'			=> $key,
							'instructions'	=> '',
							'type'			=> 'text',
							'name'			=> $key,
							'append'		=> '',
							'wrapper'       => array(
								'width'     => '14.2',
								'class'     => 'bs-breakpoints-choices-defaults pe-0',
								'id'        => ''
							)
						)
					);			
				}	
			}else{
				foreach($this->breakpoints as $key => $breakpoint){
					acf_render_field_setting(
						$field,
						array(
							'label'			=>  $key,
							'instructions'	=> $breakpoint,
							'type'			=> 'select',
							'name'			=> $key,
							'append'		=> 'px',
							'wrapper'       => array(
								'width'     => '14.2',
								'class'     => '',
								'id'        => ''
							)
						)
					);			
				}			
			}
			// To render field settings on other tabs in ACF 6.0+:
			// https://www.advancedcustomfields.com/resources/adding-custom-settings-fields/#moving-field-setting
		}

		/**
		 * HTML content to show when a publisher edits the field on the edit screen.
		 *
		 * @param array $field The field settings and values.
		 * @return void
		 */

		public function render_field( $field ) {

		    $type = $field["acf_bs_breakpoints_type"];
		    $this->type = $type;
		    if($type == "select"){
		    	if(isset($field["choices"]) && is_array($field["choices"])){
					$choices = $field["choices"];
		    	}else{
				    $options = $field["acf_bs_breakpoints_choices"];
				    if(!is_array($options) && !empty($options)){
				    	$options = explode("\n", $options);
				    }
				    $choices = array();
				    if(is_array($options)){
				        foreach ($options as $key => $line) {
				        	if(strpos($line, ":")){
					            $line_parts = explode(":", $line);
					            $value = trim($line_parts[0]);
					            $label = trim($line_parts[1]);
					            $choices[$value] = $label;		        		
				        	}else{
				        		$choices[$key] = $line;	
				        	}
				        }            
				    } 
		    	}
		    }
		    $name_root = $field['name'];
		    $value = $field['value'];
		    foreach($this->breakpoints as $key => $breakpoint){
	            $name_root = str_replace("[".$key."]", "", $name_root);
		    }
		    $description = false;
		    if ( isset($field['show_description']) && $field['show_description'] ) {
		    	$description = true;
		    }
		    ?>
		    <div class="acf-fields acf-bs-breakpoints-fields d-flex">
		        <?php foreach($this->breakpoints as $key => $breakpoint): ?>
		            <?php
		            $name = $name_root.'['.$key.']';//"acf[{$field['key']}][{$breakpoint}]"; // Define the correct name for the field
		            $val = isset($value[$key]) ? $value[$key] : ''; // Get the value if it exists
		            $val = empty($val)?(isset($field[$key])?$field[$key]:""):$val;

		            if(empty($val) && isset($field["default_value"]) && !empty($field["default_value"])){
                       $val = $field["default_value"];
		            }
		            //print_r($value);
		            ?>
		            <div class="acf-field acf-field-<?php echo esc_attr($type); ?>" data-type="<?php echo esc_attr($type); ?>" style="width: 14.2%;">
		                <div class="acf-label">
		                    <label for="<?php echo esc_attr($name); ?>"><?php echo esc_html($key); ?></label>
		                    <?php
		                    if ( $description ) {
							    echo '<p class="description">' . ($breakpoint) . '</p>';
							}?>
		                </div>
		                <div class="acf-input">

		                	<?php if ($type === "text"): ?>

		                        <input type="text" id="<?php echo esc_attr($name); ?>" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($val); ?>" />

		                    <?php elseif ($type === "number"): ?>

		                        <input type="number" id="<?php echo esc_attr($name); ?>" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($val); ?>" />

		                    <?php elseif ($type === "true_false"): ?>

		                        <div class="acf-true-false">
		                            <input type="hidden" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($val); ?>">
		                            <label>
		                            	<input type="checkbox" id="<?php echo esc_attr($name); ?>" name="<?php echo esc_attr($name); ?>" value="1" class="acf-switch-input" autocomplete="off" <?php checked($value, '1'); ?>>
		                                <div class="acf-switch <?php echo esc_attr($val?'-on':''); ?>">
		                                	<span class="acf-switch-on">Evet</span>
		                                	<span class="acf-switch-off">Hayır</span>
		                                	<div class="acf-switch-slider"></div>
		                                </div>
		                            </label>
		                        </div>

		                    <?php elseif ($type === "select"): ?>

		                        <select id="<?php echo esc_attr($name); ?>" name="<?php echo esc_attr($name); ?>">
		                            <?php foreach ($choices as $option_value => $option_label): ?>
		                                <option value="<?php echo esc_attr($option_value); ?>" <?php selected($val, $option_value); ?>><?php echo esc_html($option_label); ?></option>
		                            <?php endforeach; ?>
		                        </select>

		                    <?php elseif ($type === "color_picker"): ?>

		                        <div class="acf-color-picker">
		                        	<input type="hidden" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($val); ?>"/>
		                            <input type="text" class="" id="<?php echo esc_attr($name); ?>" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($val); ?>"  data-alpha-skip-debounce="1"/>
		                        </div>

		                    <?php elseif ($type === "image"): ?>

		                        <?php include "fields/image.php"; ?>

		                    <?php elseif ($type === "units"): ?>
	                            
	                            <?php

			                    	$field = array(
								        'key' => $name,//'field_' . uniqid(),
								        'label' => '',
								        'name' => $name, // Alanın adı
								        'value' => $val,
								        'type' => 'units', // Yeni oluşturduğunuz alan tipinin adı
								        'instructions' => 'Select units', // Talimatlar
								        'required' => 0, // Zorunlu değil
								        'conditional_logic' => 0, // Koşullu mantık
								        'wrapper' => array(
								            'width' => '100%', // Alanın genişliği
								        ),
								        //'units' => $choices,
								    );
								    acf_render_field($field);
							    ?>

		                    <?php endif; ?>
		                </div>
		            </div>
		        <?php endforeach; ?>
		    </div>
		    <?php
		}

		/*function update_value( $value, $post_id, $field ) {
	        return $value;
	    }*/

	    
		/*function acf_bs_breakpoints_update_value($value, $post_id, $field) {
		    if($field["acf_bs_breakpoints_type"] == "image" && !empty($value)){
		    	$images = $value;
		    	$ids = array_values($images);
		    	$ids = array_filter($ids, function($value) {
			        return $value !== null && $value !== '' && (!is_array($value) || !empty($value));
			    });
			    if($ids){
			    	$ids = array_values($ids);
			    	if(count($ids) == 1){
			    		$this->create_image_sizes($ids[0]);
			    	}else{
			    		foreach($ids as $id){
			    			$this->remove_image_sizes($id);
			    		}
			    	}
			    }
		    }
		    return $value;
		}*/

		public function acf_bs_breakpoints_update_value($value, $post_id, $field) {
		    if($field["acf_bs_breakpoints_type"] == "image" && !empty($value)){
		        $images = $value;
		        $ids = array_values($images);
		        $ids = array_filter($ids, function($value) {
		            return $value !== null && $value !== '' && (!is_array($value) || !empty($value));
		        });
		        if($ids){
		            $ids = array_values($ids);
		            if(count($ids) == 1){
		                $attachment_id = $ids[0];
		                
		                // Eğer görsel zaten yüklenmişse image size oluşturma
		                if (!metadata_exists('post', $attachment_id, '_wp_attachment_metadata')) {
		                    $this->create_image_sizes($attachment_id);
		                }
		            }else{
		                foreach($ids as $id){
		                    $this->remove_image_sizes($id);
		                }
		            }
		        }
		    }
		    return $value;
		}

	    public function acf_bs_breakpoints_format_value( $value, $post_id, $field ) {
	     	if($field["acf_bs_breakpoints_type"] == "image" && !empty($value)){
	     		$value = $this->get_base_data($value);
	     	}
	     	return $value;
	    }

	    public function get_base_data($value=0){
	    	if($value && is_array($value)){
	    		$ids = array_values($value);
		    	$ids = array_filter($ids, function($value) {
			        return $value !== null && $value !== '' && (!is_array($value) || !empty($value));
			    });
			    if($ids){
			    	$ids = array_values($ids);
			    	$value["id"] = $ids[0];
			    	$value["url"] =  wp_get_attachment_url($ids[0]);
			    }
	    	}
	    	return $value;
	    }


		/**
		 * Enqueues CSS and JavaScript needed by HTML in the render_field() method.
		 *
		 * Callback for admin_enqueue_script.
		 *
		 * @return void
		 */
		public function input_admin_enqueue_scripts() {
			$url     = trailingslashit( $this->env['url'] );
			$version = $this->env['version'];

			wp_register_script(
				'acf_bs_breakpoints',
				"{$url}assets/js/field.js",
				array( 'acf-input' ),
				$version
			);

			wp_register_style(
				'acf_bs_breakpoints',
				"{$url}assets/css/field.css",
				array( 'acf-input' ),
				$version
			);

			wp_enqueue_script( 'acf_bs_breakpoints' );
			wp_enqueue_style( 'acf_bs_breakpoints' );

			// Enqueue custom script for showing/hiding choices textarea based on selected type
		    wp_enqueue_script(
		        'bs_breakpoints_admin',
		        "{$url}assets/js/admin.js",
		        array( 'jquery' ),
		        $version,
		        true
		    );

		    // Pass PHP variables to JavaScript
		    wp_localize_script(
		        'bs_breakpoints_admin',
		        'bs_breakpoints_vars',
		        array(
		            'type_selector' => '.bs-breakpoints-type-setting select',
		            'choices_wrapper' => '.bs-breakpoints-choices-setting'
		        )
	    	);

	    	// Enqueue ACF color picker script
		    wp_enqueue_script( 'wp-color-picker' );

		    // Enqueue ACF color picker styles
		    wp_enqueue_style( 'wp-color-picker' );
		}

		public function disable_breakpoint_image_sizes($sizes, $metadata) {
		    if (isset($_POST['acf'])) {
		        $acf_field_name = 'acf_bs_breakpoints';
		        foreach (array_keys($this->breakpoints) as $key => $value) {
		            if (isset($sizes[$key])) {
		                unset($sizes[$key]); // Bu image size oluşturulmasın
		            }
		        }
		    }
		    return $sizes;
		}

		public function disable_all_image_sizes($sizes, $metadata) {
		    if (isset($this->name) && $this->name == "acf_bs_breakpoints") {
		        return array_intersect_key($sizes, array_flip(['thumbnail']));
		    }
		    return $sizes;
		}

		public function create_image_sizes($attachment_id) {
		    add_filter('intermediate_image_sizes_advanced', [$this, 'disable_all_image_sizes'], 10, 2);
		    $image_editor = wp_get_image_editor(get_attached_file($attachment_id));
		    if (is_wp_error($image_editor)) {
		        return;
		    }
		    $sizes = get_intermediate_image_sizes();
		    $excluded_sizes = array_merge(['thumbnail'], array_keys($this->breakpoints));
		    foreach ($sizes as $size) {
		        if (!in_array($size, $excluded_sizes)) {
		            $image_editor->resize($image_editor->get_size()['width'], $image_editor->get_size()['height']);
		            $output_file = get_attached_file($attachment_id, $size);
		            $image_editor->save($output_file);
		        }
		    }
		    remove_filter('intermediate_image_sizes_advanced', [$this, 'disable_all_image_sizes'], 10, 2);
		}

		public function remove_image_sizes($attachment_id) {
		    $sizes = get_intermediate_image_sizes();
		    $excluded_sizes = ['thumbnail'];
		    foreach ($sizes as $size) {
		        if (!in_array($size, $excluded_sizes)) {
		            $this->delete_image_size($attachment_id, $size);
		        }
		    }
		}

		private function delete_image_size($attachment_id, $size) {
		    $metadata = wp_get_attachment_metadata($attachment_id);
		    if (isset($metadata['sizes'][$size])) {
		        $file_path = $metadata['sizes'][$size]['file'];
		        $url = get_attached_file($attachment_id);
		        $url_file = basename($url);
		        $full_path = str_replace($url_file, basename($file_path), $url);
		        if (file_exists($full_path)) {
		            unlink($full_path);
		        }
		        unset($metadata['sizes'][$size]);
		        wp_update_attachment_metadata($attachment_id, $metadata);
		    }
		}

	}

	// Alan tipini kaydet
	new acf_bs_breakpoints();

endif;