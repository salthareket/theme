<?php
/*
Plugin Name: ACF Bootstrap Breakpoints
Description: Bootstrap breakpoint için değer eklememie olanak sağlar.
Version: 1.0.1
Author: Tolga Koçak
*/

if( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

    add_action('acf/include_field_types', 'include_acf_bs_breakpoint_field_types');
    function include_acf_bs_breakpoint_field_types( $version ) {
        include_once('acf-bs-breakpoints.php');
    }

?>