/*! Wordpress Shotcode Insert
 * Copyright Salt hareket
 * Licensed GPLv2
 */

function wpsscGetFieldValue(field) {
    if (!field) {
        return null;
    }

    if (field.type === 'checkbox') {
        // Checkbox'lar için, seçilenlerin değerlerini bir dizi olarak döndürelim
        const checkboxes = document.querySelectorAll('[name="' + field.name + '"]:checked');
        return Array.from(checkboxes).map(checkbox => checkbox.value);
    } else if (field.type === 'radio') {
        // Radio butonları için, seçilen değeri döndürelim
        const selectedRadio = document.querySelector('[name="' + field.name + '"]:checked');
        return selectedRadio ? selectedRadio.value : null;
    } else if (field.tagName.toLowerCase() === 'select') {
        // Select menüsü için, seçilen değeri döndürelim
        return field.options[field.selectedIndex].value;
    } else if (field.type != 'note' || field.type != 'seperator') {
        // Diğer tüm input türleri (text, textarea, vb.) için
        return field.value;
    }
}


function wpsscDataToForm(data) {
    // 1. Shortcode'u seçili yap
    const shortcodeSelect = document.querySelector('#shortcodes');
    if (shortcodeSelect) {
    	shortcodeSelect.disabled = false;
        const options = shortcodeSelect.options;
        for (let i = 0; i < options.length; i++) {
            if (options[i].value === data.name) {
                options[i].selected = true;
            } else {
                options[i].selected = false;
            }
        }
        shortcodeSelect.disabled = true;
    }

    // 2. Attrs verileriyle form elemanlarını güncelle
    const attrsContainer = document.getElementById(`${data.name}-atts`);
    if (attrsContainer) {
        for (const key in data.attrs) {
            const value = data.attrs[key];
            const input = attrsContainer.querySelector(`[name="${key}"]`);

            if (input) {
                if (input.type === 'checkbox') {
                    // Checkbox için
                    input.checked = (input.value === value);
                } else if (input.type === 'radio') {
                    // Radio için
                    const radios = attrsContainer.querySelectorAll(`[name="${key}"]`);
                    radios.forEach(radio => {
                        radio.checked = (radio.value === value);
                    });
                } else if (input.tagName.toLowerCase() === 'select') {
                    // Select için
                    const options = input.options;
                    for (let i = 0; i < options.length; i++) {
                        options[i].selected = (options[i].value === value);
                    }
                } else {
                    // Text, Textarea ve diğer inputlar için
                    input.value = value;
                }
            }
        }
    }
}

function wpscc_implode_code(selectedText){
	var shortcodeContent = "";
	var shortcodeRegex = /\[([a-zA-Z0-9_-]+)(.*?)\](.*?)\[\/\1\]/g;
	var shortcodeName = "";
	var shortcodeAttributes = "";
	var shortcodeContent = "";
	if (shortcodeRegex.test(selectedText)) {
	    var shortcodes = selectedText.match(shortcodeRegex);
	    if (shortcodes.length > 1) {
	        selectedText = shortcodes[0];
	    }
	    var firstShortcodeMatch = shortcodeRegex.exec(selectedText);
	    if (firstShortcodeMatch) {
	        shortcodeName = firstShortcodeMatch[1];
	        shortcodeAttributes = firstShortcodeMatch[2];
	        shortcodeContent = firstShortcodeMatch[3];
	    }
	}
	return {
		shortcode: shortcodeName,
		text: selectedText,
		content: shortcodeContent
	}
}

function wpsscInsertShortcode() {
	var form = document.getElementById('wpSaltShortCodes');
    var config = form.querySelector('input[name="shortcode_config"]');

	if (config) {
	   var value = config.value;
	   if (value) {
	   	  var shortcode_config = JSON.parse(config.value);
	   	  console.log(shortcode_config);
	   } else {
	   	  tinyMCEPopup.close();
	   	  return;
	   }
	} else {
	   tinyMCEPopup.close();
	   return;
	}

	var shortcode = form.querySelector('select[name="shortcodes"]').value;
	var atts = shortcode_config[shortcode];
	var shortcode_tag = "[" +shortcode+" /]";
	var declined_atts = ["note", "seperator", "_support_content"]; // these fields are not attributes
	var atts_values = "";
	var support_content = atts.indexOf("_support_content")>-1?true:false;

	if (atts) {
		atts = atts.filter(function(ele) {
	       return declined_atts.indexOf(ele) < 0;
	    });
		var atts_block = document.getElementById(shortcode + "-atts");
		var atts_values = "";
		for (var i = 0; i < atts.length; i++) {
			var atts_field = atts_block.querySelector('[name="'+atts[i]+'"]');
			var atts_value = wpsscGetFieldValue(atts_field);
			atts_values += " " + atts[i] + "='" + atts_value + "' ";
		}
	    shortcode_tag = "<p>[" + shortcode + " " + atts_values + " /]</p>";
	}

	var contentText = "";
    var selectedText = tinyMCEPopup.editor.selection.getContent();
    if (selectedText) {
    	var contents = wpscc_implode_code(selectedText);
    	var isShortcode = contents.shortcode!=""?true:false;
    	var selectedText = contents.text;
    	var contentText = contents.content;
    	if(support_content){
    		var shortcode_text = selectedText
    		if(isShortcode){
    			shortcode_text = contentText;
    		}
    		shortcode_tag = "<p>[" + shortcode + " " + atts_values + "]" + shortcode_text + "[/" + shortcode + "]</p>";
    	}
    }

	var render_shortcode = form.querySelector('input[name="render_shortcode"]').checked;
	if (render_shortcode) {

		    jQuery.ajax({
		        url: ajaxurl,
		        type: 'POST',
		        data: {
		            action: 'render_shortcode',
		            shortcode: shortcode_tag
		        },
		        success: function(response) {
		        	console.log(response)
		            var tmce_ver = window.tinyMCE.majorVersion;
				    if (selectedText != "") {
				    	var editorContent = tinyMCEPopup.editor.getContent();
				    	tinyMCEPopup.editor.setContent(''); 
				        var updatedText = editorContent.replace(selectedText, response);
				        if (tmce_ver >= "4") {
				            window.tinyMCE.execCommand('mceInsertContent', false, updatedText); // Yeni metinle replace ediyoruz
				        } else {
				            window.tinyMCE.execInstanceCommand(window.tinyMCE.activeEditor.id, 'mceInsertContent', false, updatedText);
				        }
				    } else {
				        if (tmce_ver >= "4") {
				            window.tinyMCE.execCommand('mceInsertContent', false, response);
				        } else {
				            window.tinyMCE.execInstanceCommand(window.tinyMCE.activeEditor.id, 'mceInsertContent', false, response);
				        }
				    }
				    tinyMCEPopup.editor.execCommand('mceRepaint');
		            tinyMCEPopup.close();
		        },
		        error: function(xhr, status, error) {
		            console.log('Hata: ' + error); // Hata olursa konsola yazdır
		        }
		    });

	}else {

		var tmce_ver = window.tinyMCE.majorVersion;
	    if (selectedText != "") {
	    	var editorContent = tinyMCEPopup.editor.getContent();
	    	tinyMCEPopup.editor.setContent('');
	        var updatedText = editorContent.replace(selectedText, shortcode_tag);
	        if (tmce_ver >= "4") {
	            window.tinyMCE.execCommand('mceInsertContent', false, updatedText);
	        } else {
	            window.tinyMCE.execInstanceCommand(window.tinyMCE.activeEditor.id, 'mceInsertContent', false, updatedText);
	        }
	    } else {
	        if (tmce_ver >= "4") {
	            window.tinyMCE.execCommand('mceInsertContent', false, shortcode_tag);
	        } else {
	            window.tinyMCE.execInstanceCommand(window.tinyMCE.activeEditor.id, 'mceInsertContent', false, shortcode_tag);
	        }
	    }

	    tinyMCEPopup.editor.execCommand('mceRepaint');
	    tinyMCEPopup.close();

	}
	return;
}

jQuery(function($) {
	$("#shortcodes").on("change", function() {
		var value = $(this).val();
		console.log(value)
		$(".shortcode-atts").addClass("d-none");
		$('#'+value+"-atts").removeClass("d-none");
	}).trigger("change");
});
