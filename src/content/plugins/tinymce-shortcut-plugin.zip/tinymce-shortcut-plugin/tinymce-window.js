/*! WordPress Shortcode Insert
 * Copyright Salt Hareket
 * Licensed GPLv2
 */

function wpsscGetFieldValue(field) {
    if (!field) return null;

    if (field.type === 'checkbox') {
        var checkboxes = document.querySelectorAll('[name="' + field.name + '"]:checked');
        return Array.from(checkboxes).map(function(cb) { return cb.value; });
    } else if (field.type === 'radio') {
        var selectedRadio = document.querySelector('[name="' + field.name + '"]:checked');
        return selectedRadio ? selectedRadio.value : null;
    } else if (field.tagName.toLowerCase() === 'select') {
        return field.options[field.selectedIndex].value;
    } else if (field.type !== 'note' && field.type !== 'seperator') {
        return field.value;
    }
    return null;
}

function wpsscDataToForm(data) {
    var shortcodeSelect = document.querySelector('#shortcodes');
    if (shortcodeSelect) {
        shortcodeSelect.disabled = false;
        var options = shortcodeSelect.options;
        for (var i = 0; i < options.length; i++) {
            options[i].selected = (options[i].value === data.name);
        }
        // Trigger change to show the right attrs panel
        shortcodeSelect.dispatchEvent(new Event('change'));
        shortcodeSelect.disabled = true;
    }

    var attrsContainer = document.getElementById(data.name + '-atts');
    if (!attrsContainer) return;

    for (var key in data.attrs) {
        if (!data.attrs.hasOwnProperty(key)) continue;
        var value = data.attrs[key];
        var input = attrsContainer.querySelector('[name="' + key + '"]');
        if (!input) continue;

        if (input.type === 'checkbox') {
            input.checked = (input.value === value);
        } else if (input.type === 'radio') {
            var radios = attrsContainer.querySelectorAll('[name="' + key + '"]');
            radios.forEach(function(radio) { radio.checked = (radio.value === value); });
        } else if (input.tagName.toLowerCase() === 'select') {
            var opts = input.options;
            for (var j = 0; j < opts.length; j++) {
                opts[j].selected = (opts[j].value === value);
            }
        } else {
            input.value = value;
        }
    }
}


function wpscc_implode_code(selectedText) {
    var shortcodeRegex = /\[([a-zA-Z0-9_-]+)(.*?)\](.*?)\[\/\1\]/g;
    var shortcodeName = "";
    var shortcodeContent = "";

    if (shortcodeRegex.test(selectedText)) {
        shortcodeRegex.lastIndex = 0; // reset after test()
        var firstMatch = shortcodeRegex.exec(selectedText);
        if (firstMatch) {
            shortcodeName = firstMatch[1];
            shortcodeContent = firstMatch[3];
        }
    }
    return {
        shortcode: shortcodeName,
        text: selectedText,
        content: shortcodeContent
    };
}

function wpsscInsertContent(content, selectedText) {
    var tmce_ver = window.tinyMCE.majorVersion;
    if (selectedText && selectedText !== "") {
        var editorContent = tinyMCEPopup.editor.getContent();
        tinyMCEPopup.editor.setContent('');
        var updatedText = editorContent.replace(selectedText, content);
        if (tmce_ver >= "4") {
            window.tinyMCE.execCommand('mceInsertContent', false, updatedText);
        } else {
            window.tinyMCE.execInstanceCommand(window.tinyMCE.activeEditor.id, 'mceInsertContent', false, updatedText);
        }
    } else {
        if (tmce_ver >= "4") {
            window.tinyMCE.execCommand('mceInsertContent', false, content);
        } else {
            window.tinyMCE.execInstanceCommand(window.tinyMCE.activeEditor.id, 'mceInsertContent', false, content);
        }
    }
    tinyMCEPopup.editor.execCommand('mceRepaint');
    tinyMCEPopup.close();
}

function wpsscInsertShortcode() {
    var form = document.getElementById('wpSaltShortCodes');
    var config = form.querySelector('input[name="shortcode_config"]');

    if (!config || !config.value) {
        tinyMCEPopup.close();
        return;
    }

    var shortcode_config = JSON.parse(config.value);
    var shortcode = form.querySelector('select[name="shortcodes"]').value;
    var atts = shortcode_config[shortcode];
    var shortcode_tag = "[" + shortcode + " /]";
    var declined_atts = ["note", "seperator", "_support_content"];
    var atts_values = "";
    var support_content = atts && atts.indexOf("_support_content") > -1;

    if (atts) {
        var filtered = atts.filter(function(ele) {
            return declined_atts.indexOf(ele) < 0;
        });
        var atts_block = document.getElementById(shortcode + "-atts");
        if (atts_block) {
            for (var i = 0; i < filtered.length; i++) {
                var atts_field = atts_block.querySelector('[name="' + filtered[i] + '"]');
                var atts_value = wpsscGetFieldValue(atts_field);
                if (atts_value !== null && atts_value !== '') {
                    atts_values += " " + filtered[i] + "='" + atts_value + "'";
                }
            }
        }
        shortcode_tag = "<p>[" + shortcode + atts_values + " /]</p>";
    }

    var contentText = "";
    var selectedText = tinyMCEPopup.editor.selection.getContent();
    if (selectedText) {
        var contents = wpscc_implode_code(selectedText);
        var isShortcode = contents.shortcode !== "";
        contentText = contents.content;
        if (support_content) {
            var shortcode_text = isShortcode ? contentText : selectedText;
            shortcode_tag = "<p>[" + shortcode + atts_values + "]" + shortcode_text + "[/" + shortcode + "]</p>";
        }
    }

    var render_checkbox = form.querySelector('input[name="render_shortcode"]');
    var render_shortcode = render_checkbox && render_checkbox.checked;

    if (render_shortcode) {
        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'render_shortcode',
                shortcode: shortcode_tag
            },
            success: function(response) {
                wpsscInsertContent(response, selectedText);
            },
            error: function(xhr, status, error) {
                tinyMCEPopup.close();
            }
        });
    } else {
        wpsscInsertContent(shortcode_tag, selectedText);
    }
}

jQuery(function($) {
    $("#shortcodes").on("change", function() {
        var value = $(this).val();
        $(".shortcode-atts").addClass("d-none");
        $('#' + value + "-atts").removeClass("d-none");
    }).trigger("change");
});
