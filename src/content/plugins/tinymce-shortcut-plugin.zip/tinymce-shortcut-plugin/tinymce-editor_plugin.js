function parseShortcode(shortcodeString) {
    const shortcodeRegex = /\[([a-zA-Z0-9_-]+)(.*?)\]/;
    if (!shortcodeRegex.test(shortcodeString)) {
        return [];
    }
    const matches = shortcodeString.match(shortcodeRegex);
    const shortcodeName = matches ? matches[1] : null;
    const attrs = {};
    if (matches && matches[2]) {
        const attrsRegex = /(\w+)\s*=\s*['"]([^'"]+)['"]/g;
        let attrMatch;
        while ((attrMatch = attrsRegex.exec(matches[2])) !== null) {
            attrs[attrMatch[1]] = attrMatch[2];
        }
    }
    return {
        name: shortcodeName,
        attrs: attrs
    };
}

String.prototype.replaceAll = function(target, replacement) {
  return this.split(target).join(replacement);
};

function wrapShortcodes(editorContent) {
    /*var shortcodeRegex = /\[([a-zA-Z0-9_-]+)(.*?)\](.*?)\[\/\1\]/g;
    var added = [];

    // İçerikte zaten shortcode-wrapper var mı kontrol edelim
    var tempDiv = $('<div>' + editorContent + '</div>'); // İçeriği geçici bir div içine alıyoruz
    if (tempDiv.find('.shortcode-wrapper').length > 0) {
        // Zaten wraplenmiş içerik varsa, bunu direkt döndürüyoruz
        console.log('İçerik zaten wraplenmiş.');
        return editorContent; 
    }

    // Eğer wraplenmemişse, wrap işlemi gerçekleştiriyoruz
    editorContent = editorContent.replace(shortcodeRegex, function(match, shortcodeName, attrs, content) {
        var displayContent = content.trim() ? content : '';
        
        // Eğer shortcode zaten eklenmişse bir daha eklememek için kontrol ediyoruz
        if (added.indexOf(match) < 0) {
            added.push(match);
            console.log("now added!...");
            
            return '<div class="shortcode-wrapper">' +
                   '<span style="display:block;" class="original-shortcode">' + match + '</span>' + // Orijinal shortcode'u saklıyoruz
                   '<span class="shortcode-name">' + shortcodeName + '<span class="edit">EDIT</span>  <span class="remove">REMOVE</span></span>' +
                   '<span class="shortcode-content">' + displayContent + '</span>' +
                   '</div>';
        } else {
            return match; // Eğer daha önce eklenmişse, aynı wrap işlemini yapmadan geri döndürüyoruz
        }
    });*/

    return editorContent;
}



(function () {
    var args = {};
    if (typeof wpssc_tinymce_editor_args !== "undefined") {
        args = wpssc_tinymce_editor_args;
    }
    tinymce.create('tinymce.plugins.wpSaltShortCodes', {
        init: function (ed, url) {

            /*ed.on('BeforeSetContent', function(e) {
                console.log("BeforeSetContent");
                e.content = wrapShortcodes(e.content);
            });

            ed.on('GetContent', function(e) {
                console.log("GetContent");
			    var content = $('<div>' + e.content + '</div>');  
			    if (content.find(".shortcode-wrapper").length === 0) {
			        return;
			    }
			    content.find(".shortcode-wrapper").each(function() {
			        var shortcode = $(this).find('.original-shortcode').text()
			            //.replaceAll(/&quot;/g, '"')
			        $(this).replaceWith(shortcode);
			    });
			    e.content = content.html();
			});

            // Sayfa yüklendiğinde mevcut içeriği sarmak için
            ed.on('init', function() {
                console.log("init");
                setTimeout(function() {
                    var currentContent = ed.getContent();
                    ed.setContent(wrapShortcodes(currentContent));
                }, 500);
            });*/

            ed.addCommand('mcewpSaltShortCodes', function() {
                console.log("mcewpSaltShortCodes");
                var data = [];
                var selectedText = ed.selection.getContent();
                console.log(selectedText);
                if (selectedText != "") {
                    data = parseShortcode(selectedText);
                }
                console.log(data)
                ed.windowManager.open({
                    file:   ajaxurl + '?action=wp_salt_shortcodes_tinymce',
                    width:  500,
                    height: 500,
                    inline: 1
                }, {
                    plugin_url: url,
                    data: data
                });
            });

            ed.addButton('wpSaltShortCodes', {
                title: (typeof args.insert_shortcode != 'undefined' ? args.insert_shortcode : 'Insert Shortcode'),
                cmd: 'mcewpSaltShortCodes',
                text: 'Insert Shortcode',  // Button text
                onPostRender: function() {
                    var ctrl = this;
                    ed.on('NodeChange', function(e) {
                        ctrl.active(e.element.nodeName == 'IMG');
                    });
                    var button = ctrl.getEl();
                    button.style.margin = '0 10px';
                    button.style.padding = '3px 10px';
                    button.style.backgroundColor = '#94eeb3';
                    button.style.border = '1px solid #45bd6f';
                    button.style.borderRadius = '4px';
                    button.style.cursor = 'pointer';
                }
            });
        },

        createControl: function(n, cm) {
            return null;
        },
        getInfo: function () {
            return {
                longname:  'Salt Shortcodes',
                author:    'Salt Hareket',
                authorurl: 'https://salthareket.com/',
                infourl:   'https://salthareket.com/plugins/salt-shortcodes/',
                version:   '1.0.0',
            };
        },
    });

    tinymce.PluginManager.add('wpSaltShortCodes', tinymce.plugins.wpSaltShortCodes);

    /*tinymce.on('AddEditor', function(e) {
        var editor = e.editor;

        // EDIT butonuna tıklama olayı
        editor.on('click', function(e) {
            // Eğer tıklanan eleman bir edit butonuysa
            if ($(e.target).hasClass('edit')) {
                var shortcodeWrapper = $(e.target).closest('.shortcode-wrapper');
                var originalShortcode = shortcodeWrapper.find('.original-shortcode');

                // Eğer orijinal shortcode varsa
                if (originalShortcode.length) {
                    var shortcodeText = originalShortcode.text(); // Orijinal shortcode metnini al
                    
                    // Mevcut içerikte orijinal shortcode'u seç
                    editor.setContent(editor.getContent()); // Mevcut içeriği geri yükle

                    // Seçim aralığını ayarlama
                    var range = editor.selection.getRng(); // Seçim aralığını al

                    // Orijinal shortcode metninin başlangıç ve bitiş pozisyonlarını bul
                    var startContainer = originalShortcode[0].firstChild; // İlk çocuk düğüm
                    var endContainer = originalShortcode[0].firstChild;
                    var startOffset = 0; // Başlangıç ofseti
                    var endOffset = shortcodeText.length; // Bitiş ofseti

                    range.setStart(startContainer, startOffset); // Seçimi başlat
                    range.setEnd(endContainer, endOffset); // Seçimi bitir

                    editor.selection.setRng(range); // Seçimi ayarla

                    // Seçimin yapılmasının ardından, edit komutunu tetikle
                    editor.execCommand('mcewpSaltShortCodes'); 
                }
            }
        });

        // ... Diğer kodlar ...
    });*/

        
})();
