function parseShortcode(shortcodeString) {
    var shortcodeRegex = /\[([a-zA-Z0-9_-]+)(.*?)\]/;
    if (!shortcodeRegex.test(shortcodeString)) {
        return [];
    }
    var matches = shortcodeString.match(shortcodeRegex);
    var shortcodeName = matches ? matches[1] : null;
    var attrs = {};
    if (matches && matches[2]) {
        var attrsRegex = /(\w+)\s*=\s*['"]([^'"]+)['"]/g;
        var attrMatch;
        while ((attrMatch = attrsRegex.exec(matches[2])) !== null) {
            attrs[attrMatch[1]] = attrMatch[2];
        }
    }
    return {
        name: shortcodeName,
        attrs: attrs
    };
}

(function () {
    var args = {};
    if (typeof wpssc_tinymce_editor_args !== "undefined") {
        args = wpssc_tinymce_editor_args;
    }
    tinymce.create('tinymce.plugins.wpSaltShortCodes', {
        init: function (ed, url) {
            ed.addCommand('mcewpSaltShortCodes', function() {
                var data = [];
                var selectedText = ed.selection.getContent();
                if (selectedText !== "") {
                    data = parseShortcode(selectedText);
                }
                ed.windowManager.open({
                    file:   ajaxurl + '?action=wp_salt_shortcodes_tinymce',
                    width:  560,
                    height: 520,
                    inline: 1
                }, {
                    plugin_url: url,
                    data: data
                });
            });

            ed.addButton('wpSaltShortCodes', {
                title: (typeof args.insert_shortcode !== 'undefined' ? args.insert_shortcode : 'Insert Shortcode'),
                cmd: 'mcewpSaltShortCodes',
                text: 'Shortcodes',
                onPostRender: function() {
                    var ctrl = this;
                    var button = ctrl.getEl();
                    button.style.margin = '0 6px';
                    button.style.padding = '3px 12px';
                    button.style.backgroundColor = '#e8f5e9';
                    button.style.border = '1px solid #66bb6a';
                    button.style.borderRadius = '4px';
                    button.style.cursor = 'pointer';
                    button.style.fontWeight = '600';
                    button.style.fontSize = '12px';
                }
            });
        },

        createControl: function(n, cm) {
            return null;
        },
        getInfo: function () {
            return {
                longname:  'Salt Shortcodes',
                author:    'Salt Hareket',
                authorurl: 'https://salthareket.com/',
                infourl:   'https://salthareket.com/',
                version:   '1.0.2',
            };
        },
    });

    tinymce.PluginManager.add('wpSaltShortCodes', tinymce.plugins.wpSaltShortCodes);
})();
