<?php

/*
Plugin Name: TinyMCE Shorcode Creator for Visual Editor
Description: shortcode, tinymce
Version: 1.0
Author: Tolga Koçak
*/

if( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * TinyMCE Shorcode Creator for Visual Editor.
 *
 * @package    Wordpress TinyMCE shortcode Insert
 * @author     Tolga Koçak
 * @copyright  2024 Salt Hareket
 * @version    1.0.0
 */

// Eklentinin URL'sini tanımla
define( 'WPSSC_URL',    plugin_dir_url( __FILE__ ) );

// Eklentinin dizinini tanımla
define( 'WPSSC_DIR',    plugin_dir_path( __FILE__ ) );


function wpssc_add_buttons() {
	// Add only in Rich Editor mode
	if ( 'true' == get_user_option( 'rich_editing' ) ) {
		add_filter( 'mce_external_plugins', 'wpssc_add_tinymce_plugin' );
		add_filter( 'mce_buttons', 'wpssc_register_button' );
	}
}
add_action( 'init', 'wpssc_add_buttons' );

/**
 * Register TinyMCE button
 * @since 1.9.5
 * @param array $buttons
 * @return array
 */
function wpssc_register_button( $buttons ) {
	array_push( $buttons, 'separator', 'wpSaltShortCodes' );

	return $buttons;
}

/**
 * Load TinyMCE plugin
 * @since 1.9.5
 * @param array $plugin_array
 * @return array
 */
function wpssc_add_tinymce_plugin( $plugins ) {
	$plugins['wpSaltShortCodes'] = WPSSC_URL . 'tinymce-editor_plugin.js';

	return $plugins;
}

function wpssc_tinymce_enqueue_scripts( $hook_suffix ) {
	switch ( $hook_suffix ) {
		case 'salt-shortcodes_tinymce-window':
			wp_enqueue_style( 'salt-shortcodes-tinymce-window', WPSSC_URL . 'tinymce-window.css' );
			wp_enqueue_script( 'jquery' );
			wp_enqueue_script( 'salt-shortcodes-tinymce-popup',      includes_url( 'js/tinymce/tiny_mce_popup.js' ) );
			wp_enqueue_script( 'salt-shortcodes-tinymce-form-utils', includes_url( 'js/tinymce/utils/form_utils.js' ) );
			wp_enqueue_script( 'salt-shortcodes-tinymce-window',     WPSSC_URL . 'tinymce-window.js' );

			break;

		case 'post.php':
			wp_localize_script( 'editor', 'wpssc_tinymce_editor_args', array(
				'insert_shortcode' => __( 'Insert Shortcode', 'salt-shortcodes' ),
			) );

			break;
	}
}
add_action( 'admin_enqueue_scripts', 'wpssc_tinymce_enqueue_scripts' );

/**
 * Call TinyMCE window content via admin-ajax
 * @since 1.4
 */
function wpssc_ajax_tinymce() {
	include_once( 'wpssc-tinymce-window.php' );
	die();
}
//add_action( 'wp_ajax_wp_user_avatar_tinymce', 'wpssc_ajax_tinymce' );


function wp_salt_shortcodes_tinymce_callback() {
    include_once( 'wpssc-tinymce-window.php' );
	die();
}

// AJAX işlemini tanımla
add_action('wp_ajax_wp_salt_shortcodes_tinymce', 'wp_salt_shortcodes_tinymce_callback');
add_action('wp_ajax_nopriv_wp_salt_shortcodes_tinymce', 'wp_salt_shortcodes_tinymce_callback');