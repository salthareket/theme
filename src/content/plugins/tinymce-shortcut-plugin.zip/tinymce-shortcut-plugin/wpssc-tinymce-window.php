<?php
/**
 * TinyMCE modal window.
 *
 * @package    Wordpress TinyMCE shortcode Insert
 * @author     Tolga Koçak
 * @copyright  2024 Salt Hareket
 * @version    1.0.0
 */

/**
 * @since 1.2.1
 * @uses get_users()
 */

if ( ! defined('ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

$hook_suffix = 'salt-shortcodes_tinymce-window';

?><!DOCTYPE html>
<html>
<head>
	<title><?php esc_html_e( 'Shortcodes', 'salt-shortcodes' ); ?></title>
	<meta http-equiv="Content-Type" content="<?php bloginfo( 'html_type' ); ?>; charset=<?php echo esc_attr( get_option( 'blog_charset' ) ); ?>" />
	<base target="_self" />
	<?php
	/**
	 * Enqueue scripts.
	 *
	 * @since 2.3.0
	 *
	 * @param string $hook_suffix The current admin page.
	 */
	do_action( 'admin_enqueue_scripts', $hook_suffix );

	/**
	 * Fires when styles are printed for this specific page based on $hook_suffix.
	 *
	 * @since 2.3.0
	 */
	do_action( "admin_print_styles-{$hook_suffix}" ); // phpcs:ignore WordPress.NamingConventions.ValidHookName.UseUnderscores

	/**
	 * Fires when styles are printed for all admin pages.
	 *
	 * @since 2.3.0
	 */
	do_action( 'admin_print_styles' );

	/**
	 * Fires when scripts are printed for this specific page based on $hook_suffix.
	 *
	 * @since 2.3.0
	 */
	do_action( "admin_print_scripts-{$hook_suffix}" ); // phpcs:ignore WordPress.NamingConventions.ValidHookName.UseUnderscores

	/**
	 * Fires when scripts are printed for all admin pages.
	 *
	 * @since 2.3.0
	 */
	do_action( 'admin_print_scripts' );

	/**
	 * Fires in head section for this specific admin page.
	 *
	 * The dynamic portion of the hook, `$hook_suffix`, refers to the hook suffix
	 * for the admin page.
	 *
	 * @since 2.3.0
	 */
	do_action( "admin_head-{$hook_suffix}" ); // phpcs:ignore WordPress.NamingConventions.ValidHookName.UseUnderscores

	/**
	 * Fires in head section for all admin pages.
	 *
	 * @since 2.3.0
	 */
	do_action( 'admin_head' );
	$shortcodes = customShortcodes::getInstance();
	$shortcodes_menu = $shortcodes->get_shortcodes();
	$shortcodes_list = $shortcodes->get_all();
	$shortcode_config = [];
	foreach ($shortcodes_list as $key => $shortcode) {
		$shortcode_config[$key] = array_keys($shortcode["atts"]);
		$support_content = isset($shortcode["support_content"]) && $shortcode["support_content"]?true:false;
		if($support_content){
			$shortcode_config[$key][] = "_support_content";
		}
        
	}
	$shortcode_config = json_encode($shortcode_config);
	?>
	<script type="text/javascript">
	    var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
	    document.addEventListener('DOMContentLoaded', function() {
		var params = tinymce.activeEditor.windowManager.getParams();
		var shortcode_data = [];
		if (params && params.data) {
		    var data = params.data;
		    if (Object.keys(data).length > 0) {
		        console.log('Data alındı:', data);
		        wpsscDataToForm(data);
		    }
		}
	});
	</script>
</head>

<body id="link" class="wp-core-ui" onload="document.body.style.display='';" style="display:none;">

	<form id="wpSaltShortCodes" name="wpSaltShortCodes" action="#">

		<?php echo($shortcodes_menu); ?>

		<?php
		    $counter = 0;
		    foreach ($shortcodes_list as $key => $shortcode) {
		    	$attributes = $shortcodes->get_fields($key);
		    	if(!empty($attributes)){
			    ?>
			    <div class="shortcode-atts d-none" id="<?php echo($key);?>-atts">
			    	<h4 class="shortcode-atts-header">Attributes</h4>
			    <?php
			   	   echo $attributes;
			   	?>
			    </div>
			    <?php
			    }
		    }
		?>
	
		<div class="mceActionPanel">
			<input type="hidden" name="shortcode_config" value="<?php echo esc_attr($shortcode_config);?>"/>
			<input type="button" id="insert--" class="btn btn-primary" name="insert" value="<?php esc_html_e( 'Insert into Post', 'salt-shortcodes' ); ?>" onclick="wpsscInsertShortcode();" />
		</div>

	</form>

</body>
</html>