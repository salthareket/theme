<?php
/**
 * Cloud Storage Settings View
 *
 * @package    Wt_woocommerce_invoice_addon
 * @subpackage Wt_woocommerce_invoice_addon/admin/views
 * @author     WebToffee <info@webtoffee.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>

<div class="wf-tab-content" data-id="<?php echo esc_attr( $target_id );?>">

    <form method="post" class="wf_settings_form wf_general_settings_form">
        <input type="hidden" value="main" class="wf_settings_base" />
        <input type="hidden" value="wf_save_settings" class="wf_settings_action" />
        <input type="hidden" value="wt_main_cloud_storage" name="wt_tab_name" class="wt_tab_name" />
        <?php
        if (function_exists('wp_nonce_field'))
        {
            wp_nonce_field(WF_PKLIST_PLUGIN_NAME, '_wpnonce', true, false);
        }
        ?>
        <table class="wf-form-table">
            <tbody>
            <?php 
                // Get current values from database to check if access code field should be shown
                $settings_arr['advanced_option'] = array(
                    'wt_invoice_enable_cloud_storage' => array(
                        'type' => 'wt_single_checkbox',
                        'label' => __('Enable Cloud Storage','wt-woocommerce-invoice-addon'),
                        'id' => 'wt_invoice_enable_cloud_storage',
                        'name' => 'wt_invoice_enable_cloud_storage',
                        'value' => "yes",
                        'checkbox_fields' => array('yes'=> __('Enable cloud storage integration','wt-woocommerce-invoice-addon')),
                        'class' => "wt_invoice_enable_cloud_storage",
                        'col' => 3,
                        'tooltip' => true,
                    ),
                    'wt_invoice_cloud_provider' => array(
                        'type' => 'wt_select_dropdown',
                        'label' => __('Cloud Storage Provider','wt-woocommerce-invoice-addon'),
                        'id' => "wt_invoice_cloud_provider",
                        'name' => "wt_invoice_cloud_provider",
                        'value' => "dropbox",
                        'select_dropdown_fields' => array(
                            'dropbox'=>__('Dropbox', 'wt-woocommerce-invoice-addon'),
                        ),
                        'class' => "wt_invoice_cloud_provider",
                        'col' => 3,
                        'help_text' => sprintf('%1$s <a href="https://www.dropbox.com/developers/apps" target="_blank">%2$s</a>.',
                            __("To Get App key & App secret, Please Visit","wt-woocommerce-invoice-addon"),
                            __("Dropbox API Console","wt-woocommerce-invoice-addon")), 'ref_id' => 'wt_invoice_enable_cloud_storage',
                    ),
                    'wt_invoice_dropbox_app_key' => array(
                        'type'  =>  'wt_text',
                        'label' =>  __('App key','wt-woocommerce-invoice-addon'),

                        'name'  =>    "wt_invoice_dropbox_app_key",
                        'class' => 'wt_invoice_dropbox_app_key',
                        'ref_id'=>  'wt_invoice_dropbox_app_key',
                        'help_text'=>__('Enter your Dropbox app client ID', 'wt-woocommerce-invoice-addon'),
                    ),
                    'wt_invoice_dropbox_app_secret' => array(
                        'type'  =>  'wt_decode_app_secret',
                        'label' =>  __('App secret','wt-woocommerce-invoice-addon'),
                        'id' => 'wt_invoice_dropbox_app_secret',
                        'name'  =>    "wt_invoice_dropbox_app_secret",
                        'class' => 'wt_invoice_dropbox_app_secret',
                        'ref_id'=>  'wt_invoice_dropbox_app_secret',
                        'help_text'=>__("Enter your Dropbox app client secret <br> To Get Access Code, Please Visit <a href='#' id='dropbox-access-code-link' target='_blank'>Dropbox Access Code</a>", 'wt-woocommerce-invoice-addon'),
                    ),
                    'wt_invoice_dropbox_access_code' => array(
                        'type'  =>  'wt_access_code_buttons',
                        'label' =>  __("Access code",'wt-woocommerce-invoice-addon'),
                        'id' => 'wt_invoice_dropbox_access_code',
                        'value' => '',
                        'name'  =>    "wt_invoice_dropbox_access_code",
                        'class' => 'wt_invoice_dropbox_access_code',
                        'ref_id'=>  'wt_invoice_dropbox_access_code',
                        'placeholder' => __("Enter your cloud storage access token", 'wt-woocommerce-invoice-addon'),
                    ),
                    'wt_invoice_dropbox_documents' => array(
                        'type' => 'wt_multi_checkbox',
                        'label' => __("Document types to upload","wt-woocommerce-invoice-addon"),
                        'id' => 'wt_invoice_dropbox_documents',
                        'class' => 'wt_invoice_dropbox_documents',
                        'name' => 'wt_invoice_dropbox_documents',
                        'value' => '',
                        'checkbox_fields' => array(
                            'invoice' => __('Invoice','wt-woocommerce-invoice-addon'),
                            'packinglist' => __('Packing slip', 'wt-woocommerce-invoice-addon'),
                            'creditnote' => __('Credit note','wt-woocommerce-invoice-addon'),
                        ),
                        'col' => 3,
                        'alignment' => 'vertical_with_label',
                        'tooltip' => true,
                        'help_text' => __('Select which document types you want to automatically upload to your cloud storage', 'wt-woocommerce-invoice-addon'),
                    ),
                        'wt_invoice_dropbox_folder' => array(
                        'type'  =>  'wt_text',
                        'id' => 'wt_invoice_dropbox_folder',
                        'label' =>  __('Upload Folder','wt-woocommerce-invoice-addon'),
                        'name'  =>    "wt_invoice_dropbox_folder",
                        'class' => 'wt_invoice_dropbox_folder',
                        'ref_id'=>  'wt_invoice_dropbox_folder',
                        'help_text'=>__('The folder in your Dropbox where files will be uploaded. Default: /Documents', 'wt-woocommerce-invoice-addon'),
                ),
                    );
                    
                    $settings_arr = Wf_Woocommerce_Packing_List::add_fields_to_settings($settings_arr);
                    if(class_exists('WT_Form_Field_Builder_PRO_Documents')){
                        $Form_builder = new WT_Form_Field_Builder_PRO_Documents();
                    }else{
                        $Form_builder = new WT_Form_Field_Builder();
                    } 
                    foreach($settings_arr as $settings){
                        $Form_builder->generate_form_fields($settings);
                    }
                ?>
            </tbody>
		</table>
        <?php 
            include "admin-settings-save-button.php";
        ?>
    </form>

<!-- Custom Modal for Dropbox Disconnect Confirmation -->
<div class="wt_dropbox_disconnect_confirm_popup wf_pklist_popup" style="width: 450px; display: none;">
    <div class="wf_pklist_popup_hd">
        <span class="popup_title"><?php esc_html_e('Disconnect Dropbox Connection', 'wt-woocommerce-invoice-addon'); ?></span>
        <div class="wf_pklist_popup_close">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
            <path d="M8.94004 8.00012L13.14 3.80679C13.2656 3.68125 13.3361 3.51099 13.3361 3.33346C13.3361 3.15592 13.2656 2.98566 13.14 2.86012C13.0145 2.73459 12.8442 2.66406 12.6667 2.66406C12.4892 2.66406 12.3189 2.73459 12.1934 2.86012L8.00004 7.06012L3.80671 2.86012C3.68117 2.73459 3.51091 2.66406 3.33337 2.66406C3.15584 2.66406 2.98558 2.73459 2.86004 2.86012C2.7345 2.98566 2.66398 3.15592 2.66398 3.33346C2.66398 3.51099 2.7345 3.68125 2.86004 3.80679L7.06004 8.00012L2.86004 12.1935C2.79756 12.2554 2.74796 12.3292 2.71411 12.4104C2.68027 12.4916 2.66284 12.5788 2.66284 12.6668C2.66284 12.7548 2.68027 12.8419 2.71411 12.9232C2.74796 13.0044 2.79756 13.0781 2.86004 13.1401C2.92202 13.2026 2.99575 13.2522 3.07699 13.2861C3.15823 13.3199 3.24537 13.3373 3.33337 13.3373C3.42138 13.3373 3.50852 13.3199 3.58976 13.2861C3.671 13.2522 3.74473 13.2026 3.80671 13.1401L8.00004 8.94012L12.1934 13.1401C12.2554 13.2026 12.3291 13.2522 12.4103 13.2861C12.4916 13.3199 12.5787 13.3373 12.6667 13.3373C12.7547 13.3373 12.8419 13.3199 12.9231 13.2861C13.0043 13.2522 13.0781 13.2026 13.14 13.1401C13.2025 13.0781 13.2521 13.0044 13.286 12.9232C13.3198 12.8419 13.3372 12.7548 13.3372 12.6668C13.3372 12.5788 13.3198 12.4916 13.286 12.4104C13.2521 12.3292 13.2025 12.2554 13.14 12.1935L8.94004 8.00012Z" fill="#6E7681"></path>
            </svg>
        </div>
    </div>
    <div class="wf_pklist_popup_body">
        <?php esc_html_e('If the Client ID or Secret Key is missing, your Dropbox connection will be lost. Do you want to continue?', 'wt-woocommerce-invoice-addon'); ?>
    </div>
    <div class="wf_pklist_popup_footer" style="float:left;">
        <button type="button" name="" class="button-secondary wf_pklist_popup_cancel" style="color: #3157A6;border-color: #3157A6;">
            <?php esc_html_e('Cancel','wt-woocommerce-invoice-addon'); ?>
        </button>
        <button type="button" name="" class="button-primary wt_dropbox_disconnect_confirm_popup_yes" style="background: #3157A6;">
            <?php esc_html_e('Continue','wt-woocommerce-invoice-addon'); ?>
        </button>	
    </div>
</div>


</div> 