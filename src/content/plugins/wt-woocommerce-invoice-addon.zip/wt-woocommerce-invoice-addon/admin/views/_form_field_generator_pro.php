<?php
if (!defined('ABSPATH')) {
	exit;
}

class WT_Form_Field_Builder_PRO_Documents extends WT_Form_Field_Builder{

	/**
	 * @since 1.0.0
	 * 
	 * Function to display the plain text field using form builder
	 */
	public function wt_plaintext($args,$base_id){
		extract($this->verify_the_fields($args));
		return sprintf('<tr><td>%1$s</td><td>%2$s</td><td></td></tr>',wp_kses_post($label),wp_kses_post($value));
	}

	/**
	 * @since 1.0.0
	 * 
	 * Function to display the temporary files count field using form builder
	 */
	public function wt_temp_files_field($args,$base_id){
		extract($this->verify_the_fields($args));
		$total_temp_files=Wt_woocommerce_invoice_addon_Admin::get_total_temp_files();
		$html = '<td style="width:50%;">';
		$total_temp_files = 1;
		if($total_temp_files > 0){
			$html .=sprintf('<span style="line-height:38px;" class="temp_files_count">%1$s %2$s</span>',
							wp_kses_post($total_temp_files), __('Temp file(s) found.','wt-woocommerce-invoice-addon'));
			$html .=sprintf('<button type="button" class="button button-secondary wt_pklist_temp_files_btn" data-action="delete_all_temp" style="float:right;">%1$s</button><button type="button" class="button button-secondary wt_pklist_temp_files_btn" data-action="download_all_temp" style="float:right; margin-right:10px;">%2$s</button>',
				__('Delete all','wt-woocommerce-invoice-addon'),
				__('Download all','wt-woocommerce-invoice-addon'));
		}else{
			$html .=sprintf(__('No files found','wt-woocommerce-invoice-addon'));
		}
		$html .=sprintf('</td><td></td>');
		return $html;
	}

	/**
	 * @since 1.0.0
	 * 
	 * Function to display the additional checkout field in advanced - general tab using form builder
	 */
	public function wf_invoice_additional_checkout_data_fields($args,$base_id){
		extract($this->verify_the_fields($args,$base_id));
		$custom_field_doc_url = 'https://www.webtoffee.com/how-to-add-a-custom-field-to-checkout-page/';
		$user_selected_add_fields 	= array();
		$add_checkout_data_flds 	= Wf_Woocommerce_Packing_List::$default_additional_checkout_data_fields;
        $user_created_ck_fields 	= Wf_Woocommerce_Packing_List::get_option('wf_additional_checkout_data_fields');

        /* if it is a numeric array convert it to associative.*/
        $user_created_ck_fields 	= Wf_Woocommerce_Packing_List_Pro_Common_Func::process_checkout_fields($user_created_ck_fields);
        $ck_fields = array_merge($add_checkout_data_flds,$user_created_ck_fields);
        $result = Wf_Woocommerce_Packing_List::get_option($name,$base_id);
        $user_selected_arr 	= ($result && is_array($result)) ? $result : array();
        $additional_checkout_field_options=Wf_Woocommerce_Packing_List::get_option('wt_additional_checkout_field_options');

		$html = '<td>';
		$html .= sprintf('<div class="wf_select_multi">
								<input type="hidden" name="wf_invoice_additional_checkout_data_fields_hidden" value="1" />
								<select class="wc-enhanced-select" data-placeholder="%2$s" name="%1$s[]" multiple="multiple">',
								esc_attr($name),
								esc_attr($placeholder));

		foreach($ck_fields as $ck_key => $ck_value){
			$add_data=isset($additional_checkout_field_options[$ck_key]) ? $additional_checkout_field_options[$ck_key] : array();
			$is_required=(int) (isset($add_data['is_required']) ? $add_data['is_required'] : 0);
			$is_required_label = (1 === $is_required) ? '('.__('required','wt-woocommerce-invoice-addon').')' : "";
			$selected = in_array($ck_key,$user_selected_arr) ? "selected" : "";

			/* we are giving option to edit title of builtin items */
        	$ck_value=(isset($add_data['title']) && trim($add_data['title'])!="" ? $add_data['title'] : $ck_value);

        	$html .= sprintf('<option value="%1$s" %2$s>%3$s (%1$s) %4$s</option>',
        		wp_kses_post($ck_key),
        		$selected,
        		wp_kses_post($ck_value),
        		wp_kses_post($is_required_label));
		}

		$html .= sprintf('</select><button type="button" class="button button-secondary" data-wf_popover="1" data-title="Checkout Field Inserter" data-module-base="main" data-content-container=".wt_pklist_checkout_inserter_form" data-field-type="checkout" style="margin-top:5px; margin-left:5px; float:right;">%1$s</button>',__('Add/Edit Custom Field','wt-woocommerce-invoice-addon'));
		$html .= '<div class="wt_pklist_checkout_inserter_form">';
		$html .= sprintf('<div class="wt_pklist_checkout_field_tab">
							<div class="wt_pklist_custom_field_tab_head active_tab" data-target="add_new" data-add-title="%1$s" data-edit-title="%2$s">
								<span class="wt_pklist_custom_field_tab_head_title">%1$s</span>
	                			<div class="wt_pklist_custom_field_tab_head_patch"></div>
							</div>
							<div class="wt_pklist_custom_field_tab_head" data-target="list_view">
	                			%3$s
	                			<div class="wt_pklist_custom_field_tab_head_patch"></div>		
	                		</div>
	                		<div class="wt_pklist_custom_field_tab_head_add_new" title="%1$s">
	                			<span class="dashicons dashicons-plus"></span>
	                		</div>
						</div>',
					__('Add new','wt-woocommerce-invoice-addon'),
					__('Edit', 'wt-woocommerce-invoice-addon'),
					__('Previously added','wt-woocommerce-invoice-addon'));
		$html .='<div class="wt_pklist_custom_field_tab_content active_tab" data-id="add_new">';
		$html .= sprintf('<div class="wt_pklist_custom_field_tab_form_row wt_pklist_custom_field_form_notice">
		                		%1$s
                		</div>
	                	<div class="wt_pklist_custom_field_tab_form_row">
							<div class="wt_pklist_new_custom_field_title">
								<table>
									<tr>
										<td>%2$s<i style="color:red;">*</i>:</td>
										<td><input type="text" name="wt_pklist_new_custom_field_title" data-required="1"/></td>
									<tr>
								</table> 
							</div>
						</div>
						<div class="wt_pklist_custom_field_tab_form_row">
							<div class="wt_pklist_new_custom_field_key">
								<table>
									<tr>
										<td style="vertical-align:top;">%3$s<i style="color:red;">*</i>:</td>
										<td><input type="text" name="wt_pklist_new_custom_field_key" data-required="1" />
											<br>
											<i class="meta_key_help_text"> %4$s
											<br /> %5$s : my_meta_key, meta_one 
											<br /> %6$s : #My meta Key, Meta.1 </i>
										</td>
									</tr>
								</table>
							</div>
						</div>',
						__('You can edit existing Meta items by using Meta key of the item.','wt-woocommerce-invoice-addon'),
						__('Field Name','wt-woocommerce-invoice-addon'),
						__('Meta Key','wt-woocommerce-invoice-addon'),
						__('Please use only alphabets and underscore for meta key.','wt-woocommerce-invoice-addon'),
						__('Correct','wt-woocommerce-invoice-addon'),
						__('Incorrect','wt-woocommerce-invoice-addon'));
		$html .= sprintf('<div class="wt_pklist_custom_field_tab_form_row">
								<div class="wt_pklist_new_custom_field_title_placeholder">
									<table>
										<tr>
											<td>%1$s :</td>
											<td><input type="text" name="wt_pklist_new_custom_field_title_placeholder"/></td>
										</tr>
									</table>  
								</div>
								<div class="is_mandatory_div">
									<table>
										<tr>
											<td>%2$s</td>
											<td>
												<div class="is_mandatory_inner_div">
													<span>
														<input type="radio" name="wt_pklist_cst_chkout_required" value=1> %3$s
													</span>
													<span>
														<input type="radio" name="wt_pklist_cst_chkout_required" value="0" checked="checked"> %4$s
													</span>
												</div>
											</td>
										</tr>
									</table>
								</div>
							</div>',
							__('Placeholder','wt-woocommerce-invoice-addon'),
							__('Is mandatory field?','wt-woocommerce-invoice-addon'),
							__('Yes', 'wt-woocommerce-invoice-addon'),
							__('No','wt-woocommerce-invoice-addon'));
		$html .='</div>';
		$html .='<div class="wt_pklist_custom_field_tab_content" data-id="list_view" style="height:282px; overflow:auto;"></div>';
		
		$html .= '</div>';
		$html .=sprintf('<br>
			                <span class="wf_form_help" style="display:inline;"> %1$s <br> %2$s <br> <a href="%3$s">%4$s</a>
			                </span>',
			                __('Select/add additional fields in the checkout page','wt-woocommerce-invoice-addon'),
			                __('e.g VAT, SSN etc','wt-woocommerce-invoice-addon'),
			                esc_url($custom_field_doc_url),
			                __('Learn how to add custom field at checkout','wt-woocommerce-invoice-addon'));    
		$html .='</div></td><td></td>';
		return $html;
	}


	/**
	 * @since 1.0.0
	 * 
	 * Function to display the order meta field using form builder
	 */
	public function order_meta_fields_pro($args,$base_id){
		extract($this->verify_the_fields($args,$base_id));
		$additional_fields = array();
		$default_add_fields = Wf_Woocommerce_Packing_List::$default_additional_data_fields; 
		$user_created=Wf_Woocommerce_Packing_List::get_option('wf_additional_data_fields');
		if(is_array($user_created))  //user created
        {
            $additional_fields=array_merge($default_add_fields,$user_created);
        }else
        {
            $additional_fields=$default_add_fields; //default
        }

        //additional checkout fields
        $additional_checkout=Wf_Woocommerce_Packing_List::get_option('wf_additional_checkout_data_fields');
    	$additional_checkout=Wf_Woocommerce_Packing_List_Pro_Common_Func::process_checkout_fields($additional_checkout);
    	$additional_fields=array_merge($additional_fields, $additional_checkout);
    	$result = Wf_Woocommerce_Packing_List::get_option($name,$base_id);
        $user_selected_arr 	= ($result && is_array($result)) ? $result : array(); 

    	$vat_fields = array('vat','vat_number','eu_vat_number');
    	$temp = array();
    	foreach($user_selected_arr as $u_val){
    		if(in_array($u_val,$vat_fields)){
    			if(!in_array('vat',$temp)){
    				$temp[] = 'vat';
    			}
    		}else{
    			$temp[] = $u_val;
    		}
    	}
    	$user_selected_arr = $temp;
    	$d_temp = array();
    	foreach($additional_fields as $d_key => $d_val){
    		if(in_array($d_key,$vat_fields)){
    			if(!array_key_exists('vat',$d_temp)){
    				$d_temp[$d_key] = 'VAT';
    			}
    		}else{
    			$d_temp[$d_key] = $d_val;
    		}
    	}
    	$additional_fields = $d_temp;

		/**
		 * @since 1.0.3 - [Tweak] - Remove the default order fields from the settings page and moved them to the customizer
		 */
		$unset_keys = array('contact_number','email','ssn','vat','vat_number','eu_vat_number','cus_note','aelia_vat');
		foreach($unset_keys as $unset_key){
			if(isset($additional_fields[$unset_key])){
				unset($additional_fields[$unset_key]);
			}
		}

    	$html = '<td>';

		$html .= sprintf('<div class="wf_select_multi">
							<input type="hidden" name="%1$s_hidden" value="1" />
							<select class="wc-enhanced-select" name="%1$s[]" multiple="multiple">',esc_attr($name));
    	foreach($additional_fields as $add_field_key => $add_field_value){
    		$meta_key_display=Wf_Woocommerce_Packing_List::get_display_key($add_field_key);
    		$selected = in_array($add_field_key, $user_selected_arr) ? "selected" : "";

    		$html .= sprintf('<option value="%1$s" %2$s>%3$s</option>',
    				esc_attr($add_field_key),
		    		$selected,
		    		wp_kses_post($add_field_value.$meta_key_display));
    	}
		$html .=sprintf('</select><br><button type="button" class="button button-secondary" data-wf_popover="1" data-title="%1$s" data-module-base="%2$s" data-content-container=".wt_pklist_custom_field_form" data-field-type="order_meta" style="margin-top:5px; margin-left:5px; float: right;">%3$s</button>',
			__('Order meta','wt-woocommerce-invoice-addon'),
			$module_base,
			__('Add/Edit order meta field','wt-woocommerce-invoice-addon'));
		$html .= sprintf('<span class="wf_form_help"  style="display:inline;">%1$s</span>',wp_kses_post($help_text));
			
    	$html .='</div>
    	</td><td></td>';
    	return $html;
	}

	/**
	 * @since 1.0.0
	 * 
	 * Function to display the product meta field using form builder
	 */
	public function product_meta_fields_pro($args,$base_id){
		extract($this->verify_the_fields($args,$base_id));

		$result = Wf_Woocommerce_Packing_List::get_option($name,$base_id);
        $user_selected_arr 	= ($result && is_array($result)) ? $result : array(); 
		$wt_product_spec_fields=Wf_Woocommerce_Packing_List::get_option('wf_product_meta_fields');
		
		$html ='<td>';
		$html .= sprintf('<div class="wf_select_multi">
							<input type="hidden" name="%1$s_hidden" value="1" />
							<select class="wc-enhanced-select" name="%1$s[]" multiple="multiple">',esc_attr($name));
		
		if (is_array($wt_product_spec_fields))
        {
            foreach ($wt_product_spec_fields as $prod_meta_key => $prod_meta_val)
            {
            	$meta_key_display=Wf_Woocommerce_Packing_List::get_display_key($prod_meta_key);
            	$selected = in_array($prod_meta_key, $user_selected_arr) ? "selected" : "";
                $html .=sprintf('<option value="%1$s" %2$s>%3$s</option>',
                	esc_attr($prod_meta_key),
                	$selected,
                	wp_kses_post($prod_meta_val.$meta_key_display)
            	);
            }
        }

		$html .= sprintf('</select><br><button type="button" class="button button-secondary" data-wf_popover="1" data-title="%1$s" data-module-base="%2$s" data-content-container=".wt_pklist_custom_field_form" data-field-type="product_meta" style="margin-top:5px; margin-left:5px; float: right;">%3$s</button>',
			__('Product Meta','wt-woocommerce-invoice-addon'),
			esc_attr($module_base),
			__('Add/Edit Product Meta','wt-woocommerce-invoice-addon'));
		$html .= sprintf('<span class="wf_form_help"  style="display:inline;">%1$s</span>',wp_kses_post($help_text));
		$html .='</div></td><td></td>';
		
		return $html;
	}

	/**
	 * @since 1.0.0
	 * 
	 * Function to display the product attributes field using form builder
	 */
	public function product_attribute_pro($args,$base_id){
		extract($this->verify_the_fields($args,$base_id));

		$result = Wf_Woocommerce_Packing_List::get_option($name,$base_id);
        $user_selected_arr 	= ($result && is_array($result)) ? $result : array(); 
		$wt_product_spec_fields=Wf_Woocommerce_Packing_List::get_option('wt_product_attribute_fields');
		$html ='<td>';
		$html .= sprintf('<div class="wf_select_multi">
							<input type="hidden" name="%1$s_hidden" value="1" />
							<select class="wc-enhanced-select" name="%1$s[]" multiple="multiple">',esc_attr($name));
		
		if (is_array($wt_product_spec_fields))
        {
            foreach ($wt_product_spec_fields as $prod_meta_key => $prod_meta_val)
            {
            	$meta_key_display=Wf_Woocommerce_Packing_List::get_display_key($prod_meta_key);
            	$selected = in_array($prod_meta_key, $user_selected_arr) ? "selected" : "";
                $html .=sprintf('<option value="%1$s" %2$s>%3$s</option>',
                	esc_attr($prod_meta_key),
                	$selected,
                	wp_kses_post($prod_meta_val.$meta_key_display)
            	);
            }
        }

		$html .= sprintf('</select><br><button type="button" class="button button-secondary" data-wf_popover="1" data-title="%1$s" data-module-base="%2$s" data-content-container=".wt_pklist_custom_field_form" data-field-type="product_attribute" style="margin-top:5px; margin-left:5px; float: right;">%3$s</button>',
			__('Product Attributes','wt-woocommerce-invoice-addon'),
			esc_attr($module_base),
			__('Add/Edit Product Attribute','wt-woocommerce-invoice-addon'));
		$html .= sprintf('<span class="wf_form_help"  style="display:inline;">%1$s</span>',wp_kses_post($help_text));
		$html .='</div></td><td></td>';
		
		return $html;
	}

	/**
	 * To show the multi language compatibility option
	 *
	 * @since 1.1.0
	 * @param array $args
	 * @param string $base_id
	 * @return string
	 */
	public function multi_language_option($args,$base_id){
		
		extract( $this->verify_the_fields( $args ) );
		$result			= Wf_Woocommerce_Packing_List::get_option( $name, $base_id );
		$result			= is_string( $result ) ? stripslashes( $result ) : $result;
		$radio_fields_help_text = (isset($radio_fields_help_text) && !empty($radio_fields_help_text) && is_array($radio_fields_help_text)) ? $radio_fields_help_text : array();
		$td_sytle 		= "";
		$radio_opt_name = $name;

		if( "woocommerce_wf_generate_for_taxstatus" === $name ) {
			$radio_opt_name = "woocommerce_wf_generate_for_taxstatus[]";
		}

		$html	= sprintf( '<td style="%1$s">', $td_sytle );
		$i = 1;
		foreach( $radio_fields as $radio_key => $radio_label ) {
			$checked = "";
			if ( ( is_array( $result ) && in_array( $radio_key, $result ) ) || ( is_string( $result ) && $result == $radio_key ) ) {
				$checked	= 'checked';
			}

			$html	.= '<div style="display:flex;">';
			$html	.= sprintf(
				'<input type="radio" name="%1$s" id="%8$s" class="%3$s %4$s" %7$s value="%2$s" %5$s style="margin:0 .25rem 0 0;"> <p style="margin:-3px 5px 0;">%6$s</p>',
				$radio_opt_name,
				$radio_key,
				$class,
				$form_toggler_p_class,
				$checked,
				$radio_label,
				$form_toggler_register,
				$name.'_'.$radio_key
			);
			$html 	.= '</div>';

			if( isset( $radio_fields_help_text[$radio_key] ) && !empty( $radio_fields_help_text[$radio_key] ) ) {
				$html .= sprintf( '<div style="display:flex;" class="wf_form_help wf_form_help_option_wise">%1$s</div>', wp_kses_post( $radio_fields_help_text[$radio_key] ) );
			}

			if ( "vertical_with_label" === $alignment ) {
				$html	.= ($i !== count($radio_fields)) ?  "<br>" : '';
			} else {
				$html	.="&nbsp;&nbsp;";
			}
			$i++;
		}
		
		if ( "" !== trim( $end_col_call_back ) ) {
			$col3_data	= $this->{$end_col_call_back}($base_id,$module_base);
			$row_span	= 'rowspan="3" style="position:relative;"';
		} else {
			$col3_data	= "";
			$row_span	= '';
		}
		
		$html .= sprintf(
			'%1$s</td><td %3$s>%2$s</td>',
			$this->wt_add_help_text($help_text,$conditional_help_html,$after_form_field),
			$col3_data,
			$row_span
		);
		return $html;
	}

	/**
	 * To render the restart invoice number decline popup
	 *
	 * @since 1.5.0
	 * @param array $args
	 * @param string $base_id
	 * @return string
	 */
	public function wt_restart_invoice_number_confirm_popup( $args, $base_id) {
		$html = '<tr valign="top">
			<td>
				<div class="wt_restart_invoice_number_confirm_popup wf_pklist_popup" style="width: 450px;">
					<div class="wf_pklist_popup_hd">
						<span class="popup_title">'.__('Disable invoice number auto-reset','wt-woocommerce-invoice-addon').'</span>
						<div class="wf_pklist_popup_close">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
							<path d="M8.94004 8.00012L13.14 3.80679C13.2656 3.68125 13.3361 3.51099 13.3361 3.33346C13.3361 3.15592 13.2656 2.98566 13.14 2.86012C13.0145 2.73459 12.8442 2.66406 12.6667 2.66406C12.4892 2.66406 12.3189 2.73459 12.1934 2.86012L8.00004 7.06012L3.80671 2.86012C3.68117 2.73459 3.51091 2.66406 3.33337 2.66406C3.15584 2.66406 2.98558 2.73459 2.86004 2.86012C2.7345 2.98566 2.66398 3.15592 2.66398 3.33346C2.66398 3.51099 2.7345 3.68125 2.86004 3.80679L7.06004 8.00012L2.86004 12.1935C2.79756 12.2554 2.74796 12.3292 2.71411 12.4104C2.68027 12.4916 2.66284 12.5788 2.66284 12.6668C2.66284 12.7548 2.68027 12.8419 2.71411 12.9232C2.74796 13.0044 2.79756 13.0781 2.86004 13.1401C2.92202 13.2026 2.99575 13.2522 3.07699 13.2861C3.15823 13.3199 3.24537 13.3373 3.33337 13.3373C3.42138 13.3373 3.50852 13.3199 3.58976 13.2861C3.671 13.2522 3.74473 13.2026 3.80671 13.1401L8.00004 8.94012L12.1934 13.1401C12.2554 13.2026 12.3291 13.2522 12.4103 13.2861C12.4916 13.3199 12.5787 13.3373 12.6667 13.3373C12.7547 13.3373 12.8419 13.3199 12.9231 13.2861C13.0043 13.2522 13.0781 13.2026 13.14 13.1401C13.2025 13.0781 13.2521 13.0044 13.286 12.9232C13.3198 12.8419 13.3372 12.7548 13.3372 12.6668C13.3372 12.5788 13.3198 12.4916 13.286 12.4104C13.2521 12.3292 13.2025 12.2554 13.14 12.1935L8.94004 8.00012Z" fill="#6E7681"></path>
							</svg>
						</div>
					</div>
				<div class="wf_pklist_popup_body">
					'.__('With the current settings, the annual auto reset functionality will not work', 'wt-woocommerce-invoice-addon').'
				</div>
				<div class="wf_pklist_popup_footer" style="float:left;">
					<button type="button" name="" class="button-secondary wf_pklist_popup_cancel" style="color: #3157A6;border-color: #3157A6;">
						'.__('Cancel','wt-woocommerce-invoice-addon').'
					</button>
					<button type="button" name="" class="button-primary wt_restart_invoice_number_confirm_popup_yes" style="background: #3157A6;">
						'.__('Continue','wt-woocommerce-invoice-addon').'
					</button>	
				</div>
			</td>
		</tr>';
		return wp_kses_post($html);
	}

	/**
	 * To render the invoice number format field with pro option
	 *
	 * @since 1.5.0
	 * @param array $args
	 * @param string $base_id
	 * @return string
	 */
	public function invoice_number_format_pro($args,$base_id){
		$template_type 	= Wf_Woocommerce_Packing_List::get_module_base($base_id);
		$query 			= new WC_Order_Query( array(
			'limit' 	=> 1,
			'orderby' 	=> 'date',
			'order' 	=> 'DESC',
			'parent'	=>0,
		) );
		$orders			= $query->get_orders();
		$order_number 	= "123";

		if(count($orders)>0)
		{
			$order			= $orders[0];
			$order_number	= $order->get_order_number();
		}

		$current_invoice_number 		= (int) Wf_Woocommerce_Packing_List::get_option( 'woocommerce_wf_Current_Invoice_number', $base_id );
		$current_invoice_number_in_db  	= $current_invoice_number = ( 0 > $current_invoice_number ? 0 : $current_invoice_number );
		$inv_num						= ++$current_invoice_number;
		$use_wc_order_number 			= Wf_Woocommerce_Packing_List::get_option( 'woocommerce_wf_invoice_as_ordernumber', $base_id );
		$attach_invoice 				= Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_add_invoice_in_customer_mail',$base_id);
		$invoice_no_type 				= Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_invoice_as_ordernumber',$base_id);
		$invoice_no_format 				= Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_invoice_number_format',$base_id);
		$prefix 						= Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_invoice_number_prefix',$base_id);
		$suffix 						= Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_invoice_number_postfix',$base_id);
		$invoice_start_number 			= Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_invoice_start_number',$base_id);
		$invoice_no_length 				= Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_invoice_padding_number',$base_id);
		
		$order_no_selected 							=  "Yes" === $invoice_no_type ? 'selected' : '';
		$custom_no_selected 						=  "No" === $invoice_no_type ? 'selected' : '';
		$preview_invoice_number_text_display 		= ( "No" === $use_wc_order_number ) ? "display: none;" : '';
		$preview_invoice_number_text_custom_display = ( "Yes" === $use_wc_order_number ) ? "display: none;" : '';

		$date_frmt_tooltip	= __( 'Click to append with existing data', 'wt-woocommerce-invoice-addon' );
		$input_checkbox 	= '';
		$popup_title 		= __( 'Add date to invoice number', 'wt-woocommerce-invoice-addon' );
		$setting_title 		= __( 'Invoice number format', 'wt-woocommerce-invoice-addon' );
		$starting_no_label 	= __( 'What should be the starting number for your invoices?', 'wt-woocommerce-invoice-addon' );
		$num_length_label 	= __( 'What length would you prefer for your invoice', 'wt-woocommerce-invoice-addon' );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading page parameter for admin menu navigation, no form processing
		if( isset( $_GET['page'] ) && ( "wf_woocommerce_packing_list_invoice" === $_GET['page'] || "wf_woocommerce_packing_list_creditnote" === $_GET['page'] ) ) {
			if( is_plugin_active( 'wt-woocommerce-invoice-addon/wt-woocommerce-invoice-addon.php' ) ) {
				$input_checkbox	= '<p style="text-align:left; max-width:400px; margin-top:0px;">
				<input type="checkbox" name="wf_inv_num_frmt_data_val_pdf_fw" id="wf_inv_num_frmt_order_date" value="order_date"> <label for="wf_inv_num_frmt_order_date">'.__('Use order date as input instead.','wt-woocommerce-invoice-addon').'</label>
				</p>';
			}

			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading page parameter for admin menu navigation, no form processing
			if( "wf_woocommerce_packing_list_creditnote" === $_GET['page'] ) {
				$popup_title 		= __( 'Add date to credit note number', 'wt-woocommerce-invoice-addon' );
				$setting_title 		= __( 'Creditnote number format', 'wt-woocommerce-invoice-addon' );
				$starting_no_label 	= __( 'What should be the starting number for your credit notes?', 'wt-woocommerce-invoice-addon' );
				$num_length_label 	= __( 'What length would you prefer for your credit note', 'wt-woocommerce-invoice-addon' );
			}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading page parameter for admin menu navigation, no form processing
		} elseif ( isset($_GET['page']) && "wf_woocommerce_packing_list_proformainvoice" === $_GET['page'] ) {
			if( is_plugin_active( 'wt-woocommerce-proforma-addon/wt-woocommerce-proforma-addon.php' ) ) {
				$input_checkbox = '<p style="text-align:left; max-width:400px; margin-top:0px;">
				<input type="checkbox" name="wf_inv_num_frmt_data_val_pdf_fw" id="wf_inv_num_frmt_order_date" value="order_date"> <label for="wf_inv_num_frmt_order_date">'.__('Use order date as input instead.','wt-woocommerce-invoice-addon').'</label>
				</p>';
			}
			$popup_title 		= __( 'Add date to proforma invoice number', 'wt-woocommerce-invoice-addon' );
			$setting_title 		= __( 'Proforma invoice number format', 'wt-woocommerce-invoice-addon' );
			$starting_no_label 	= __( 'What should be the starting number for your proforma invoices?', 'wt-woocommerce-invoice-addon' );
			$num_length_label 	= __( 'What length would you prefer for your proforma invoice', 'wt-woocommerce-invoice-addon' );
		}

		$html = '<tr valign="top">
			<th>'.esc_html($setting_title).'</th>
			<td colspan="2">
				<table style="margin-top:-14px;width:100%;">
					<tbody>
					<tr>
						<td style="width:35%;">
							<input type="hidden" id="woocommerce_wf_invoice_number_format" name="woocommerce_wf_invoice_number_format_pdf_fw" value="'.esc_attr($invoice_no_format).'">
							<div class="choose_date_div">
								<input type="text" name="woocommerce_wf_invoice_number_prefix_pdf_fw" placeholder="'.__('Prefix','wt-woocommerce-invoice-addon').'" value="'.esc_attr($prefix).'">
								<img class="choose_date_img" data-target-id="woocommerce_wf_invoice_number_prefix_pdf_fw" src="'.esc_url(WF_PKLIST_PLUGIN_URL . "admin/images/choose_date.png").'">
								<a class="choose_date_drop_down" data-target-id="woocommerce_wf_invoice_number_prefix_pdf_fw">'.__('Choose date','wt-woocommerce-invoice-addon').'</a>
							</div>
						</td>
						<td style="width:25%;">
							<select name="woocommerce_wf_invoice_as_ordernumber_pdf_fw">
								<option value="Yes" '.esc_attr($order_no_selected).'>'.__('Order number','wt-woocommerce-invoice-addon').'</option>
								<option value="No" '.esc_attr($custom_no_selected).'>'.__('Custom number','wt-woocommerce-invoice-addon').'</option>
							</select>
						</td>
						<td style="width:35%;">
							<div class="choose_date_div">
								<input type="text" name="woocommerce_wf_invoice_number_postfix_pdf_fw" placeholder="'.__('Suffix','wt-woocommerce-invoice-addon').'" value="'.esc_attr($suffix).'">
								<img class="choose_date_img" data-target-id="woocommerce_wf_invoice_number_postfix_pdf_fw" src="'.esc_url(WF_PKLIST_PLUGIN_URL . "admin/images/choose_date.png").'">
								<a class="choose_date_drop_down" data-target-id="woocommerce_wf_invoice_number_postfix_pdf_fw">'.__('Choose date','wt-woocommerce-invoice-addon').'</a>
							</div>	
						</td>
					</tr>
					<tr class="wc_custom_no_div">
						<td colspan="3">
							<p>'.esc_html($starting_no_label).'</p>
						</td>
					</tr>
					<tr class="wc_custom_no_div">
						<td>
							<input type="number" name="woocommerce_wf_invoice_start_number_preview_pdf_fw" value="'.esc_attr($invoice_start_number).'" min="0" style="width:40%;">
							<input type="hidden" name="woocommerce_wf_invoice_start_number_pdf_fw" value="'.esc_attr($invoice_start_number).'" min="0" style="width:40%;">
							<input type="hidden" class="wf_current_invoice_number_pdf_fw" value="'. esc_attr($current_invoice_number_in_db) .'" name="woocommerce_wf_Current_Invoice_number_pdf_fw" class="">
						</td>
					</tr>
					<tr>
						<td colspan="3">
							<p>'.esc_html($num_length_label).'</p>
						</td>
					</tr>
					<tr>
						<td>
						<input type="number" name="woocommerce_wf_invoice_padding_number_pdf_fw" value="'.esc_attr($invoice_no_length).'" min="0" style="width:40%;">
						</td>
					</tr>
					<tr>
						<td>
							<input type="hidden" value="'.esc_attr($order_number).'" id="sample_invoice_number_pdf_fw">
							<input type="hidden" id="sample_current_invoice_number_pdf_fw" value="'.esc_attr($current_invoice_number).'">
							<div id="invoice_number_prev_div" style="width: auto;border: 1px solid #dadadc;padding: 5px 12px;border-radius: 5px;display: inline-block;background: #f0f0f1;margin-top:25px;">
								<p style="font-weight: bold;line-height: 0;">
									 '.__('PREVIEW','wt-woocommerce-invoice-addon').'
								</p>
								<p style="margin: 1em  0 0.5em 0;'.esc_attr($preview_invoice_number_text_display).'" id="preview_invoice_number_text">
									'.__('If the order number is','wt-woocommerce-invoice-addon').' '.esc_html( $order_number ).', 
									<br> 
									'.
									/* translators: %s: template type (e.g., invoice, proforma) */
									sprintf(__( 'the %s number would be','wt-woocommerce-invoice-addon' ), esc_html( $template_type ) ).'
								</p>
								<p style="margin: 1em  0 0.5em 0;'.$preview_invoice_number_text_custom_display.'" id="preview_invoice_number_text_custom">
									'.
									/* translators: %s: template type (e.g., invoice, proforma) */
									sprintf(__('Your next %s number would be','wt-woocommerce-invoice-addon'), esc_html($template_type)).'
								</p>
								<span id="preview_invoice_number_pdf_fw" style="background: #ffffff;padding: 5px;color: #3c434a;border-radius: 3px;float: left;font-weight: bold;margin-bottom: 0.5em;"></span>    
							</div>
						</td>
					</tr>
					</tbody>
				</table>
			</td>
		</tr>';
		
		$html .='<tr valign="top">
			
			<td>
				<div class="wf_inv_num_frmt_hlp_fw wf_pklist_popup" style="width: 450px;">
					<div class="wf_pklist_popup_hd">
						<span class="popup_title">'.esc_html($popup_title).'</span>
						<div class="wf_pklist_popup_close"><span class="dashicons dashicons-dismiss"></span></div>
					</div>
					<div class="wf_pklist_popup_body">
						'.wp_kses_post($input_checkbox).'
						<table class="wp-list-table widefat choose_date_table">
							<thead>
								<tr>
									<th style="width:40%;">'.__('Date format strings','wt-woocommerce-invoice-addon').'</th><th>'.__('Output','wt-woocommerce-invoice-addon').'</th><th></th>
								</tr>
							</thead>
							<tbody>
								<tr class="wf_inv_num_frmt_fw_append_btn_tr">
									<td><a class="wf_inv_num_frmt_fw_append_btn" title="'.esc_attr($date_frmt_tooltip).'">[F]</a></td>
									<td class="date_format_text">'.esc_html(gmdate('F')).'</td>
									<td class="date_format_add"></td>
								</tr>
								<tr class="wf_inv_num_frmt_fw_append_btn_tr">
									<td><a class="wf_inv_num_frmt_fw_append_btn" title="'.esc_attr($date_frmt_tooltip).'">[dS]</a></td>
									<td class="date_format_text">'.esc_html(gmdate('dS')).'</td>
									<td class="date_format_add"></td>
								</tr>
								<tr class="wf_inv_num_frmt_fw_append_btn_tr">
									<td><a class="wf_inv_num_frmt_fw_append_btn" title="'.esc_attr($date_frmt_tooltip).'">[M]</a></td>
									<td class="date_format_text">'.esc_html(gmdate('M')).'</td>
									<td class="date_format_add"></td>
								</tr>
								<tr class="wf_inv_num_frmt_fw_append_btn_tr">
									<td><a class="wf_inv_num_frmt_fw_append_btn" title="'.esc_attr($date_frmt_tooltip).'">[m]</a></td>
									<td class="date_format_text">'.esc_html(gmdate('m')).'</td>
									<td class="date_format_add"></td>
								</tr>
								<tr class="wf_inv_num_frmt_fw_append_btn_tr">
									<td><a class="wf_inv_num_frmt_fw_append_btn" title="'.esc_attr($date_frmt_tooltip).'">[d]</a></td>
									<td class="date_format_text">'.esc_html(gmdate('d')).'</td>
									<td class="date_format_add"></td>
								</tr>
								<tr class="wf_inv_num_frmt_fw_append_btn_tr">
									<td><a class="wf_inv_num_frmt_fw_append_btn" title="'.esc_attr($date_frmt_tooltip).'">[D]</a></td>
									<td class="date_format_text">'.esc_html(gmdate('D')).'</td>
									<td class="date_format_add"></td>
								</tr>
								<tr class="wf_inv_num_frmt_fw_append_btn_tr">
									<td><a class="wf_inv_num_frmt_fw_append_btn" title="'.esc_attr($date_frmt_tooltip).'">[y]</a></td>
									<td class="date_format_text">'.esc_html(gmdate('y')).'</td>
									<td class="date_format_add"></td>
								</tr>
								<tr class="wf_inv_num_frmt_fw_append_btn_tr">
									<td><a class="wf_inv_num_frmt_fw_append_btn" title="'.esc_attr($date_frmt_tooltip).'">[Y]</a></td>
									<td class="date_format_text">'.esc_html(gmdate('Y')).'</td>
									<td class="date_format_add"></td>
								</tr>
								<tr class="wf_inv_num_frmt_fw_append_btn_tr">
									<td><a class="wf_inv_num_frmt_fw_append_btn" title="'.esc_attr($date_frmt_tooltip).'">[d/m/y]</a></td>
									<td class="date_format_text">'.esc_html(gmdate('d/m/y')).'</td>
									<td class="date_format_add"></td>
								</tr>
								<tr class="wf_inv_num_frmt_fw_append_btn_tr">
									<td><a class="wf_inv_num_frmt_fw_append_btn" title="'.esc_attr($date_frmt_tooltip).'">[d-m-Y]</a></td>
									<td class="date_format_text">'.esc_html(gmdate('d-m-Y')).'</td>
									<td class="date_format_add"></td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</td>
		</tr>';
		return wp_kses_post($html);
	}

	/**
	 * @since 1.6.7
	 * 
	 * Function to display access code field with disconnect button
	 */
	public function wt_decode_app_secret($args, $base_id) {
		extract($this->verify_the_fields($args));
		$result = Wf_Woocommerce_Packing_List::get_option($name, $base_id);
		$result = is_string($result) ? stripslashes($result) : $result;

		$html = '<td>';
		$html .= '<div style="display: flex; align-items: center; gap: 10px;">';
		$id_attr = !empty($id) ? 'id="' . esc_attr($id) . '"' : '';
		$html .= sprintf(
			'<input type="text" name="%1$s" %2$s class="%3$s wt-password-field" value="%4$s" placeholder="%5$s" style="flex: 1;" data-original-value="%4$s">',
			esc_attr($name),
			$id_attr,
			esc_attr($class),
			esc_attr($result),
			esc_attr($placeholder)
		);
		$html .= '</div>';
		$html .= '<style>
			.wt-password-field {
				-webkit-text-security: disc !important;
				text-security: disc !important;
				font-size: 14px !important;
				letter-spacing: 1px !important;
			}
		</style>';
		$html .= $this->wt_add_help_text($help_text, $conditional_help_html, $after_form_field);
		$html .= '</td><td></td>';
		return $html;
	}

	/**
	 * @since 1.6.7
	 * 
	 * Function to display the access code buttons field using form builder
	 */
	public function wt_access_code_buttons($args, $base_id)
	{
		extract($this->verify_the_fields($args));
		
		// Get Dropbox API instance
		$dropbox_api_file = plugin_dir_path( __FILE__ ) . '../modules/cloud-storage/dropbox/class-dropbox-api.php';
		$dropbox_api = null;
		
		if ( file_exists( $dropbox_api_file ) ) {
			include_once $dropbox_api_file;
			global $wt_invoice_dropbox_api;
			if ( isset( $wt_invoice_dropbox_api ) && is_object( $wt_invoice_dropbox_api ) ) {
				$dropbox_api = $wt_invoice_dropbox_api;
			} else {
				$dropbox_api = new Wt_Invoice_Addon_Dropbox_API();
			}
		}
		
		$access_code = Wf_Woocommerce_Packing_List::wf_decode(Wf_Woocommerce_Packing_List::get_option( 'wt_invoice_dropbox_access_code', '' ));
		// print_r("hello"); die;
		$is_connected = $dropbox_api && method_exists($dropbox_api, 'is_connected') ? $dropbox_api->is_connected() : false;
		$has_access_code = !empty($access_code);

		$html = '<td>';
		$html .= '<div class="input-button-row" style="display: flex; align-items: center; gap: 10px;">';
		$id_attr = !empty($id) ? 'id="' . esc_attr($id) . '"' : '';
		$html .= sprintf(
			'<input type="%1$s" %2$s name="%3$s" value="%4$s" class="regular-text" placeholder="%5$s" %6$s style="flex: 1;" />',
			$has_access_code ? 'password' : 'text',
			$id_attr,
			'wt_invoice_dropbox_access_code_display',
			esc_attr($has_access_code ? '••••••••••••••••••••••••••••••••' : ''),
			esc_attr($placeholder),
			$has_access_code ? 'readonly' : ''
		);
		$html .= sprintf('<input type="hidden" name="%1$s" value="%2$s" />', esc_attr($name), esc_attr($access_code));
		
		if ( $has_access_code ) {
			$html .= sprintf(
				'<button type="button" class="button button-link-delete wt-dropbox-disconnect-btn" data-confirm="%2$s">%1$s</button>',
				__('Disconnect', 'wt-woocommerce-invoice-addon'),
				esc_js(__('Are you sure you want to disconnect from Dropbox?', 'wt-woocommerce-invoice-addon'))
			);
		} else {
			$html .= sprintf(
				'<button type="button" class="button button-primary wt-dropbox-authorize-btn">%1$s</button>',
				__('Authorize', 'wt-woocommerce-invoice-addon')
			);
		}
		
		$html .= '</div>';
		$html .= $this->wt_add_help_text($help_text, $conditional_help_html, $after_form_field);
		$html .= '</td><td></td>';
		
		return $html;
	}
}