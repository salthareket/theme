<?php
if ( ! defined( 'WPINC' ) ) {
    die;
}
?>
<div class="wf-tab-content" data-id="<?php echo esc_attr( $target_id );?>">
    <form method="post" class="wf_settings_form wf_general_settings_form">
        <input type="hidden" value="main" class="wf_settings_base" />
        <input type="hidden" value="wf_save_settings" class="wf_settings_action" />
        <input type="hidden" value="wt_main_advanced" class="wt_tab_name" name="wt_tab_name">
        <?php
        if (function_exists('wp_nonce_field'))
        {
            wp_nonce_field(WF_PKLIST_PLUGIN_NAME);
        }

        $mpdf_plugin_data = Wf_Woocommerce_Packing_List_Admin::get_mpdf_plugin_data();
        $mpdf_msg = isset($mpdf_plugin_data['enable_mpdf_msg']) ? $mpdf_plugin_data['enable_mpdf_msg'] : '';
        ?>
        <table class="wf-form-table">
            <tbody>
                <?php 
                    $settings_arr['advanced_option'] = array(
                        'wf_invoice_additional_checkout_data_fields' => array(
                            'type' => 'wf_invoice_additional_checkout_data_fields',
                            'label' => __('Add additional fields on checkout page','wt-woocommerce-invoice-addon'),
                            'name'  =>  'wf_invoice_additional_checkout_data_fields',
                            'id'    =>  'wf_invoice_additional_checkout_data_fields',
                            'class' =>  'wf_invoice_additional_checkout_data_fields',
                            'tooltip' => true,
                            'placeholder' => __('No fields added yet','wt-woocommerce-invoice-addon'),
                        ),
                        'woocommerce_wf_tracking_number' => array(
                            'type' => 'wt_text',
                            'label' => __('Tracking number meta','wt-woocommerce-invoice-addon'),
                            'id' => 'woocommerce_wf_tracking_number',
                            'name' => 'woocommerce_wf_tracking_number',
                            'class' => 'woocommerce_wf_tracking_number',
                            'help_text' => __('Enter the tracking number meta field to add tracking number information','wt-woocommerce-invoice-addon'),
                            'tooltip' => true,
                        ),
                       'woocommerce_wf_state_code_disable' => array(
                            'type' => 'wt_single_checkbox',
                            'label' => __('Display state name','wt-woocommerce-invoice-addon'),
                            'id' => 'woocommerce_wf_state_code_disable',
                            'name' => 'woocommerce_wf_state_code_disable',
                            'value' => "yes",
                            'checkbox_fields' => array('yes'=> __('Enable to show state name in addresses','wt-woocommerce-invoice-addon')),
                            'class' => "woocommerce_wf_state_code_disable",
                            'col' => 3,
                            'tooltip' => true,
                        ),

                        'wt_pklist_show_currency_code' => array(
                            'type' => 'wt_single_checkbox',
                            'label' => __('Display currency code','wt-woocommerce-invoice-addon'),
                            'id' => 'wt_pklist_show_currency_code',
                            'name' => 'wt_pklist_show_currency_code',
                            'value' => "Yes",
                            'checkbox_fields' => array('Yes'=> __('Enable to show currency code instead of currency symbol','wt-woocommerce-invoice-addon')),
                            'class' => "wt_pklist_show_currency_code",
                            'col' => 3,
                            'tooltip' => true,
                        ),
                        
                        'woocommerce_wf_packinglist_preview' => array(
                            'type' => 'wt_single_checkbox',
                            'label' => __('Preview before printing','wt-woocommerce-invoice-addon'),
                            'id' => 'woocommerce_wf_packinglist_preview',
                            'name' => 'woocommerce_wf_packinglist_preview',
                            'value' => "Yes",
                            'checkbox_fields' => array('Yes'=> __('Preview documents before printing','wt-woocommerce-invoice-addon')),
                            'class' => "woocommerce_wf_packinglist_preview",
                            'col' => 3,
                            'tooltip' => true,
                        ),

                        'woocommerce_wf_add_rtl_support' => array(
                            'type' => 'wt_single_checkbox',
                            'label' => __('Enable RTL support','wt-woocommerce-invoice-addon'),
                            'id' => 'woocommerce_wf_add_rtl_support',
                            'name' => 'woocommerce_wf_add_rtl_support',
                            'value' => "Yes",
                            'checkbox_fields' => array('Yes'=> __('RTL support for documents','wt-woocommerce-invoice-addon')),
                            'class' => "woocommerce_wf_add_rtl_support",
                            'col' => 3,
                            'help_text' => sprintf('%1$s', $mpdf_msg),
                        ),
                    );
                    if(is_array($pdf_libs) && count($pdf_libs)>1)
                    {
                        $pdf_libs_form_arr=array();
                        foreach ($pdf_libs as $key => $value)
                        {
                            $pdf_libs_form_arr[$key]=(isset($value['title']) ? $value['title'] : $key);
                        }
                        $settings_arr['advanced_option']['active_pdf_library']=array(
                            'type'  =>  "wt_radio",
                            'label' =>  __("PDF library",'wt-woocommerce-invoice-addon'),
                            'name'  =>  "active_pdf_library",
                            'radio_fields'  =>  $pdf_libs_form_arr,
                            'tooltip' => true,
                            'form_toggler'=>array(
                                'type'=>'parent',
                                'target'=>'wt_pklist_additional_currency_font_support',
                            ),
                        );

                        $settings_arr['advanced_option']['wt_pklist_additional_currency_font_support'] = array(
                            'type'              => 'wt_single_checkbox',
                            'label'             => sprintf('%1$s',
                                __('Enable additional currency font support','wt-woocommerce-invoice-addon'),
                            ),
                            'id'                => 'wt_pklist_additional_currency_font_support',
                            'name'              => 'wt_pklist_additional_currency_font_support',
                            'value'             => "Yes",
                            'checkbox_fields'   => array('Yes'=> __('Enable to use additional font library to support the currency symbol in pdf','wt-woocommerce-invoice-addon')),
                            'class'             => "wt_pklist_additional_currency_font_support",
                            'col'               => 3,
                            'tooltip'           => true,
                            'form_toggler'=>array(
                                'type'  => 'child',
                                'val'   => 'dompdf',
                                'id'    => 'wt_pklist_additional_currency_font_support',
                                'lvl'   => 2,
                            ),
                        );
                    } else {
                        $settings_arr['advanced_option']['wt_pklist_additional_currency_font_support'] = array(
                            'type'              => 'wt_single_checkbox',
                            'label'             => sprintf('%1$s',
                                __('Enable additional currency font support','wt-woocommerce-invoice-addon'),
                            ),
                            'id'                => 'wt_pklist_additional_currency_font_support',
                            'name'              => 'wt_pklist_additional_currency_font_support',
                            'value'             => "Yes",
                            'checkbox_fields'   => array('Yes'=> __('Enable to use additional font library to support the currency symbol in pdf','wt-woocommerce-invoice-addon')),
                            'class'             => "wt_pklist_additional_currency_font_support",
                            'col'               => 3,
                            'tooltip'           => true,
                        );
                    }

                    $is_tax_enabled=wc_tax_enabled();
                    $tax_not_enabled_info='';
                    $incl_tax_img_src = $wf_admin_img_path.'/incl_tax.png';
                    $excl_tax_img_src = $wf_admin_img_path.'/excl_tax.png';
                    $incl_tax_img = '<br><br><img src="'.esc_url($incl_tax_img_src).'" alt="include tax img" width="100%" style="background: #f0f0f1;padding: 10px;">'; 
                    $excl_tax_img = '<br><br><img src="'.esc_url($excl_tax_img_src).'" alt="exclude tax img" width="100%" style="background: #f0f0f1;padding: 10px;">'; 
                    if(!$is_tax_enabled)
                    {
                        $tax_not_enabled_info.='<br>';
                        /* translators: %1$s: b tag %2$s: b tag close %3$s: a tag open %4$s: a tag close */
                        $tax_not_enabled_info.=sprintf(__(' %1$sNote:%2$s You have not enabled tax option in WooCommerce. If you need to apply tax for new orders you need to enable it %3$s here. %4$s', 'wt-woocommerce-invoice-addon'), '<b>', '</b>', '<a href="'.admin_url('admin.php?page=wc-settings').'" target="_blank">', '</a>');

                        $incl_tax_img = ""; 
                        $excl_tax_img = "";
                    }
                    $settings_arr['advanced_option']['woocommerce_wf_generate_for_taxstatus'] = array(
                        'type'  => 'wt_radio',
                        'label' => __('Display price in the product table', 'wt-woocommerce-invoice-addon'),
                        'name'  => 'woocommerce_wf_generate_for_taxstatus',
                        'id'    => 'woocommerce_wf_generate_for_taxstatus',
                        'class' => 'woocommerce_wf_generate_for_taxstatus',
                        'attr'=>($is_tax_enabled ? '' : "disabled"),
                        'after_form_field'=>($is_tax_enabled ? '<a href="'.admin_url('admin.php?page=wc-settings&tab=tax').'" class="" target="_blank" style="text-align:center;">'.__('WooCommerce tax settings', 'wt-woocommerce-invoice-addon').'<span class="dashicons dashicons-external"></span></a>' : ""),
                            'radio_fields'  =>  array(
                                'ex_tax'=>__('Exclude tax','wt-woocommerce-invoice-addon'),
                                'in_tax'=>__('Include tax','wt-woocommerce-invoice-addon'),
                            ),
                        'help_text_conditional'=>array(
                            array(
                                'help_text'=>__('All price columns displayed will be inclusive of tax.', 'wt-woocommerce-invoice-addon').$tax_not_enabled_info.$incl_tax_img,
                                'condition'=>array(
                                    array('field'=>'woocommerce_wf_generate_for_taxstatus', 'value'=>'in_tax')
                                )
                            ),
                            array(
                                'help_text'=>__('All price columns displayed will be exclusive of tax.', 'wt-woocommerce-invoice-addon').$tax_not_enabled_info.$excl_tax_img,
                                'condition'=>array(
                                    array('field'=>'woocommerce_wf_generate_for_taxstatus', 'value'=>'ex_tax')
                                )
                            )
                        ),
                    );

                    $packaging_doc_types = array();
                    $account_doc_types  = array();
                    if(class_exists('Wf_Woocommerce_Packing_List_Pro_Common_Func')){
                        $packaging_doc_types['packingslip'] = __('Packing slip','wt-woocommerce-invoice-addon');
                        $account_doc_types['invoice'] = __('Invoice','wt-woocommerce-invoice-addon');
                    }
                    if(class_exists('Wf_Woocommerce_Packing_List_Pro_Common_Func_SDD')){
                        $packaging_doc_types['shippinglabel'] = __('Shipping label','wt-woocommerce-invoice-addon');
                        $packaging_doc_types['deliverynote'] = __('Delivery note','wt-woocommerce-invoice-addon');
                        $account_doc_types['dispatchlabel'] = __('Dispatch label','wt-woocommerce-invoice-addon');
                    }
                    $pack_help = "";
                    if(!empty($packaging_doc_types)){
                        /* translators: %s: list of document types */
                        $pack_help = sprintf(__('Note: This option is applicable on %s only','wt-woocommerce-invoice-addon'),implode(', ', $packaging_doc_types));

                    }
                    if(class_exists('Wf_Woocommerce_Packing_List_Pro_Common_Func_PKL')){
                        $packaging_doc_types['picklist'] = __('Pick list','wt-woocommerce-invoice-addon');
                    }
                    if(class_exists('Wf_Woocommerce_Packing_List_Pro_Common_Func_PI')){
                        $account_doc_types['proformainvoice'] = __('Proforma invoice','wt-woocommerce-invoice-addon');
                    }
                    $dokan_support_docs = array_merge($account_doc_types,$packaging_doc_types);
                    $dokan_help = "";
                    if(!empty($dokan_support_docs)){
                        sort($dokan_support_docs);
                        /* translators: %s: list of document types */
                        $dokan_help = sprintf(__('Note: This option is applicable on %s only','wt-woocommerce-invoice-addon'),implode(', ', $dokan_support_docs));
                    }
                    $settings_arr['advanced_option']['woocommerce_wf_packinglist_package_type'] = array(
                         'type'=>'wt_select_dropdown',
                            'label'=>__('Packaging type', 'wt-woocommerce-invoice-addon'),
                            'name'=>"woocommerce_wf_packinglist_package_type",
                            'select_dropdown_fields'=>array(
                               'pack_items_individually'=>__('Pack items individually','wt-woocommerce-invoice-addon'),
                                'box_packing'=>__('Box packing','wt-woocommerce-invoice-addon'),
                                'single_packing'=>__('Single package per order','wt-woocommerce-invoice-addon')
                            ),
                            'class' => 'woocommerce_wf_packinglist_package_type',
                            'id' => 'woocommerce_wf_packinglist_package_type',
                            'tooltip' => true,
                            'help_text' => sprintf('<b>%1$s</b> - %2$s <br><b>%3$s</b> - %4$s <br><b>%5$s</b> - %6$s <br><b>%7$s</b>',
                                __('Single package(per order)','wt-woocommerce-invoice-addon'),
                                __('All the items belonging to an order are packed together into a single package. Every order will have a respective package','wt-woocommerce-invoice-addon'),
                                __('Box packing(per order)','wt-woocommerce-invoice-addon'),
                                __('All the items belonging to an order are packed into the respective boxes as per the configuration. Every order may have one or more boxes based on the configuration','wt-woocommerce-invoice-addon'),
                                __('Pack items individually','wt-woocommerce-invoice-addon'),
                                __('Every item from the order/s are packed individually. e.g if an order has 2 quantities of product A and 1 quantity of product B, there will be three packages consisting one item each from the order','wt-woocommerce-invoice-addon'),
                                $pack_help,
                            ),
                            'form_toggler'=>array(
                                'type'=>'parent',
                                'target'=>'wf_box_packing_table',
                            )
                    );
                    $settings_arr = Wf_Woocommerce_Packing_List::add_fields_to_settings($settings_arr);
                    if(class_exists('WT_Form_Field_Builder_PRO_Documents')){
                        $Form_builder = new WT_Form_Field_Builder_PRO_Documents();
                    }else{
                        $Form_builder = new WT_Form_Field_Builder();
                    }
                    foreach($settings_arr as $settings){
                        $Form_builder->generate_form_fields($settings);
                    }
                ?>
            </tbody>
        </table>

        <!-- box dimensions -->
        <div wf_frm_tgl-id="wf_box_packing_table" wf_frm_tgl-val="box_packing">
            <?php
            $wf_packlist_boxes=Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_packinglist_boxes');
            $weight_unit = get_option('woocommerce_weight_unit');
            $dimension_unit = get_option('woocommerce_dimension_unit');
            ?>
            <input type='hidden' id='dimension_unit' value='<?php echo esc_attr($dimension_unit); ?>'>
            <input type='hidden' id='weight_unit' value='<?php echo esc_attr($weight_unit); ?>'>
            <strong><?php esc_html_e('Box Sizes','wt-woocommerce-invoice-addon'); ?></strong><br><br>
            <table class="woocommerce_wf_packinglist_boxes widefat">
                <thead>
                    <tr>
                        <th class="check-column" style="padding: 0px; vertical-align: middle;"><input type="checkbox" /></th>
                        <th><?php esc_html_e('Name','wt-woocommerce-invoice-addon'); ?></th>
                        <th><?php esc_html_e('Length','wt-woocommerce-invoice-addon'); ?></th>
                        <th><?php esc_html_e('Width','wt-woocommerce-invoice-addon'); ?></th>
                        <th><?php esc_html_e('Height','wt-woocommerce-invoice-addon'); ?></th>
                        <th><?php esc_html_e('Box Weight','wt-woocommerce-invoice-addon'); ?></th>
                        <th><?php esc_html_e('Max Weight','wt-woocommerce-invoice-addon'); ?></th>
                        <th><?php esc_html_e('Enabled','wt-woocommerce-invoice-addon'); ?></th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th colspan="8">
                            <div style="float:left; margin:0px 15px;">
                                <a href="#" class="button plus insert"><?php esc_html_e('Add Box','wt-woocommerce-invoice-addon'); ?></a>
                                <a href="#" class="button minus remove"><?php esc_html_e('Remove selected box(es)','wt-woocommerce-invoice-addon'); ?></a>
                            </div>
                            <small class="description"><?php esc_html_e('Items will be packed into these boxes depending on its dimensions and volume, those that do not fit will be packed individually.','wt-woocommerce-invoice-addon'); ?></small>
                        </th>
                    </tr>
                </tfoot>
                <tbody id="rates">
                <?php
                if ($wf_packlist_boxes) 
                {
                    foreach ($wf_packlist_boxes as $key => $box) 
                    {
                        if (!is_numeric($key))
                        continue;
                    ?>
                        <tr>
                            <td class="check-column" style="padding: 10px; vertical-align: middle;"><input type="checkbox" /></td>
                            <td><input type="text" name="woocommerce_wf_packinglist_boxes[<?php echo esc_attr( $key ); ?>][name]" value="<?php echo esc_attr($box['name']); ?>" /></td>
                            <td><input type="text" name="woocommerce_wf_packinglist_boxes[<?php echo esc_attr( $key ); ?>][length]" value="<?php echo esc_attr($box['length']); ?>" /><?php echo esc_html( $dimension_unit ); ?></td>
                            <td><input type="text" name="woocommerce_wf_packinglist_boxes[<?php echo esc_attr( $key ); ?>][width]" value="<?php echo esc_attr($box['width']); ?>" /><?php echo esc_html( $dimension_unit ); ?></td>
                            <td><input type="text" name="woocommerce_wf_packinglist_boxes[<?php echo esc_attr( $key ); ?>][height]" value="<?php echo esc_attr($box['height']); ?>" /><?php echo esc_html( $dimension_unit ); ?></td>
                            <td><input type="text" name="woocommerce_wf_packinglist_boxes[<?php echo esc_attr( $key ); ?>][box_weight]" value="<?php echo esc_attr($box['box_weight']); ?>" /><?php echo esc_html( $weight_unit ); ?></td>
                            <td><input type="text" name="woocommerce_wf_packinglist_boxes[<?php echo esc_attr( $key ); ?>][max_weight]" value="<?php echo esc_attr($box['max_weight']); ?>" /><?php echo esc_html( $weight_unit ); ?></td>
                            <td><input type="checkbox" name="woocommerce_wf_packinglist_boxes[<?php echo esc_attr( $key ); ?>][enabled]" <?php checked($box['enabled'], true); ?> /></td>
                        </tr>
                    <?php
                    }
                }
                ?>
                </tbody>
            </table>    
        </div>
        <!-- box dimensions -->
        <table class="wf-form-table">
            <tbody>
                    <?php
                    $dokan_compatibility['advanced_option']['wt_pklist_dokan_compatibility_enable'] = array(
                            'type'  => 'wt_single_checkbox',
                            'label' => __('Compatibility with Dokan plugin','wt-woocommerce-invoice-addon'),
                            'id'    => 'wt_pklist_dokan_compatibility_enable',
                            'name'  => 'wt_pklist_dokan_compatibility_enable',
                            'value' => "Yes",
                            'checkbox_fields' => array('Yes'=> __('Enable','wt-woocommerce-invoice-addon')),
                            'class' => "wt_pklist_dokan_compatibility_enable",
                            'col'   => 3,
                            'help_text' => __('The vendor`s store address will be used as From address in all the document types instead of general store address','wt-woocommerce-invoice-addon').'<br><b>'.$dokan_help.'</b>',
                    );
                    $dokan_compatibility = Wf_Woocommerce_Packing_List::add_fields_to_settings($dokan_compatibility);
                    if(class_exists('WT_Form_Field_Builder_PRO_Documents')){
                        $Form_builder = new WT_Form_Field_Builder_PRO_Documents();
                    }else{
                        $Form_builder = new WT_Form_Field_Builder();
                    }
                    foreach($dokan_compatibility as $dokan){
                        $Form_builder->generate_form_fields($dokan);
                    }
                ?>
            </tbody>
        </table>
        <?php 
            include "admin-settings-save-button.php";
        ?>
    </form>
</div>