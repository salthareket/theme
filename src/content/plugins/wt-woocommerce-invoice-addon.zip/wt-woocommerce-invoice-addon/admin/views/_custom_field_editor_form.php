<?php
if ( ! defined( 'WPINC' ) ) {
    die;
}
?>
<div class="wt_pklist_custom_field_form" style="display:none;">
	<div class="wt_pklist_checkout_field_tab">
		<div class="wt_pklist_custom_field_tab_head active_tab" data-target="add_new" data-add-title="<?php esc_attr_e('Add new', 'wt-woocommerce-invoice-addon');?>" data-edit-title="<?php esc_attr_e('Edit','wt-woocommerce-invoice-addon');?>">
			<span class="wt_pklist_custom_field_tab_head_title"> <?php esc_html_e('Add new', 'wt-woocommerce-invoice-addon');?></span>
			<div class="wt_pklist_custom_field_tab_head_patch"></div>
		</div>
		<div class="wt_pklist_custom_field_tab_head" data-target="list_view">
			<?php esc_html_e('Previously added', 'wt-woocommerce-invoice-addon');?>
			<div class="wt_pklist_custom_field_tab_head_patch"></div>		
		</div>
		<div class="wt_pklist_custom_field_tab_head_add_new" title="<?php esc_attr_e('Add new', 'wt-woocommerce-invoice-addon');?>">
			<span class="dashicons dashicons-plus"></span>
		</div>
	</div>
	<div class="wt_pklist_custom_field_tab_content active_tab" data-id="add_new">
    	<div class='wt_pklist_custom_field_tab_form_row wt_pklist_custom_field_form_notice'>
    		<?php esc_html_e('You can edit an existing item by using its key.', 'wt-woocommerce-invoice-addon');?>
    	</div>
    	<div class='wt_pklist_custom_field_tab_form_row'>
    		<table>
    			<tr>
    				<td style="width:30%;"><?php esc_html_e('Field Name', 'wt-woocommerce-invoice-addon'); ?><i style="color:red;">*</i></td>
    				<td style="width:50%;"><input type='text' name='wt_pklist_new_custom_field_title' data-required="1" style='width:100%'/></td>
    			</tr>
    			<tr>
    				<td style="width:30%;"><?php esc_html_e('Meta Key', 'wt-woocommerce-invoice-addon'); ?><i style="color:red;">*</i></td>
    				<td style="width:50%;"><input type='text' name='wt_pklist_new_custom_field_key' data-required="1" style='width:100%'/></td>
    			</tr>
    		</table>
		</div>
		<div class='wt_pklist_custom_field_tab_form_row' style="height:25px;">

		</div>
	</div>
	<div class="wt_pklist_custom_field_tab_content" data-id="list_view" style="height:155px; overflow:auto;">
		
	</div>
</div>