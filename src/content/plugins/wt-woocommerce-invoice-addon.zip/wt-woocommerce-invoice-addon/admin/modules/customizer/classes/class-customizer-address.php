<?php
/**
 * Address related function for customizer module
 *
 * @link       
 * @since 1.0.0     
 *
 * @package  Wt_woocommerce_invoice_addon  
 */

if (!defined('ABSPATH')) {
    exit;
}
trait Wf_Woocommerce_Packing_List_Customizer_Address
{
	/**
	 * Get shipping address
	 *
	 * @param string $template_type
	 * @param object $order
	 * @return array
	 */
	public static function get_shipping_address($template_type, $order=null)
	{
		if(!is_null($order))
        {
			$the_options 	= Wf_Woocommerce_Packing_List::get_settings();
			if ( is_null( $order ) ) {
				return array();
			}
			$order = is_a( $order, 'WC_Order' ) ? $order : wc_get_order( $order );
			$order_id = $order->get_id();
	        $shipping_address 	= array();
	        $countries 			= WC()->countries;
			$shipping_country	= Wt_Pklist_Common_Ipc::get_order_meta($order_id,'_shipping_country',true);
	        $shipping_state 	= Wt_Pklist_Common_Ipc::get_order_meta($order_id, '_shipping_state', true);
	        $shipping_state_full 	= ( $shipping_country && $shipping_state && isset($countries->states[$shipping_country][$shipping_state]) ) ? $countries->states[$shipping_country][$shipping_state] : $shipping_state;
	        $shipping_country_full 	= ( $shipping_country && isset($countries->countries[$shipping_country]) ) ? $countries->countries[$shipping_country] : $shipping_country;
	        $shipping_phone 	= (WC()->version < '5.6.0') ? "" : Wt_Pklist_Common_Ipc::get_order_meta($order_id,'_shipping_phone',true);
	        
	        if("" !== trim($shipping_phone)){
				$shipping_phone_label = apply_filters( 'wt_pklist_alter_shipping_address_phone_number_label', '', $template_type, $order );
				if ( !empty( $shipping_phone_label ) ) {
					$shipping_phone = $shipping_phone_label . ' '. $shipping_phone;
				}
	        }

	        $shipping_address=array(
	        	'name'			=>	'',
	        	'first_name'	=> $order->get_shipping_first_name(),
	        	'last_name'		=> $order->get_shipping_last_name(),
	        	'company'		=> $order->get_shipping_company(),
	        	'address_1'		=> $order->get_shipping_address_1(),
	        	'address_2'		=> $order->get_shipping_address_2(),
	        	'city'			=> $order->get_shipping_city(),
	        	'state'			=> ('yes' === $the_options['woocommerce_wf_state_code_disable'] ? $shipping_state_full : $shipping_state),
	        	'country'		=> $shipping_country_full,
	        	'postcode'		=> $order->get_shipping_postcode(),
	        	'phone' 		=> $shipping_phone,
	        );

	        $shipping_address 	= apply_filters('wf_pklist_alter_shipping_address',$shipping_address,$template_type,$order);
	        $shipping_address['name']	= (isset($shipping_address['first_name']) ? $shipping_address['first_name'] : '').' '.(isset($shipping_address['last_name']) ? $shipping_address['last_name'] : ''); 
	        unset($shipping_address['last_name'], $shipping_address['first_name']);

	        if("" === trim($shipping_address['name'])){ unset($shipping_address['name']); }
			if(isset($countries)){
				unset($countries);
			}
	        return $shipping_address;
	    }else
	    {
	    	return array();
	    }
	}

	/**
	 * To Merge the city and state
	 *
	 * @param array $address
	 * @since 1.0.0  - Merge City State Zip code to one line
	 * Preserves the array key order while merging
	 * @return array
	 */
	public static function merge_city_state_zip($address)
	{
		$arr 		= array();
		$to_merge	= array('city','state','postcode');
		foreach($address as $k=>$v)
		{
			if(in_array($k,$to_merge))
			{
				$arr[]	= $v;
			}
		}
		unset($address['state']);
		unset($address['postcode']);
		$address['city']	= implode(", ", array_filter(array_values($arr)));
		return $address;
	}

	/**
	 * Set shipping address
	 *
	 * @param array $find_replace
	 * @param string $template_type
	 * @param string $html
	 * @param object $order
	 * @return array
	 */
	public static function set_shipping_address($find_replace,$template_type, $html="", $order=null)
	{
		if(!is_null($order))
        {
			$shipping_address 	= self::get_shipping_address($template_type, $order);

			if(0 === count(array_filter(array_values($shipping_address)))) //no data
			{
				$shipping_address 	= self::get_billing_address($template_type, $order);
			}

	    	if(false !== strpos($html, '[wfte_shipping_address]'))
	        {
				/**
				 * To hide the shipping address if the order has local pickup shipping method alone.
				 * @since 1.3.0
				 */
				$show_shipping_address_for_local_pickup = Wt_Pklist_Common_Ipc::has_order_local_pickup_only( $order );
				if ( true === apply_filters( 'wt_pklist_hide_shipping_address_for_local_pickup', $show_shipping_address_for_local_pickup, $template_type, $order ) ) {
					$find_replace['wfte_shipping_address_label'] 	= 'wfte_shipping_address_label wfte_hidden';
					$find_replace['[wfte_shipping_address]']		= '';
				} else {
					$shipping_address 	= self::merge_city_state_zip($shipping_address);
					$shipping_addr_vals	= array_filter(array_values($shipping_address));
					$find_replace['[wfte_shipping_address]']	= implode("<br />",$shipping_addr_vals);
					$hide_address = false;
					
					if( empty( $shipping_addr_vals ) && false === apply_filters( 'wt_pklist_use_billing_address_as_shipping_address', false, $template_type, $order ) ) {
						$hide_address = true;
					}
					if(!has_filter('wf_pklist_alter_shipping_address')){
						$wc_formatted_shipping_address = $order->get_formatted_shipping_address();
						
						if( empty( $wc_formatted_shipping_address ) && true === apply_filters( 'wt_pklist_use_billing_address_as_shipping_address', false, $template_type, $order ) ) {
							$wc_formatted_shipping_address 	= $order->get_formatted_billing_address();
						}
						
						if( empty( $wc_formatted_shipping_address ) ) {
							$hide_address = true;
						}

						$shipping_phone        	= ( WC()->version < '5.6.0' ) ? '' : $order->get_shipping_phone();
						if( !empty( $shipping_phone ) ) {
							$shipping_phone_label = apply_filters( 'wt_pklist_alter_shipping_address_phone_number_label', '', $template_type, $order );
							$wc_formatted_shipping_address .= '<br>';
							if ( !empty( $shipping_phone_label ) ) {
								$wc_formatted_shipping_address .= $shipping_phone_label . ' ';
							}
							$wc_formatted_shipping_address .= $shipping_phone;
						}
						$find_replace['[wfte_shipping_address]'] = $wc_formatted_shipping_address;
					}
					
					// hide the shipping address label, if the shipping address is empty.
					if(true === $hide_address) {
						$find_replace['wfte_shipping_address_label'] = 'wfte_shipping_address_label wfte_hidden';
					}
				}	
		    }
			$find_replace 	= self::set_address_inner_placeholders($find_replace, $shipping_address, 'wfte_shipping_address_');
	    }else
	    {
	    	$find_replace['[wfte_shipping_address]']	= '';
	    }
	    return $find_replace;
	}
	
	/**
	 * Get billing address
	 *
	 * @param string $template_type Document type eg:invoice
	 * @param object $order Order object 
	 * @return array $billing address
	 */
	public static function get_billing_address($template_type, $order=null)
	{
		if(!is_null($order))
        {
			$the_options 		= Wf_Woocommerce_Packing_List::get_settings();
			$order = is_a( $order, 'WC_Order' ) ? $order : wc_get_order( $order );
			$order_id = $order->get_id();   
	        $countries 			= WC()->countries; 
	        $billing_country 	= Wt_Pklist_Common_Ipc::get_order_meta($order_id, '_billing_country', true);   
	        $billing_state 		= Wt_Pklist_Common_Ipc::get_order_meta($order_id, '_billing_state', true);
	        $billing_state_full = ( $billing_country && $billing_state && isset($countries->states[$billing_country][$billing_state]) ) ? $countries->states[$billing_country][$billing_state] : $billing_state;
	        $billing_country_full = ( $billing_country && isset($countries->countries[$billing_country]) ) ? $countries->countries[$billing_country] : $billing_country;
	        
	        $billing_address 	= array(
	        	'name'			=> '',
	        	'first_name'	=> $order->get_billing_first_name(),
	        	'last_name'		=> $order->get_billing_last_name(),
	        	'company'		=> $order->get_billing_company(),
	        	'address_1'		=> $order->get_billing_address_1(),
	        	'address_2'		=> $order->get_billing_address_2(),
	        	'city'			=> $order->get_billing_city(),
	        	'state'			=> ('yes' === $the_options['woocommerce_wf_state_code_disable'] ? $billing_state_full : $billing_state),
	        	'country'		=> $billing_country_full,
	        	'postcode'		=> $order->get_billing_postcode(),
	        );
	        $billing_address 	= apply_filters('wf_pklist_alter_billing_address',$billing_address,$template_type,$order);

	        $billing_address['name']	= (isset($billing_address['first_name']) ? $billing_address['first_name'] : '').' '.(isset($billing_address['last_name']) ? $billing_address['last_name'] : ''); 
	        unset($billing_address['last_name'], $billing_address['first_name']);
	        if("" === trim($billing_address['name'])){ unset($billing_address['name']); }
			if(isset($countries)){
				unset($countries);
			}
	        return $billing_address;
	    }else
	    {
	    	return array();
	    }
	}

	/**
	 * Set the billing address
	 *
	 * @param array $find_replace
	 * @param string $template_type
	 * @param string $html
	 * @param object $order
	 * @return array $find_replace
	 */
	public static function set_billing_address($find_replace, $template_type, $html="",$order=null)
	{
		if(!is_null($order))
        {
			$billing_address 	= self::get_billing_address($template_type, $order);
        	if(false !== strpos($html, '[wfte_billing_address]'))
	        {
		        $billing_address 	= self::merge_city_state_zip($billing_address);
	        	$billing_addr_vals	= array_filter(array_values($billing_address));
	        	$find_replace['[wfte_billing_address]']	= implode("<br />",$billing_addr_vals);
				$hide_address		= empty( $billing_addr_vals );
				if(!has_filter('wf_pklist_alter_billing_address')){
					$find_replace['[wfte_billing_address]'] = $order->get_formatted_billing_address();
					if( empty($order->get_formatted_billing_address()) ) {
						$hide_address = true;
					}
				}

				// hide the billing address label, if the billing address is empty.
				if(true === $hide_address) {
					$find_replace['wfte_billing_address_label'] = 'wfte_billing_address_label wfte_hidden';
				}
		    }
			$find_replace 	= self::set_address_inner_placeholders($find_replace, $billing_address, 'wfte_billing_address_');

	    }else
	    {
	    	$find_replace['[wfte_billing_address]']	= '';
	    }
	    return $find_replace;
	}
	
	/**
	 * @since 1.6.4 - Added compatibility for Wpml: Get the translated address from WPML
	 */
	public static function set_shipping_from_address($find_replace, $template_type, $html="", $order=null)
	{ 
		$the_options 		= Wf_Woocommerce_Packing_List::get_settings();
        $country_selected	= $the_options['wf_country'];
        $country_arr		= explode(":",$country_selected);
        $country = $country_code	= isset($country_arr[0]) ? $country_arr[0] : '';
        $state 				= isset($country_arr[1]) ? $country_arr[1] : '';
        $countries 			= WC()->countries;
		$fromaddress 		= array(
        	'name'			=> $the_options['woocommerce_wf_packinglist_sender_name'],
        	'address_line1'	=> $the_options['woocommerce_wf_packinglist_sender_address_line1'],
        	'address_line2'	=> $the_options['woocommerce_wf_packinglist_sender_address_line2'],
        	'city'			=> $the_options['woocommerce_wf_packinglist_sender_city'],
        	'state'			=> $state,
        	'country'		=> (isset($countries->countries[$country]) ? $countries->countries[$country] : ''),
        	'postcode'		=> $the_options['woocommerce_wf_packinglist_sender_postalcode'],
        	'contact_number'=> $the_options['woocommerce_wf_packinglist_sender_contact_number'],
        	'vat'			=> $the_options['woocommerce_wf_packinglist_sender_vat'],
        );
		//display state name instead of state code   
        if('yes' === $the_options['woocommerce_wf_state_code_disable'])
        {
        	$fromaddress['state'] = isset($countries->states[$country]) && isset($countries->states[$country][$state]) ? $countries->states[$country][$state] : '';
        }

		/**
		 * Get the vendor address instead of store address, if dokan plugin is active
		 * @since 1.0.6
		 */
		$is_dokan_active	= Wt_Pklist_Common_Ipc::is_dokan_plugin_active();
		if(true === $is_dokan_active && !empty($order))
		{
			$enable_dokan_compatibility = Wf_Woocommerce_Packing_List::get_option('wt_pklist_dokan_compatibility_enable');
			$enable_dokan_compatibility_for_template = apply_filters('wt_pklist_dokan_compatibility_enable_for_template',true,$template_type,$order);
			if("Yes" === $enable_dokan_compatibility && true === $enable_dokan_compatibility_for_template)
			{
				$dokan_vendor_id = $order->get_meta('_dokan_vendor_id',true);
				if(!empty($dokan_vendor_id))
				{
					$store_info = function_exists('dokan_get_store_info') ? dokan_get_store_info($dokan_vendor_id) : array();
					$vendor_from_address = (is_array($store_info) && isset($store_info['address'])) ? $store_info['address'] : array();
					if(!empty($vendor_from_address))
					{
						$country_code = $v_country 	= $vendor_from_address['country'];
						$v_state	= $vendor_from_address['state'];
						$fromaddress 		= array(
							'name'			=> (isset($store_info['store_name'])) ? $store_info['store_name'] : "",
							'address_line1'	=> $vendor_from_address['street_1'],
							'address_line2'	=> $vendor_from_address['street_2'],
							'city'			=> $vendor_from_address['city'],
							'state'			=> $vendor_from_address['state'],
							'country'		=> (isset($countries->countries[$v_country]) ? $countries->countries[$v_country] : $v_country),
							'postcode'		=> $vendor_from_address['zip'],
							'contact_number'=> (isset($store_info['phone'])) ? $store_info['phone'] : "",
							'vat'			=> "",
						);
						

						//display state name instead of state code   
						if('yes' === $the_options['woocommerce_wf_state_code_disable'])
						{
							$fromaddress['state'] = isset($countries->states[$v_country]) && isset($countries->states[$v_country][$v_state]) ? $countries->states[$v_country][$v_state] : $v_state;
						}
					}
				}
			}
		}

        $returnaddress = $fromaddress; //not affect from address filter to return address
        if(!is_null($order))
        {
			$order = is_a( $order, 'WC_Order' ) ? $order : wc_get_order( $order );
        	$fromaddress 	= apply_filters('wf_pklist_alter_shipping_from_address',$fromaddress,$template_type,$order);
        	$returnaddress 	= apply_filters('wf_pklist_alter_shipping_return_address',$returnaddress,$template_type,$order);
        }

        if(false !== strpos($html, '[wfte_from_address]'))
        {
			$original_from_address = $fromaddress;
			$fromaddress 	= self::merge_city_state_zip($fromaddress);
	        $from_addr_vals = is_array($fromaddress) ? array_filter(array_values($fromaddress)) : array();
	        $find_replace['[wfte_from_address]'] = implode("<br />",$from_addr_vals);

			if(!has_filter('wf_pklist_alter_shipping_from_address')){

				$from_address_params = array(
					'first_name' => $original_from_address['name'],
					'last_name'  => '',
					'company'    => '',
					'address_1'  => $original_from_address['address_line1'],
					'address_2'  => $original_from_address['address_line2'],
					'city'       => $original_from_address['city'],
					'postcode'   => $original_from_address['postcode'],
				);

				// is wpml active
				if ( defined( 'ICL_SITEPRESS_VERSION' ) ) {
					$from_address_params = self::get_translated_address_from_wpml( $from_address_params, determine_locale() );

				} 
				
				$from_address_params['country'] = $country_code;
				$from_address_params['state'] = $original_from_address['state'];

				$wc_formatted_from_address = WC()->countries->get_formatted_address( $from_address_params );
				if( isset($original_from_address['contact_number']) && !empty($original_from_address['contact_number']) ) {
					$wc_formatted_from_address .= '<br>'.$original_from_address['contact_number'];
				}

				if( isset( $original_from_address['vat'] ) && !empty( $original_from_address['vat'] ) ) {
					$wc_formatted_from_address .= '<br>'.$original_from_address['vat'];
				}
				$find_replace['[wfte_from_address]'] =  $wc_formatted_from_address;
			}
	        
	    }

		$find_replace 	= self::set_address_inner_placeholders($find_replace, $fromaddress, 'wfte_from_address_');

	    if(false !== strpos($html, '[wfte_return_address]'))
        {
			$original_return_address = $returnaddress;
	        $returnaddress 	= self::merge_city_state_zip($returnaddress);
	        $return_addr_vals	= is_array($returnaddress) ? array_filter(array_values($returnaddress)) : array();
	        $find_replace['[wfte_return_address]'] 	= implode("<br />",$return_addr_vals);
			if(!has_filter('wf_pklist_alter_shipping_return_address')){
				$return_address_params = array(
					'first_name' => $original_return_address['name'],
					'last_name'  => '',
					'company'    => '',
					'address_1'  => $original_return_address['address_line1'],
					'address_2'  => $original_return_address['address_line2'],
					'city'       => $original_return_address['city'],
					'state'      => $original_return_address['state'],
					'postcode'   => $original_return_address['postcode'],
					'country'    => $country_code
				);
				$wc_formatted_return_address = WC()->countries->get_formatted_address( $return_address_params );
				if( isset($original_return_address['contact_number']) && !empty($original_return_address['contact_number']) ) {
					$wc_formatted_return_address .= '<br>'.$original_return_address['contact_number'];
				}

				if( isset( $original_return_address['vat'] ) && !empty( $original_return_address['vat'] ) ) {
					$wc_formatted_return_address .= '<br>'.$original_return_address['vat'];
				}
				$find_replace['[wfte_return_address]'] =  $wc_formatted_return_address;
			}
	    }

		$find_replace=self::set_address_inner_placeholders($find_replace, $returnaddress, 'wfte_return_address_');

		if(isset($countries)){
			unset($countries);
		}
		return $find_replace;
	}


	/**
	 * Get the translated from address from WPML
	 * @since 1.6.4
	 * @param array $original_from_address
	 * @param string $lang
	 * @return array
	 */
	private static function get_translated_address_from_wpml( $original_from_address, $lang ) {
		$domain = 'admin_texts_Wf_Woocommerce_Packing_List';
	
		// Mapping keys to WPML string translation keys
		$fields = array(
			'first_name'  => '[Wf_Woocommerce_Packing_List]woocommerce_wf_packinglist_sender_name',
			'last_name'   => '',
			'company'     => '[Wf_Woocommerce_Packing_List]woocommerce_wf_packinglist_sender_companyname',
			'address_1'   => '[Wf_Woocommerce_Packing_List]woocommerce_wf_packinglist_sender_address_line1',
			'address_2'   => '[Wf_Woocommerce_Packing_List]woocommerce_wf_packinglist_sender_address_line2',
			'city'        => '[Wf_Woocommerce_Packing_List]woocommerce_wf_packinglist_sender_city',
			'postcode'    => '[Wf_Woocommerce_Packing_List]woocommerce_wf_packinglist_sender_postalcode',
		);
	
		$translated_address = array(); 
	
		// Apply WPML translation to each field
		foreach ( $fields as $key => $wpml_key ) {
			$original_value = isset( $original_from_address[$key] ) ? $original_from_address[$key] : '';
	
			$translated_string = apply_filters(
				'wpml_translate_single_string',
				$original_value,
				$domain,
				$wpml_key,
				$lang
			);
	
			/**
			 * Normally, the WPML filter returns the original string if no translation is available. 
			 * This is just a fallback to ensure the original value is used if needed.
			 */
			$translated_address[$key] = ! empty( $translated_string ) ? $translated_string : $original_value;
		}
	
		return $translated_address;
	}
	

	/**
	*	@since 1.0.0
	*	Set values to inner placeholder of address blocks.
	*/
	private static function set_address_inner_placeholders($find_replace, $data_arr, $address_prefix)
	{

		/**
		*	Some fields in adress block is showing in one line. We have to hide the entire row if values of all fields are empty
		*/
		$single_line_fields_arr	= array(
			'city_state_postcode_country'	=> array('city', 'state', 'postcode', 'country'),
			'address_1_address_2'			=> array('address_1', 'address_2'),
			'address_line1_address_line2'	=> array('address_line1', 'address_line2'),
			'phone' 						=> array('phone'),
		);
		foreach($single_line_fields_arr as $address_key => $single_line_fields)
		{
			$find_replace["[".$address_prefix.$address_key."]"]	= ''; //empty value to hide
			
			foreach($single_line_fields as $field)
			{
				if(isset($data_arr[$field]) && "" !== trim($data_arr[$field])) //atleast one field with value found then prevent hiding by setting a value
				{
					$find_replace["[".$address_prefix.$address_key."]"] = 1; //just a value to prevent hiding
					break 1; //break the loop
				}
			}
		}

		foreach ($data_arr as $key => $value)
		{
			if(false === strpos($key, ' ')) /* check no space in key */
			{
				$find_replace["[".$address_prefix.$key."]"] = $value;
			}
		}
		return $find_replace;
	}
}