<?php

/**
 * Product table related function for customizer module
 *
 * @link
 * @since 1.0.0
 *
 * @package  Wt_woocommerce_invoice_addon
 */

if (! defined('ABSPATH')) {
	exit;
}

trait Wf_Woocommerce_Packing_List_Customizer_Tax_table_Ipc_Pro
{
	public static function set_tax_table($find_replace, $template_type, $html, $order = null, $box_packing = null, $order_package = null)
	{
		// saved_template_preview will be set during ajax call from invoice add-on for preview of saved template.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- This is a page routing check, not form processing.
		$current_page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- This is a page routing check, not form processing.
		$is_invoice_page = 'wf_woocommerce_packing_list_invoice' === $current_page || isset( $_GET['saved_template_preview'] );

		if ( $is_invoice_page ) {
			return $find_replace;
		}

		// Searching for the tax summary table in the HTML
		if ( preg_match( '#<table[^>]*class\s*=\s*["\']([^"\']*)tax_summary_table(.*?[^"\']*)["\'][^>]*>(.*?)</table>#s', $html, $match ) ) {
			// If order has no taxes, remove the tax table completely
			if ( ! $order || ! self::order_has_taxes( $order ) || ! is_plugin_active( 'wt-advanced-customizer-addon/wt-advanced-customizer-addon.php' ) ) {
				$find_replace[$match[0]] = '';
			} else {
				// Process tax table as normal for orders with taxes
				$tax_tb_html = $match[0];
				$columns_list_arr = array();
				$column_list_options = array();
				$thead_match = array();
				$th_html = '';

				// Extract <thead> content
				if ( preg_match( '/<thead(.*?)>(.*?)<\/thead>/s', $tax_tb_html, $thead_match ) ) {
					if ( isset( $thead_match[2] ) && "" !== $thead_match[2] ) {
						$thead_tr_match = array();
						if ( preg_match( '/<tr(.*?)>(.*?)<\/tr>/s', $thead_match[2], $thead_tr_match ) ) {
							if ( isset( $thead_tr_match[2] ) ) {
								$th_html = $thead_tr_match[2];
							}
						}
					}
				}

				if ( "" !== $th_html ) {
					$th_html_arr = explode( '</th>', $th_html );
					$th_html_arr = array_filter( $th_html_arr );
					$col_ind = 0;

					foreach ( $th_html_arr as $th_single_html ) {
						$th_single_html = trim( $th_single_html );
						if ( "" !== $th_single_html ) {
							$matchs = array();
							$is_have_col_id = preg_match( '/col-type="(.*?)"/', $th_single_html, $matchs );
							$col_ind++;
							$col_key = ( $is_have_col_id ? $matchs[1] : $col_ind ); // Column ID exists

							// Extract additional column attributes
							$extra_table_col_opt = self::extract_tax_table_col_options( $th_single_html );

							// Store column data
							$columns_list_arr[$col_key] = $th_single_html . '</th>';
							$column_list_options[$col_key] = $extra_table_col_opt;
						}
					}
					$find_replace[$th_html] = self::generate_tax_summary_table_head_html( $columns_list_arr, $template_type, $order );
				}

				// Processing the tax table body
				if ( preg_match( '/<tbody.*?>.*?<\/tbody>/s', $tax_tb_html, $tbody_match ) ) {
					// Generate the actual tbody content with dynamic tax rows
					$tbody_html = self::generate_tax_summary_table_body_html( $column_list_options, $template_type, $order, $box_packing, $order_package );

					// Replace full <tbody> section
					$find_replace[$tbody_match[0]] = '<tbody>' . $tbody_html . '</tbody>';
				}
			}
		}

		// Remove placeholders for the tax summary table
		$find_replace['[wfte_tax_summary_table_start]'] = '';
		$find_replace['[wfte_tax_summary_table_end]'] = '';

		return $find_replace;
	}

	/**
	 * Check if an order has any taxes
	 *
	 * @param WC_Order $order The order to check
	 * @return boolean True if order has any taxes, false otherwise
	 */
	private static function order_has_taxes($order)
	{
		if ( ! $order ) {
			return false;
		}

		// Check tax data in each order item
		$items = $order->get_items();
		foreach ( $items as $item ) {
			$item_taxes = $item->get_taxes();
			$item_tax_subtotal	= ( isset( $item_taxes['subtotal'] ) ? $item_taxes['subtotal'] : array() );

			if ( ! empty( $item_tax_subtotal ) ) {
				return true;
			}

		}

		// No taxes found
		return false;
	}


	private static function extract_tax_table_col_options($th_single_html)
	{
		$options = array();

		// Extracts text alignment if exists
		if (preg_match('/class=["\'](.*?)["\']/', $th_single_html, $matches)) {
			$options['text-align'] = $matches[1];
		}

		return $options;
	}
	private static function extract_inline_styles($html_element)
	{
		$styles = array();

		// Extract inline style if it exists
		if (preg_match('/style=["\'](.*?)["\']/', $html_element, $matches)) {
			$style_string = $matches[1];

			// Split styles by `;` and process each style
			$style_array = explode(';', $style_string);
			foreach ($style_array as $style) {
				$style = trim($style);
				if (!empty($style)) {
					list($property, $value) = explode(':', $style, 2);
					$styles[trim($property)] = trim($value);
				}
			}
		}

		return $styles;
	}


	// Function to generate tax table head dynamically
	private static function generate_tax_summary_table_head_html($columns_list_arr, $template_type, $order)
	{


		if ($order) {
			$thead_html = self::genarate_tax_header($order, $columns_list_arr);

			return $thead_html;
		} else {


			$thead_html = '<thead class="wfte_tax_summary_table_head">';
			$thead_html .= '<tr>';

			foreach ($columns_list_arr as $col_html) {
				$thead_html .= $col_html;
			}

			$thead_html .= '</tr></thead>';


			return $thead_html;
		}
	}


	private static function genarate_tax_header($order, $columns_list_arr)
	{

		$tax_coloumns_data = self::extract_tax_table_col_options($columns_list_arr['tax_coloumns']);
		$tax_coloumns_attrs = $tax_coloumns_data['text-align'];

		

		$tax_coloumns_style_data = self::extract_inline_styles($columns_list_arr['tax_coloumns']);
		$style_tag = self::generate_style_tag($tax_coloumns_style_data);

		$default_columns = array('base_price', 'total_tax_rate', 'total_tax');
		$columns_list_arr = array_intersect_key($columns_list_arr, array_flip($default_columns));


		$items = $order->get_items();
		$applied_taxes = [];

		foreach ($items as $item_id => $item) {
			$tax_data = $item->get_taxes();

			if (empty($tax_data['total'])) {
				continue;
			}

			foreach ($tax_data['total'] as $rate_id => $tax_amount) {
				$rate = WC_Tax::get_rate_percent($rate_id);
				$tax_label = WC_Tax::get_rate_label($rate_id);

				if (!$rate || !$tax_label) {
					continue;
				}

				// Store unique tax labels
				$applied_taxes[$tax_label] = $rate;
			}
		}

		$formatted_taxes = [];

		foreach ($applied_taxes as $key => $value) {
			$formatted_taxes[$key . " (%)"] = $key . " (%)"; // Key with "(%)" and value as same
			$formatted_taxes[$key . " "] = $key;            // Original key with space and value as same
		}

		$thead_html = '';
		$thead_html .= $columns_list_arr['base_price'];

		foreach ($formatted_taxes as $col_data) {
			$thead_html .= '<th class="' . $tax_coloumns_attrs . '"  style="border-bottom: 1px solid #D7DBDF; padding: 5px 5px;">' . $col_data . '</th>';
		}
		$thead_html .= $columns_list_arr['total_tax_rate'];
		$thead_html .= $columns_list_arr['total_tax'];


		return $thead_html;
	}
	private static function sanitize_class_name($name)
	{
		return strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $name));
	}

	// Function to generate tax table body dynamically
	private static function generate_tax_summary_table_body_html($column_list_options, $template_type, $order, $box_packing = null, $order_package = null)
	{
		$tax_summary = self::add_real_tax_data($order);


		$tbody_html = '';

		// Extract unique tax placeholders from all entries
		$tax_placeholders = [];
		foreach ($tax_summary as $entry) {
			if (isset($entry['taxes']) && is_array($entry['taxes'])) {
				foreach ($entry['taxes'] as $tax) {
					$tax_placeholders[$tax['placeholder']] = true;
				}
			}
		}

		$base_price_attrs = '';
		$tax_coloumns_attrs = '';
		$total_tax_rate_attrs = '';
		$total_tax_attrs = '';
		if (isset($column_list_options['base_price']['text-align'])) {
			$base_price_attrs = $column_list_options['base_price']['text-align'];
		}
		if (isset($column_list_options['tax_coloumns']['text-align'])) {
			$tax_coloumns_attrs = $column_list_options['tax_coloumns']['text-align'];
		}
		if (isset($column_list_options['total_tax_rate']['text-align'])) {
			$total_tax_rate_attrs = $column_list_options['total_tax_rate']['text-align'];
		}

		if (isset($column_list_options['total_tax']['text-align'])) {
			$total_tax_attrs = $column_list_options['total_tax']['text-align'];
		}

		// Generate table rows dynamically
		foreach ($tax_summary as $entry) {
			$tbody_html .= '<tr class="wfte_tax_summary_table_row">';
			$tbody_html .= '<td class="' . $base_price_attrs . '">' . wc_price($entry['total_base_price']) . '</td>';

			// Populate tax data dynamically
			foreach (array_keys($tax_placeholders) as $placeholder) {
				$tax_rate_display = '-';
				$tax_amount_display = '-';

				foreach ($entry['taxes'] as $tax) {
					if ($tax['placeholder'] === $placeholder) {
						$tax_rate_display = $tax['rate'];
						$tax_amount_display = wc_price($tax['amount']);
						break;
					}
				}

				$sanitized_placeholder = self::sanitize_class_name($placeholder);
				$tbody_html .= "<td class='wfte_tax_summary_table_{$sanitized_placeholder}_rate {$tax_coloumns_attrs}'>{$tax_rate_display}</td>";
				$tbody_html .= "<td class='wfte_tax_summary_table_{$sanitized_placeholder}_amount {$tax_coloumns_attrs}'>{$tax_amount_display}</td>";
			}

			// Add Total Tax Rate and Total Tax columns
			$tbody_html .= '<td class="' . $total_tax_rate_attrs . '">' . esc_html($entry['total_tax_rate']) . '</td>';
			$tbody_html .= '<td class="' . $total_tax_attrs . '">' . wc_price($entry['total_tax']) . '</td>';
			$tbody_html .= '</tr>';
		}

		return $tbody_html;
	}



	private static function add_real_tax_data($order)
	{
		if (!$order) return [];

		$items = $order->get_items();
		$tax_summary = [];

		foreach ($items as $item_id => $item) {
			$base_price = floatval($item->get_total());
			$tax_data = $item->get_taxes();

			if (empty($tax_data['total'])) {
				continue;
			}

			$total_tax_rate = 0;
			$total_tax_amount = 0;
			$grouped_taxes = [];

			foreach ($tax_data['total'] as $rate_id => $tax_amount) {
				$rate = WC_Tax::get_rate_percent($rate_id);
				$tax_label = WC_Tax::get_rate_label($rate_id);

				if (!$rate || !$tax_label) {
					continue;
				}

				$rate = floatval($rate);
				$amount = floatval($tax_amount);

				$total_tax_rate += $rate;
				$total_tax_amount += $amount;

				if (!isset($grouped_taxes[$tax_label])) {
					$grouped_taxes[$tax_label] = [
						'placeholder' => $tax_label,
						'rate' => "{$rate}",
						'amount' => 0
					];
				}

				$grouped_taxes[$tax_label]['amount'] += $amount;
			}

			// Create a unique key for this tax group
			$group_key = $total_tax_rate . '-' . implode('+', array_keys($grouped_taxes));

			if (!isset($tax_summary[$group_key])) {
				$tax_summary[$group_key] = [
					'total_base_price' => 0,
					'total_tax' => 0,
					'total_tax_rate' => "{$total_tax_rate}%",
					'taxes' => []
				];
			}

			$tax_summary[$group_key]['total_base_price'] += $base_price;
			$tax_summary[$group_key]['total_tax'] += $total_tax_amount;

			// Merge tax entries by label
			foreach ($grouped_taxes as $label => $tax_entry) {
				$found = false;
				foreach ($tax_summary[$group_key]['taxes'] as &$existing) {
					if ($existing['placeholder'] === $label) {
						$existing['amount'] += $tax_entry['amount'];
						$found = true;
						break;
					}
				}
				unset($existing);

				if (!$found) {
					$tax_summary[$group_key]['taxes'][] = $tax_entry;
				}
			}
		}

		return $tax_summary;
	}



	private static function generate_style_tag($style_data)
	{
		// Build the CSS string
		$css='';
		foreach ($style_data as $property => $value) {
			$css .= "$property: $value;";
		}

		return 'style="'.$css.'"';
	}
	
}
