/**
 * Cloud Storage JavaScript
 *
 * @package    Wt_woocommerce_invoice_addon
 * @subpackage Wt_woocommerce_invoice_addon/admin/modules/cloud-storage
 * @since      1.6.7
 */

(function($) {
    'use strict';

    $(function(){
        var wt_pklist_cloud_storage = {
            Set: function() {
                this.checkUrlParams();
                this.initUpdateDropboxLink();
                this.dropboxConnection();
                this.disconnectDropbox();
                this.handleCloudStorageToggle();
            },
            
            checkUrlParams: function() {
                // Check for URL parameters and display toast messages
                var urlParams = new URLSearchParams(window.location.search);
                
                // Check if wf_notify_msg is available (from main admin JS)
                if (typeof wf_notify_msg === 'undefined') {
                    return; // Toast notification system not available
                }
                
                // Check for authorization success
                if (urlParams.get('auth_success') === '1') {
                    var message = (typeof wt_cloud_storage_params !== 'undefined' && wt_cloud_storage_params.msgs && wt_cloud_storage_params.msgs.auth_success) 
                        ? wt_cloud_storage_params.msgs.auth_success 
                        : 'Successfully authorized with Dropbox!';
                    wf_notify_msg.success(message);
                    
                    // Clean URL by removing the parameter
                    urlParams.delete('auth_success');
                    var newUrl = window.location.pathname + (urlParams.toString() ? '?' + urlParams.toString() : '') + window.location.hash;
                    window.history.replaceState({}, document.title, newUrl);
                }

                // Check for disconnect success
                if (urlParams.get('disconnect_success') === '1') { 
                    var message = (typeof wt_cloud_storage_params !== 'undefined' && wt_cloud_storage_params.msgs && wt_cloud_storage_params.msgs.disconnect_success) 
                        ? wt_cloud_storage_params.msgs.disconnect_success 
                        : 'Successfully disconnected from Dropbox and cleared access code.';
                    wf_notify_msg.success(message);
                    
                    // Clean URL by removing the parameter
                    urlParams.delete('disconnect_success');
                    var newUrl = window.location.pathname + (urlParams.toString() ? '?' + urlParams.toString() : '') + window.location.hash;
                    window.history.replaceState({}, document.title, newUrl);
                }
                
                // Check for authorization failure
                if (urlParams.get('auth_fail') === '1') {
                    var message = (typeof wt_cloud_storage_params !== 'undefined' && wt_cloud_storage_params.msgs && wt_cloud_storage_params.msgs.auth_fail) 
                        ? wt_cloud_storage_params.msgs.auth_fail 
                        : 'Failed to authorize with Dropbox. Please check your access code.';
                    wf_notify_msg.error(message);
                    
                    // Clean URL by removing the parameter
                    urlParams.delete('auth_fail');
                    var newUrl = window.location.pathname + (urlParams.toString() ? '?' + urlParams.toString() : '') + window.location.hash;
                    window.history.replaceState({}, document.title, newUrl);
                }

                // Check for cloud storage disabled
                if (urlParams.get('cloud_storage_disabled') === '1') {
                    var message = (typeof wt_cloud_storage_params !== 'undefined' && wt_cloud_storage_params.msgs && wt_cloud_storage_params.msgs.cloud_storage_disabled) 
                        ? wt_cloud_storage_params.msgs.cloud_storage_disabled 
                        : 'Cloud storage is disabled. Documents will not be automatically uploaded to cloud storage.';
                    wf_notify_msg.error(message);

                    // Clean URL by removing the parameter
                    urlParams.delete('cloud_storage_disabled');
                    var newUrl = window.location.pathname + (urlParams.toString() ? '?' + urlParams.toString() : '') + window.location.hash;
                    window.history.replaceState({}, document.title, newUrl);
                }
                
            },
            
            initUpdateDropboxLink: function() {
                var self = this;
                
                // Function to check if app key and secret are empty
                var checkCredentialsEmpty = function() {
                    var $appKeyField = $('#wt_invoice_dropbox_app_key, input[name="wt_invoice_dropbox_app_key"], .wt_invoice_dropbox_app_key').first();
                    var appKey = $appKeyField.length ? $appKeyField.val().trim() : '';
                    var $appSecretField = $('input[name="wt_invoice_dropbox_app_secret"], #wt_invoice_dropbox_app_secret').first();
                    var appSecret = $appSecretField.length ? $appSecretField.val().trim() : '';
                    return !appKey || !appSecret;
                };
                
                // Function to show app_key_required toast
                var showAppKeyRequiredToast = function() {
                    if (typeof wf_notify_msg !== 'undefined' && typeof wt_cloud_storage_params !== 'undefined' && wt_cloud_storage_params.msgs && wt_cloud_storage_params.msgs.app_key_required) {
                        wf_notify_msg.error(wt_cloud_storage_params.msgs.app_key_required);
                    }
                };
                
                // Update link URL when app key changes
                $(document).on('input change keyup paste', '#wt_invoice_dropbox_app_key, input[name="wt_invoice_dropbox_app_key"], .wt_invoice_dropbox_app_key', function() {
                    var $appKeyField = $('#wt_invoice_dropbox_app_key, input[name="wt_invoice_dropbox_app_key"], .wt_invoice_dropbox_app_key').first();
                    var appKey = $appKeyField.length ? $appKeyField.val().trim() : '';
                    var $link = $('#dropbox-access-code-link');
                    
                    if ($link.length) {
                        var authUrl = appKey ? 'https://www.dropbox.com/oauth2/authorize?client_id=' + encodeURIComponent(appKey) + '&token_access_type=offline&response_type=code' : 'https://www.dropbox.com/developers';
                        $link.attr('href', authUrl || '#');
                    }
                });
                
                // Handle click on Dropbox Access Code link
                $(document).on('click', '#dropbox-access-code-link', function(e) {
                    if (checkCredentialsEmpty()) {
                        e.preventDefault();
                        showAppKeyRequiredToast();
                        return false;
                    }
                });
                
                // Initialize link URL on page load
                var $appKeyField = $('#wt_invoice_dropbox_app_key, input[name="wt_invoice_dropbox_app_key"], .wt_invoice_dropbox_app_key').first();
                var appKey = $appKeyField.length ? $appKeyField.val().trim() : '';
                var $link = $('#dropbox-access-code-link');
                
                if ($link.length) {
                    var authUrl = appKey ? 'https://www.dropbox.com/oauth2/authorize?client_id=' + encodeURIComponent(appKey) + '&token_access_type=offline&response_type=code' : 'https://www.dropbox.com/developers';
                    $link.attr('href', authUrl || '#');
                }
            },

            sendAjaxRequest: function(action, additionalData, successCallback, errorCallback) {
                var elm = $('.wf_settings_form');
                var data = elm.serialize();
                data += '&action=' + action;
                
                if (additionalData) {
                    for (var key in additionalData) {
                        if (additionalData.hasOwnProperty(key)) {
                            data += '&' + key + '=' + encodeURIComponent(additionalData[key]);
                        }
                    }
                }

                jQuery.ajax({
                    url: wt_cloud_storage_params.ajaxurl,
                    type: 'POST',
                    data: data,
                    success: successCallback || function(response) {
                        // Handle auth_fail in success callback (wp_send_json_error still returns 200 status)
                        if (!response.success && response.data && response.data.message === 'auth_fail' && response.data.redirect_url) {
                            // Redirect with fail parameter - toast will be shown by checkUrlParams()
                            window.location.href = response.data.redirect_url;
                        } else if (response.success && response.data && response.data.message === 'auth_success' && response.data.redirect_url) {
                            // Redirect with success parameter - toast will be shown by checkUrlParams()
                            window.location.href = response.data.redirect_url;
                        } else if (response.success && response.data && response.data.message === 'disconnect_success' && response.data.redirect_url) {
                            // Redirect with disconnect success parameter - toast will be shown by checkUrlParams()
                            window.location.href = response.data.redirect_url;
                        } else if (response.success) {
                            // Fallback for other success responses
                            if (typeof wf_notify_msg !== 'undefined') {
                                wf_notify_msg.success(wt_cloud_storage_params.msgs.settings_updated || 'Settings Updated.');
                            } else {
                                alert(wt_cloud_storage_params.msgs.settings_updated || 'Settings Updated.');
                            }
                        } else if (!response.success && response.data && response.data.message === 'auth_fail') {
                            // Handle auth_fail without redirect_url
                            if (typeof wf_notify_msg !== 'undefined') {
                                wf_notify_msg.error(wt_cloud_storage_params.msgs.auth_fail || 'Failed to authorize with Dropbox. Please check your access code.');
                            } else {
                                alert(wt_cloud_storage_params.msgs.auth_fail || 'Failed to authorize with Dropbox. Please check your access code.');
                            }
                        }
                    },
                    error: errorCallback || function(response) {
                        if (response.responseJSON && response.responseJSON.data && response.responseJSON.data.message === 'auth_fail' && response.responseJSON.data.redirect_url) {
                            // Redirect with fail parameter - toast will be shown by checkUrlParams()
                            window.location.href = response.responseJSON.data.redirect_url;
                        } else if (response.responseJSON && response.responseJSON.data && response.responseJSON.data.message === 'auth_fail') {
                            if (typeof wf_notify_msg !== 'undefined') {
                                wf_notify_msg.error(wt_cloud_storage_params.msgs.auth_fail || 'Failed to authorize with Dropbox. Please check your access code.');
                            } else {
                                alert(wt_cloud_storage_params.msgs.auth_fail || 'Failed to authorize with Dropbox. Please check your access code.');
                            }
                        } else {
                            if (typeof wf_notify_msg !== 'undefined') {
                                wf_notify_msg.error('An error occurred. Please try again.');
                            } else {
                                alert('An error occurred. Please try again.');
                            }
                        }
                    }
                });
            },

            dropboxConnection: function() {
                $(document).on('click', '.wt-dropbox-authorize-btn', function(e) {
                    e.preventDefault();
                    
                    // Check if app key and secret are empty
                    var $appKeyField = $('#wt_invoice_dropbox_app_key, input[name="wt_invoice_dropbox_app_key"], .wt_invoice_dropbox_app_key').first();
                    var appKey = $appKeyField.length ? $appKeyField.val().trim() : '';
                    var $appSecretField = $('input[name="wt_invoice_dropbox_app_secret"], #wt_invoice_dropbox_app_secret').first();
                    var appSecret = $appSecretField.length ? $appSecretField.val().trim() : '';
                    
                    if (!appKey || !appSecret) {
                        if (typeof wf_notify_msg !== 'undefined' && typeof wt_cloud_storage_params !== 'undefined' && wt_cloud_storage_params.msgs && wt_cloud_storage_params.msgs.app_key_required) {
                            wf_notify_msg.error(wt_cloud_storage_params.msgs.app_key_required);
                        }
                        return false;
                    }
                    
                    var accessCode = $('#wt_invoice_dropbox_access_code').val();
                    var wt_enable_cloud_storage = $('#wt_invoice_enable_cloud_storage').val();
                    
                    wt_pklist_cloud_storage.sendAjaxRequest('wt_dropbox_connection', {
                        'wt_invoice_dropbox_access_code': accessCode,
                        'wt_invoice_enable_cloud_storage': wt_enable_cloud_storage,
                        'wt_invoice_connect_dropbox': '1'
                    });
                });
            },

            disconnectDropbox: function() {
                $(document).on('click', '.wt-dropbox-disconnect-btn', function(e) {
                    e.preventDefault();
                    
                    var confirmMsg = $(this).data('confirm') || (typeof wt_cloud_storage_params !== 'undefined' && wt_cloud_storage_params.msgs && wt_cloud_storage_params.msgs.disconnect_confirm) || 'Are you sure you want to disconnect from Dropbox?';
                    
                    if (!confirm(confirmMsg)) {
                        return false;
                    }
                    
                    wt_pklist_cloud_storage.sendAjaxRequest('wt_dropbox_connection', {
                        'wt_invoice_disconnect_dropbox': '1'
                    });
                });
            },

            handleCloudStorageToggle: function() {
                var self = this;
                // Listen for change on all checkboxes related to cloud storage
                $(document).on('change', 'input[type="checkbox"][id="wt_invoice_enable_cloud_storage"], input[type="checkbox"][name="wt_invoice_enable_cloud_storage"], input[type="checkbox"].wt_invoice_enable_cloud_storage', function() {
                    var $checkbox = $(this);
                    var isChecked = $checkbox.is(':checked');
                    
                    // If checkbox is unchecked, show the message
                    if (!isChecked && typeof wf_notify_msg !== 'undefined') {
                        var message = (typeof wt_cloud_storage_params !== 'undefined' && wt_cloud_storage_params.msgs && wt_cloud_storage_params.msgs.cloud_storage_disabled) 
                            ? wt_cloud_storage_params.msgs.cloud_storage_disabled 
                            : 'Cloud storage is disabled. Documents will not be automatically uploaded to cloud storage.';
                        wf_notify_msg.error(message);
                    }
                });
            }
        };
        wt_pklist_cloud_storage.Set();
    });

})(jQuery);

