<?php

/**
 * Dropbox Uploader Class
 *
 * @package    Wt_woocommerce_invoice_addon
 * @subpackage Wt_woocommerce_invoice_addon/admin/modules/cloud-storage/dropbox
 * @author     WebToffee <info@webtoffee.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'Wt_Invoice_Addon_Dropbox_Uploader' ) ) :

/**
 * Dropbox Uploader Class
 * 
 * Handles document uploads to Dropbox with proper error handling
 */
class Wt_Invoice_Addon_Dropbox_Uploader {

	/**
	 * @var Wt_Invoice_Addon_Dropbox_API
	 */
	private $dropbox_api;

	/**
	 * @var string
	 */
	private $upload_folder;

	/**
	 * @var bool
	 */
	private $cloud_storage_enabled;

	/**
	 * @var object
	 */
	private $customizer;

	/**
	 * @var object
	 */
	private $parent_class;

	/**
	 * @var bool Static flag to ensure hooks are only added once
	 */
	private static $hooks_added = false;

	/**
	 * Construct
	 * 
	 * @return void
	 */
	public function __construct() {
		// Load Dropbox API - use global instance if available to prevent duplicates
		global $wt_invoice_dropbox_api;
		if ( isset( $wt_invoice_dropbox_api ) && is_object( $wt_invoice_dropbox_api ) ) {
			$this->dropbox_api = $wt_invoice_dropbox_api;
		} else {
			include_once plugin_dir_path( __FILE__ ) . 'class-dropbox-api.php';
			// Check if global was set by the include, otherwise create new instance
			if ( isset( $wt_invoice_dropbox_api ) && is_object( $wt_invoice_dropbox_api ) ) {
				$this->dropbox_api = $wt_invoice_dropbox_api;
			} elseif ( class_exists( 'Wt_Invoice_Addon_Dropbox_API' ) ) {
				$this->dropbox_api = new Wt_Invoice_Addon_Dropbox_API();
				// Set global for future use
				$wt_invoice_dropbox_api = $this->dropbox_api;
			} else {
				$this->dropbox_api = null;
			}
		}
		
		$print_invoice_plugin_file = WP_PLUGIN_DIR . '/print-invoices-packing-slip-labels-for-woocommerce/public/modules/invoice/invoice.php';

        if ( file_exists( $print_invoice_plugin_file ) ) {
            include_once( $print_invoice_plugin_file );
        }

		// Get settings
		$this->upload_folder = Wf_Woocommerce_Packing_List::get_option( 'wt_invoice_dropbox_folder' );
		$this->cloud_storage_enabled = !empty( Wf_Woocommerce_Packing_List::get_option( 'wt_invoice_enable_cloud_storage') );
		// Initialize customizer and parent class properties
		$this->customizer = null;
		$this->parent_class = null;
		
		// Add hooks for automatic file upload - only once to prevent duplicate hooks
		if ( ! self::$hooks_added ) {
			add_filter('wt_upload_documets_to_cloud_storage', array($this, 'add_dropbox_attachments'), 10, 3);
			self::$hooks_added = true;
		}

	}

	/**
	 * Initialize customizer and parent class when needed
	 * 
	 * @param string $template_type The document type (invoice, packinglist, creditnote)
	 * @return void
	 */
	private function init_customizer( $template_type = 'invoice' ) {
		if ( $this->customizer === null ) {
			if ( class_exists( 'Wf_Woocommerce_Packing_List' ) ) {
				$this->customizer = Wf_Woocommerce_Packing_List::load_modules('customizer');
			}
		}
		
		if ( $template_type === 'invoice' && class_exists( 'Wf_Woocommerce_Packing_List_Invoice' ) ) {
			return;
		} elseif ( $template_type === 'packinglist' && class_exists( 'Wf_Woocommerce_Packing_List_Packinglist_Pro' ) ) {
			$this->parent_class = new Wf_Woocommerce_Packing_List_Packinglist_Pro();
		} elseif ( $template_type === 'creditnote' && class_exists( 'Wf_Woocommerce_Packing_List_Creditnote_Pro' ) ) {
			$this->parent_class = new Wf_Woocommerce_Packing_List_Creditnote_Pro();
		} elseif ( $this->parent_class === null && class_exists( 'Wf_Woocommerce_Packing_List' ) ) {
			// Fallback to invoice if no parent class is set
			$this->parent_class = Wf_Woocommerce_Packing_List::load_modules('invoice');
		}
	}

	/**
	 * Upload invoice to Dropbox
	 * 
	 * @param int $order_id
	 * @param string $chosen_wc_email_classes
	 * @param string $template_type
	 * @return array Empty array (filter callback)
	 */
	public function add_dropbox_attachments( $order_id, $chosen_wc_email_classes, $template_type ) {
		// Return early if cloud storage is disabled or shouldn't upload
		if ( ! $this->cloud_storage_enabled || ! $this->should_upload( $template_type ) ) {
			return array();
		}

		$attachments = array();

		// Check if this specific document type for this order has already been uploaded to prevent duplicates
        $uploaded_documents = get_transient( 'wt_invoice_dropbox_uploaded_documents' );
        if ( !is_array( $uploaded_documents ) ) {
            $uploaded_documents = array();
        } 
        
        // Create a unique key for this document type and order
        $document_key = $order_id . '_' . $template_type;
        
        // If this specific document for this order was already uploaded in this session, skip it
        if ( in_array( $document_key, $uploaded_documents ) ) {
            return array();
        }
		
		// Check for concurrent upload prevention using transient lock
		$upload_lock = get_transient( 'wt_invoice_dropbox_upload_lock_' . $document_key );
		if ( $upload_lock ) {
			// Upload already in progress, skip to prevent memory exhaustion from concurrent uploads
			return array();
		}
		
		// Set upload lock (expires in 5 minutes to prevent stuck locks)
		set_transient( 'wt_invoice_dropbox_upload_lock_' . $document_key, true, 300 );
		
		global $wt_invoice_dropbox_api;
        if ( isset( $wt_invoice_dropbox_api ) && is_object( $wt_invoice_dropbox_api ) ) {
            $dropbox_api = $wt_invoice_dropbox_api;
        } else {
            // Create a new instance if global doesn't exist
            if ( class_exists( 'Wt_Invoice_Addon_Dropbox_API' ) ) {
                $dropbox_api = new Wt_Invoice_Addon_Dropbox_API();
            } else {
                $dropbox_api = null;
            }
        }

        // Initialize customizer first (needed for all document types)
		$this->init_customizer( $template_type );
		
		// Check if customizer is available
		if ( $this->customizer === null ) {
			delete_transient( 'wt_invoice_dropbox_upload_lock_' . $document_key );
			return array();
		}
		
		// This prevents hook duplication while ensuring correct PDF generation
		$temp_invoice_instance = null;
		if ( $template_type === 'invoice' && class_exists( 'Wf_Woocommerce_Packing_List_Invoice' ) ) {
			// Create temporary instance for PDF generation only
			$temp_invoice_instance = new Wf_Woocommerce_Packing_List_Invoice();
			$this->parent_class = $temp_invoice_instance;
			
			// to prevent duplicate buttons in order
			if ( $temp_invoice_instance->is_enable_invoice === 'Yes' ) {
				remove_filter( 'wt_email_print_actions', array( $temp_invoice_instance, 'add_email_print_buttons' ), 10 );
			}
		} else {
			// For other types, use normal initialization
			if ( $this->parent_class === null ) {
				$this->init_customizer( $template_type );
			}
		}
		
		// Check if parent class is available
		if ( $this->parent_class === null ) {
			delete_transient( 'wt_invoice_dropbox_upload_lock_' . $document_key );
			return array();
		}

		$order_ids = array($order_id);
		if ( $template_type === 'creditnote' ) {
			$order = wc_get_order($order_id);
			$refund_ids = $order->get_refunds();
			$refund_ids = array();
			if ( $order ) {
				foreach ( $order->get_refunds() as $refund ) {
					$refund_ids[] = $refund->get_id();
				}
			}
			$wf_invoice_pdf_name_format = Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_custom_pdf_name', $this->parent_class->module_id );
			$wf_invoice_pdf_name_prefix = Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_custom_pdf_name_prefix', $this->parent_class->module_id );
			$wf_invoice_pdf_name_prefix = !empty( $wf_invoice_pdf_name_prefix ) ? sanitize_text_field( $wf_invoice_pdf_name_prefix ) : 'Creditnote_';

			if("[prefix][invoice_no]" === $wf_invoice_pdf_name_format){
				foreach($refund_ids as $refund_id){
					$crt_no = Wt_Pklist_Common::get_order_meta($refund_id,'wf_creditnote_number',true);
				}
				$pdf_name = $wf_invoice_pdf_name_prefix.$crt_no;
			} elseif ("[prefix][order_no]" === $wf_invoice_pdf_name_format) {
				$pdf_name = $wf_invoice_pdf_name_prefix.$order->get_order_number();
			}
		
		} else {
			
			$pdf_name = $this->customizer->generate_pdf_name($template_type,$order_ids);
		}

		$this->customizer->template_for_pdf = true;
		$html = $this->generate_order_template($order_ids, $pdf_name, $template_type);

        // Clean up temporary invoice instance immediately after use
        if ( $temp_invoice_instance !== null ) {
        	$this->parent_class = null;
        	unset( $temp_invoice_instance );
        }
        
        // Initialize attachments array
        $attachment = $this->customizer->generate_template_pdf($html, $template_type, $pdf_name, 'attach');
		
		// Check if Dropbox API is initialized and connected
        if ( ! $this->dropbox_api || ! is_object( $this->dropbox_api ) || ! $this->dropbox_api->is_connected() ) {
			delete_transient( 'wt_invoice_dropbox_upload_lock_' . $document_key );
            return array();
        }

        if ( is_string( $attachment ) && file_exists( $attachment ) && pathinfo( $attachment, PATHINFO_EXTENSION ) === 'pdf' ) {
                
			// Get upload folder from settings
			$upload_folder = Wf_Woocommerce_Packing_List::get_option( 'wt_invoice_dropbox_folder');

			// Get the filename from the attachments path
			$filename = basename( $attachment );
			$dropbox_path = $upload_folder . '/' . $filename;
                
			// Upload the actual PDF file to Dropbox
			$upload_result = false;
			if ( $dropbox_api && is_object( $dropbox_api ) ) {
				$upload_result = $dropbox_api->upload_file( $attachment, $dropbox_path );
			}
			
			// Clear upload lock regardless of success/failure
			delete_transient( 'wt_invoice_dropbox_upload_lock_' . $document_key );
			
			if ( $upload_result ) {
				// Mark as uploaded to prevent duplicates
				$uploaded_documents[] = $document_key;
				set_transient( 'wt_invoice_dropbox_uploaded_documents', $uploaded_documents, 300 ); // Expire in 5 minutes
			}
		} else {
			// Clear lock if file doesn't exist or isn't a PDF
			delete_transient( 'wt_invoice_dropbox_upload_lock_' . $document_key );
		}
        
        return array();
    }

	
	/**
	 * Upload file to Dropbox
	 * 
	 * @param string $file_path
	 * @param string $dropbox_path
	 * @param int $order_id
	 * @param string $document_type
	 * @return bool
	 */
	private function upload_file( $file_path, $dropbox_path, $order_id, $document_type ) {
		// Check if Dropbox API is initialized
		if ( ! $this->dropbox_api || ! is_object( $this->dropbox_api ) ) {
			$this->log_error( 'Dropbox API not initialized for order ' . $order_id );
			return false;
		}
		
		// Check if Dropbox is connected
		if ( ! $this->dropbox_api->is_connected() ) {
			$this->log_error( 'Dropbox not connected for order ' . $order_id );
			return false;
		}

		// Check if file exists
		if ( ! file_exists( $file_path ) ) {
			$this->log_error( 'File not found: ' . $file_path . ' for order ' . $order_id );
			return false;
		}

		// Check file size
		$file_size = filesize( $file_path );
		if ( $file_size === false || $file_size === 0 ) {
			$this->log_error( 'Invalid file size for: ' . $file_path . ' for order ' . $order_id );
			return false;
		}

		// Upload to Dropbox
		$result = $this->dropbox_api->upload_file( $file_path, $dropbox_path );
		
		if ( $result ) {
			$this->log_success( sprintf( '%s uploaded to Dropbox for order %s: %s', ucfirst( $document_type ), $order_id, $dropbox_path ) );
			
			// Store upload record in order meta
			$this->store_upload_record( $order_id, $document_type, $dropbox_path, $file_path );
			
			return true;
		} else {
			$this->log_error( sprintf( 'Failed to upload %s to Dropbox for order %s', $document_type, $order_id ) );
			return false;
		}
	}

	/**
	 * Check if upload should proceed
	 * 
	 * @param string $document_type
	 * @return bool
	 */
	private function should_upload( $document_type ) {
		// Check if Dropbox API is initialized
		if ( ! $this->dropbox_api || ! is_object( $this->dropbox_api ) ) {
			return false;
		}
		
		// Check if Dropbox is connected
		if ( ! $this->dropbox_api->is_connected() ) {
			return false;
		}
		
		// For invoice, check if the invoice module itself is enabled
		if ( $document_type === 'invoice' ) {
			$invoice_module_id = Wf_Woocommerce_Packing_List::get_module_id( 'invoice' );
			$invoice_enabled = Wf_Woocommerce_Packing_List::get_option( 'woocommerce_wf_enable_invoice', $invoice_module_id );
			if ( $invoice_enabled !== 'Yes' ) {
				return false;
			}
		}
		
		// Get selected document types from wt_invoice_dropbox_documents option
		$selected_documents = Wf_Woocommerce_Packing_List::get_option( 'wt_invoice_dropbox_documents' );
		
		// Ensure it's an array
		if ( ! is_array( $selected_documents ) ) {
			$selected_documents = array();
		}
		
		// Map template_type values to option keys used in wt_invoice_dropbox_documents
		$document_type_map = array(
			'invoice' => 'invoice',
			'packinglist' => 'packinglist',
			'creditnote' => 'creditnote',
		);
		
		// Check if the document type is selected for upload
		$option_key = isset( $document_type_map[ $document_type ] ) ? $document_type_map[ $document_type ] : $document_type;
		
		return in_array( $option_key, $selected_documents, true );
	}

	/**
	 * Store upload record in order meta
	 * 
	 * @param int $order_id
	 * @param string $document_type
	 * @param string $dropbox_path
	 * @param string $local_file_path
	 * @return void
	 */
	private function store_upload_record( $order_id, $document_type, $dropbox_path, $local_file_path ) {
		$upload_record = array(
			'document_type' => $document_type,
			'dropbox_path' => $dropbox_path,
			'local_file_path' => $local_file_path,
			'uploaded_at' => current_time( 'mysql' ),
			'file_size' => filesize( $local_file_path ),
		);

		$existing_records = get_post_meta( $order_id, '_wt_dropbox_uploads', true );
		if ( ! is_array( $existing_records ) ) {
			$existing_records = array();
		}

		$existing_records[] = $upload_record;
		update_post_meta( $order_id, '_wt_dropbox_uploads', $existing_records );
	}

	/**
	 * Get upload history for an order
	 * 
	 * @param int $order_id
	 * @return array
	 */
	public function get_upload_history( $order_id ) {
		$uploads = get_post_meta( $order_id, '_wt_dropbox_uploads', true );
		return is_array( $uploads ) ? $uploads : array();
	}

	/**
	 * Log success message
	 * 
	 * @param string $message
	 * @return void
	 */
	private function log_success( $message ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug logging only when WP_DEBUG is enabled.
			error_log( '[WT Invoice Addon - Dropbox Success] ' . $message );
		}
	}

	/**
	 * Log error message
	 * 
	 * @param string $message
	 * @return void
	 */
	private function log_error( $message ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug logging only when WP_DEBUG is enabled.
			error_log( '[WT Invoice Addon - Dropbox Error] ' . $message );
		}
	}

	/**
	 * Clear uploaded documents transient (for testing/debugging)
	 * 
	 * @return bool
	 */
	public function clear_uploaded_documents_transient() {
		$result = delete_transient( 'wt_invoice_dropbox_uploaded_documents' );
		$this->log_success( 'Cleared uploaded documents transient' );
		return $result;
	}

	/**
	 * Get upload statistics
	 * 
	 * @return array
	 */
	public function get_upload_stats() {
		global $wpdb;
		
		$stats = array(
			'total_uploads' => 0,
			'successful_uploads' => 0,
			'failed_uploads' => 0,
			'last_upload' => null,
		);

		$cache_key = 'wt_dropbox_upload_stats';
		$cached_stats = wp_cache_get( $cache_key, 'wt_invoice_addon' );

		if ( false !== $cached_stats ) {
			return $cached_stats;
		}

		// Count orders with upload records
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Caching is handled manually above, direct query needed for aggregate count.
		$upload_orders = $wpdb->get_var( "
			SELECT COUNT(DISTINCT post_id) 
			FROM {$wpdb->postmeta} 
			WHERE meta_key = '_wt_dropbox_uploads'
		" );

		if ( $upload_orders ) {
			$stats['total_uploads'] = $upload_orders;
			
			// Get last upload time
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Caching is handled manually, direct query needed to get latest record.
			$last_upload = $wpdb->get_var( "
				SELECT meta_value 
				FROM {$wpdb->postmeta} 
				WHERE meta_key = '_wt_dropbox_uploads' 
				ORDER BY meta_id DESC 
				LIMIT 1
			" );
			
			if ( $last_upload ) {
				$uploads = maybe_unserialize( $last_upload );
				if ( is_array( $uploads ) && ! empty( $uploads ) ) {
					$last_upload_record = end( $uploads );
					$stats['last_upload'] = $last_upload_record['uploaded_at'];
				}
			}
		}

		// Cache for 5 minutes
		wp_cache_set( $cache_key, $stats, 'wt_invoice_addon', 300 );

		return $stats;
	}

	/**
	 * Generate order template HTML
	 * 
	 * @param array $order_ids
	 * @param string $pdf_name
	 * @param string $template_type The document type (invoice, packinglist, creditnote)
	 * @return string
	 */
	private function generate_order_template($order_ids, $pdf_name, $template_type = 'invoice') {
		// Ensure parent class is loaded for the correct template type
		if ( $this->parent_class === null ) {
			$this->init_customizer( $template_type );
		}
		
		if ($this->parent_class && method_exists($this->parent_class, 'generate_order_template')) {
			// Handle different method signatures for different document types
			if ( $template_type === 'creditnote' ) {
				// Credit note uses a different signature - needs page_title as reference
				$page_title = '';
				return $this->parent_class->generate_order_template($order_ids, $page_title);
			} elseif ( $template_type === 'packinglist' ) {
				// Packing list can accept html and action parameters
				return $this->parent_class->generate_order_template($order_ids, $pdf_name, '', '');
			} else {
				// Invoice - uses standard signature
				return $this->parent_class->generate_order_template($order_ids, $pdf_name);
			}
		}
		
		return '';
	}
}

endif; // class_exists

// Create a global instance only if not already set
// This prevents multiple instantiations that could cause memory issues
global $wt_invoice_dropbox_uploader;
if ( ! isset( $wt_invoice_dropbox_uploader ) ) {
	$wt_invoice_dropbox_uploader = new Wt_Invoice_Addon_Dropbox_Uploader();
}

// Return the global instance (always return the same instance to prevent duplicates)
return $wt_invoice_dropbox_uploader;
