<?php
/**
 * Cloud Storage Module
 *
 * @package    Wt_woocommerce_invoice_addon
 * @subpackage Wt_woocommerce_invoice_addon/admin/modules/cloud-storage
 * @author     WebToffee <info@webtoffee.com>
 * @since      1.6.7
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'Wt_Cloud_Storage' ) ) {

	/**
	 * Cloud Storage Module Class
	 *
	 * @since 1.6.7
	 */
	class Wt_Cloud_Storage {

		/**
		 * Instance of this class
		 *
		 * @var object|null
		 */
		private static $instance = null;

		/**
		 * Module base
		 *
		 * @var string
		 */

		/**
		 * Plugin name
		 *
		 * @var string
		 */
		private $plugin_name;

		/**
		 * Plugin version
		 *
		 * @var string
		 */
		private $version;

        public $module_id = '';
        public $module_base = 'cloud-storage';

        /**
         * @var Wt_Invoice_Addon_Dropbox_API
         */
        private $dropbox_api;

        /**
         * @var Wt_Invoice_Addon_Dropbox_Uploader
         */
        private $dropbox_uploader;

		/**
		 * Constructor
		 *
		 * @since 1.6.7
		 */
		public function __construct() {
			// Get plugin name and version from admin class if available
			if ( class_exists( 'Wt_woocommerce_invoice_addon_Admin' ) ) {
				// We'll get these values when enqueuing scripts
			}
            $this->module_id = Wf_Woocommerce_Packing_List::get_module_id( $this->module_base );
            
            // Load Dropbox API - include file and get global instance
            include_once plugin_dir_path( __FILE__ ) . 'dropbox/class-dropbox-api.php';
            global $wt_invoice_dropbox_api;
            $this->dropbox_api = isset( $wt_invoice_dropbox_api ) && is_object( $wt_invoice_dropbox_api ) ? $wt_invoice_dropbox_api : null;
            
            // Load Dropbox Uploader - include file and get global instance
            include_once plugin_dir_path( __FILE__ ) . 'dropbox/class-dropbox-uploader.php';
            global $wt_invoice_dropbox_uploader;
            $this->dropbox_uploader = isset( $wt_invoice_dropbox_uploader ) && is_object( $wt_invoice_dropbox_uploader ) ? $wt_invoice_dropbox_uploader : null;
			// Enqueue scripts and styles
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
            add_action( 'wp_ajax_wt_dropbox_connection', array( $this, 'wt_dropbox_connection' ) );
			
            // Hook to process dropbox documents field after settings save
            add_action( 'admin_init', array( $this, 'save_dropbox_documents_fields_after_update' ), 10, 1 );
		}

		/**
		 * Get instance of this class
		 *
		 * @since 1.6.7
		 * @return Wt_Cloud_Storage
		 */
		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

        /**
	 * Get Dropbox API instance
	 * 
	 * @return Wt_Invoice_Addon_Dropbox_API
	 */
	public function get_dropbox_api() {
		return $this->dropbox_api;
	}

	/**
	 * Get Dropbox Uploader instance
	 * 
	 * @return Wt_Invoice_Addon_Dropbox_Uploader
	 */
	public function get_dropbox_uploader() {
		return $this->dropbox_uploader;
	}

	/**
	 * Check if cloud storage is enabled
	 * 
	 * @return bool
	 */
	public function is_enabled() {
		if ( ! $this->dropbox_api || ! is_object( $this->dropbox_api ) ) {
			return false;
		}
		return $this->dropbox_api->is_connected();
	}

		/**
		 * Enqueue scripts and styles
		 *
		 * @since 1.6.7
		 */
		public function enqueue_scripts() { 
			// Only load on the settings page with cloud-storage tab
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- This is a page routing check, not form processing.
			$current_page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
			if ( $this->module_id == 'wf_woocommerce_packing_list_cloud-storage' && 'wf_woocommerce_packing_list' === $current_page ) {
				
				// Get plugin info
                
				$plugin_name = 'wt-woocommerce-invoice-addon';
				$version     = defined( 'WT_PKLIST_INVOICE_ADDON_VERSION' ) ? WT_PKLIST_INVOICE_ADDON_VERSION : '1.6.7';

				// Enqueue cloud storage JavaScript
				wp_enqueue_script(
					$plugin_name . '-cloud-storage-js',
					plugin_dir_url( __FILE__ ) . 'assets/js/wt-cloud-storage.js',
					array( 'jquery' ),
					$version,
					false
				);

				// Localize cloud storage script
				$cloud_storage_params = array(
					'nonces' => array(
						'wf_packlist' => wp_create_nonce( WF_PKLIST_PLUGIN_NAME ),
					),
					'ajaxurl' => admin_url( 'admin-ajax.php' ),
					'msgs' => array(
						'app_key_required' => __( 'Please enter your Dropbox App Key and App Secret first.', 'wt-woocommerce-invoice-addon' ),
						'disconnect_confirm' => __( 'Are you sure you want to disconnect from Dropbox?', 'wt-woocommerce-invoice-addon' ),
						'authorize' => __( 'Authorize', 'wt-woocommerce-invoice-addon' ),
						'cloud_storage_disabled' => __( 'Cloud storage is disabled. Documents will not be automatically uploaded to cloud storage.', 'wt-woocommerce-invoice-addon' ),
						'settings_updated' => __( 'Settings Updated.', 'wt-woocommerce-invoice-addon' ),
						'auth_success' => __( 'Successfully authorized with Dropbox!', 'wt-woocommerce-invoice-addon' ),
						'auth_fail' => __( 'Failed to authorize with Dropbox. Please check your access code.', 'wt-woocommerce-invoice-addon' ),
						'disconnect_success' => __( 'Successfully disconnected from Dropbox and cleared access code.', 'wt-woocommerce-invoice-addon' ),
					),
				);
				wp_localize_script( $plugin_name . '-cloud-storage-js', 'wt_cloud_storage_params', $cloud_storage_params );
			}
		}

        public function wt_dropbox_connection() {

        // Handle main form submission - check if authorize button was clicked
            $nonce = isset( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) : '';
            if ( ! empty( $nonce ) && wp_verify_nonce( $nonce, WF_PKLIST_PLUGIN_NAME ) ) {

                if ( isset($_POST['wt_invoice_connect_dropbox']) ) {

                    $wt_invoice_enable_cloud_storage = isset( $_POST['wt_invoice_enable_cloud_storage'] ) ? sanitize_text_field( wp_unslash( $_POST['wt_invoice_enable_cloud_storage'] ) ) : '';               
                    $client_id = isset( $_POST['wt_invoice_dropbox_app_key'] ) ? sanitize_text_field( wp_unslash( $_POST['wt_invoice_dropbox_app_key'] ) ) : '';
                    $access_code = isset( $_POST['wt_invoice_dropbox_access_code'] ) ? sanitize_text_field( wp_unslash( $_POST['wt_invoice_dropbox_access_code'] ) ) : '';

					// Save Dropbox app secret
					if ( isset( $_POST['wt_invoice_dropbox_app_secret'] ) ) {
						$app_secret = sanitize_text_field( wp_unslash( $_POST['wt_invoice_dropbox_app_secret'] ) );
							
						// Check if the value contains the corrupted pattern or is masked dots
						if ( strpos($app_secret, 'Kioq') === false ) {
							$decoded = Wf_Woocommerce_Packing_List::wf_decode($app_secret);
							$re_encoded = Wf_Woocommerce_Packing_List::wf_encode($decoded);

							if ($re_encoded === $app_secret && !empty($app_secret)) {
								// Already encoded, save as is
								Wf_Woocommerce_Packing_List::update_option( 'wt_invoice_dropbox_app_secret', $app_secret );
							} else {
								$app_secret = Wf_Woocommerce_Packing_List::wf_encode($app_secret);
								Wf_Woocommerce_Packing_List::update_option( 'wt_invoice_dropbox_app_secret', $app_secret );
							}
						}
					}
                    
                    // Save app key if provided
                    if ( ! empty( $client_id ) ) {
                        Wf_Woocommerce_Packing_List::update_option( 'wt_invoice_dropbox_app_key', $client_id );
                    }

                    // Handle access code - save if provided
                    $display_field_value = isset( $_POST['wt_invoice_dropbox_access_code_display'] ) ? sanitize_text_field( wp_unslash( $_POST['wt_invoice_dropbox_access_code_display'] ) ) : '';
                    $hidden_field_value = isset( $_POST['wt_invoice_dropbox_access_code'] ) ? sanitize_text_field( wp_unslash( $_POST['wt_invoice_dropbox_access_code'] ) ) : '';
                    
                    // Use display field if it has a real value (not masked dots), otherwise use hidden field
                    $access_code = '';
                    if ( $display_field_value && $display_field_value !== '••••••••••••••••••••••••••••••••' ) {
                        // New access code entered in display field
                        $access_code = Wf_Woocommerce_Packing_List::wf_encode($display_field_value);

                    } elseif ( $hidden_field_value ) {
                        // Use existing access code from hidden field
                        $access_code = $hidden_field_value;
                    }

					if ( ! empty( $client_id ) && ! empty( $app_secret ) && ! empty( $access_code ) ) {
                        // Check if Dropbox API is initialized
                        if ( ! $this->dropbox_api || ! is_object( $this->dropbox_api ) ) {
                            wp_send_json_error( array( 'message' => 'Dropbox API not initialized' ) );
                            return;
                        }
                        
                        // Update the Dropbox API instance with the new credentials
                        $this->dropbox_api->update_credentials( $client_id, $app_secret );
                        
                        // All fields provided - try to connect to Dropbox
                        $is_connected = $this->dropbox_api->exchange_and_save_token( $access_code );

                        if ( $is_connected ) {
                            Wf_Woocommerce_Packing_List::update_option( 'wt_invoice_dropbox_access_code', $access_code );
                            Wf_Woocommerce_Packing_List::update_option( 'wt_invoice_dropbox_access_code_encoded', $access_code );							
                            
                            // Connection successful - return redirect URL with success message
                            $redirect_url = add_query_arg( 'auth_success', '1', admin_url( 'admin.php?page=wf_woocommerce_packing_list&tab=cloud-storagecloud-storage#cloud-storage' ) );
                            wp_send_json_success( array( 'message' => 'auth_success', 'redirect_url' => $redirect_url ) );
                        } else {
                            // Connection failed - clear access code and return redirect URL with error
                            Wf_Woocommerce_Packing_List::update_option( 'wt_invoice_dropbox_access_code_encoded', '' );
                            $redirect_url = add_query_arg( 'auth_fail', '1', admin_url( 'admin.php?page=wf_woocommerce_packing_list&tab=cloud-storagecloud-storage#cloud-storage' ) );
                            wp_send_json_error( array( 'message' => 'auth_fail' ) );
                        }
                    } else {
                        // Missing required fields - return error
                        $redirect_url = add_query_arg( 'auth_fail', '1', admin_url( 'admin.php?page=wf_woocommerce_packing_list&tab=cloud-storagecloud-storage#cloud-storage' ) );
                        wp_send_json_error( array( 'message' => 'auth_fail', 'redirect_url' => $redirect_url ) );
                    }
                }

                if( isset($_POST['wt_invoice_disconnect_dropbox']) ) {
                    Wf_Woocommerce_Packing_List::update_option( 'wt_invoice_dropbox_access_code', '' );
					Wf_Woocommerce_Packing_List::update_option( 'wt_invoice_dropbox_access_code_encoded', '' );
                    $redirect_url = add_query_arg( 'disconnect_success', '1', admin_url( 'admin.php?page=wf_woocommerce_packing_list&tab=cloud-storagecloud-storage#cloud-storage' ) );
                    wp_send_json_success( array( 'message' => 'disconnect_success', 'redirect_url' => $redirect_url ) );
                }
            } else {
                // Nonce verification failed - return error
                wp_send_json_error( array( 'message' => 'Security check failed. Please refresh the page and try again.' ) );
            }
        }

        /**
         * Save individual document upload fields based on wt_invoice_dropbox_documents selection
         * This runs after settings are saved
         * 
         * @param array $the_options The saved options array
         * @param string $base_id The base ID
         * @return void
         */
        public function save_dropbox_documents_fields_after_update() {

            $documents = Wf_Woocommerce_Packing_List::get_option( 'wt_invoice_dropbox_documents' );

			$app_secret = Wf_Woocommerce_Packing_List::get_option( 'wt_invoice_dropbox_app_secret', '' );
			$app_key = Wf_Woocommerce_Packing_List::get_option( 'wt_invoice_dropbox_app_key', '' );
			$access_code = Wf_Woocommerce_Packing_List::get_option( 'wt_invoice_dropbox_access_code', '' );
			$encoded_access_code = Wf_Woocommerce_Packing_List::get_option( 'wt_invoice_dropbox_access_code_encoded', '' );


			if( empty($app_secret) || empty($app_key) ) {
				Wf_Woocommerce_Packing_List::update_option( 'wt_invoice_dropbox_access_code', '' );
				Wf_Woocommerce_Packing_List::update_option( 'wt_invoice_dropbox_access_code_encoded', '' );
			}

			if(!empty($encoded_access_code)) {
				Wf_Woocommerce_Packing_List::update_option( 'wt_invoice_dropbox_access_code', $encoded_access_code );
			}
        }
    }

	// Initialize the module
	Wt_Cloud_Storage::get_instance();
}

