<?php
/**
 * Dropbox API Class for Cloud Storage
 *
 * @package    Wt_woocommerce_invoice_addon
 * @subpackage Wt_woocommerce_invoice_addon/admin/modules/cloud-storage/dropbox
 * @author     WebToffee <info@webtoffee.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'Wt_Invoice_Addon_Dropbox_API' ) ) :

/**
 * Dropbox API Class
 * 
 * Handles Dropbox authentication and API operations with refresh token support
 */
class Wt_Invoice_Addon_Dropbox_API {

	/**
	 * @var string
	 */
	private $app_key;

	/**
	 * @var string
	 */
	private $app_secret;

	/**
	 * @var string
	 */
	private $redirect_uri;

	/**
	 * @var string
	 */
	private $access_token;

	/**
	 * @var string
	 */
	private $refresh_token;

	/**
	 * @var int
	 */
	private $token_expires_at;

	/**
	 * @var string
	 */
	private $settings_option = 'wt_invoice_addon_dropbox_settings';

	/**
	 * @var bool Static flag to ensure hooks are only added once
	 */
	private static $hooks_added = false;

	/**
	 * Construct
	 * 
	 * @return void
	 */
	public function __construct() {
		// Load app credentials from settings
		$this->app_key = Wf_Woocommerce_Packing_List::get_option( 'wt_invoice_dropbox_app_key' );
		$this->app_secret = Wf_Woocommerce_Packing_List::wf_decode( Wf_Woocommerce_Packing_List::get_option( 'wt_invoice_dropbox_app_secret', '' ) );

		// Use specific admin page as redirect URI for Dropbox OAuth
		$this->redirect_uri = admin_url( 'admin.php?page=wf_woocommerce_packing_list&tab=cloud-storage' );
		
		// Load tokens from settings
		$this->load_tokens();
		
		// Only add hooks once to prevent duplicate hook registrations
		if ( ! self::$hooks_added ) {
			// Handle OAuth callback
			if ( ! empty( $_REQUEST['wt_invoice_dropbox_code'] ) ) {
				$this->finish_auth();
			}
			
			// Handle OAuth callback from Dropbox (code parameter)
			if ( ! empty( $_REQUEST['code'] ) && ! empty( $_REQUEST['state'] ) ) {
				// Check if this is our OAuth callback by verifying the state parameter
				$state = sanitize_text_field( wp_unslash( $_REQUEST['state'] ) );
				if ( function_exists( 'wp_verify_nonce' ) && wp_verify_nonce( $state, 'wt_invoice_dropbox_auth' ) ) {
					// Convert to our internal format 
					$code = sanitize_text_field( wp_unslash( $_REQUEST['code'] ) );
					$_REQUEST['wt_invoice_dropbox_code'] = $code;
					$this->finish_auth();
				}
			}

			// Display success/failure messages
			if ( isset( $_REQUEST['wt_invoice_dropbox_success'] ) ) {
				add_action( 'admin_notices', array( $this, 'auth_success_notice' ) );
			}

			if ( isset( $_REQUEST['wt_invoice_dropbox_fail'] ) ) {
				add_action( 'admin_notices', array( $this, 'auth_fail_notice' ) );
			}
			
			self::$hooks_added = true;
		}
	}

	/**
	 * Load tokens from settings
	 * 
	 * @return void
	 */
	private function load_tokens() {
		$settings = Wf_Woocommerce_Packing_List::get_option( $this->settings_option );
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}
		$this->access_token = isset( $settings['access_token'] ) ? $settings['access_token'] : false;
		$this->refresh_token = isset( $settings['refresh_token'] ) ? $settings['refresh_token'] : false;
		$this->token_expires_at = isset( $settings['token_expires_at'] ) ? $settings['token_expires_at'] : 0;
	}

	/**
	 * Get authorization URL
	 * 
	 * @return string
	 */
	public function get_auth_url() {
		// Check if app credentials are configured
		if ( empty( $this->app_key ) || empty( $this->app_secret ) ) {
			return false;
		}
		
		$state = wp_create_nonce( 'wt_invoice_dropbox_auth' );
		
		return add_query_arg( array(
			'client_id'     => $this->app_key,
			'response_type' => 'code',
			'redirect_uri'  => urlencode( $this->redirect_uri ),
			'state'         => $state,
			'token_access_type' => 'offline', // Request refresh token
		), 'https://www.dropbox.com/oauth2/authorize' );
	}

	/**
	 * Exchange authorization code for access token and refresh token
	 * 
	 * @param string $auth_code
	 * @return array|false
	 */
	public function exchange_code_for_token( $auth_code ) {

		// Validate app credentials
		if ( empty( $this->app_key ) || empty( $this->app_secret ) ) {
			return false;
		}
		
		$response = wp_remote_post( 'https://api.dropboxapi.com/oauth2/token', array(
			'body' => array(
				'code'          => $auth_code,
				'grant_type'    => 'authorization_code',
				'client_id'     => $this->app_key,
				'client_secret' => $this->app_secret,
			),
			'timeout' => 30,
		) );

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$response_code = wp_remote_retrieve_response_code( $response );
		if ( $response_code !== 200 ) {
			return false;
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( isset( $data['access_token'] ) ) {
			return $data;
		}

		return false;
	}

	/**
	 * Exchange authorization code for token and save it
	 * 
	 * @param string $auth_code
	 * @return bool
	 */
	public function exchange_and_save_token( $auth_code ) {
		$auth_code = Wf_Woocommerce_Packing_List::wf_decode( $auth_code );
		
		if ( empty( $auth_code ) || strlen( $auth_code ) < 10 ) {
			return false;
		}
		
		if ( empty( $this->app_key ) || empty( $this->app_secret ) ) {
			return false;
		}
		
		$token_data = $this->exchange_code_for_token( $auth_code );

		if ( $token_data && isset( $token_data['access_token'] ) ) {
			$this->access_token = $token_data['access_token'];
			$this->refresh_token = isset( $token_data['refresh_token'] ) ? $token_data['refresh_token'] : '';
			$this->token_expires_at = time() + ( isset( $token_data['expires_in'] ) ? $token_data['expires_in'] : 14400 );
			
			$this->save_tokens();
			return true;
		}
		
		return false;
	}

	/**
	 * Refresh access token using refresh token
	 * 
	 * @return bool
	 */
	public function refresh_access_token() {
		if ( empty( $this->refresh_token ) ) {
			return false;
		}

		$response = wp_remote_post( 'https://api.dropboxapi.com/oauth2/token', array(
			'body' => array(
				'refresh_token' => $this->refresh_token,
				'grant_type'    => 'refresh_token',
				'client_id'     => $this->app_key,
				'client_secret' => $this->app_secret,
			),
		) );

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( isset( $data['access_token'] ) ) {
			$this->access_token = $data['access_token'];
			$this->token_expires_at = time() + ( isset( $data['expires_in'] ) ? $data['expires_in'] : 14400 );
			
			$this->save_tokens();
			return true;
		}

		return false;
	}

	/**
	 * Check if access token is expired and refresh if needed
	 * 
	 * @return bool
	 */
	public function ensure_valid_token() {
		if ( empty( $this->access_token ) ) {
			return $this->refresh_access_token();
		}

		if ( $this->token_expires_at && ( $this->token_expires_at - 300 ) < time() ) {
			return $this->refresh_access_token();
		}

		return true;
	}

	/**
	 * Finish the authorization process
	 * 
	 * @return void
	 */
	private function finish_auth() {
		if ( ! isset( $_REQUEST['wt_invoice_dropbox_code'] ) || ! isset( $_REQUEST['state'] ) ) {
			wp_die( esc_html__( 'Security check failed.', 'wt-woocommerce-invoice-addon' ) );
		}

		$code = sanitize_text_field( wp_unslash( $_REQUEST['wt_invoice_dropbox_code'] ) );
		$state = sanitize_text_field( wp_unslash( $_REQUEST['state'] ) );
		
		if ( ! function_exists( 'wp_verify_nonce' ) || ! wp_verify_nonce( $state, 'wt_invoice_dropbox_auth' ) ) {
			wp_die( esc_html__( 'Security check failed.', 'wt-woocommerce-invoice-addon' ) );
		}

		try {
			$token_data = $this->exchange_code_for_token( $code );

			if ( $token_data && isset( $token_data['access_token'] ) ) {
				$this->access_token = $token_data['access_token'];
				$this->refresh_token = isset( $token_data['refresh_token'] ) ? $token_data['refresh_token'] : '';
				$this->token_expires_at = time() + ( isset( $token_data['expires_in'] ) ? $token_data['expires_in'] : 14400 );
				
				$this->save_tokens();

				$redirect_url = add_query_arg( 'wt_invoice_dropbox_success', '1', admin_url( 'admin.php?page=wf_woocommerce_packing_list&tab=cloud-storage' ) );
				wp_redirect( $redirect_url );
				exit();
			} else {
				throw new Exception( __( 'Failed to exchange authorization code for access token.', 'wt-woocommerce-invoice-addon' ) );
			}
		} catch ( Exception $e ) {
			$redirect_url = add_query_arg( 'wt_invoice_dropbox_fail', '1', admin_url( 'admin.php?page=wf_woocommerce_packing_list&tab=cloud-storage' ) );
			wp_redirect( $redirect_url );
			exit();
		}
	}

	public function save_tokens() {
		$settings = Wf_Woocommerce_Packing_List::get_option( $this->settings_option );
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}
		$settings['access_token'] = $this->access_token;
		$settings['refresh_token'] = $this->refresh_token;
		$settings['token_expires_at'] = $this->token_expires_at;
		$settings['connected_at'] = current_time( 'timestamp' );
		Wf_Woocommerce_Packing_List::update_option( $this->settings_option, $settings );
	}

	public function get_access_token() {
		if ( $this->ensure_valid_token() ) {
			return $this->access_token;
		}
		return false;
	}

	public function is_configured() {
		return ! empty( $this->app_key ) && ! empty( $this->app_secret );
	}

	public function update_credentials( $app_key, $app_secret ) {
		$this->app_key = $app_key;
		$this->app_secret = Wf_Woocommerce_Packing_List::wf_decode( $app_secret );
	}

	public function is_connected() {
		$access_code = Wf_Woocommerce_Packing_List::get_option( 'wt_invoice_dropbox_access_code_encoded' );
		if ( empty( $access_code ) ) {
			return false;
		}

		return $this->ensure_valid_token();
	}

	public function disconnect() {
		Wf_Woocommerce_Packing_List::update_option( $this->settings_option, '' );
		Wf_Woocommerce_Packing_List::update_option( 'wt_invoice_dropbox_access_code', '' );
		Wf_Woocommerce_Packing_List::update_option( 'wt_invoice_dropbox_access_code_encoded', '' );
		$this->access_token = false;
		$this->refresh_token = false;
		$this->token_expires_at = 0;
	}

	public function auth_success_notice() {
		?>
		<div class="notice notice-success is-dismissible">
			<p><?php esc_html_e( 'Successfully connected to Dropbox! Your connection will remain active until you disconnect.', 'wt-woocommerce-invoice-addon' ); ?></p>
		</div>
		<?php
	}

	public function auth_fail_notice() {
		?>
		<div class="notice notice-error is-dismissible">
			<p><?php esc_html_e( 'Failed to connect to Dropbox. Please try again.', 'wt-woocommerce-invoice-addon' ); ?></p>
		</div>
		<?php
	}

	public function upload_file( $file_path, $dropbox_path ) {
		if ( ! $this->is_connected() || ! file_exists( $file_path ) ) {
			return false;
		}

		$file_content = file_get_contents( $file_path );
		$response = wp_remote_post( 'https://content.dropboxapi.com/2/files/upload', array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $this->access_token,
				'Content-Type'  => 'application/octet-stream',
				'Dropbox-API-Arg' => json_encode( array(
					'path' => $dropbox_path,
					'mode' => 'add',
					'autorename' => true,
					'mute' => false,
				) ),
			),
			'body' => $file_content,
		) );
		
		return ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200;
	}
}

endif; // class_exists

/**
 * Initialize the Dropbox API instance
 * Create immediately when file is included to ensure it's available for uploader
 */
global $wt_invoice_dropbox_api;
if ( ! isset( $wt_invoice_dropbox_api ) ) {
	$wt_invoice_dropbox_api = new Wt_Invoice_Addon_Dropbox_API();
}

/**
 * Also ensure initialization on plugins_loaded as a fallback
 * This handles cases where the file might be included before globals are set
 */
add_action( 'plugins_loaded', function() {
	global $wt_invoice_dropbox_api;
	if ( ! isset( $wt_invoice_dropbox_api ) || ! is_object( $wt_invoice_dropbox_api ) ) {
		$wt_invoice_dropbox_api = new Wt_Invoice_Addon_Dropbox_API();
	}
});
