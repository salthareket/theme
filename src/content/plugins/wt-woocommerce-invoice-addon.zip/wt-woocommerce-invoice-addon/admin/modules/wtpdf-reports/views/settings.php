<?php
if ( ! defined( 'WPINC' ) ) {
    die;
}
?> 
<style>
#wpcontent{background: #F1F8FE;}
.wt_wrap{ background: #F1F8FE; margin: 0px; width: 100%; }
#wpcontent{padding: 0px;}
.wt_heading_section{background-color: #fff; box-shadow: 0px 4px 12px 0px #55657D1A;}
.wt_pdf_center_container{margin: auto 20%;padding: 20px 0;}
.wt_pdf_report_content{padding: 10px 20px;}
.wt_pdf_report_filter_form{background-color: #fff; padding: 35px 21px; border-radius: 12px; margin-bottom: 20px;box-shadow: 0px 4px 12px 0px #55657D14;}
.wt_pdf_report_form_field{display: flex; align-items: baseline;margin-bottom: 20px;}
.wt_pdf_report_form_field label{ font-size: 14px; }
.wt_pdf_reports_radio-toggle {display: inline-block;}
.wt_pdf_reports_radio-toggle input[type="radio"] { display: none; /* Hide the actual radio buttons */ }
.wt_pdf_reports_radio-toggle label { cursor: pointer; display: inline-block; padding: 8px 20px; font-size: 14px; color: #555E6B; background-color: #fff; border: 1px solid #A0B2D6; margin-right: -4px; /* Remove margin between labels */ box-shadow: 0px 4px 12px 0px #55657D14; }
.wt_pdf_reports_radio-toggle-fixed{border-radius: 20px 0 0 20px;}
.wt_pdf_reports_radio-toggle-custom{border-radius: 0 20px 20px 0;}
.wt_pdf_reports_radio-toggle input[type="radio"]:checked + label { background-color: #EBF1FD; color: #3157A6; }
.wt_pdf_report_form_field_option{width: 40%;}
.wt_pdf_reports_date_type_fixed_div{display: flex;}
.wt_pdf_reports_date_type_fixed_div_inner{width: 50%; margin: 5px 0px;}
.wt_pdf_reports_date_type_main{margin-bottom: 15px;}
.wt_pdf_report_form_field_option .select2-container{width: 100% !important;}
.wt_pdf_report_form_field_option .select2-container--default .select2-selection--multiple .select2-selection__choice{ background-color: #EBF1FD; border: 1px solid #EBF1FD; border-radius: 6px; color:#2A3646; }
.wt_pdf_report_form_field_option .select2-container--default .select2-selection--multiple .select2-selection__choice__remove { margin-left: 10px; float: right; }
.wt_pdf_report_form_field_option .select2-container--default .select2-selection--multiple .select2-selection__rendered{padding: 0px 16px;}
.wc-wp-version-gte-53 .select2-container .select2-selection--multiple{min-height: 40px !important;}
.wt_pdf_reports_payment_type_div_inner{margin-bottom: 15px;}
.wt_wrap input[type=radio]{ background: #fff;width: 16px;height: 16px;border-radius: 20px;border: 2px solid #9DA3AA; }
.wt_wrap input[type=radio]:checked{ background: #0C66E4; border: 2px solid #0C66E4; }
.wt_wrap input[type=radio]:checked::before{ content: ""; border-radius: 50%; width: 4.57px; height: 4.57px; margin: 4.1px; background-color: #fff; line-height: 1.14285714; }
.wt_pdf_report_popup .wf_pklist_popup_hd{ background-color: #fff; border-radius: 10px;}
.wt_pdf_report_popup{ border-radius: 10px;}
.wt_pdf_report_popup .wf_pklist_popup_hd .popup_title {
    font-style: normal;
    font-weight: 500;
    font-size: 14px;
    line-height: 14px;
    color: #555E6B;
}
#wtpdf-report-progress-bar-container {
  width: 100%;
  background-color: #f0f0f0;
  height: 5px;
  border-radius: 5px;
  margin-bottom: 12px;
}

.wt_wrap select {
    border: 1.5px solid #BDC1C6;
    padding: 5px 15px;
    height: 40px;
    width: 200px;
    border-radius: 6px;
    font-size: 14px;
    background: #fff url("data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M14.9958 6.97401C14.7977 6.77716 14.5299 6.66667 14.2506 6.66667C13.9714 6.66667 13.7035 6.77716 13.5055 6.97401L9.71116 10.7155L5.96965 6.97401C5.77162 6.77716 5.50374 6.66667 5.22452 6.66667C4.94529 6.66667 4.67741 6.77716 4.47938 6.97401C4.38032 7.07227 4.30169 7.18916 4.24803 7.31796C4.19437 7.44676 4.16675 7.5849 4.16675 7.72443C4.16675 7.86395 4.19437 8.0021 4.24803 8.1309C4.30169 8.25969 4.38032 8.37659 4.47938 8.47484L8.96074 12.9562C9.059 13.0553 9.17589 13.1339 9.30469 13.1876C9.43349 13.2412 9.57163 13.2688 9.71116 13.2688C9.85068 13.2688 9.98883 13.2412 10.1176 13.1876C10.2464 13.1339 10.3633 13.0553 10.4616 12.9562L14.9958 8.47484C15.0948 8.37659 15.1735 8.25969 15.2271 8.1309C15.2808 8.0021 15.3084 7.86395 15.3084 7.72443C15.3084 7.5849 15.2808 7.44676 15.2271 7.31796C15.1735 7.18916 15.0948 7.07227 14.9958 6.97401Z' fill='%232A3646'/%3E%3C/svg%3E%0A") no-repeat right 12px top 55% !important;
}

#wtpdf-report-progress-bar {
  width: 0%;
  height: 100%;
  background-color: #4caf50;
  border-radius: 5px;
}
.wt_pdf_report_popup{top: 30% !important; padding: 17px 24px;}
#wtpdf-report-progress-msg{margin-bottom: 12px;}
.wtpdf_report_btn{
    border: none;
    padding: 12px 20px 12px 20px;
    border-radius: 4px;
    font-weight: 500;
    font-size: 14px;
    line-height: 16px;
    cursor: pointer;
}
.wtpdf_report_btn_primary{
    box-shadow: 0px 3px 4px 0px #55657D26;
    background: #3157A6;
    color:#fff;
}
.wt_pdf_report_form_field:last-child, .wt_pdf_reports_payment_type_div_inner:last-child{
    margin-bottom: 0px;
}
.total_order_count{
    display: none;
    padding: 6px 10px;
    background: #EAEBED;
    border-radius: 3px;
    font-size: 12px;
    font-weight: 700;
    line-height: 16px;
    text-align: center;
    text-transform: uppercase;
}
.wt_pdf_reports_user_type_sub{margin-top: 20px;}
#wtpdf_report_after_download{margin-top: 13px;}

.wt_pdf_reports_date_based_on_sub {
    display: flex;
}

.wt_pdf_reports_date_based_on_order_date,
.wt_pdf_reports_date_based_on_invoice_date {
    width: 50%;
}



/* Style the dropdown button */

</style>
<div class="wt_wrap">
    <div class="wt_pdf_settings_container" style="position: relative;">
        <div class="packingslip_warn_msg" style="position: absolute;background: #fff;width: 17%;right: 1.2%;border-radius: 6px;padding: 5px;top: 26.3%;align-items: start;display:none; box-shadow: 0px 4px 12px 0px #55657D14;">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" style=" width: 10%; padding: 15px 7px; ">
                <circle cx="10" cy="10" r="10" transform="rotate(-180 10 10)" fill="#0576FE"></circle>
                    <path d="M9.90039 15V9" stroke="white" stroke-width="2.2" stroke-linecap="round"></path>
                <circle cx="9.8" cy="4.8" r="1.2" transform="rotate(-180 9.8 4.8)" fill="white"></circle>
            </svg>
            <p style=" width: 79%; font-size: 14px; font-weight: 500; line-height: 16.71px; text-align: left;"><?php esc_html_e('Packing slips may not be generated for certain orders based on your settings','wt-woocommerce-invoice-addon'); ?></p>
        </div>
        <div class="wt_heading_section">
            <h2 class="wp-heading-inline">
            <?php esc_html_e('Reports','wt-woocommerce-invoice-addon');?>
            </h2>
            <?php
                //webtoffee branding
                include WF_PKLIST_PLUGIN_PATH.'/admin/views/admin-settings-branding.php';
                $wt_today = gmdate('Y-m-d');
            ?>
        </div>
        <div class="wt_pdf_center_container">
            <div class="wt_pdf_report_action_bar wt_pdf_report_content" style="display:flex;align-items:center;">
                <div style="width: 65%;display:flex;align-items:center;justify-content:left;">
                    <div style="display: flex; align-items:center;">
                        <label style="padding-right: 10px;font-size: 20px;font-weight: 600;"> <?php esc_html_e( 'Reports', 'wt-woocommerce-invoice-addon' ); ?> </label>
                        <select id="wtpdf_report_doc_type" class="wt_pdf_report_field" name="report_document_type" style="padding-right: 10px;">
                            <option value="invoice" data-doc-label="<?php esc_attr_e( 'Invoices', 'wt-woocommerce-invoice-addon' ); ?>"><?php esc_html_e( 'Invoice', 'wt-woocommerce-invoice-addon' ); ?></option>
                            <option value="packinglist" data-doc-label="<?php esc_attr_e( 'Packing slips', 'wt-woocommerce-invoice-addon' ); ?>"><?php esc_html_e( 'Packing slip', 'wt-woocommerce-invoice-addon' ); ?></option>
                            <option value="creditnote" data-doc-label="<?php esc_attr_e( 'Credit notes', 'wt-woocommerce-invoice-addon' ); ?>"><?php esc_html_e( 'Credit note', 'wt-woocommerce-invoice-addon' ); ?></option>
                        </select>
                    </div>
                    <p style="margin: 0px;padding-left:20px;font-size: 12px;font-weight: 700;"> <span class="total_order_count" data-document-type="invoice"> <?php echo esc_html( $total_invoice ); ?> <?php esc_html_e('invoices','wt-woocommerce-invoice-addon'); ?></span>
                    <span class="total_order_count" data-document-type="packinglist"> <?php echo esc_html( $packinglist_count ); ?> <?php esc_html_e('packing slips', 'wt-woocommerce-invoice-addon'); ?></span>
                    <span class="total_order_count" data-document-type="creditnote"> <?php echo esc_html( $order_has_creditnote ); ?> <?php esc_html_e('credit notes','wt-woocommerce-invoice-addon'); ?></span></p>
                </div>
                <div style="width: 35%;display:flex;align-items:center;justify-content:right;">
                    <button class="wtpdf_report_btn wtpdf_report_btn_primary" id="wt_pdf_report_export"> <?php esc_html_e( 'Export as ZIP', 'wt-woocommerce-invoice-addon' ); ?> </button>
                </div>
                <div class="wt_pdf_report_popup wf_pklist_popup" style="width: 450px;">
					<div class="wf_pklist_popup_hd">
						<div class="popup_title">
                            <div id="wtpdf_report_before_download">
                                <div id="wtpdf-report-progress-msg"><span><?php esc_html_e('Preparing ZIP','wt-woocommerce-invoice-addon'); ?>....</span> <span id="wtpdf-report-progress-file-count"></span><span id="wtpdf-report-progress-file-precentage">(0%)</span></div>
                                <div id="wtpdf-report-progress-bar-container">
                                    <div id="wtpdf-report-progress-bar"></div>
                                </div>
                            </div>
                            <div id="wtpdf_report_after_download" style="display: none;">
                                <span><?php esc_html_e('Download started','wt-woocommerce-invoice-addon'); ?>...</span>
                            </div>
                            <div class="wf_pklist_popup_close" style="display:none;">
                            </div>
                        </div>
					</div>
                </div>
            </div>
            <div class="wt_pdf_report_filter_container">
                <p id="document_success_notice"></p>
                <p class="wt_pdf_report_content" style="font-size: 16px;font-weight: 600;"> <?php esc_html_e('Filters','wt-woocommerce-invoice-addon'); ?> </p>
                <div class="wt_pdf_report_filter_form" >

                
                <div class="wt_pdf_report_form_field wt_pdf_report_based_on_main">
                    <label style="width:20%;"> <?php esc_html_e( 'Based on', 'wt-woocommerce-invoice-addon' ); ?> </label>
                        <div class="wt_pdf_report_form_field_option">
                            <div class="wt_pdf_reports_radio-toggle_date_based_on wt_pdf_reports_date_type_main">
                                    <div class="wt_pdf_reports_date_based_on_sub">
                                            <div class="wt_pdf_reports_date_based_on_order_date">
                                                <input type="radio" id="import_as_order_date" name="wt_pdf_reports_date_based_on" value="_order_date" class="wt_pdf_report_field" checked >
                                                <label for="import_as_order_date" class="wt_pdf_reports_radio-toggle-order_date"><?php esc_html_e( 'Order Date', 'wt-woocommerce-invoice-addon' ); ?></label>
                                            </div>

                                            <div class="wt_pdf_reports_date_based_on_invoice_date">
                                                <input type="radio" id="import_as_invoice_date" name="wt_pdf_reports_date_based_on" value="_invoice_date" class="wt_pdf_report_field">
                                                <label for="import_as_invoice_date" class="wt_pdf_reports_radio-toggle-invoice_date"><?php esc_html_e( 'Invoice Date', 'wt-woocommerce-invoice-addon' ); ?></label>
                                            </div>
                                    </div>
                            </div>
                        </div>
                </div>


                    <div class="wt_pdf_report_form_field">
                        <input type="hidden" name="wtpdf_bulk_export_pdf_nonce" id="wtpdf_bulk_export_pdf_nonce_id" value="<?php echo esc_attr( wp_create_nonce( $this->module_id ) ); ?>">
                        <label style="width:20%;"> <?php esc_html_e( 'Date & time', 'wt-woocommerce-invoice-addon' ); ?> </label>
                        <div class="wt_pdf_report_form_field_option">
                            <div class="wt_pdf_reports_radio-toggle wt_pdf_reports_date_type_main">
                                <input type="radio" id="fixed" name="wt_pdf_reports_date_type" value="fixed" class="wt_pdf_report_field" checked class="wt_pdf_report_field">
                                <label for="fixed" class="wt_pdf_reports_radio-toggle-fixed"><?php esc_html_e( 'Fixed', 'wt-woocommerce-invoice-addon' ); ?></label>
                                <input type="radio" id="custom" name="wt_pdf_reports_date_type" value="custom" class="wt_pdf_report_field" class="wt_pdf_report_field">
                                <label for="custom" class="wt_pdf_reports_radio-toggle-custom"><?php esc_html_e( 'Custom date', 'wt-woocommerce-invoice-addon' ); ?></label>
                            </div>
                            <div class="wt_pdf_reports_date_type_sub">
                                <div class="wt_pdf_reports_date_type_sub_fields" data-date-type="fixed">
                                    <div class="wt_pdf_reports_date_type_fixed_div">
                                        <div class="wt_pdf_reports_date_type_fixed_div_inner">
                                            <input type="radio" id="data_type_today" name="wt_pdf_reports_date_type_fixed" value="today" class="wt_pdf_report_field" data-from-date="<?php echo esc_attr( gmdate( 'Y-m-d 00:00:00', strtotime( $wt_today ) ) ); ?>" data-to-date="<?php echo esc_attr( gmdate( 'Y-m-d 23:59:59', strtotime( $wt_today ) ) ); ?>" checked>
                                            <label for="data_type_today" class="wt_pdf_reports_radio-toggle-fixed"><?php esc_html_e( 'Today', 'wt-woocommerce-invoice-addon' ); ?></label>
                                        </div>
                                        <div class="wt_pdf_reports_date_type_fixed_div_inner">
                                            <input type="radio" id="data_type_yesterday" name="wt_pdf_reports_date_type_fixed" value="yesterday" class="wt_pdf_report_field" data-from-date="<?php echo esc_attr(gmdate( 'Y-m-d 00:00:00', strtotime( '-1 day', strtotime( $wt_today) ) )); ?>" data-to-date="<?php echo esc_attr(gmdate( 'Y-m-d 23:59:59', strtotime( '-1 day', strtotime( $wt_today) ) )); ?>">
                                            <label for="data_type_yesterday" class="wt_pdf_reports_radio-toggle-fixed"><?php esc_html_e( 'Yesterday', 'wt-woocommerce-invoice-addon' ); ?></label>
                                        </div>
                                    </div>

                                    <div class="wt_pdf_reports_date_type_fixed_div">
                                        <div class="wt_pdf_reports_date_type_fixed_div_inner">
                                            <input type="radio" id="data_type_this_week" name="wt_pdf_reports_date_type_fixed" value="this_week" class="wt_pdf_report_field" data-from-date="<?php echo esc_attr(gmdate( 'Y-m-d 00:00:00', strtotime( 'monday this week', strtotime( $wt_today) ) )); ?>" data-to-date="<?php echo esc_attr(gmdate( 'Y-m-d 23:59:59', strtotime( 'sunday this week', strtotime( $wt_today) ) )); ?>">
                                            <label for="data_type_this_week" class="wt_pdf_reports_radio-toggle-fixed"><?php esc_html_e( 'This week', 'wt-woocommerce-invoice-addon' ); ?></label>
                                        </div>
                                        <div class="wt_pdf_reports_date_type_fixed_div_inner">
                                            <input type="radio" id="data_type_last_week" name="wt_pdf_reports_date_type_fixed" value="last_week" class="wt_pdf_report_field" data-from-date="<?php echo esc_attr(gmdate( 'Y-m-d 00:00:00', strtotime( 'monday last week', strtotime( $wt_today) ) )); ?>" data-to-date="<?php echo esc_attr(gmdate( 'Y-m-d 23:59:59', strtotime( 'sunday last week', strtotime( $wt_today) ) )); ?>">
                                            <label for="data_type_last_week" class="wt_pdf_reports_radio-toggle-fixed"><?php esc_html_e( 'Last week', 'wt-woocommerce-invoice-addon' ); ?></label>
                                        </div>
                                    </div>

                                    <div class="wt_pdf_reports_date_type_fixed_div">
                                        <div class="wt_pdf_reports_date_type_fixed_div_inner">
                                            <input type="radio" id="data_type_this_month" name="wt_pdf_reports_date_type_fixed" value="this_month" class="wt_pdf_report_field" data-from-date="<?php echo esc_attr(gmdate( 'Y-m-01 00:00:00', strtotime( $wt_today) )); ?>" data-to-date="<?php echo esc_attr(gmdate( 'Y-m-t 23:59:59', strtotime( $wt_today) )); ?>">
                                            <label for="data_type_this_month" class="wt_pdf_reports_radio-toggle-fixed"><?php esc_html_e( 'This month', 'wt-woocommerce-invoice-addon' ); ?></label>
                                        </div>
                                        <div class="wt_pdf_reports_date_type_fixed_div_inner">
                                            <input type="radio" id="data_type_last_month" name="wt_pdf_reports_date_type_fixed" value="last_month" class="wt_pdf_report_field" data-from-date="<?php echo esc_attr(gmdate( 'Y-m-01 00:00:00', strtotime( 'first day of last month', strtotime( $wt_today ) ) )); ?>" data-to-date="<?php echo esc_attr(gmdate( 'Y-m-t 23:59:59', strtotime( 'last day of last month', strtotime( $wt_today ) ) )); ?>" >
                                            <label for="data_type_last_month" class="wt_pdf_reports_radio-toggle-fixed"><?php esc_html_e( 'Last month', 'wt-woocommerce-invoice-addon' ); ?></label>
                                        </div>
                                    </div>

                                    <div class="wt_pdf_reports_date_type_fixed_div">
                                        <div class="wt_pdf_reports_date_type_fixed_div_inner">
                                            <input type="radio" id="data_type_this_year" name="wt_pdf_reports_date_type_fixed" value="this_year" class="wt_pdf_report_field" data-from-date="<?php echo esc_attr(gmdate( 'Y-01-01 00:00:00', strtotime( $wt_today ) )); ?>" data-to-date="<?php echo esc_attr(gmdate( 'Y-12-31 23:59:59', strtotime( $wt_today ) )); ?>">
                                            <label for="data_type_this_year" class="wt_pdf_reports_radio-toggle-fixed"><?php esc_html_e( 'This year', 'wt-woocommerce-invoice-addon' ); ?></label>
                                        </div>
                                        <div class="wt_pdf_reports_date_type_fixed_div_inner">
                                            <input type="radio" id="data_type_last_year" name="wt_pdf_reports_date_type_fixed" value="last_year" class="wt_pdf_report_field" data-from-date="<?php echo esc_attr(gmdate( 'Y-01-01 00:00:00', strtotime( '-1 year', strtotime( $wt_today ) ) )); ?>" data-to-date="<?php echo esc_attr(gmdate( 'Y-12-31 23:59:59', strtotime( '-1 year', strtotime( $wt_today ) ) )); ?>">
                                            <label for="data_type_last_year" class="wt_pdf_reports_radio-toggle-fixed"><?php esc_html_e( 'Last year', 'wt-woocommerce-invoice-addon' ); ?></label>
                                        </div>
                                    </div>

                                    <div class="wt_pdf_reports_date_type_fixed_div">
                                        <div class="wt_pdf_reports_date_type_fixed_div_inner">
                                            <input type="radio" id="wt_pdf_reports_date_type_fixed_today" name="wt_pdf_reports_date_type_fixed" value="all" class="wt_pdf_report_field">
                                            <label for="wt_pdf_reports_date_type_fixed_today" class="wt_pdf_reports_radio-toggle-fixed"><?php esc_html_e( 'All time', 'wt-woocommerce-invoice-addon' ); ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="wt_pdf_reports_date_type_sub_fields" data-date-type="custom" style="display: none;">
                                    <div class="wt_pdf_reports_date_type_custom_div">
                                        <div class="wt_pdf_reports_date_type_custom_div_inner">
                                            <label for="data_type_from" class="wt_pdf_reports_radio-toggle-fixed" style="float:left; width:100%; margin-bottom:10px;"><?php esc_html_e('From','wt-woocommerce-invoice-addon'); ?></label>
                                            <input type="date" id="data_type_from" name="wt_pdf_reports_date_type_custom_from" value="<?php echo esc_attr( gmdate('Y-m-d') ); ?>" class="wt_pdf_report_field" max="<?php echo esc_attr( gmdate('Y-m-d') ); ?>">
                                        </div>
                                        <div class="wt_pdf_reports_date_type_fixed_div_inner">
                                            <label for="data_type_to" class="wt_pdf_reports_radio-toggle-fixed" style="float:left; width:100%; margin-bottom:10px;"><?php esc_html_e('To','wt-woocommerce-invoice-addon'); ?></label>
                                            <input type="date" id="data_type_to" name="wt_pdf_reports_date_type_custom_to" value="<?php echo esc_attr( gmdate('Y-m-d') ); ?>" class="wt_pdf_report_field" max="<?php echo esc_attr( gmdate('Y-m-d') ); ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="wt_pdf_report_form_field">
                        <label style="width:20%;"> <?php esc_html_e( 'Order statuses', 'wt-woocommerce-invoice-addon' ); ?> </label>
                        <div class="wt_pdf_report_form_field_option">
                            <select class="wc-enhanced-select wt_pdf_report_field" id="wt_pdf_reports_order_statuses" name="wt_pdf_reports_order_statuses[]" multiple="multiple">
                            <?php 
                                foreach( $order_statuses as $status_key => $status_label ) {
                                    echo '<option value="'. esc_attr( $status_key ) .'">
                                        '.esc_html( $status_label ).'
                                    </option>';
                                }
                            ?>
                            </select>
                        </div>
                    </div>
                    <div class="wt_pdf_report_form_field">
                        <label style="width:20%;"> <?php esc_html_e( 'Users', 'wt-woocommerce-invoice-addon' ); ?> </label>
                        <div class="wt_pdf_report_form_field_option">
                            <div class="wt_pdf_reports_user_type_main">
                                <select name="wt_pdf_reports_user_type" class="wt_pdf_report_field">
                                    <option value="all"><?php esc_html_e( 'All users', 'wt-woocommerce-invoice-addon' ); ?></option>
                                    <option value="selected_users"><?php esc_html_e( 'Selected users', 'wt-woocommerce-invoice-addon' ); ?></option>
                                    <option value="except_users"><?php esc_html_e( 'All users except', 'wt-woocommerce-invoice-addon' ); ?></option>
                                </select>
                            </div>
                            <div class="wt_pdf_reports_user_type_sub" data-user-type="selected_users" style="display: none;">
                                <select class="wc-enhanced-select wt_pdf_report_field" id="wt_pdf_reports_user_type_selected_users" name="wt_pdf_reports_user_type_selected_users[]" multiple="multiple">
                                <?php 
                                    foreach( $available_user_email_ids as $mail ) {
                                        echo '<option value="'. esc_attr( $mail ) .'">
                                            '.esc_html( $mail ).'
                                        </option>';
                                    }
                                ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="wt_pdf_report_form_field">
                        <label style="width:20%;"> <?php esc_html_e( 'Payment methods', 'wt-woocommerce-invoice-addon' ); ?> </label>
                        <div class="wt_pdf_report_form_field_option">
                            <div class="wt_pdf_reports_payment_type_div">
                                <?php
                                    foreach ( $available_payment_methods as $p_key => $p_label) {
                                        ?>
                                        <div class="wt_pdf_reports_payment_type_div_inner">
                                            <input type="checkbox" class="wt_pdf_reports_payment_method wt_pdf_report_field" name="wt_pdf_reports_payment_method" id="wt_pdf_reports_payment_method_<?php echo esc_attr( $p_key ); ?>" value="<?php echo esc_attr($p_key); ?>"> <label for="wt_pdf_reports_payment_method_<?php echo esc_attr( $p_key ); ?>" > <?php echo esc_attr( $p_label ); ?></label>
                                        </div>
                                        <?php
                                    }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>