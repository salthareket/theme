<?php
if ( ! defined( 'WPINC' ) ) {
    die;
}

if( !class_exists( 'Wtpdf_Reports' ) ) {

    class Wtpdf_Reports {
        
        private static $instance            = null;
        public $module_id                   = '';
        public static $module_id_static     = '';
        public $module_base                 = 'reports';
        public static $module_base_static   = '';
        public $which_table                 = '';
        public $wt_pdf_report_log_name      = 'wt_pklist_report_log';

        public function __construct() {
            $this->module_id		    = Wf_Woocommerce_Packing_List::get_module_id( $this->module_base );
            self::$module_id_static	    = $this->module_id;
            self::$module_base_static   = $this->module_base;
            $this->which_table          = Wt_Pklist_Common_Ipc::which_table_to_take();

            add_filter( 'wt_admin_menu', array( $this, 'add_admin_pages' ), 12, 1 ); // Add report menu.
            add_action( 'wp_ajax_wt_pklist_report_get_order_ids', array( $this, 'wt_report_get_order_ids' ) );
            add_action( 'wp_ajax_wtpdf_bulk_export_document', array($this, 'save_bulk_document' ));
            add_action( 'wp_ajax_wtpdf_report_zip_bulk', array( $this, 'wtpdf_report_zip_bulk'));
        }

        public function wt_report_get_order_ids() {
            $nonce  = isset( $_POST['report_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['report_nonce'] ) ) : '';

            // Default output format.
            $output = array( 
                'error'     => '', 
                'success'   => '', 
                'order_ids' => array() 
            );

            if ( !wp_verify_nonce( $nonce, $this->module_id ) ) {
                $output['error'] = __( 'You are not allowed to do this action', 'wt-woocommerce-invoice-addon' );
                echo wp_json_encode( $output );
                exit();
            }

            $template_type      = isset( $_POST['template_type'] ) ?  sanitize_text_field( wp_unslash( $_POST['template_type'] ) ) : 'invoice';
            $date_from          = isset( $_POST['from_date'] ) ? sanitize_text_field( wp_unslash( $_POST['from_date'] ) ) : '';
            $date_to            = isset( $_POST['to_date'] ) ? sanitize_text_field( wp_unslash( $_POST['to_date'] ) ) : '';
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized via custom sanitize_text_arr method
            $order_statuses     = isset( $_POST['order_statuses'] ) ? Wf_Woocommerce_Packing_List_Admin::sanitize_text_arr( wp_unslash( $_POST['order_statuses'] ) ) : array();
            $user_type          = isset( $_POST['user_type'] ) ? sanitize_text_field( wp_unslash( $_POST['user_type'] ) ) : '';
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized via custom sanitize_text_arr method
            $users              = isset( $_POST['users'] ) ? Wf_Woocommerce_Packing_List_Admin::sanitize_text_arr( wp_unslash( $_POST['users'] ) ) : array();
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized via custom sanitize_text_arr method
            $payment_methods    = isset( $_POST['payment_methods'] ) ? Wf_Woocommerce_Packing_List_Admin::sanitize_text_arr( wp_unslash( $_POST['payment_methods'] ) ) : array();
            $based_on           = isset( $_POST['based_on'] ) ? sanitize_text_field( wp_unslash( $_POST['based_on'] ) ) : '_order_date';

            global $wpdb;
            if ( "post_table" === $this->which_table ) {
                $query  = "SELECT DISTINCT p.`ID` FROM {$wpdb->prefix}posts p INNER JOIN {$wpdb->prefix}postmeta pm ON p.`ID` = pm.`post_id`";
                $where  = " WHERE p.`post_type` = 'shop_order' AND p.`post_status` != 'wc-checkout-draft'";

                // Status filter.
                if ( !empty( $order_statuses ) ) {
                    $where .= " AND p.`post_status` IN ('" . implode("','", esc_sql($order_statuses)) . "')";
                } else {
                    $where .= " AND p.post_status != 'trash'";
                }

                // Date filter.
                if ( ! empty( $date_from ) && ! empty( $date_to ) ) {
                    if ( '_invoice_date' === $based_on ) {
                        // Convert human-readable dates to Unix timestamps.
                        $date_from_timestamp = strtotime( $date_from );
                        $date_to_timestamp = strtotime( $date_to );

                        $query .= " INNER JOIN {$wpdb->prefix}postmeta as inv_date ON p.`ID` = inv_date.`post_id`";
                        $where .= " AND inv_date.`meta_key` = '_wf_invoice_date' 
                                    AND inv_date.`meta_value` >= '".esc_sql( $date_from_timestamp )."' 
                                    AND inv_date.`meta_value` <= '".esc_sql( $date_to_timestamp )."'";
                        
                    } elseif ( '_order_date' === $based_on ) {
                        $where .= " AND p.`post_date` >= '".esc_sql( $date_from )."' 
                                    AND p.`post_date` <= '".esc_sql( $date_to )."'";
                    }
                }

                // User filter.
                if ( !empty( $users ) ) {
                    $query .= " INNER JOIN {$wpdb->prefix}postmeta um ON p.`ID` = um.`post_id`";
                    if ( "selected_users" === $user_type ) {
                        $where .= " AND ( ( um.`meta_key` = '_billing_email' AND um.`meta_value` IN ('" . implode("','", esc_sql($users)) . "') ) OR ( um.`meta_key` = '_shipping_email' AND um.`meta_value` IN ('" . implode("','", esc_sql($users)) . "') ) )";
                    } else if ( "except_users" === $user_type ) {
                        $where .= " AND ( ( um.`meta_key` = '_billing_email' AND um.`meta_value` NOT IN ('" . implode("','", esc_sql($users)) . "') ) AND ( um.`meta_key` = '_shipping_email' AND um.`meta_value` IN ('" . implode("','", esc_sql($users)) . "') ) )";
                    }
                }

                // Payment method filter.
                if ( !empty( $payment_methods ) ) {
                    $query  .= " INNER JOIN {$wpdb->prefix}postmeta pmt ON p.`ID` = pmt.`post_id`";
                    $where  .= " AND pmt.`meta_key` = '_payment_method' AND pmt.`meta_value` IN ('" . implode("','", esc_sql($payment_methods)) . "')";
                }

                if ( "invoice" === $template_type ) {
                    $query  .= " INNER JOIN {$wpdb->prefix}postmeta as inv ON p.`ID` = inv.`post_id`";
                    $where  .= " AND inv.`meta_key` = 'wf_invoice_number' AND inv.`meta_value` != '' ";
                }

                if ( "packinglist" === $template_type ) {
                    $query  .= " INNER JOIN {$wpdb->prefix}postmeta as pl ON p.`ID` = pl.`post_id`";
                }

                if( "creditnote" === $template_type ) {
                    $where .= " AND p.`post_parent` = 0 AND EXISTS ( SELECT 1 FROM {$wpdb->prefix}posts AS child INNER JOIN {$wpdb->prefix}postmeta as child_m ON child.`ID` = child_m.`post_id` WHERE child.`post_parent` = p.`ID` AND child.`post_type` = 'shop_order_refund' AND child_m.`meta_key` = 'wf_creditnote_number' AND child_m.`meta_value` != '')";
                }

                $order_by = " order by p.`ID` ASC";
            } else {
                $query  = "SELECT DISTINCT p.`id` FROM {$wpdb->prefix}wc_orders p";
                $where  = " WHERE p.`type` = 'shop_order' AND p.`status` != 'wc-checkout-draft'";

                // Status filter.
                if ( !empty( $order_statuses ) ) {
                    $where .= " AND p.`status` IN ('" . implode("','", esc_sql($order_statuses)) . "')";
                } else {
                    $where .= " AND p.`status` != 'trash'";
                }

                // Date filter.
                if ( ! empty( $date_from ) && ! empty( $date_to ) ) {
                    if ( '_invoice_date' === $based_on ) {
                        $date_from_timestamp = strtotime( $date_from );
                        $date_to_timestamp = strtotime( $date_to );
                    
                        $query .= " INNER JOIN {$wpdb->prefix}wc_orders_meta as inv_date ON p.ID = inv_date.order_id";
                        $where .= " AND inv_date.meta_key = '_wf_invoice_date' 
                                    AND inv_date.meta_value >= '".esc_sql( $date_from_timestamp )."' 
                                    AND inv_date.meta_value <= '".esc_sql( $date_to_timestamp )."'";

                    } elseif ( '_order_date' === $based_on ) {
                        $where .= " AND p.`date_created_gmt` >= '".esc_sql( $date_from )."' 
                                    AND p.`date_created_gmt` <= '".esc_sql( $date_to )."'";
                    }
                }

                // User filter.
                if ( !empty( $users ) ) {
                    $where .= " AND p.`billing_email` != '' AND p.`billing_email` IS NOT NULL AND p.`billing_email` IN ('" . implode("','", esc_sql($users)) . "')";
                }

                // Payment method filter.
                if ( !empty( $payment_methods ) ) {
                    $where .= " AND p.`payment_method` != '' AND p.`payment_method` IS NOT NULL AND p.`payment_method` IN ('" . implode("','", esc_sql($payment_methods)) . "')";
                }

                if ( "invoice" === $template_type ) {
                    $query .= " INNER JOIN {$wpdb->prefix}wc_orders_meta as pm ON p.`id` = pm.`order_id`";
                    $where .= " AND pm.`meta_key` = 'wf_invoice_number' AND pm.`meta_value` != '' ";
                }

                if ( "packinglist" === $template_type ) {
                    $query .= " INNER JOIN {$wpdb->prefix}wc_orders_meta as pm ON p.`id` = pm.`order_id`";
                }

                if ( "creditnote" === $template_type ) {
                    $query .= " LEFT JOIN {$wpdb->prefix}wc_orders_meta AS pm ON p.`id` = pm.`order_id`";
                    $where .= " AND p.`parent_order_id` = 0 AND EXISTS ( SELECT 1 FROM {$wpdb->prefix}wc_orders AS child INNER JOIN {$wpdb->prefix}wc_orders_meta as child_m ON child.`id` = child_m.`order_id` WHERE child.`parent_order_id` = p.`id` AND child.`type` = 'shop_order_refund' AND child_m.`meta_key` = 'wf_creditnote_number' AND child_m.`meta_value` != '' )";
                }

                $order_by = " order by p.`id` ASC";
            }
            
            $structured_query = $query . $where . $order_by;
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Complex dynamic query with proper escaping via esc_sql()
            $order_ids = $wpdb->get_col( $structured_query );
            $output['order_ids'] = $order_ids;
            if ( !empty( $order_ids ) ) {
                $output['success'] = __( 'Success', 'wt-woocommerce-invoice-addon' );
            } else {
                $output['error'] = __( 'No orders found', 'wt-woocommerce-invoice-addon' );   
            }
            echo wp_json_encode( $output );
            exit();
        }

        public static function get_instance() {
            if ( null === self::$instance ) {
                self::$instance = new Wtpdf_Reports();
            }
            return self::$instance;    
        }

        public function add_admin_pages($menus) {
            $menus[] = array(
                'submenu',
                WF_PKLIST_POST_TYPE,
                __( 'Reports', 'wt-woocommerce-invoice-addon' ),
                __( 'Reports', 'wt-woocommerce-invoice-addon' ),
                'manage_woocommerce',
                $this->module_id,
                array( $this, 'admin_settings_page' ),
                'id' => 'reports',
            );
            return $menus;
        }

        public function admin_settings_page() {
            $order_statuses = wc_get_order_statuses();
            global $wpdb;
            $table_prefix = $wpdb->prefix;
            $which_table = Wt_Pklist_Common_Ipc::which_table_to_take();
            $total_invoice = 0;

            if ( "post_table" === $which_table ) {
                // Total invoice count
                $total_invoice_qry = "
                    SELECT COUNT(DISTINCT p.`ID`) AS distinct_invoice_count
                    FROM {$wpdb->prefix}posts AS p
                    LEFT JOIN {$wpdb->prefix}postmeta AS pm ON p.`ID` = pm.`post_id` AND pm.`meta_key` = 'wf_invoice_number'
                    WHERE p.`post_type` = 'shop_order' AND pm.`meta_value` != '' AND pm.`meta_value` IS NOT NULL
                ";
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Static query for counting invoices
                $total_invoice = $wpdb->get_var($total_invoice_qry);

                // Orders with refund/credit note.
                $total_creditnote_qry = "
                    SELECT DISTINCT p.ID AS refund_order_count
                    FROM {$wpdb->prefix}posts AS p
                    LEFT JOIN {$wpdb->prefix}postmeta AS pm ON p.ID = pm.post_id
                    WHERE p.post_type = 'shop_order'
                        AND p.post_parent = 0
                        AND EXISTS (
                            SELECT 1
                            FROM {$wpdb->prefix}posts AS child
                            INNER JOIN {$wpdb->prefix}postmeta as child_m ON child.ID = child_m.post_id
                            WHERE child.post_parent = p.ID 
                                AND child.post_type = 'shop_order_refund' 
                                AND child_m.meta_key = 'wf_creditnote_number' 
                                AND child_m.meta_value != ''
                        )
                    GROUP BY p.ID
                ";
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Static query for counting credit notes
                $total_creditnote_col = $wpdb->get_col($total_creditnote_qry);
                $order_has_creditnote = count( $total_creditnote_col );

                $packing_list_qry = "
                    SELECT count( DISTINCT p.ID ) AS order_count
                    FROM {$wpdb->prefix}posts AS p
                    INNER JOIN {$wpdb->prefix}postmeta AS pm ON p.ID = pm.post_id
                    WHERE p.post_type = 'shop_order' AND p.post_status != 'wc-checkout-draft'
                ";
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Static query for counting packing lists
                $packinglist_count = $wpdb->get_var( $packing_list_qry );

                $user_emails_qry = "
                    SELECT DISTINCT pm.`meta_value` AS user_email
                    FROM {$wpdb->prefix}posts AS p
                    LEFT JOIN {$wpdb->prefix}postmeta AS pm ON p.`ID` = pm.`post_id` 
                        AND ( pm.`meta_key` = '_billing_email' OR pm.`meta_key` = '_shipping_email' )
                    WHERE p.`post_type` = 'shop_order'
                        AND pm.`meta_value` != '' AND pm.`meta_value` IS NOT NULL
                ";
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Static query for fetching user emails
                $available_user_email_ids = $wpdb->get_col($user_emails_qry);

                $payment_qry = "
                    SELECT p.ID as order_id, pm.meta_value as payment_method, pmt.meta_value as payment_method_title
                    FROM {$wpdb->prefix}posts as p
                    LEFT JOIN {$wpdb->prefix}postmeta as pm ON p.ID = pm.post_id AND pm.meta_key = '_payment_method'
                    LEFT JOIN {$wpdb->prefix}postmeta as pmt ON p.ID = pmt.post_id AND pmt.meta_key = '_payment_method_title'
                    WHERE p.`post_type` = 'shop_order'
                        AND pm.`meta_value` != '' AND pm.`meta_value` IS NOT NULL
                        AND pmt.`meta_value` != '' AND pmt.`meta_value` IS NOT NULL
                ";
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Static query for fetching payment methods
                $payments_results = $wpdb->get_results($payment_qry, ARRAY_A);
            } else {
                // Total invoice count for wc_orders.
                $total_invoice_qry = "
                    SELECT COUNT(DISTINCT p.`id`) AS distinct_invoice_count
                    FROM {$wpdb->prefix}wc_orders AS p
                    LEFT JOIN {$wpdb->prefix}wc_orders_meta AS pm ON p.`id` = pm.`order_id` AND pm.`meta_key` = 'wf_invoice_number'
                    WHERE p.`type` = 'shop_order'
                        AND pm.`meta_value` != '' AND pm.`meta_value` IS NOT NULL
                ";
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Static query for counting invoices
                $total_invoice = $wpdb->get_var($total_invoice_qry);

                $total_creditnote_qry = "
                    SELECT DISTINCT p.id AS refund_order_count
                    FROM {$wpdb->prefix}wc_orders AS p
                    LEFT JOIN {$wpdb->prefix}wc_orders_meta AS pm ON p.id = pm.order_id
                    WHERE p.type = 'shop_order'
                        AND p.parent_order_id = 0
                        AND EXISTS (
                            SELECT 1
                            FROM {$wpdb->prefix}wc_orders AS child
                            INNER JOIN {$wpdb->prefix}wc_orders_meta as child_m ON child.id = child_m.order_id
                            WHERE child.parent_order_id = p.id 
                                AND child.type = 'shop_order_refund' 
                                AND child_m.meta_key = 'wf_creditnote_number' 
                                AND child_m.meta_value != ''
                        )
                    GROUP BY p.id
                ";
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Static query for counting credit notes
                $total_creditnote_col = $wpdb->get_col($total_creditnote_qry);
                $order_has_creditnote = count( $total_creditnote_col );
                
                $packing_list_qry = "
                    SELECT count( DISTINCT p.id ) AS order_count
                    FROM {$wpdb->prefix}wc_orders AS p
                    INNER JOIN {$wpdb->prefix}wc_orders_meta AS pm ON p.id = pm.order_id
                    WHERE p.type = 'shop_order' AND p.status != 'wc-checkout-draft'
                ";
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Static query for counting packing lists
                $packinglist_count = $wpdb->get_var( $packing_list_qry );

                $user_emails_qry = "
                    SELECT DISTINCT p.`billing_email` AS user_email
                    FROM {$wpdb->prefix}wc_orders AS p
                    WHERE p.`type` = 'shop_order'
                        AND p.`billing_email` != '' AND p.`billing_email` IS NOT NULL
                ";
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Static query for fetching user emails
                $available_user_email_ids = $wpdb->get_col($user_emails_qry);

                $payment_qry = "
                    SELECT p.id as order_id, p.payment_method as payment_method, p.payment_method_title as payment_method_title
                    FROM {$wpdb->prefix}wc_orders as p
                    WHERE p.`type` = 'shop_order'
                        AND p.`payment_method` != '' AND p.`payment_method` IS NOT NULL
                        AND p.`payment_method_title` != '' AND p.`payment_method_title` IS NOT NULL
                ";
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Static query for fetching payment methods
                $payments_results = $wpdb->get_results($payment_qry, ARRAY_A);
            }

            $unique_payment_methods    = wp_list_pluck( $payments_results, 'payment_method_title', 'payment_method' );
            $wc_payment_gateways       = WC()->payment_gateways()->get_available_payment_gateways();
            $available_payment_methods = wp_list_pluck($wc_payment_gateways, 'title', 'id');
            $available_payment_methods = $unique_payment_methods + $available_payment_methods;
            $params = array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'msgs'     => array(
                    'date_compare_message' => __( 'From date should be less than To date', 'wt-woocommerce-invoice-addon' )
                ),
            );
            wp_enqueue_script('wc-enhanced-select');
            wp_enqueue_style('woocommerce_admin_styles', WC()->plugin_url().'/assets/css/admin.css', array(), WC_VERSION);
            wp_enqueue_media();
            wp_enqueue_script($this->module_id, plugin_dir_url( __FILE__ ).'assets/js/reports.js', array('jquery'), WF_PKLIST_VERSION, true);
            wp_localize_script($this->module_id, $this->module_id.'_params', $params);
            include( plugin_dir_path( __FILE__ ) . 'views/settings.php' );
        }

        public function save_bulk_document() {
            $nonce = isset( $_REQUEST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['_wpnonce'] ) ) : ''; 
            if ( ! wp_verify_nonce( $nonce, $this->module_id ) ) {
                $return = array(
                    'error' => __( 'You are not allowed to do this action', 'wt-woocommerce-invoice-addon' ),
                );
                echo wp_json_encode($return);
                exit();
            } else {
                // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized via custom sanitize_text_arr method
                $order_ids = isset( $_POST['order_ids'] ) ? Wf_Woocommerce_Packing_List_Admin::sanitize_text_arr( wp_unslash( $_POST['order_ids'] ), 'int') : array();
                
                if ( empty( $order_ids ) ) {
                    $return = array(
                        'error' => __( 'No orders found!', 'wt-woocommerce-invoice-addon' ),
                    );
                    echo wp_json_encode($return);
                    exit();
                }

                $template_type = isset( $_POST['template_type'] ) ? sanitize_text_field( wp_unslash( $_POST['template_type'] ) ) : '';
                
                if ( empty( $template_type ) ) {
                    $return = array(
                        'error' => __( 'Document type is not selected', 'wt-woocommerce-invoice-addon' ),
                    );
                    echo wp_json_encode($return);
                    exit();
                }

                $transient  = "wt_pdf_report_bulk_export_{$template_type}";
                $filelist   = get_transient( $transient );
                $success    = array();
                if ( ! is_array( $filelist ) ) {
                    $filelist = array();
                }
                
                $file_list_arr      = array( 'file_list' => array(), 'success' => array() );
                $document_module_id = Wf_Woocommerce_Packing_List::get_module_id( $template_type );
                $file_list_arr      = apply_filters( 'wt_pklist_export_bulk_report_pdfs_'.$template_type, $file_list_arr, $order_ids, $document_module_id );
                $file_list          = array_unique( array_merge( $filelist, $file_list_arr['file_list'] ) );
                set_transient( $transient, $file_list, DAY_IN_SECONDS );
                $return = array(
                    'file_list'     => $file_list_arr['file_list'],
                    'success_files' => $file_list_arr['success'],
                    'order_ids'     => $order_ids,
                    'transient'     => $transient,
                    'file_name'     => sanitize_file_name( $template_type.'.zip' ),
                );
                if ( empty( $return['file_list'] ) ) {
                    $return['error'] = __( 'Could not process this request', 'wt-woocommerce-invoice-addon' );
                }
                echo wp_json_encode($return);
                exit();
            }    
        }

        public function wtpdf_report_zip_bulk() {
            $nonce = isset( $_REQUEST['security'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['security'] ) ) : ''; 
            if ( ! wp_verify_nonce( $nonce, $this->module_id ) ) {
                $return = array(
                    'error' => __( 'You are not allowed to do this action', 'wt-woocommerce-invoice-addon' ),
                );
                $this->wtpdf_report_logger( $return );
                echo wp_json_encode( $return );
                exit();
            } 
            
            // phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged -- Required for bulk PDF generation
            @set_time_limit(0);

            if ( isset( $_GET['transient'] ) ) {
                $transient = sanitize_key( $_GET['transient'] );
                $filelist  = get_transient( $transient );
                if ( false === $filelist ) {
                    $this->wtpdf_report_logger( sprintf( 'Could not read file list transient (%s) for bulk export process', $transient ) );
                }	
                delete_transient( $transient );
            }

            $template_type = isset( $_REQUEST['template_type'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['template_type'] ) ) : '';
            $filename      = sanitize_file_name( $template_type.'.zip' );
            $filelist      = array_filter($filelist, function($value) {
                return $value !== "empty_file";
            });

            try {
                if ( $zipfile = $this->create_zip( $filelist, $filename ) ) {
                    if ( headers_sent() ) {
                        $this->wtpdf_report_logger('HTTP header already sent');
                        echo 'HTTP header already sent';
                    } else {
                        if ( function_exists('apache_setenv') ) {
                            apache_setenv('no-gzip', 1);
                            apache_setenv('dont-vary', 1);
                        }
                        $output_compression = ini_get('zlib.output_compression');
                        if ( $output_compression && $output_compression !== 'off' ) {
                            // phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged -- Required to disable output compression for ZIP download
                            $set_output_compression = ini_set('zlib.output_compression', 0);
                            if ( $output_compression && $output_compression !== 'off' ) {
                                $this->wtpdf_report_logger('zlib.output_compression needs to be turned off in PHP to create a zip file');
                                throw new \Exception('zlib.output_compression needs to be turned off in PHP to create a zip file');
                            }
                        }
                        ob_clean();
                        ob_end_flush();
                        header('Content-Description: File Transfer');
                        header('Content-Type: application/x-zip');
                        header('Content-Disposition: attachment; filename="'.$filename.'"');
                        header('Content-Transfer-Encoding: binary');
                        header('Connection: Keep-Alive');
                        header('Expires: 0');
                        header('Cache-Control: no-cache, must-revalidate, post-check=0, pre-check=0');
                        header('Pragma: public');
                        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile -- Direct file output for download
                        @readfile($zipfile);
                        wp_delete_file($zipfile); // Delete the file after downloading.
                    }
                }	
            } catch (\Exception $e) {
                $this->wtpdf_report_logger( $e->getMessage() );
                $return = array(
                    'error' => $e->getMessage()
                );
                echo wp_json_encode( $return );
            }
            exit;
        }

        public function create_zip( $filelist, $zip_filename ) {
            $zip      = new \ZipArchive();
            $tmp_path = trailingslashit( Wf_Woocommerce_Packing_List::get_temp_dir('path') );
            wp_delete_file( $tmp_path . $zip_filename );

            if ( TRUE !== $zip->open( $tmp_path . $zip_filename, \ZipArchive::CREATE | \ZipArchive::OVERWRITE ) ) {
                $this->wtpdf_report_logger( sprintf( 'An error occurred creating your ZIP file (%s)', $zip_filename ) );
                throw new \Exception( sprintf( 'An error occurred creating your ZIP file (%s)', esc_html( $zip_filename ) ) );
            }

            foreach ( $filelist as $filepath ) {
                if ( is_readable( $filepath ) ) {
                    $added = $zip->addFile( $filepath, basename( $filepath ) );
                    if ( $added === false ) {
                        $this->wtpdf_report_logger( sprintf( 'Could not add PDF file (%s) during ZIP process', $filepath ) );
                    }
                } else {
                    $this->wtpdf_report_logger( sprintf( 'Could not read PDF file (%s) during ZIP process', $filepath ) );
                }
            }

            $closed = $zip->close();
            if ( $closed === true ) {
                return $tmp_path . $zip_filename;
            } else {
                $this->wtpdf_report_logger( sprintf( 'ZIP file could not be saved (%s)', $zip_filename ) );
                throw new \Exception( sprintf( 'ZIP file could not be saved (%s)', esc_html( $zip_filename ) ) );
            }
        }

        public function wtpdf_report_logger( $logger_res_array = '' ) {
            $track_log = ( defined( 'WP_DEBUG' ) && WP_DEBUG ) || apply_filters( 'wt_pklist_report_pdf_enable_log', false );
            if ( function_exists( 'wc_get_logger' ) && ! empty( $logger_res_array ) && true === $track_log ) {
                $logger = wc_get_logger();
                $logger->info( wc_print_r( $logger_res_array, true ), array( 'source' => $this->wt_pdf_report_log_name ) );
            }
        }
    }
    new Wtpdf_Reports();
}
