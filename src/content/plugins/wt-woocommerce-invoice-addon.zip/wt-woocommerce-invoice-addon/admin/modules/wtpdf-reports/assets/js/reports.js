(function( $ ) {
    $(function() {

        do_report_pdf();

        $(".wt_pdf_report_field").on('change',function(){
            do_report_pdf();
        });

        // Getting order ids on the export button click event.
        $( '#wt_pdf_report_export' ).on( 'click', function( event ) {
            event.preventDefault();
            var report_nonce    = $("#wtpdf_bulk_export_pdf_nonce_id").val();
            var template_type   = $("#wtpdf_report_doc_type").val();
            var date_type       = $('[name=wt_pdf_reports_date_type]:checked').val();
            var fromDate        = '';
            var toDate          = '';
            var based_on        = $('[name=wt_pdf_reports_date_based_on]:checked').val();
            
            if ( "fixed" === date_type ) {
                var chosen_date_elm = $('[name="wt_pdf_reports_date_type_fixed"]:checked');
                if ("all" !== chosen_date_elm.val() ) {
                    fromDate    = chosen_date_elm.attr( 'data-from-date' );
                    toDate      = chosen_date_elm.attr( 'data-to-date');
                }
            } else {
                var from_date   = $('[name="wt_pdf_reports_date_type_custom_from"]').val();
                var to_date     = $('[name="wt_pdf_reports_date_type_custom_to"]').val();
                fromDate        = from_date +' 00:00:00';
                toDate          = to_date + ' 23:59:59';
            }

            if ( fromDate > toDate ) {
                wf_notify_msg.error( wf_woocommerce_packing_list_reports_params.msgs.date_compare_message );
                return false;
            }

            var order_statuses  = $('#wt_pdf_reports_order_statuses').val();

            var user_type       = $('[name=wt_pdf_reports_user_type]').val();
            if( "selected_users" === user_type || "except_users" === user_type ) {
                selectedUsers = $('#wt_pdf_reports_user_type_selected_users').val();
            } else{
                selectedUsers = [];
            }

            var selectedPaymentMethod = [];
            $('input[name="wt_pdf_reports_payment_method"]:checked').each( function() {
                var payment_method = $(this).val();
                if ( !selectedPaymentMethod.includes( payment_method ) ) {
                    selectedPaymentMethod.push( payment_method );
                }
            });

            $.ajax({
                url: wf_woocommerce_packing_list_reports_params.ajax_url,
                type: 'POST',
                data: {
                    'report_nonce'      : report_nonce,
                    'action'            : 'wt_pklist_report_get_order_ids',
                    'template_type'     : template_type,
                    'from_date'         : fromDate,
                    'to_date'           : toDate,
                    'order_statuses'    : order_statuses,
                    'user_type'         : user_type,
                    'users'             : selectedUsers,
                    'payment_methods'   : selectedPaymentMethod,
                    'based_on'          : based_on,
                },
                dataType: 'json',
                success: function(response) {
                    if ( null !== response && 'object' === typeof response ) {
                        wf_woocommerce_packing_list_reports_params.saved_files = [];
                        wf_woocommerce_packing_list_reports_params.successcount = 0;
                        wf_woocommerce_packing_list_reports_params.empty_file = 0;
                        if ( response.order_ids.length > 0) {
                            wf_popup.showPopup($('.wt_pdf_report_popup'));
                            wtpdf_bulk_export( response.order_ids, 10, 0, 'zip')
                        } else {
                            wf_popup.hidePopup($('.wt_pdf_report_popup'));
                            wf_notify_msg.error( response.error );
                            return false;
                        }
                    }
                },
                error: function(xhr, status, error) {
                    // Handle error
                    console.log( error );
                }
            });
        }); 
    });

    function do_report_pdf () {
        var template_type   = $('#wtpdf_report_doc_type').val();
        $('.total_order_count').hide();
        $('.total_order_count[data-document-type="'+ template_type +'"]').show();
        if( "packinglist" === template_type ) {
            $(".packingslip_warn_msg").fadeIn().css('display','flex');
        } else {
            $(".packingslip_warn_msg").hide();
        }

        if ('invoice' !== template_type) {
            $('.wt_pdf_report_based_on_main').hide();
            $('input[name="wt_pdf_reports_date_based_on"]').prop('checked', false);
        } else {
            if (!$('.wt_pdf_report_based_on_main').is(':visible')) {
                $('.wt_pdf_report_based_on_main').show();
                $('input[name="wt_pdf_reports_date_based_on"][value="_order_date"]').prop('checked', true);
            }
        }
        

        // date type changes
        var date_type   = $('[name=wt_pdf_reports_date_type]:checked').val();
        $(".wt_pdf_reports_date_type_sub_fields").hide();
        $('.wt_pdf_reports_date_type_sub_fields[data-date-type="'+date_type+'"]').show();

        if ( date_type === "custom" ) {
            var from_date   = $('[name="wt_pdf_reports_date_type_custom_from"]').val();
            var to_date     = $('[name="wt_pdf_reports_date_type_custom_to"]').val();

            $('[name="wt_pdf_reports_date_type_custom_from"]').attr('max',to_date);
            $('[name="wt_pdf_reports_date_type_custom_to"]').attr('min',from_date);
        }

        // user type changes
        var user_type   = $('[name=wt_pdf_reports_user_type]').val();
        if( user_type === "selected_users" || user_type === "except_users" ) {
            $('.wt_pdf_reports_user_type_sub').show();
        } else{
            $('.wt_pdf_reports_user_type_sub').hide();
        }

    }

    function wtpdf_bulk_export( order_ids, chunk_size, current_offset ) {
        $("#wtpdf_report_before_download").show();
        $("#wtpdf_report_after_download").hide();
        var order_ids_chunk = order_ids.slice( current_offset, current_offset+chunk_size );
        var bulk_nonce      = $("[name=wtpdf_bulk_export_pdf_nonce]").val();
        var template_type   = $("#wtpdf_report_doc_type").val();
        var data            = {
            action          : 'wtpdf_bulk_export_document',
            _wpnonce        : bulk_nonce,
            template_type   : template_type,
            order_ids       : order_ids_chunk,
        };
        $.ajax({
            async:    true,
            url:      wf_woocommerce_packing_list_reports_params.ajax_url,
            data:     data,
            type:     'POST',
            dataType: 'json',
            success:  function( response ) {
                //document_success_notice
                if (response !== null && typeof response === 'object' && 'success_files' in response) {
                    
                    if( Object.keys(response.success_files).length > 0 ) {
                        $.each(response.success_files, function (order_id, filename) {

                            wf_woocommerce_packing_list_reports_params.successcount++;

                            if ( "empty_file" === filename ) {
                                wf_woocommerce_packing_list_reports_params.empty_file++;
                            }

                            var progress_width = (wf_woocommerce_packing_list_reports_params.successcount/order_ids.length) * 100;
                            var pre_text = '('+parseInt(progress_width)+'%)';
                            $("#wtpdf-report-progress-file-precentage").text( pre_text  );
                            $("#wtpdf-report-progress-bar").css('width',progress_width+'%');
                        });
                    } else {
                        jQuery('.wf_cst_overlay, .wf_pklist_popup').hide();
                        wf_notify_msg.error( response.error );
                        return false;
                    }
                }
                
                // calc make new offset
                current_offset = current_offset + chunk_size;
                // continue if we have order_ids left
                if ( current_offset < order_ids.length ) {
                    wtpdf_bulk_export( order_ids, chunk_size, current_offset );
                } else {

                    setTimeout(function() {
                        $("#wtpdf_report_before_download").hide();
                        $("#wtpdf-report-progress-file-precentage").text( '0%' );
                        $("#wtpdf-report-progress-bar").css('width','0%');
                        $("#wtpdf_report_after_download").show();

                        var url = wf_woocommerce_packing_list_reports_params.ajax_url+'?action=wtpdf_report_zip_bulk&security='+bulk_nonce+'&transient='+response.transient+'&template_type='+template_type;
                        var a = document.createElement('A');
                        a.href = url;
                        a.download = response.filename;
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);

                        setTimeout(function() {
                            jQuery('.wf_cst_overlay, .wf_pklist_popup').hide();
                        }, 1000);
                    }, 3000);
                }
            },
        });
    }

})( jQuery );