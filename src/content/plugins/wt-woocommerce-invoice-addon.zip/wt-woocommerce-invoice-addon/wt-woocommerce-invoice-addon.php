<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://www.webtoffee.com/
 * @since             1.0.0
 * @package           Wt_woocommerce_invoice_addon
 *
 * @wordpress-plugin
 * Plugin Name:       WooCommerce PDF Invoices, Packing Slips and Credit Notes (Pro)
 * Plugin URI:        https://www.webtoffee.com/
 * Description:       Extension for the WooCommerce PDF Invoices and Packingslip by Webtoffee
 * Version:           1.7.5
 * Author:            Webtoffee
 * Description:       Extension for the WooCommerce PDF Invoices and Packingslip by WebToffee
 * Author:            WebToffee
 * Author URI:        https://www.webtoffee.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wt-woocommerce-invoice-addon
 * Domain Path:       /languages
 * WC tested up to:   10.6.2
 */

// If this file is called directly, abort.
if (! defined('WPINC')) {
    die;
}

include_once(ABSPATH . 'wp-admin/includes/plugin.php');

/**
 *  Declare compatibility with custom order tables for WooCommerce.
 * 
 *  @since 1.0.3
 *  @since 1.3.0 - Declare the compatibility with WooCommerce Checkout block
 *  
 */
add_action(
    'before_woocommerce_init',
    function () {
        if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
        }
    }
);

$current_plugin_name = 'WooCommerce PDF Invoices, Packing Slips and Credit Notes (Pro)';
$wt_pklist_no_plugin_conflict = true;

//check if premium version is there
if (is_plugin_active('wt-woocommerce-packing-list/wf-woocommerce-packing-list.php')) {
    $active_plugin_name = 'WooCommerce PDF Invoices, Packing Slips, Delivery Notes and Shipping Labels (Pro)';
    $wt_pklist_no_plugin_conflict = false;
} else if (is_plugin_active('shipping-labels-for-woo/wf-woocommerce-packing-list.php')) {
    $active_plugin_name = 'WooCommerce Shipping Label (Basic)';
    $wt_pklist_no_plugin_conflict = false;
}

// Handle conflicts with premium and basic versions (existing flow)
if (!$wt_pklist_no_plugin_conflict) {
    deactivate_plugins(plugin_basename(__FILE__));
    /* translators: %1$s: active plugin name %2$s: current plugin name */
    wp_die(sprintf( esc_html__('The plugins %1$s and %2$s cannot be active in your store at the same time. Kindly deactivate one of these prior to activating the other.', 'wt-woocommerce-invoice-addon'), esc_html($active_plugin_name), esc_html($current_plugin_name)), "", array('link_url' => esc_url(admin_url('plugins.php')), 'link_text' => esc_html__('Go to plugins page', 'wt-woocommerce-invoice-addon') ));
}

// Handle conflict with remote print addon (deactivate remote print addon instead)
if (is_plugin_active('wt-woocommerce-packing-list-printnode/wt-woocommerce-packing-list-printnode.php')) {
    $conflicting_plugin_basename = 'wt-woocommerce-packing-list-printnode/wt-woocommerce-packing-list-printnode.php';
    $active_plugin_name = 'Remote print addon for WooCommerce PDF Invoices - PrintNode';
    // Deactivate the conflicting plugin instead of this plugin
    deactivate_plugins($conflicting_plugin_basename);
    /* translators: %1$s: active plugin name %2$s: current plugin name */
    wp_die(sprintf( esc_html__('The plugin %1$s has been deactivated because it conflicts with %2$s. These plugins cannot be active at the same time.', 'wt-woocommerce-invoice-addon'), esc_html($active_plugin_name), esc_html($current_plugin_name)), "", array('link_url' => esc_url(admin_url('plugins.php')), 'link_text' => esc_html__('Go to plugins page', 'wt-woocommerce-invoice-addon') ));
}

if (!is_plugin_active('print-invoices-packing-slip-labels-for-woocommerce/print-invoices-packing-slip-labels-for-woocommerce.php')) {
    deactivate_plugins(plugin_basename(__FILE__));
    unset($_GET['activate']);
    add_action('admin_notices', 'base_plugin_not_active_ipc');
    return;
}
function base_plugin_not_active_ipc()
{
    // $base_plugin_name =  "WooCommerce PDF Invoices, Packing Slips, Delivery Notes and Shipping Labels (Free)";
    $class = 'notice notice-error';
    $message = __('WooCommerce PDF Invoices, Packing Slips and Credit Notes (Pro) plugin could not be activated. Please ensure the WooCommerce PDF Invoices, Packing Slips, Delivery Notes and Shipping Labels (Free) is active', 'wt-woocommerce-invoice-addon');

    printf('<div class="%1$s"><p>%2$s</p></div>', esc_attr($class), esc_html($message));
}
/**
 * Currently plugin version.
 */
if (!defined('WT_PKLIST_INVOICE_ADDON_VERSION')) {
    define('WT_PKLIST_INVOICE_ADDON_VERSION', '1.7.5');
}
if (!defined('WT_PKLIST_INVOICE_ADDON_TRANSLATION_VERSION')) {
    define('WT_PKLIST_INVOICE_ADDON_TRANSLATION_VERSION', '1.7.0');
}
if (!defined('WT_PKLIST_INVOICE_ADDON_PLUGIN_URL')) {
    define('WT_PKLIST_INVOICE_ADDON_PLUGIN_PATH', plugin_dir_path(__FILE__));
    define('WT_PKLIST_INVOICE_ADDON_PLUGIN_URL', plugin_dir_url(__FILE__));
}
if (!defined('WT_PKLIST_INVOICE_ADDON_FILENAME')) {
    define('WT_PKLIST_INVOICE_ADDON_FILENAME', __FILE__);
}
if (!defined('WT_PKLIST_INVOICE_ADDON_PLUGIN_NAME')) {
    define('WT_PKLIST_INVOICE_ADDON_PLUGIN_NAME', 'wt-woocommerce-invoice-addon');
}

if (!defined('WT_PKLIST_INVOICE_ADDON_PLUGIN_BASENAME')) {
    define('WT_PKLIST_INVOICE_ADDON_PLUGIN_BASENAME', plugin_basename(__FILE__));
}
define('WT_PKLIST_INVOICE_ADDON_EDD_ACTIVATION_ID', '10191');

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wt_woocommerce_invoice_addon-activator.php
 */
function activate_wt_woocommerce_invoice_addon()
{
    require_once plugin_dir_path(__FILE__) . 'includes/class-wt_woocommerce_invoice_addon-activator.php';
    Wt_woocommerce_invoice_addon_Activator::activate();
}



/**
 *  @since 1.6.3
 *  Changelog in plugins page
 */

add_action('in_plugin_update_message-wt-woocommerce-invoice-addon/wt-woocommerce-invoice-addon.php', 'wbte_woocommerce_invoice_addon_update_message', 10, 2);

function wbte_woocommerce_invoice_addon_update_message($data, $response)
{
    if (isset($data['upgrade_notice'])) {
        add_action('admin_print_footer_scripts', 'wbte_woocommerce_invoice_addon_plugin_screen_update_js');

        $msg = str_replace(array('<p>', '</p>'), array('<div>', '</div>'), $data['upgrade_notice']);
        echo '<style type="text/css">
             #wt-woocommerce-invoice-addon-update .update-message p:last-child { display: none; }
             #wt-woocommerce-invoice-addon-update ul { list-style: disc; margin-left: 30px; }
             .wf-update-message { padding-left: 30px; }
         </style>
         <div class="update-message wf-update-message">' . wp_kses_post( wpautop( $msg ) ) . '</div>';
    }
}

function wbte_woocommerce_invoice_addon_plugin_screen_update_js()
{
?>
    <script>
        (function($) {
            var updateDiv = $('#wt-woocommerce-invoice-addon-update');
            updateDiv.find('.wf-update-message').next('p').remove();
            updateDiv.find('a.update-link:eq(0)').click(function() {
                $('.wf-update-message').remove();
            });
        })(jQuery);
    </script>
<?php
}





/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wt_woocommerce_invoice_addon-deactivator.php
 */
function deactivate_wt_woocommerce_invoice_addon()
{
    require_once plugin_dir_path(__FILE__) . 'includes/class-wt_woocommerce_invoice_addon-deactivator.php';
    Wt_woocommerce_invoice_addon_Deactivator::deactivate();
}
if (class_exists('Wf_Woocommerce_Packing_List')) {
    register_activation_hook(__FILE__, 'activate_wt_woocommerce_invoice_addon');
}
register_deactivation_hook(__FILE__, 'deactivate_wt_woocommerce_invoice_addon');

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path(__FILE__) . 'includes/class-wt_woocommerce_invoice_addon.php';

/**
 * PrintNode functionality integration
 */
require plugin_dir_path(__FILE__) . 'includes/remote_print/class-wt_woocommerce_printnode_addon.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wt_woocommerce_invoice_addon()
{

    $plugin = new Wt_woocommerce_invoice_addon();
    $plugin->run();
}
if (class_exists('Wf_Woocommerce_Packing_List')) {
    run_wt_woocommerce_invoice_addon();
}

add_action( 'plugins_loaded', function () {

    // Only touch the admin side.
    if ( ! is_admin() ) {
        return;
    }

    // Make sure the licence manager class exists.
    if ( ! class_exists( 'Wf_Woocommerce_Packing_List_Licence_Manager' ) ) {
        return;
    }

    global $wp_filter;

    if ( empty( $wp_filter['admin_init'] ) ) {
        return;
    }

    $hook = $wp_filter['admin_init'];

    // Modern WP stores hooks in WP_Hook objects.
    if ( $hook instanceof WP_Hook ) {
        foreach ( $hook->callbacks as $priority => $callbacks ) {
            foreach ( $callbacks as $id => $callback ) {

                if ( empty( $callback['function'] ) || ! is_array( $callback['function'] ) ) {
                    continue;
                }

                $object = $callback['function'][0];
                $method = $callback['function'][1];

                // Strip only the licence manager's init() callback.
                if ( is_object( $object )
                    && $object instanceof Wf_Woocommerce_Packing_List_Licence_Manager
                    && 'init' === $method
                ) {
                    unset( $hook->callbacks[ $priority ][ $id ] );
                }
            }

            // Clean up empty priority buckets.
            if ( empty( $hook->callbacks[ $priority ] ) ) {
                unset( $hook->callbacks[ $priority ] );
            }
        }
    }
}, 50 );

