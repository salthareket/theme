<?php
 
/**
*	EDD specific methods
*
*/
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( !class_exists( 'Wf_Woocommerce_Packing_List_Licence_Manager_Edd' )) {
	class Wf_Woocommerce_Packing_List_Licence_Manager_Edd
	{

		private static $instance;

		public static function get_instance()
		{
			if(!self::$instance)
			{
				self::$instance=new Wf_Woocommerce_Packing_List_Licence_Manager_Edd();
			}
			return self::$instance;
		}

		/**
		*	Fetch the details of the new update.
		*	This will show in the plugins page as a popup
		*/
		public function update_details($license_manager, $product_data, $licence_data, $false, $action, $args)
		{
			$url_args = array(
				'edd_action'		=> 	'get_version',
				'item_id'			=>	(isset($product_data['product_edd_id']) ? $product_data['product_edd_id'] : 0),
				'license'			=>	$licence_data['key'],
				'url' 				=> 	urlencode(home_url()),
			);
			$response = $license_manager->fetch_plugin_info($url_args);		

			if(isset($response) && is_object($response) && $response!==false)
			{
				if(!property_exists($response, 'errors')) /* no errors */
				{
					$plugin_slug=$args->slug;
					$response->name=$license_manager->get_display_name($plugin_slug);
					
					if(isset($response->download_link))
					{
						$response->version=isset($response->new_version) ? $response->new_version : 0;
						$response->slug=$plugin_slug;
						$response->download_link=isset($response->download_link) ? $response->download_link : '';
						$response->sections=isset($response->sections) ? maybe_unserialize($response->sections) : array();				
						$response->banners=isset($response->banners) ? maybe_unserialize($response->banners) : array();				
						$response->icons=isset($response->icons) ? maybe_unserialize($response->icons) : array();				
					}
					return $response;
				}
			}
			return $false;
		}

		/**
		 * To get the status of the license data
		 *
		 * @param array $licence_data
		 * @param array $response_arr
		 * @return string
		 */
		public function check_status( $licence_data, $response_arr )
		{
			$new_status = $licence_data['status'];

			if ( ! empty( $response_arr['success'] ) ) {
				if ( true === $response_arr['success'] && !empty( $response_arr['license'] ) ) {
					$new_status = ( $response_arr['license'] === 'valid' ) ? 'active' : 'inactive';
				} elseif ( isset( $response_arr['license'] ) && $response_arr['license'] !== 'valid' ) {
					$new_status = 'inactive';
				}
			}
			return $new_status;
		}
	}
}