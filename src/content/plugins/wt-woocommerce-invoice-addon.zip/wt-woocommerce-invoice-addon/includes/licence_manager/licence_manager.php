<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! class_exists( 'Wf_Woocommerce_Packing_List_Licence_Manager' ) ) {

	class Wf_Woocommerce_Packing_List_Licence_Manager {

		public $module_id        = '';
		public $module_base      = 'licence_manager';
		public $api_url          = 'https://licensing.webtoffee.com/';
		public $main_plugin_slug = '';
		public $my_account_url   = 'https://www.webtoffee.com/my-account';
		public $products         = array();
		public $tab_icons        = array(
			'active'   => '<span class="dashicons dashicons-yes" style="color:#03da01; font-size:25px;"></span>',
			'inactive' => '<span class="dashicons dashicons-warning" style="color:#ff1515; font-size:25px;"></span>',
		);
		public $last_error_message;

		/**
		 * Product data to show expired message.
		 * This will be used in the callback method for showing messages.
		 * 
		 * @since 1.6.1
		 * @var array
		 */
		private $product_data_to_show_expired_msg = array();

		/** 
		 * 	Licence data to show expired message.
		 * 	This will be used in the callback method for showing messages.
		 * 
		 * @since 1.6.1
		 * @var array
		 */
		private $licence_data_to_show_expired_msg = array();
		
		public function __construct() {
			$this->module_id        = Wf_Woocommerce_Packing_List::get_module_id( $this->module_base );
			$this->my_account_url   = $this->api_url . 'my-account';
			$this->main_plugin_slug = 'wt-woocommerce-invoice-addon'; // main file name.
			$this->products         = array();
			require_once plugin_dir_path( __FILE__ ) . 'classes/class-edd.php';

			add_action( 'admin_init', array( $this, 'init' ), 1 );

			/**
			*   Add tab to settings section
			*/
			add_filter( 'wf_pklist_plugin_settings_tabhead', array( $this, 'licence_tabhead' ) );
			add_action( 'wf_pklist_plugin_out_settings_form', array( $this, 'licence_content' ) );

			add_filter( 'wt_pklist_plugin_settings_tabhead', array( $this, 'licence_tabhead' ) );
			add_action( 'wt_pklist_plugin_out_settings_form', array( $this, 'licence_content' ) );

			/**
			*    Main Ajax hook to handle all ajax requests
			*/
			add_action( 'wp_ajax_wt_pklist_licence_manager_ajax', array( $this, 'ajax_main' ), 11 );

			/**
			 *	Check for licence status. Will check once in a day.
			 *	@since 1.6.1
			 */
			add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'check_licence_status' ), 9 );
		}

		public function init() {
			/**
			*   Add products to licence manager
			*/
			$this->products = apply_filters( 'wt_pklist_add_licence_manager', $this->products );

			$this->check_for_licence_status_message();
			$this->add_to_edd_plugin_updator();
		}

		public function all_products() {
			/**
			*   Add products to licence manager
			*/
			$this->products = apply_filters( 'wt_pklist_add_licence_manager', $this->products );
			return $this->products;
		}

		/**
		*   Licence tab head
		*/
		public function licence_tabhead( $arr ) {
			$all_products = $this->all_products();
			if ( empty( $all_products ) ) {
				return $arr;
			}

			$status       = true;
			$licence_data = $this->get_licence_data();
			if ( ! $licence_data ) {
				$status = false; //no licence found
			}

			if ( $status && count( $licence_data ) !== count( $this->products ) ) {
				$status = false; //licence misisng for some products
			}

			if ( $status ) {
				$licence_statuses = array_column( $licence_data, 'status' );
				if ( 0 === count( $licence_statuses ) || in_array( 'inactive', $licence_statuses ) || in_array( '', $licence_statuses ) ) {
					$status = false;
				}
			}

			if ( $status ) {
				$activate_icon = $this->tab_icons['active'];
			} else {
				$activate_icon = $this->tab_icons['inactive'];
			}
			$arr['wt-licence'] = array( __( 'License', 'wt-woocommerce-invoice-addon' ), $activate_icon );
			return $arr;
		}

		/**
		*   Licence tab content
		*/
		public function licence_content() {
			
			wp_enqueue_script( $this->module_id, plugin_dir_url( __FILE__ ) . 'assets/js/main.js', array( 'jquery' ), WF_PKLIST_VERSION, true );

			$params = array(
				'ajax_url'  => admin_url( 'admin-ajax.php' ),
				'nonce'     => wp_create_nonce( WF_PKLIST_POST_TYPE ),
				'tab_icons' => $this->tab_icons,
				'msgs'      => array(
					'key_mandatory'      => __( 'Please enter license key', 'wt-woocommerce-invoice-addon' ),
					'email_mandatory'    => __( 'Please enter Email', 'wt-woocommerce-invoice-addon' ),
					'product_mandatory'  => __( 'Please select a product', 'wt-woocommerce-invoice-addon' ),
					'please_wait'        => __( 'Please wait...', 'wt-woocommerce-invoice-addon' ),
					'error'              => __( 'Error', 'wt-woocommerce-invoice-addon' ),
					'success'            => __( 'Success', 'wt-woocommerce-invoice-addon' ),
					'unable_to_fetch'    => __( 'Unable to fetch license details', 'wt-woocommerce-invoice-addon' ),
					'no_licence_details' => __( 'No license details found.', 'wt-woocommerce-invoice-addon' ),
					'sure'               => __( 'Are you sure?', 'wt-woocommerce-invoice-addon' ),
				)
			);
			wp_localize_script( $this->module_id, 'wt_pklist_licence_params', $params );

			$view_file = plugin_dir_path( __FILE__ ) . 'views/licence-settings.php';
			$params    = array(
				'products' => $this->products,
			);
			Wf_Woocommerce_Packing_List_Admin::envelope_settings_tabcontent( 'wt-licence', $view_file, '', $params, 0 );
		}

		/**
		* Main Ajax hook to handle all ajax requests.
		*/
		public function ajax_main() {
			$allowed_actions = array( 'activate', 'deactivate', 'delete', 'licence_list' );
			$action          = (isset($_POST['wt_pklist_licence_manager_action']) ? sanitize_text_field(wp_unslash($_POST['wt_pklist_licence_manager_action'])) : ''); // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$out             = array(
				'status' => true,
				'msg'    => '',
			);
			if ( ! Wf_Woocommerce_Packing_List_Admin::check_write_access( WF_PKLIST_POST_TYPE ) ) {
				$out['status'] = false;

			} else {
				if ( !empty( $action ) && in_array( $action, $allowed_actions ) ) {
					if ( method_exists( $this, $action ) ) {
						$out = $this->{$action}( $out );
					}
				}
			}
			echo json_encode( $out );
			exit();
		}

		/**
		*   Ajax sub function to get license list
		*/
		public function licence_list( $out ) {
			// This method is also hooked into `pre_set_site_transient_update_plugins` filter.
			$this->check_licence_status();

			$licence_data_arr = $this->get_licence_data(); //taking all license info
			ob_start();
			include plugin_dir_path( __FILE__ ) . 'views/_licence_list.php';
			$out['html'] = ob_get_clean();
			return $out;
		}

		/**
		 * Get the license data of plugins
		 *
		 * @param string $product_slug
		 * @return array
		 */
		private function get_licence_data( $product_slug = '' ) {
			$this->products = $this->all_products();

			if ( '' !== $product_slug ) {
				$licence_data = (array) get_option( $product_slug . '_licence_data', false );
			} else {
				$licence_data = array();
				foreach ( $this->products as $product_slug => $product ) {
					$licence_info = get_option( $product_slug . '_licence_data', false );
					if ( $licence_info ) {
						$licence_data[ $product_slug ] = $licence_info;
					}
				}
			}
			return $licence_data;
		}

		/**
		*   Fetch plugin info for update check and update info
		*/
		public function fetch_plugin_info( $args ) {
			$request = $this->remote_get( $args );

			if ( is_wp_error( $request ) || 200 !== wp_remote_retrieve_response_code( $request ) ) {
				return false;
			}

			if ( isset( $args['api_key'] ) ) {
				$response = maybe_unserialize( wp_remote_retrieve_body( $request ) );
			} else {
				$response = json_decode( wp_remote_retrieve_body( $request ) );
			}

			if ( is_object( $response ) ) {
				return $response;
			} else {
				return false;
			}
		}

		/**
		*   Fetch licence status
		*/
		public function fetch_status( $product_data, $licence_data ) {
			$args = array(
				'edd_action' => 'check_license',
				'license'    => $licence_data['key'],
				'item_id'    => ( isset( $product_data['product_edd_id'] ) ? $product_data['product_edd_id'] : 0 ),
				'url'        => urlencode( home_url() ),
			);

			$request = $this->remote_get( $args );

			$response = wp_remote_retrieve_body( $request );

			return $response;
		}

		/**
		*   Ajax sub function to delete licence
		*/
		public function delete( $out ) {
			$this->products		= $this->all_products();
			$out['status'] 		= false;
			$er            		= 0;
			$licence_product 	= trim(isset($_POST['wt_pklist_licence_product']) ? sanitize_text_field(wp_unslash($_POST['wt_pklist_licence_product'])) : ''); // phpcs:ignore WordPress.Security.NonceVerification.Missing
			if ( '' === $licence_product ) {
				$er         = 1;
				$out['msg'] = __( 'Error !!!', 'wt-woocommerce-invoice-addon' );
			} else {
				if ( ! isset( $this->products[ $licence_product ] ) ) {
					$er         = 1;
					$out['msg'] = __( 'Error !!!', 'wt-woocommerce-invoice-addon' );
				}
			}
			if ( 0 === $er ) {
				$this->remove_licence_data( $licence_product );
				$out['status'] = true;
				$out['msg']    = __( 'Successfully deleted.', 'wt-woocommerce-invoice-addon' );
			}

			return $out;
		}


		/**
		*   Ajax sub function to deactivate licence
		*/
		public function deactivate( $out ) {

			$this->products 	= $this->all_products();
			$out['status']  	= false;
			$er             	= 0;
			$licence_product 	= trim(isset($_POST['wt_pklist_licence_product']) ? sanitize_text_field(wp_unslash($_POST['wt_pklist_licence_product'])) : ''); // phpcs:ignore WordPress.Security.NonceVerification.Missing
			
			if ( '' === $licence_product ) {
				$er         = 1;
				$out['msg'] = __( 'Error !!!', 'wt-woocommerce-invoice-addon' );
			} else {
				if ( ! isset( $this->products[ $licence_product ] ) ) {
					$er         = 1;
					$out['msg'] = __( 'Error !!!', 'wt-woocommerce-invoice-addon' );
				}
			}

			if ( 0 === $er ) {
				$licence_data = $this->get_licence_data( $licence_product );
				if ( ! $licence_data ) {
					$er         = 1;
					$out['msg'] = __( 'Error !!!', 'wt-woocommerce-invoice-addon' );
				}
			}

			$product_data = $this->products[ $licence_product ];
			if ( 0 === $er ) {
				$args = array(
					'edd_action' => 'deactivate_license',
					'license'    => $licence_data['key'],
					//'item_name'   => $product_data['product_display_name'], //name in EDD
					'item_id'    => ( isset( $product_data['product_edd_id'] ) ? $product_data['product_edd_id'] : 0 ), //ID in EDD
					'url'        => urlencode( home_url() ),
				);

				$response = $this->remote_get( $args );

				if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
					$out['msg'] = __( 'Request failed, Please try again', 'wt-woocommerce-invoice-addon' );
				} else {
					$response 	= json_decode( wp_remote_retrieve_body( $response ), true );
					$success  	= false;

					if ( isset( $response['success'] ) && true === $response['success'] ) {
						$success = true;
					}

					if ( $success ) {
						$this->remove_licence_data( $licence_product );
						// $this->check_if_license_activated( $licence_product, $this->products[ $licence_product ] );
						$out['status'] 	= true;
						$out['msg']    	= __( 'Successfully deactivated.', 'wt-woocommerce-invoice-addon' );
					} else {
						$out['msg'] 	= __( 'Error', 'wt-woocommerce-invoice-addon' );
					}
				}
			}
			return $out;
		}

		public function remote_get( $args ) {
			global $wp_version;
			$target_url = esc_url_raw( $this->create_api_url( $args ) );
			
			$def_args = array(
				'timeout'     => 5,
				'redirection' => 5,
				'httpversion' => '1.0',
				'user-agent'  => 'WordPress/' . $wp_version . '; ' . home_url(),
				'blocking'    => true,
				'headers'     => array(),
				'cookies'     => array(),
				'body'        => null,
				'compress'    => false,
				'decompress'  => true,
				'sslverify'   => false,
				'stream'      => false,
				'filename'    => null,
			);
			return wp_remote_get( $target_url, $def_args );
		}

		/**
		*   Ajax sub function to activate licence
		*/
		public function activate( $out ) {
			global $wp_version;
			$all_products   	= $this->all_products();
			$this->products 	= $all_products;
			$out['status']  	= false;
			$er             	= 0;
			$licence_product 	= trim(isset($_POST['wt_pklist_licence_product']) ? sanitize_text_field(wp_unslash($_POST['wt_pklist_licence_product'])) : ''); // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$licence_key     	= trim(isset($_POST['wt_pklist_licence_key']) ? sanitize_text_field(wp_unslash($_POST['wt_pklist_licence_key'])) : ''); // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$licence_email   	= trim(isset($_POST['wt_pklist_licence_email']) ? sanitize_text_field(wp_unslash($_POST['wt_pklist_licence_email'])) : ''); // phpcs:ignore WordPress.Security.NonceVerification.Missing

			if ( '' === $licence_product ) {
				$er         = 1;
				$out['msg'] = __( 'Please select a product', 'wt-woocommerce-invoice-addon' );
			} else {
				if ( ! isset( $this->products[ $licence_product ] ) ) {
					$er         = 1;
					$out['msg'] = __( 'Invalid product', 'wt-woocommerce-invoice-addon' );
				}
			}
			if ( 0 === $er && '' === $licence_key ) {
				$er         = 1;
				$out['msg'] = __( 'Please enter Licence key', 'wt-woocommerce-invoice-addon' );
			}
			if ( 0 === $er && '' !== $licence_key ) {
				/* check the licence key already applied */
				$licence_data = $this->get_licence_data();
				foreach ( $licence_data as $product_slug => $licence_info ) {
					if ( $product_slug == $licence_product ) {
						if ( 'active' === $licence_info['status'] ) {
							$er         = 1;
							$out['msg'] = __( 'The chosen plugin already has an active licence.', 'wt-woocommerce-invoice-addon' );
							break;
						}
					}

					/* current licence key matches with another product */
					if ( $licence_key === $licence_info['key'] && $product_slug !== $licence_product && $licence_info['status'] === 'active' ) {
						$er         = 1;
						$out['msg'] = __( 'This licence key has already been activated for another product. Please provide another licence key.', 'wt-woocommerce-invoice-addon' );
						break;
					}
				}
			}

			if ( 0 === $er ) {
				$product_data = $this->products[ $licence_product ];
				$args         = array(
					'edd_action' => 'activate_license',
					'license'    => $licence_key,
					//'item_name'       => $product_data['product_display_name'], //name in EDD
					'item_id'    => ( isset( $product_data['product_edd_id'] ) ? $product_data['product_edd_id'] : 0 ), //ID in EDD
					'url'        => urlencode( home_url() ),
				);
				$response     = $this->remote_get( $args );

				// Request failed
				if ( is_wp_error( $response ) ) {
					$out['msg'] = $response->get_error_message();
				} elseif ( 200 !== wp_remote_retrieve_response_code( $response ) ) {
					$out['msg'] = __( 'Request failed, Please try again', 'wt-woocommerce-invoice-addon' );
				} else {
					$response_arr = json_decode( $response['body'], true );
					if ( isset( $response_arr['success'] ) && true === $response_arr['success'] ) {
						$licence_data  = array(
							'key'         => $licence_key,
							'email'       => ( isset( $response_arr['customer_email'] ) ? sanitize_text_field( $response_arr['customer_email'] ) : '' ), //from EDD
							'status'      => 'active',
							'products'    => $product_data['product_display_name'],
							'instance_id' => ( isset( $response_arr['checksum'] ) ? sanitize_text_field( $response_arr['checksum'] ) : '' ), //from EDD
						);
						$out['status'] = true;
					}

					if ( ! $out['status'] ) {
						$out['msg'] = $this->process_error_keys( ( isset( $response_arr['error'] ) ? $response_arr['error'] : '' ) );
					}

					if ( true === $out['status'] ) {
						$this->add_new_licence_data( $licence_product, $licence_data );
						// $this->set_error_message( false, $licence_product, $this->products[ $licence_product ] );
						$out['msg'] = __( 'Successfully activated.', 'wt-woocommerce-invoice-addon' );
					}
				}
			}
			return $out;
		}

		/**
		*   Mask licence key
		*/
		public function mask_licence_key( $key ) {
			$total_length    = strlen( $key );
			$non_mask_length = 6; //including both side
			$mask_length     = $total_length - $non_mask_length;

			if ( $mask_length >= 1 ) {
				$key = substr_replace( $key, str_repeat( '*', $mask_length ), floor( $non_mask_length / 2 ), ( $total_length - $non_mask_length ) );
			} else {
				$key = str_repeat( '*', $total_length ); //replace all character
			}
			return $key;
		}

		public function get_status_label( $status ) {
			$color_arr = array(
				'active'   => '#37eb37',
				'inactive' => '#ccc',
			);
			$color_css = ( isset( $color_arr[ $status ] ) ? 'background:' . $color_arr[ $status ] . ';' : '' );
			return '<span class="wt_pklist_badge" style="' . $color_css . 'padding: 5px;border-radius: 5px;">' . ucfirst( $status ) . '</span>';
		}

		public function get_display_name( $product_slug ) {
			$this->products = $this->all_products();

			if ( isset( $this->products[ $product_slug ] ) ) {
				return $this->products[ $product_slug ]['product_display_name'];
			}
			return '';
		}

		private function create_api_url( $args ) {
			return urldecode( add_query_arg( $args, $this->api_url ) );
		}

		/**
		*   Add new licence info
		*/
		private function add_new_licence_data( $product_slug, $licence_data ) {
			update_option( $product_slug . '_licence_data', $licence_data, false );
		}

		private function remove_licence_data( $product_slug ) {
			delete_option( $product_slug . '_licence_data' );
		}

		private function update_licence_data( $product_slug, $licence_data ) {
			update_option( $product_slug . '_licence_data', $licence_data, false );
		}

		/**
		*   Check the licence type is EDD or WC
		*/
		private function get_license_type_obj( $licence_data ) {
			return Wf_Woocommerce_Packing_List_Licence_Manager_Edd::get_instance();
		}

		private function process_error_keys( $key ) {
			$msg_arr = array(
				'missing'               => __( "License doesn't exist", 'wt-woocommerce-invoice-addon' ),
				'missing_url'           => __( 'URL not provided', 'wt-woocommerce-invoice-addon' ),
				'license_not_activable' => __( "Attempting to activate a bundle's parent license", 'wt-woocommerce-invoice-addon' ),
				'disabled'              => __( 'License key revoked', 'wt-woocommerce-invoice-addon' ),
				'no_activations_left'   => __( 'No activations left', 'wt-woocommerce-invoice-addon' ),
				'expired'               => __( 'License has expired', 'wt-woocommerce-invoice-addon' ),
				'key_mismatch'          => __( 'License is not valid for this product', 'wt-woocommerce-invoice-addon' ),
				'invalid_item_id'       => __( 'Invalid Product', 'wt-woocommerce-invoice-addon' ),
				'item_name_mismatch'    => __( 'License is not valid for this product', 'wt-woocommerce-invoice-addon' ),
			);
			return ( isset( $msg_arr[ $key ] ) ? $msg_arr[ $key ] : __( 'Error', 'wt-woocommerce-invoice-addon' ) );
		}

		public function check_for_licence_status_message() {
			global $pagenow;
			
			// Check if we are on the plugins page or the plugin's page.
			if( empty( $pagenow ) || ! in_array( $pagenow, array( 'plugins.php', 'admin.php' ) ) ) {
				return;
			}

			/**
			*   Get all licence info
			*/
			$licence_data = $this->get_licence_data();

			$require_js_block = false;

			foreach ( $this->products as $product_slug => $product ) {
			
				$product_licence_data = ! empty( $licence_data[ $product_slug ] ) ? $licence_data[ $product_slug ] : array();
	
				// Check if the licence is not active.
				if ( ! ( isset( $product_licence_data['status'] ) 
					  && $product_licence_data['status'] !== '' 
					  && $product_licence_data['status'] !== 'inactive' ) ) {
					
					$this->product_data_to_show_expired_msg[ $product_slug ] = $product;
					$this->licence_data_to_show_expired_msg[ $product_slug ] = $product_licence_data;
	
					if ( 'plugins.php' === $pagenow ) { // On the plugins page.
						$require_js_block = true;
						add_action('after_plugin_row_'.("{$product_slug}/{$product_slug}.php"), array($this, 'add_licence_status_message'), 10, 3);
					} else { // On the plugin's page.	
						add_action('admin_notices', array($this, 'add_licence_status_message'));
					}
				}
			}
			
			if ( $require_js_block ) {
				add_action('admin_footer', array($this, 'plugins_page_scripts'));
			}
		}

		public function plugins_page_scripts() {
			?>
		<style type="text/css">
			.wt-pklist-addons-plugin-notice-tr p:before{ content: "\f534"; }
		</style>
		<script type="text/javascript">
			jQuery(document).ready(function(){
				jQuery('.wt-pklist-addons-plugin-notice-tr').each(function(){
					if(jQuery(this).prev().addClass('update').hasClass('active'))
					{
						jQuery(this).addClass('active');
					}
				});
			});
		</script>
			<?php
		}

		/**
		 * Check the licence data and show the message.
		 * Hooked into `admin_notices`, `after_plugin_row_<product-slug>/<after_plugin_row_>.php`.
		 * 
		 * @param string $plugin_file The plugin file.
		 * @param array $plugin_data The plugin data.
		 * @param string $status The status of the plugin.
		 * @return void
		 */
		public function add_licence_status_message( $plugin_file = '', $plugin_data = array(), $status = '' ) {
			
			global $pagenow;
			

			if ( ! empty( $pagenow ) && 'plugins.php' === $pagenow ) {

				$product_slug = basename( dirname( $plugin_file ) );
				$product_data = $this->product_data_to_show_expired_msg[ $product_slug ] ?? array();
				$licence_data = $this->licence_data_to_show_expired_msg[ $product_slug ] ?? array();
				$message = $this->prepare_message_for_licence_renewal( $product_data, $licence_data );
				$campaign_links = isset( $product_data['expired_campaign_links'] ) && is_array( $product_data['expired_campaign_links'] ) ? $product_data['expired_campaign_links'] : array();

				$campaign_link = isset( $campaign_links['wp_plugins_page'] ) ? esc_url( $campaign_links['wp_plugins_page'] ) : 'https://www.webtoffee.com/plugins/';
				$message = str_replace( array( '{{campaign_link}}', '{{campaign_link_class}}', '{{line_break}}' ), array( $campaign_link, '', ''), $message );
				?>
				<tr class="plugin-update-tr installer-plugin-update-tr wt-sc-plugin-notice-tr">
					<td colspan="4" class="plugin-update colspanchange">
						<div class="update-message notice inline">
							<p><?php echo wp_kses_post( $message ); ?></p>
						</div>
					</td>
				</tr>
				<?php
			} else { // On the `admin.php` page.
				
				$screen = function_exists('get_current_screen') ? get_current_screen()  : null;
				$screen_id = $screen ? $screen->id : '';
				
				// Check if we are on the plugin's page.
				if ( false !== strpos( $screen_id, WF_PKLIST_POST_TYPE ) ) {
					
					foreach( $this->product_data_to_show_expired_msg as $product_slug => $product_data ) {
						$licence_data = $this->licence_data_to_show_expired_msg[ $product_slug ] ?? array();
						$message = $this->prepare_message_for_licence_renewal( $product_data, $licence_data );
						$campaign_links = isset( $product_data['expired_campaign_links'] ) && is_array( $product_data['expired_campaign_links'] ) ? $product_data['expired_campaign_links'] : array();
						$campaign_link = isset( $campaign_links['plugin_setting_page'] ) ? esc_url( $campaign_links['plugin_setting_page'] ) : 'https://www.webtoffee.com/plugins/';
						$message = str_replace( array( '{{campaign_link}}', '{{campaign_link_class}}', '{{line_break}}' ), array( $campaign_link, 'button button-primary', '<br><br>'), $message );

						?>
						<div class="notice notice-warning wt_pklist_licence_expired">
							<p><?php echo wp_kses_post( $message ); ?></p>
						</div>
						<?php
					}
				}
			}
		}

		/**
		 *  Prepare message for licence renewal based on the licence expiry date.
		 * 	
		 * 	@since 1.6.1
		 * 	@param array $product_data The product data.
		 * 	@param array $licence_data The licence data.
		 * 	@return string $message The message to show.
		 */
		private function prepare_message_for_licence_renewal( $product_data, $licence_data ) {

			// If no licence data / expiry data available then set the current date as expiry date.
			$current_date 	= strtotime( wp_date('Y-m-d H:i:s') ); // Current date.
			$expired_date 	= ! empty( $licence_data['expires'] ) ? strtotime( $licence_data['expires'] ) : $current_date;
			$five_days_before_date = $current_date - ( 7 * 86400 ); // 7 days before the current date.
			$plugin_name 	= ! empty( $product_data['product_display_name'] ) ? '<b>' . $product_data['product_display_name'] . '</b>' : __( 'The plugin', 'wt-woocommerce-invoice-addon' );
			$coupon_code 	= ! empty( $product_data['expired_campaign_coupon'] ) ? '<b>' . $product_data['expired_campaign_coupon'] . '</b>' : '';

			if ($expired_date <= $five_days_before_date) { // 7 days ago the licence was expired.
				// translators: %s is the plugin name.
				$message  = sprintf(__('Your subscription to the `%s` has expired. Without an active license, you will not receive updates for the latest features, compatibility, and security.', 'wt-woocommerce-invoice-addon'), $plugin_name);
				$message .= '<br>';
				// translators: %1$s is the discount code and %2$s is the coupon code.
				$message .= sprintf(__('You can avail a %1$s discount on your new subscription with coupon code %2$s.', 'wt-woocommerce-invoice-addon'), '<b>50%</b>', $coupon_code);
				$message .= '{{line_break}}';
					$message .= ' <a href="{{campaign_link}}" target="_blank" class="{{campaign_link_class}}" style="font-weight:bold;">' . __('Get Plugin Now', 'wt-woocommerce-invoice-addon') . '</a>';
			} else {
				// translators: %1$s is the plugin name, %2$s is the activate now link opening tag, %3$s is the activate now link closing tag.
				$message = sprintf(__(' %1$s license is not activated. You will not receive compatibility and security updates if the plugin license is not activated. %2$s Activate now %3$s', 'wt-woocommerce-invoice-addon'), $plugin_name, '<a href="' . esc_url(admin_url('admin.php?page=' . WF_PKLIST_POST_TYPE)) . '#wt-licence" target="_blank">', '</a>');
			}

			return $message;
		}

		public function add_to_edd_plugin_updator() {

			// EDD plugin updator class
			include_once plugin_dir_path( __FILE__ ) . 'classes/EDD_WT_Pklist_Addons_Plugin_Updater.php';

			/**
			 *  Get all licence info
			 */
			$licence_data = $this->get_licence_data();

			foreach ( $this->products as $product_slug => $product ) {

				$status = true;
				if ( ! isset( $licence_data[ $product_slug ] ) ) {
					$status = false;
				} else {
					if ( isset( $licence_data[ $product_slug ]['status'] ) ) {
						if ( '' === $licence_data[ $product_slug ]['status'] || 'inactive' === $licence_data[ $product_slug ]['status'] ) {
							$status = false;
						}
					} else {
						$status = false;
					}
				}

				$plugin_base_path = "$product_slug/$product_slug.php"; // Plugin base path

				if ( $status && function_exists( 'is_plugin_active' ) && is_plugin_active( $plugin_base_path ) ) { // Plugin and licence are active

					// Initiate plugin updator class
					new Wf_Woocommerce_Packing_List\Licence_Manager\EDD_WT_Pklist_Addons_Plugin_Updater(
						$this->api_url,
						WP_PLUGIN_DIR . "/$plugin_base_path",
						array(
							'version' => $product['product_version'], // current version number
							'license' => $licence_data[ $product_slug ]['key'], // license key (used get_option above to retrieve from DB)
							'item_id' => $product['product_edd_id'], // ID of the product
							'author'  => 'WebToffee', // author of this plugin
							'beta'    => false,
						)
					);

				}
			}
		}

		/**
		 * Check the licence status. Will check once in a day. Trigger the force update check to check immediately.
		 * 
		 * @param  array $transient
		 * @return array
		 */
		public function check_licence_status( $transient = array() ) {
			$timestamp = time(); // Current timestamp.
			$home_url = urlencode( home_url() );
			$licence_data_arr = $this->get_licence_data(); // Get all licence info.

			foreach ( $licence_data_arr as $product_slug => $licence_data ) {
			
				if ( ! empty ( $licence_data ) && ! empty ( $this->products[ $product_slug ] ) ) {
					
					// Get the last check time.
					$last_check = get_option( $product_slug . '-last-update-check' );
					if ( is_null( $last_check ) ) { // First time so add a 24 hour back time. 
						$last_check = $timestamp - 86402;
						update_option( $product_slug . '-last-update-check', $last_check, false );
					}
	
					// Previous check is before 24 hours or `force check`.
					if( ( $timestamp - $last_check ) > 86400 || isset( $_GET['force-check'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verification is not required for force-check parameter
	
						$product_data = $this->products[ $product_slug ];				
						$response = $this->fetch_status( $product_data, $licence_data );
						$response_arr = json_decode( $response, true );
						$new_status = $this->get_license_type_obj( $licence_data )->check_status( $licence_data, $response_arr );
	
						// Check update needed.
						if ( $licence_data['status'] !== $new_status ) {
							$licence_data['status'] = $new_status;
							$licence_data['expires'] = $response_arr['expires'];
							$this->update_licence_data( $product_slug, $licence_data );
						}
	
						// Update the last check time with the current time.
						update_option( $product_slug . '-last-update-check', $timestamp, false );
					}			
				}
			}
	
			return $transient;
		}
	}
	new Wf_Woocommerce_Packing_List_Licence_Manager();

}