(function( $ ) {
	'use strict';
	$(function() {
		var wt_pklist_printnode_manual_print=
		{
			on_progress:false,
			Set:function()
			{
				if(wt_pklist_manual_printnode_params.default_printer_id==0)
				{
					$('.wt_pklist_printnode_manual_print').hide();
				}

				$('.wt_pklist_printnode_manual_print').removeAttr('href').css({'cursor':'pointer'});
				
				$('.wt_pklist_printnode_manual_print').on('click',function(){

					var btn=$(this);
					var prnt_promt_attr = btn.attr('data-prompt');
					var proceed_print = true;
					var reload_page = false;
					if (typeof prnt_promt_attr !== 'undefined' && prnt_promt_attr !== false) {
						var a = prnt_promt_attr;
						if(0 !== a && "0" !== a){
							if("2" === a || 2 === a){
					    		var invoice_prompt = wt_pklist_manual_printnode_params.msgs.invoice_number_prompt_free_order;
					    	}else if("11" === a || 11 === a){
					    		var invoice_prompt = wt_pklist_manual_printnode_params.msgs.creditnote_number_prompt;
					    	}else if("3" === a || 3 === a){
					    		var invoice_prompt = wt_pklist_manual_printnode_params.msgs.invoice_number_prompt_no_from_addr;
					    		alert(invoice_prompt);
					    		return false;
					    	}else{
					    		var msg_title=((1 === a || "1" === a) ? wt_pklist_manual_printnode_params.msgs.invoice_title_prompt : a);
					    		var invoice_prompt = msg_title+' '+wt_pklist_manual_printnode_params.msgs.invoice_number_prompt;
					    	}

					        if(confirm (invoice_prompt))
					        {
					        	proceed_print = true;
					        	reload_page = true;
					        }else{
					        	proceed_print = false;
					        }
						}
					}

					if(proceed_print === true){
						if(btn.attr('data-on-progress')==1)
						{
							return false;
						}
						var template_type=btn.attr('data-template_type').trim();
						var order_id=btn.attr('data-id').trim();
						if(template_type!="" && order_id!="")
						{
							var data = {
					            _wpnonce:wt_pklist_manual_printnode_params.nonces.main,
					            action: "wt_pklist_printnode_ajax",
					            printnode_action: "manual_print",
					            template_type: template_type,
					            order_id: order_id,
					        };
					        var btn_html_bck=btn.html();
					        btn.html('<img src="'+wt_pklist_manual_printnode_params.loading_gif+'" style="width:16px; height:16px; display:inline;" />').attr('data-on-progress', 1).css({'cursor':'wait'});
							$.ajax({
								type: 'POST',
				            	url:wt_pklist_manual_printnode_params.ajax_url,
				            	data:data,
				            	dataType:'json',
				            	success:function(data)
				            	{
				            		btn.html(btn_html_bck).attr('data-on-progress', 0).css({'cursor':'pointer'});
				            		if(data.status==1)
				            		{	
				            			wf_notify_msg.success(wt_pklist_manual_printnode_params.msgs.success);
				            			if(reload_page === true){
				            				setTimeout(function () {
								                window.location.reload(true);
								            }, 3000);
				            			}
				            		}else
				            		{
				            			wf_notify_msg.error(data.msg);
				            		}
				            	},
				            	error:function()
				            	{
				            		btn.html(btn_html_bck).attr('data-on-progress', 0).css({'cursor':'pointer'});
				            		wf_notify_msg.error(wt_pklist_manual_printnode_params.msgs.error);
				            	}
							});
						}
					}
				});
			},
		};

		wt_pklist_printnode_manual_print.Set();
	});

})( jQuery );