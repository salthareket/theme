var wt_pklist_printnode=(function( $ ) {
	'use strict';
	var wt_pklist_printnode=
	{
		default_printer_id:0,
		on_progress:false,
		api_key:'',
		Set:function()
		{
			this.default_printer_id=wt_pklist_printnode_params.default_printer_id;
			this.reg_events();	
		},
		reg_events:function()
		{
			$('.wt_pklist_printnode_test_connection_btn').click(function(){
				wt_pklist_printnode.test_account($(this));
			});

			$(document).on('click', '.wt_pklist_printnode_search_printers_btn, .wt_pklist_printnode_refresh_printers_list', function(){
				wt_pklist_printnode.find_printers($(this));
			});
		},
		find_printers:function(elm)
		{
			if(this.on_progress){ return false; }
			var api_key_input_val=$('[name="wt_pklist_remote_print_api_key"]').val().trim();
			if(this.api_key=="")
			{
				if(api_key_input_val=="")
				{
					wf_notify_msg.error(wt_pklist_printnode_params.msgs.api_key_mandatory);
					$('[name="wt_pklist_remote_print_api_key"]').focus();
					return false;
				}else
				{
					var api_key=api_key_input_val;
				}
			}else
			{
				if(api_key_input_val=="")
				{
					wf_notify_msg.error(wt_pklist_printnode_params.msgs.api_key_mandatory);
					$('[name="wt_pklist_remote_print_api_key"]').focus();
					return false;
				}

				var api_key=this.api_key;
				if(api_key_input_val!="" && api_key_input_val!=api_key)
				{
					api_key=api_key_input_val; /* if given API key input is different then give preference to input */
				}
			}

			$('[name="wt_pklist_remote_print_api_key"]').val(api_key);
			this.api_key=api_key;

			/* Search printers */
			var data = {
	            _wpnonce:wt_pklist_printnode_params.nonces.main,
	            action: "wt_pklist_printnode_ajax",
	            printnode_action: "search_printers",
	            api_key: api_key,
	        };

	        this.on_progress=true;
	        var pop_elm=$('.wt_pklist_printnode_printers');
	        if(!pop_elm.is(':visible'))
	        {
	        	wf_popup.showPopup(pop_elm);	
	        }
	        
	        var pop_content_elm=pop_elm.find('.wf_pklist_popup_body');
	        var load_html=this.set_popup_loader(wt_pklist_printnode_params.msgs.finding, 'wt_pklist_printnode_printers_loader');
	        pop_content_elm.html(load_html);

	        $.ajax({
	        	type: 'POST',
            	url:wt_pklist_printnode_params.ajax_url,
            	data:data,
            	dataType:'json',
            	success:function(data)
            	{
            		wt_pklist_printnode.on_progress=false;
            		if(data.status==1) //success
					{
						wt_pklist_printnode.api_key=api_key;
						pop_content_elm.html(data.html);
						wt_pklist_printnode.process_default_toggle_btn_labels();
						$(".wt-tips").tipTip({'attribute': 'data-wt-tip'});
						$('#tiptip_holder').css({'z-index':1000000000});
					}else
					{
						wf_notify_msg.error(data.msg);
						var load_html=wt_pklist_printnode.set_popup_loader(data.msg, 'wt_pklist_printnode_printers_loader');
						pop_content_elm.html(load_html);
					}

            	},
            	error:function()
            	{
            		wt_pklist_printnode.on_progress=false;
					wf_notify_msg.error(wt_pklist_printnode_params.msgs.unable_to_connect);
					var load_html=wt_pklist_printnode.set_popup_loader(wt_pklist_printnode_params.msgs.unable_to_connect, 'wt_pklist_printnode_printers_loader');
					pop_content_elm.html(load_html);
            	}
	        });
		},
		test_printer:function(elm, printer_id, status)
		{
			if(this.on_progress){ return false; }
			if(status!=='online')
			{
				return false;
			}

			var data = {
	            _wpnonce:wt_pklist_printnode_params.nonces.main,
	            action: "wt_pklist_printnode_ajax",
	            printnode_action: "test_printer",
	            printer_id: printer_id,
	        };
	        this.on_progress=true;
	        var html_bck=$(elm).html();
	        $(elm).html(wt_pklist_printnode_params.msgs.connecting);
	        var msg_box=$('.wt_pklist_printnode_test_msg_box');
			msg_box.hide();

			$.ajax({
				type: 'POST',
            	url:wt_pklist_printnode_params.ajax_url,
            	data:data,
            	dataType:'json',
            	success:function(data)
            	{
            		wt_pklist_printnode.on_progress=false;
            		$(elm).html(html_bck);
            		msg_box.show();
            		if(data.status==1)
            		{
            			msg_box.attr('class', 'wt_pklist_printnode_test_msg_box wt_success_box');
            			msg_box.html(wt_pklist_printnode_params.msgs.printer_test_success);
            		}else
            		{
            			msg_box.attr('class', 'wt_pklist_printnode_test_msg_box wt_error_box');
            			msg_box.html(data.msg);	
            		}
            	},
            	error:function()
            	{
            		wt_pklist_printnode.on_progress=false;
            		$(elm).html(html_bck);
            		msg_box.show().html(wt_pklist_printnode_params.msgs.printer_test_error).attr('class', 'wt_pklist_printnode_test_msg_box wt_error_box');
            	}
			});
		},
		set_popup_loader:function(txt, css_clss)
		{
			return '<div class="'+css_clss+'">'+txt+'</div>';
		},
		test_account:function(btn_elm)
		{
			if(this.on_progress){ return false; }

			var api_key=$('[name="wt_pklist_remote_print_api_key"]').val().trim();

			if(api_key=="")
			{
				wf_notify_msg.error(wt_pklist_printnode_params.msgs.api_key_mandatory);
				$('[name="wt_pklist_remote_print_api_key"]').focus();
				return false;
			}

			/* Test account */
			var data = {
	            _wpnonce:wt_pklist_printnode_params.nonces.main,
	            action: "wt_pklist_printnode_ajax",
	            printnode_action: "test_connection",
	            api_key: api_key,
	        };
	        this.on_progress=true;
	        var pop_elm=$('.wt_pklist_printnode_test_connection');
	        wf_popup.showPopup(pop_elm);
	        var pop_content_elm=pop_elm.find('.wf_pklist_popup_body');
	        var load_html=this.set_popup_loader(wt_pklist_printnode_params.msgs.connecting, 'wt_pklist_printnode_test_connection_loader');
	        pop_content_elm.html(load_html);
			$.ajax({
				type: 'POST',
            	url:wt_pklist_printnode_params.ajax_url,
            	data:data,
            	dataType:'json',
            	success:function(data)
            	{
            		wt_pklist_printnode.on_progress=false;
            		if(data.status==1) //success
					{
						wt_pklist_printnode.api_key=api_key;
						pop_content_elm.html(data.html);
					}else
					{
						wf_notify_msg.error(data.msg);
						var load_html=wt_pklist_printnode.set_popup_loader(data.msg, 'wt_pklist_printnode_test_connection_loader');
						pop_content_elm.html(load_html);
					}
            	},
            	error:function()
				{
					wt_pklist_printnode.on_progress=false;
					wf_notify_msg.error(wt_pklist_printnode_params.msgs.unable_to_connect);
					var load_html=wt_pklist_printnode.set_popup_loader(wt_pklist_printnode_params.msgs.unable_to_connect, 'wt_pklist_printnode_test_connection_loader');
					pop_content_elm.html(load_html);
				}
			});
		},
		process_default_toggle_btn_labels:function()
		{
			var tb=$('.wt_pklist_printnode_printers_tb');
			if(tb.length>0)
			{
				var default_printer_name='';
				tb.find('tbody').find('tr').each(function(){
					var default_toggle_btn=$(this).find('.wt_pklist_printnode_printer_default_toggle_btn');
					if(default_toggle_btn.length>0)
					{
						var printer_id=default_toggle_btn.attr('data-id');
						var name_tr=$(this).find('.wt_pklist_printnode_printer_name');
						name_tr.find('.wt_pklist_printnode_default_printer_info').remove();
						if(printer_id===wt_pklist_printnode.default_printer_id)
						{
							default_toggle_btn.html(wt_pklist_printnode_params.msgs.remove_from_default);
							default_printer_name=name_tr.text();
							name_tr.append(' <span class="wt_pklist_printnode_default_printer_info" title="'+wt_pklist_printnode_params.msgs.default_printer+'"><span class="dashicons dashicons-yes-alt"></span></span>');
						}else
						{
							default_toggle_btn.html(wt_pklist_printnode_params.msgs.set_as_default);	
						}
					}
				});
			}
		},
		toggle_default_printer:function(elm, printer_id)
		{
			if(this.on_progress){ return false; }

			if(this.api_key=="")
			{
				wf_notify_msg.error(wt_pklist_printnode_params.msgs.api_key_mandatory);
				return false;
			}

			var printer_name=$(elm).parents('tr').find('.wt_pklist_printnode_printer_name').html();

			var data = {
	            _wpnonce:wt_pklist_printnode_params.nonces.main,
	            action: "wt_pklist_printnode_ajax",
	            printnode_action: "toggle_default_printer",
	            printer_id: printer_id,
	            printer_name: printer_name,
	            api_key: this.api_key,
	        };
	        this.on_progress=true;
	        var html_bck=$(elm).html();
	        $(elm).html(wt_pklist_printnode_params.msgs.connecting);
			$.ajax({
				type: 'POST',
            	url:wt_pklist_printnode_params.ajax_url,
            	data:data,
            	dataType:'json',
            	success:function(data)
            	{
            		wt_pklist_printnode.on_progress=false;
            		$(elm).html(html_bck);
            		if(data.status==1)
            		{
            			wt_pklist_printnode.default_printer_id=data.default_printer_id;
            			wt_pklist_printnode.process_default_toggle_btn_labels();
            			wf_notify_msg.success(wt_pklist_printnode_params.msgs.success);
            			var btn_label=(data.default_printer_id==0 ? wt_pklist_printnode_params.msgs.setup_default_printer : wt_pklist_printnode_params.msgs.change_default_printer);
            			$('.wt_pklist_printnode_search_printers_btn').html(btn_label);
            			if(data.default_printer_id==0)
            			{
            				$('.wt_pklist_printnode_default_printer_name').html(wt_pklist_printnode_params.msgs.no_printer_label).css({'color':'red'});
            			}else
            			{
            				$('.wt_pklist_printnode_default_printer_name').html(printer_name).css({'color':'black'});
            			}
            		}else
            		{
            			wf_notify_msg.error(data.msg);	
            		}
            	},
            	error:function()
            	{
            		wt_pklist_printnode.on_progress=false;
            		$(elm).html(html_bck);
            		wf_notify_msg.error(wt_pklist_printnode_params.msgs.error);
            	}
			});
		}

	};
	return wt_pklist_printnode;
})( jQuery );

jQuery(function() {
	wt_pklist_printnode.Set();
});