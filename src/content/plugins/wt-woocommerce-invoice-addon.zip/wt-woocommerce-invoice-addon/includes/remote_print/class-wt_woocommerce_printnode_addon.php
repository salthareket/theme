<?php
if(!class_exists('Wt_Pklist_PrintNode_Addon'))
{
		// Constants are now defined in the main plugin file
	
	class Wt_Pklist_PrintNode_Addon
	{
		public $module_base = 'printnode';
		public $module_id = 'wf_woocommerce_packing_list_printnode';
		public $documents=array();
		public $return_needed=false;

		public function __construct()
		{
			/**
			*   Add tab to settings section
			*/

			add_action('admin_enqueue_scripts', array($this, 'enqueue_manual_print_js'), 10, 1);
			
			add_action('init', array($this, 'init'), 1);

			/**
			* 	Main hook to handle all ajax actions 
			*/
			add_action('wp_ajax_wt_pklist_printnode_ajax', array($this, 'ajax_main'), 1);

			// Initialize default settings if they don't exist
			$this->initialize_default_settings();

		}

		/**
		 * Initialize default settings if they don't exist
		 */
		public function initialize_default_settings()
		{
			// Check if settings exist, if not initialize with defaults
			$current_settings = Wf_Woocommerce_Packing_List::get_settings($this->module_id);
			
			if (empty($current_settings)) {
				$default_settings = array(
					'wt_pklist_remote_print_api_key' => '',
					'wt_pklist_remote_print_automatic' => 'No',
					'wt_pklist_remote_print_manual' => 'No',
					'wt_pklist_remote_print_email_notification' => 'No',
					'wt_pklist_remote_print_enable_log' => 'No',
				);
				
				// Save default settings
				Wf_Woocommerce_Packing_List::update_option('wt_pklist_remote_print_automatic', 'No', $this->module_id);
				Wf_Woocommerce_Packing_List::update_option('wt_pklist_remote_print_manual', 'No', $this->module_id);
				Wf_Woocommerce_Packing_List::update_option('wt_pklist_remote_print_email_notification', 'No', $this->module_id);
				Wf_Woocommerce_Packing_List::update_option('wt_pklist_remote_print_enable_log', 'No', $this->module_id);
			}
		}

		public function init()
		{
			/* Pro v4.1.4 or above */
			$min_required_version='4.0.0';

			/**
			*	If minimum required version of Invoice plugin is not installed then return.
			*/
			if(!version_compare(WF_PKLIST_VERSION, $min_required_version, '>='))
			{
			   $this->return_needed=true;
			}

			if(!class_exists('Wf_Woocommerce_Packing_List') && !$this->return_needed)
			{
				$this->return_needed=true;
			}

			add_filter('plugin_action_links_'.plugin_basename(__FILE__), array($this, 'plugin_action_links'));

			if(!$this->return_needed)
			{
				/**
				*	Remote printing enabled docs
				*/
				$this->documents=apply_filters('wt_pklist_add_to_remote_printing', $this->documents, $this->module_base);
				

				/* filter to set module default settings */
				add_filter('wf_module_default_settings', array($this, 'default_settings'), 10, 2);

				/** 
				* Declaring multi select form fields in settings form 
				*/
				add_filter('wt_pklist_intl_alter_multi_select_fields', array($this, 'alter_multi_select_fields'), 10, 2);

				/** 
				* Declaring validation rule for form fields in settings form 
				*/
				add_filter('wt_pklist_intl_alter_validation_rule', array($this, 'alter_validation_rule'), 10, 2);
				
				
				/**
				* 	Hook to woocommerce status changed to do automatic printing 
				*/ 
				add_action('woocommerce_order_status_changed', array($this, 'auto_remote_print'), 10, 3);

				/**
				* 	Add manual remote printing buttons, If enabled 
				*/ 
				$this->manual_remote_print();
			}
			
			/**
			*	Add settings tab
			*/
			add_filter('wt_pklist_plugin_settings_tabhead', array( $this, 'settings_tabhead'));
			add_action('wt_pklist_plugin_out_settings_form', array($this, 'out_settings_form'));

			add_filter('wf_pklist_plugin_settings_tabhead', array( $this, 'settings_tabhead'));
			add_action('wf_pklist_plugin_out_settings_form', array($this, 'out_settings_form'));
		}

		public function plugin_action_links($links)
		{
			$url=admin_url('admin.php?page='.WF_PKLIST_POST_TYPE.'#remote-print');
			$links[]='<a href="'.esc_url($url).'">'.__('Settings', 'wt-woocommerce-invoice-addon').'</a>';
			return $links;
		}

		/**
		*	This method will do automatic cloud printing
		*	@since 1.0.1 [Bug fix] PDF Encoding issue
		*/
		public function auto_remote_print($order_id, $old_status, $new_status)
		{
			if(!$order_id)
			{
	        	return;
	    	}

			if("No" === Wf_Woocommerce_Packing_List::get_option('wt_pklist_remote_print_automatic',$this->module_id)) {
				return;
			}
	    	$need_remote_print_arr=array();
			if(is_array($this->documents) && count($this->documents)>0) /* check cloud print docs available */
			{
				$settings=Wf_Woocommerce_Packing_List::get_settings($this->module_id);
	        	$order	= Wt_Pklist_Common_Ipc::get_order($order_id);
	        	$status = $order->get_status();
				
				foreach ($this->documents as $doc_key => $doc_title)
				{
					$settings_key='wt_pklist_remote_print_automatic_'.$doc_key.'_statuses';
					
					/* check remote print enabled for current category */
					if(isset($settings[$settings_key]) && is_array($settings[$settings_key]) && in_array('wc-'.$status, $settings[$settings_key]))
					{
						$doc_module_id = Wf_Woocommerce_Packing_List::get_module_id( $doc_key );
						$document_order_statuses = array();
						if ( 'invoice' === $doc_key || 'creditnote' === $doc_key || 'proformainvoice' === $doc_key ) {
							$document_order_statuses = Wf_Woocommerce_Packing_List::get_option( 'woocommerce_wf_generate_for_orderstatus', $doc_module_id );
							if ( is_array( $document_order_statuses ) && !empty( $document_order_statuses ) && in_array( 'wc-'.$status, $document_order_statuses ) ) {
								$need_remote_print_arr[$doc_key]=array();
							} 
						} else {
							$need_remote_print_arr[$doc_key]=array();
						} 
					}
				}
			}		

			if(count($need_remote_print_arr)>0) /* some modules need remote print on current order status */
			{
				$out=array(
					'status'=>1
				);
				$error_msg_arr=array(); /* this array for email notification */

				$api_key=$this->get_api_credentials();
				if(!$api_key || "" === trim($api_key))
				{
					$out['msg']=__('API key missing', 'wt-woocommerce-invoice-addon');
					$out['status']=0;
				}

				if(1 === $out['status'])
				{
					$printer_id=$this->get_default_printer(); /* taking default printer id */
					if(!isset($printer_id) || !$printer_id)
					{
						$out['msg']=__('Please set up a default printer', 'wt-woocommerce-invoice-addon');
						$out['status']=0;
					}
				}

				if(1 === $out['status']) /* all are okay then do the print job */
				{
					/* modules needed to check their module base is avaialable for remote print. If yes then they need to return back the processessed template HTML */
					$remote_print_arr=apply_filters('wt_pklist_do_remote_printing', $need_remote_print_arr, $order_id);				
					if(is_array($remote_print_arr) && count($remote_print_arr)>0)
					{
						$this->include_print_node(); /* include print node library */
						
						foreach ($remote_print_arr as $doc_key => $doc_data)
						{
							if(isset($doc_data['pdf_file']) && "" !== $doc_data['pdf_file']) /* post type module responded with PDF */
							{
								$job_title=(isset($doc_data['title']) ? $doc_data['title'] : $doc_key.'_'.$order_id);
								$args=array(
						    		'printerId'=>$printer_id,
						    		'title'=>$job_title,
						    		'contentType'=>'pdf_base64',
						    		'content'=>$this->prepare_pdf_base64($doc_data['pdf_file']),
						    		/* translators: %d: Order ID */
						    		'source'=>sprintf(__("Print for Order ID %d", 'wt-woocommerce-invoice-addon'), $order_id),
						    	);
								$printer_response=Wt_Pklist_Printnode::send_to_printer($api_key, $args); /* send job to printer */ 
								

								/* process printer response */
								$out=$this->process_printer_response($printer_response, $out);

								if(0 === $out['status'] || '0' === $out['status']) /* an error, then record the message in separate array because next value in the foreach loop may overwrite the value */
								{
									$error_msg_arr[]=$out['msg'];
								}
							}else
							{
								$error_msg_arr[]=__('Unable to generate PDF file', 'wt-woocommerce-invoice-addon');
							}
						}
					}
				}

				/**
				*	Check email notification enabled.
				*/
				if("Yes" === Wf_Woocommerce_Packing_List::get_option('wt_pklist_remote_print_email_notification', $this->module_id))
				{
					/**
					*	Printing not success
					*	We also need to check this with the `error_msg_arr` array count because we must send the error message when an item in the middle of the above foreach loop is failed
					*/
					if(0 === $out['status'] || "0" == $out['status'] || count($error_msg_arr)>0) 
					{

						$order=new WC_Order($order_id);
						$order_number=$order->get_order_number(); /* compatibility for Order number plugins. Eg: Sequential order number */

						$to=array(get_option('admin_email'));
						$to=apply_filters('wt_pklist_printnode_alter_notification_email_list', $to, $order);
						
						if((is_string($to) && "" !== trim($to)) || (is_array($to) && count($to)>0))
						{
							/* translators: %s: Order number */
							$subject =sprintf(__('PrintNode print error: %s', 'wt-woocommerce-invoice-addon'), $order_number).' - '.get_bloginfo('name');
						
							/* translators: %s: Order number */
							$body=sprintf(__('Automatic remote printing of order number %s was failed because of these reason(s).', 'wt-woocommerce-invoice-addon'), $order_number).'<br />';
							$body.=(count($error_msg_arr)>0 ? implode('<br />', $error_msg_arr) : $out['msg']);

							$headers = array('Content-Type: text/html; charset=UTF-8');
							wp_mail($to, $subject, $body, $headers);
						}
						
					}	
				}

			}
		}

		/**
		*	This method will add manual remote print buttons
		*/
		public function manual_remote_print()
		{
			$manual_remote_print=Wf_Woocommerce_Packing_List::get_option('wt_pklist_remote_print_manual', $this->module_id);
			
			if(is_array($this->documents) && count($this->documents)>0 && "Yes" === $manual_remote_print) /* check remote print docs available */
			{ 
				foreach ($this->documents as $doc_key => $doc_title)
				{
					add_filter('wt_pklist_after_'.$doc_key.'_print_button_list', array($this, 'manual_remote_print_buttons'), 10, 4);
				}
			}
		}

		/**
		*	Sub function to add manual remote print buttons
		*/
		public function manual_remote_print_buttons($item_arr, $order, $button_location, $template_type)
		{

			if("detail_page" === $button_location) /* we are adding button to detail page only */
			{
				if(isset($item_arr[$template_type.'_details_actions'])){
					$last_item = $item_arr[$template_type.'_details_actions'];
					if(isset($last_item['button_type']) && ("dropdown" === $last_item['button_type'] || "aggregate" === $last_item['button_type'])) /* only for dropdown/aggregate buttons */
					{
						if(isset($last_item['items']) && is_array($last_item['items']))
						{
							$is_show_prompt = apply_filters('wt_pklist_check_prompt_'.$template_type,0,$order,$template_type);
							/* add new button data */
							$last_item['items'][$template_type.'_printnode']=array(  
								'label'=>__('Send to PrintNode', 'wt-woocommerce-invoice-addon'),
								'action'=>$template_type.'_printnode',
								'icon_url'=>WT_PKLIST_INVOICE_ADDON_PLUGIN_URL.'includes/remote_print/assets/images/printnode.png',
								'tooltip'=>__('Send to PrintNode', 'wt-woocommerce-invoice-addon'),
								'is_show_prompt'=>$is_show_prompt,
								'button_location'=>$button_location,						
								'css_class'=>'wt_pklist_printnode_manual_print',						
								'custom_attr'=>' data-template_type="'.esc_html($template_type).'"',						
							);

							// $item_arr[(count($item_arr)-1)]=$last_item; /* add to main item array */
							$item_arr[$template_type.'_details_actions'] = $last_item;
						}
					}
				}
			}
			return $item_arr;
		}

		/**
		* 	Ajax main hook for all actions
		*/
	public function ajax_main()
		{
			$out=array(
				'status'=>0,
				'msg'=>__("Error", 'wt-woocommerce-invoice-addon')
			);
	    	if(Wf_Woocommerce_Packing_List_Admin::check_write_access($this->module_id)) //no error then proceed
	    	{
			$allowed_actions=array('test_connection', 'search_printers', 'toggle_default_printer', 'manual_print');
			
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verification is handled by check_write_access above
			if ( ! isset( $_REQUEST['printnode_action'] ) ) {
				echo wp_json_encode( $out );
				exit();
			}
			
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verification is handled by check_write_access above
			$printnode_action = sanitize_text_field( wp_unslash( $_REQUEST['printnode_action'] ) );
				
				include_once WT_PKLIST_INVOICE_ADDON_PLUGIN_PATH."includes/remote_print/classes/class-printnode-ajax.php";
				
				$printnode_ajax=new Wt_Pklist_Printnode_Ajax();
				if(method_exists($printnode_ajax, $printnode_action))
				{
					$out=$printnode_ajax->{$printnode_action}($out, $this);
				}
			}
			echo json_encode($out);
			exit();
		}

		/**
		*	Include print node class
		*/
		public function include_print_node()
		{
			include_once WT_PKLIST_INVOICE_ADDON_PLUGIN_PATH."includes/remote_print/classes/class-printnode.php";
		}

		/**
		*	Update/Add default printer.
		*/
		public function update_default_printer($printer_id)
		{
			update_option('wt_pklist_printnode_default_printer', $printer_id, false);
		}

		/**
		*	Update/Add default printer name.
		*/
		public function update_default_printer_name($printer_name)
		{
			update_option('wt_pklist_printnode_default_printer_name', $printer_name, false);
		}

		/**
		*	Get ID of default printer
		*/
		public function get_default_printer()
		{
			return get_option('wt_pklist_printnode_default_printer', 0);
		}

		/**
		*	Get Name of default printer
		*/
		public function get_default_printer_name()
		{
			return get_option('wt_pklist_printnode_default_printer_name', '');
		}

		/**
		*
		*	Get API key	
		*/
		public function get_api_credentials()
		{
			return Wf_Woocommerce_Packing_List::get_option('wt_pklist_remote_print_api_key', $this->module_id);
		}

		/**
		*
		*	Update API key.
		*	On normal form submission(Settings form) these values are saved by `save_settings` method	
		*/
		public function update_api_credentails($api_key)
		{
			Wf_Woocommerce_Packing_List::update_option('wt_pklist_remote_print_api_key', $api_key, $this->module_id);
		}

		/**
		* 	Tab head for admin settings page
		*
		*/
	public function settings_tabhead($arr)
	{
		$added=0;
		$out_arr=array();
		$menu_pos_key='cloud-storage'; /* after cloud-storage tab */

		foreach($arr as $k=>$v)
		{
			$out_arr[$k]=$v;
			if($k==$menu_pos_key && $added==0)
			{				
				$out_arr['remote-print']=__('Remote print (PrintNode)', 'wt-woocommerce-invoice-addon');
				$added=1;
			}
		}
		if($added==0)
		{
			$out_arr['remote-print']=__('Remote print (PrintNode)', 'wt-woocommerce-invoice-addon');
		}
		return $out_arr;
	}

		/**
		* 	Declaring validation rule for form fields in settings form
		*/
		public function alter_validation_rule($arr, $base_id)
		{
			if($base_id == $this->module_id)
			{
				$arr=array();
				if(is_array($this->documents))
				{
					foreach ($this->documents as $key => $value)
					{
						$arr['wt_pklist_remote_print_automatic_'.$key.'_statuses']=array('type'=>'text_arr');
					}
				}
			}
			return $arr;
		}

		/**
		* 	Declaring multi select form fields in settings form
		*/
		public function alter_multi_select_fields($arr, $base_id)
		{
			if($base_id==$this->module_id)
			{
				$arr=array();
				if(is_array($this->documents))
				{
					foreach ($this->documents as $key => $value)
					{
						$arr['wt_pklist_remote_print_automatic_'.$key.'_statuses']=array();
					}
				}
			}
			return $arr;
		}

		public function default_settings($settings, $base_id)
		{
			if($base_id==$this->module_id)
			{
				$def_settings=array(
					'wt_pklist_remote_print_api_key'=>'',
					'wt_pklist_remote_print_automatic'=>'No',
					'wt_pklist_remote_print_manual'=>'No',
					'wt_pklist_remote_print_email_notification'=>'No',
					'wt_pklist_remote_print_enable_log' => 'No',
				);
				if(is_array($this->documents))
				{
					foreach ($this->documents as $key => $value)
					{
						$def_settings['wt_pklist_remote_print_automatic_'.$key.'_statuses']=array();
					}
				}
				return $def_settings;
			}else
			{
				return $settings;
			}
		}

		/**
		*	Process the response got from printer while adding a job
		*/
		public function process_printer_response($printer_response, $out)
		{
			if($printer_response && is_array($printer_response)) /* expected response format */
			{
				if(isset($printer_response['status']))
				{
					if($printer_response['status']!==true)
					{
						$out['status']=0;
						$out['msg']=$printer_response['msg']; 
					}else
					{
						$out['status']=1;
						$out['msg']='';
					}
				}else
				{
					$out['status']=0;
					$out['msg']=__('Invalid response status', 'wt-woocommerce-invoice-addon'); 
				}
			}else
			{
				$out['status']=0;
				$out['msg']=__('Invalid response format', 'wt-woocommerce-invoice-addon');
			}
			return $out;
		}

		public function prepare_pdf_base64($file_path)
		{
			global $wp_filesystem;
			
			// Initialize WP_Filesystem if not already done
			if ( ! function_exists( 'WP_Filesystem' ) ) {
				require_once ABSPATH . 'wp-admin/includes/file.php';
			}
			
			if ( ! WP_Filesystem() ) {
				return false;
			}
			
			if ( $wp_filesystem->exists( $file_path ) ) {
				$pdf_data = $wp_filesystem->get_contents( $file_path );
				if ( false !== $pdf_data ) {
					return base64_encode( $pdf_data );
				}
			}
			
			return false;
		}

		/**
		*	JS for manual remote print
		*	This will only enqueue JS in order detail page
		*	@since 1.0.5 - WC HPOS Compatibility
		*/
		public function enqueue_manual_print_js($hook)
		{
			$do_enqueue_js = false;
			if(Wt_Pklist_Common_Ipc::is_hpos_order_edit_page()){
				$do_enqueue_js = true;
			}else{
				if('post-new.php' === $hook || 'post.php' === $hook)
				{
					global $post;
					if("shop_order" === $post->post_type) //only in order detail page
					{
						$do_enqueue_js = true;
					}
				}
			}

			if(true === $do_enqueue_js){
				wp_enqueue_script($this->module_id.'_manual', WT_PKLIST_INVOICE_ADDON_PLUGIN_URL.'includes/remote_print/assets/js/manual_print.js', array('jquery'), WT_PKLIST_INVOICE_ADDON_VERSION, true);  
				$params=array(
					'nonces' => array(
						'main'=>wp_create_nonce($this->module_id),
					),
					'ajax_url' => admin_url('admin-ajax.php'),
					'default_printer_id'=>$this->get_default_printer(),
					'loading_gif'=>WT_PKLIST_INVOICE_ADDON_PLUGIN_URL.'includes/remote_print/assets/images/loading.gif',
					'msgs'=>array(
						'invoice_title_prompt' => __("Invoice",'wt-woocommerce-invoice-addon'),
						'invoice_number_prompt' => __("number has not been generated yet. Do you want to manually generate one ?",'wt-woocommerce-invoice-addon'),
						'invoice_number_prompt_free_order' => __("‘Generate invoice for free orders’ is disabled in Invoice settings. You are attempting to generate invoice for this free order. Proceed?",'wt-woocommerce-invoice-addon'),
						'creditnote_number_prompt' => __("Refund in this order seems not having credit number yet. Do you want to manually generate one ?",'wt-woocommerce-invoice-addon'),
						'invoice_number_prompt_no_from_addr' => __("Please fill the `from address` in the plugin's general settings.",'wt-woocommerce-invoice-addon'),
						'error'=>__('PrintNode error', 'wt-woocommerce-invoice-addon'),	
						'success'=>__('Successfully sent to PrintNode', 'wt-woocommerce-invoice-addon'),
						'wait'=>__('Please wait...', 'wt-woocommerce-invoice-addon'),
					)
				);
				wp_localize_script($this->module_id.'_manual', 'wt_pklist_manual_printnode_params', $params);
			}
		}
		
		/**
		* Settings form
		*
		*/
		public function out_settings_form($args)
		{
			if($this->return_needed) 
			{
				$params=array(
					'module_id'=>$this->module_id,
				);
				$view_file=WT_PKLIST_INVOICE_ADDON_PLUGIN_PATH.'includes/remote_print/views/_minimum_version_required.php';
				Wf_Woocommerce_Packing_List_Admin::envelope_settings_tabcontent('remote-print', $view_file, '', $params, 0);
				return;
			}

			wp_enqueue_script($this->module_id, WT_PKLIST_INVOICE_ADDON_PLUGIN_URL.'includes/remote_print/assets/js/main.js', array('jquery'), WT_PKLIST_INVOICE_ADDON_VERSION, true);

			$order_statuses = wc_get_order_statuses();
			// phpcs:ignore WordPress.WP.EnqueuedResourceParameters.NotInFooter, WordPress.WP.EnqueuedResourceParameters.NoExplicitVersion -- This is a WooCommerce registered script
			wp_enqueue_script('wc-enhanced-select');

			$default_printer_id=$this->get_default_printer();
			$default_printer_name=$this->get_default_printer_name();

			$setup_default_printer_label=__('Setup now', 'wt-woocommerce-invoice-addon');
			$change_default_printer_label=__('Change default printer', 'wt-woocommerce-invoice-addon');
			$no_printer_label=__('None', 'wt-woocommerce-invoice-addon');

			$params=array(
				'nonces' => array(
		            'main'=>wp_create_nonce($this->module_id),
		        ),
		        'ajax_url' => admin_url('admin-ajax.php'),
		        'default_printer_id'=>$default_printer_id,
		        'default_printer_name'=>$default_printer_name,
		        'msgs'=>array(
		        	'error'=>__('Error', 'wt-woocommerce-invoice-addon'),
		        	'success'=>__('Success', 'wt-woocommerce-invoice-addon'),	
		        	'unable_to_connect'=>__('Unable to connect', 'wt-woocommerce-invoice-addon'),
		        	'api_key_mandatory'=>__('API key is missing', 'wt-woocommerce-invoice-addon'),
		        	'connecting'=>__('Connecting...', 'wt-woocommerce-invoice-addon'),	
		        	'finding'=>__('Searching for printers...', 'wt-woocommerce-invoice-addon'),
		        	/* translators: %1$s: Opening anchor tag, %2$s: Closing anchor tag */
		        	'printer_search_error'=>sprintf(__('An error occurred. Please %1$stry again.%2$s', 'wt-woocommerce-invoice-addon'), '<a class="wt_pklist_printnode_setup_printer" onclick="wt_pklist_remote_print.find_printers()">', '</a>'),
	        		'printer_test_error'=>__('Testing failed.', 'wt-woocommerce-invoice-addon'),	
	        		'printer_test_success'=>__('Tested OK. Verify print.', 'wt-woocommerce-invoice-addon'),
	        		'set_as_default'=>__('Set as default', 'wt-woocommerce-invoice-addon'),	
	        		'remove_from_default'=>__('Remove from default', 'wt-woocommerce-invoice-addon'),
	        		'default_printer'=>__('Default printer. This printer will be the default one to print documents.', 'wt-woocommerce-invoice-addon'),
	        		'setup_default_printer'=>$setup_default_printer_label,
	        		'change_default_printer'=>$change_default_printer_label,
	        		'no_printer_label'=>$no_printer_label,
		        )
			);
			wp_localize_script($this->module_id, 'wt_pklist_printnode_params', $params);

			/**
			*	Remote print enabled docs available
			*/
			if($this->documents && is_array($this->documents) && count($this->documents)>0)
			{	
				$params=array(
					'module_id'=>$this->module_id,
					'module_base'=>$this->module_base,
					'order_statuses'=>$order_statuses,
					'documents'=>$this->documents, /* remote print enabled docs */
					'msgs'=>array(
						'setup_default_printer'=>$setup_default_printer_label,
	        			'change_default_printer'=>$change_default_printer_label,
	        			'no_printer_label'=>$no_printer_label,
					),
					'default_printer_id'=>$default_printer_id,
					'default_printer_name'=>$default_printer_name,
				);
				$view_file=WT_PKLIST_INVOICE_ADDON_PLUGIN_PATH.'includes/remote_print/views/settings_pro_addons.php';
			}else
			{
				$params=array(
					'module_id'=>$this->module_id,
				);
				$view_file=WT_PKLIST_INVOICE_ADDON_PLUGIN_PATH.'includes/remote_print/views/no_remote_print_enabled_docs.php';
			}
			Wf_Woocommerce_Packing_List_Admin::envelope_settings_tabcontent('remote-print', $view_file, '', $params, 0);
		}
	}
	new Wt_Pklist_PrintNode_Addon();
}?>