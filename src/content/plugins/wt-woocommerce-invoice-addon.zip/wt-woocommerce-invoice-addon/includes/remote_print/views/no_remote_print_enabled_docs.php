<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div style="background:#fcf8e3; padding:10px; border:solid 1px #faebcc; color:#a66d3c; margin:50px 0px;">
	<b><?php esc_html_e('Oops !!!', 'wt-woocommerce-invoice-addon'); ?></b>	 <?php esc_html_e('No Remote printing enabled documents found.', 'wt-woocommerce-invoice-addon'); ?>
</div>