<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<style type="text/css">
.wt_pklist_printnode_test_connection{ width:350px; height:200px; }
.wt_pklist_printnode_test_connection_loader{ width:100%; height:75px; margin-top:70px; text-align:center; font-size:14px; }

.wt_pklist_printnode_printers{ width:900px; height:500px; }
.wt_pklist_printnode_printers_loader{ width:100%; height:200px; margin-top:70px; text-align:center; font-size:14px; }

.wt_pklist_printnode_printers_tb th{ font-weight:bold; text-align:center; }
.wt_pklist_printnode_printers_tb td{text-align:center; }

.wt_pklist_printnode_action_btn{ cursor:pointer; }
.wt_pklist_printnode_status_info{ display:inline-block; width:15px; height:15px; border-radius:10px; margin-right:5px; }
.wt_pklist_printnode_status_info_text{ display:inline-block; margin-top:-2px; }
.wt_pklist_printnode_test_msg_box{margin-bottom: 15px; clear:both;}
.wt_pklist_printnode_default_printer_info{ color:green; }

.wt_pklist_printnode_search_printers_btn{ margin-left:15px; text-decoration:underline;}
.wt_pklist_printnode_printer_action_btn, .wt_pklist_printnode_search_printers_btn{ cursor:pointer; }
.wt_pklist_printnode_default_printer_info{ color:green; }
.wt_pklist_printnode_default_printer_name{ font-style:italic; }

.wt_pklist_default_printer_info{ margin-top:10px; display:inline-block;}

.wt_pklist_printnode_manual_print_button_preview{ cursor:pointer; }
.wt_pklist_printnode_manual_print_button_preview_pop{display:none; position:absolute; z-index:1000; border:solid 1px #ccc; padding:2px; background:#fff; box-shadow:0px 5px 5px #ccc; }
.wt_pklist_printnode_manual_print_button_preview:hover .wt_pklist_printnode_manual_print_button_preview_pop{ display:block; }
.wt_pklist_printnode_refresh_printers_list{ float:right; margin-bottom:10px !important; }
/* Ensure popup and overlay are above all other elements including Update Settings button */
.wf_cst_overlay { position: fixed !important; z-index: 100000010 !important; width: 100% !important; height: 100% !important; top: 0 !important; left: 0 !important; background-color: rgba(0, 0, 0, 0.5) !important; }
.wf_pklist_popup,
.wt_pklist_printnode_printers.wf_pklist_popup,
.wt_pklist_printnode_test_connection.wf_pklist_popup { position: fixed !important; z-index: 100000011 !important; }
.wf-plugin-toolbar.bottom,
.wf-plugin-toolbar.bottom[style*="position: fixed"],
.wf-plugin-toolbar.bottom[style*="position:fixed"],
#wf-plugin-toolbar,
#wf-plugin-toolbar.wf-plugin-toolbar,
#wf-plugin-toolbar.wf-plugin-toolbar.bottom,
.wt_pklist_update_settings_btn,
.wt_pklist_update_settings_btn_div,
div.wf-plugin-toolbar.bottom,
div#wf-plugin-toolbar { z-index: 999998 !important; }
.wt-popup-force-below,
.wt-popup-force-below.wf-plugin-toolbar,
.wt-popup-force-below#wf-plugin-toolbar,
#wf-plugin-toolbar.wt-popup-force-below,
.wf-plugin-toolbar.bottom.wt-popup-force-below { z-index: 1 !important; position: relative !important; }
</style>

<!-- Test connection popup -->
<div class="wt_pklist_printnode_test_connection wf_pklist_popup">
	<div class="wf_pklist_popup_hd">
		<span class="dashicons dashicons-admin-generic" style="line-height:40px;"></span> <?php esc_html_e('Test connection','wt-woocommerce-invoice-addon');?>
		<div class="wf_pklist_popup_close">X</div>
	</div>
	<div class="wf_pklist_popup_body"></div>
</div>

<!-- Printers popup -->
<div class="wt_pklist_printnode_printers wf_pklist_popup">
	<div class="wf_pklist_popup_hd">
		<span class="dashicons dashicons-printer" style="line-height:40px;"></span> <?php esc_html_e('Setup a printer','wt-woocommerce-invoice-addon');?>
		<div class="wf_pklist_popup_close">X</div>
	</div>
	<div class="wf_pklist_popup_body"></div>
</div>

<form method="post" class="wf_settings_form">
	<p>
		<?php
		/* translators: %1$s: Opening anchor tag, %2$s: Closing anchor tag */
		echo wp_kses_post( sprintf( __( "Use API key from the PrintNode developer %1\$s dashboard %2\$s to setup a remote print option for the same.", 'wt-woocommerce-invoice-addon' ), '<a href="https://app.printnode.com/app/login" target="_blank">', '</a>' ) );
		?>
		<?php
		/* translators: %1$s: Opening anchor tag, %2$s: Closing anchor tag */
		echo wp_kses_post( sprintf( __( "Click here to find how to %1\$s set up %2\$s your remote printer for PrintNode.", 'wt-woocommerce-invoice-addon' ), '<a href="https://www.printnode.com/en/docs" target="_blank">', '</a>' ) );
		?>
	</p>
	<table class="wf-form-table">
		<?php
		$btn_html='<button class="wf_button button button-primary wt_pklist_printnode_test_connection_btn" type="button" style="float:right; width:35%;">'.__('Test connection', 'wt-woocommerce-invoice-addon').'</button>';
		$manual_print_preview_html='<div class="wt_pklist_printnode_manual_print_button_preview_pop">
					<img src="'.WT_PKLIST_INVOICE_ADDON_PLUGIN_URL.'includes/remote_print/assets/images/manual_print_button_preview.png">
				</div>';
		$form_fields=array(
			array(
				'label'=>__("API Key",'wt-woocommerce-invoice-addon'),
				'option_name'=>"wt_pklist_remote_print_api_key",
				'mandatory'=>true,
				'attr'=>'style="width:60%; float:left;"',
				'after_form_field'=>$btn_html,
				'help_text'=>__('Specify the API Key obtained from PrintNode dashboard for authentication.', 'wt-woocommerce-invoice-addon'),
			),
			array(
				'type'=>'radio',
				'label'=>__("Enable manual printing",'wt-woocommerce-invoice-addon'),
				'option_name'=>"wt_pklist_remote_print_manual",
				/* translators: %1$s: Opening anchor tag with preview image, %2$s: Closing anchor tag */
				'help_text'=>sprintf(__("Choose `Yes` to have a `Send to PrintNode` button in the WooCommerce Orders admin page. %1\$s Preview. %2\$s", 'wt-woocommerce-invoice-addon'), '<a class="wt_pklist_printnode_manual_print_button_preview">'.$manual_print_preview_html, '</a>'),
				'radio_fields'=>array(
					'Yes'=>__('Yes','wt-woocommerce-invoice-addon'),
					'No'=>__('No', 'wt-woocommerce-invoice-addon')
				),
			),
			array(
				'type'=>'radio',
				'label'=>__("Enable automatic printing",'wt-woocommerce-invoice-addon'),
				'option_name'=>"wt_pklist_remote_print_automatic",
				'help_text'=>__("Prints the document automatically whenever an order status is updated. Ensure that a default printer is set up for this to work.", 'wt-woocommerce-invoice-addon'),
				'radio_fields'=>array(
					'Yes'=>__('Yes','wt-woocommerce-invoice-addon'),
					'No'=>__('No','wt-woocommerce-invoice-addon')
				),
				'form_toggler'=>array(
					'type'=>'parent',
					'target'=>'wt_pklist_remote_print_automatic',
				)
			),
			array(
				'type'=>'radio',
				'label'=>__('Notify by email','wt-woocommerce-invoice-addon'),
				'option_name'=>"wt_pklist_remote_print_email_notification",
				/* translators: %s: Admin email address */
				'help_text'=>sprintf(__("Choose `Yes` to notify the site admin(%s) of print failures.", 'wt-woocommerce-invoice-addon'), get_option('admin_email')),
				'radio_fields'=>array(
					'Yes'=>__('Yes','wt-woocommerce-invoice-addon'),
					'No'=>__('No','wt-woocommerce-invoice-addon')
				),
				'form_toggler'=>array(
					'type'=>'child',
					'val'=>'Yes',
					'id'=>'wt_pklist_remote_print_automatic',
				)
			)
		);
		if(is_array($documents))
		{
			foreach ($documents as $doc_key => $doc_title)
			{
				$form_fields[]=array(
					'type'=>'order_st_multiselect',
					'label'=>$doc_title,
					'option_name'=>"wt_pklist_remote_print_automatic_{$doc_key}_statuses",
					'order_statuses'=>$order_statuses,
					'field_vl'=>array_flip($order_statuses),
					/* translators: %s: Document type title */
					'help_text'=>sprintf(__('Choose the order statuses for which the %s has to be printed.', 'wt-woocommerce-invoice-addon'), $doc_title),
					'form_toggler'=>array(
						'type'=>'child',
						'val'=>'Yes',
						'id'=>'wt_pklist_remote_print_automatic',
					)
				);
			}
		}
		$form_fields[]=
			array(
				'type'=>'radio',
				'label'=>__("Enable log",'wt-woocommerce-invoice-addon'),
				'option_name'=>"wt_pklist_remote_print_enable_log",
				'help_text'=>__('Records print node api responses into WooCommerce status log.', 'wt-woocommerce-invoice-addon'),
				'radio_fields'=>array(
					'Yes'=>__('Yes','wt-woocommerce-invoice-addon'),
					'No'=>__('No', 'wt-woocommerce-invoice-addon')
				),
			);
		self::generate_form_field($form_fields, $module_id);
		?>
	</table>
	<input type="hidden" value="<?php echo esc_attr( $module_base ); ?>" class="wf_settings_base" />
	<?php
	$setup_printer_btn_text=$msgs['setup_default_printer'];
	$default_printer_name_css="color:red;";
	if($default_printer_id>0)
	{
		$setup_printer_btn_text=$msgs['change_default_printer'];
		$default_printer_name_css="";
	}else
	{
		$default_printer_name=$msgs['no_printer_label'];
	}
	$left_html='<span class="wt_pklist_default_printer_info"><b>'.esc_html__('Default printer', 'wt-woocommerce-invoice-addon').'</b>: <span style="'.esc_attr($default_printer_name_css).'" class="wt_pklist_printnode_default_printer_name">'.esc_html($default_printer_name).'</span> <a class="wt_pklist_printnode_search_printers_btn">'.esc_html($setup_printer_btn_text).'</a></span>';

	self::add_settings_footer('', $left_html);
	?>
</form>