<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<div style="padding:15px;">
	<div class="wt_pklist_printnode_test_msg_box">
		
	</div>
	<button type="button" class="button button-secondary wt_pklist_printnode_refresh_printers_list">
		<span class="dashicons dashicons-image-rotate" style="font-size:16px; margin-top:6px;"></span> <?php esc_html_e('Refresh list', 'wt-woocommerce-invoice-addon');?>
	</button>
	<?php
	if(is_array($printer_arr) && count($printer_arr)>0)
	{
	?>
		<table class="wp-list-table widefat fixed striped wt_pklist_printnode_printers_tb">
			<thead>
				<tr>
					<th><?php esc_html_e('Name', 'wt-woocommerce-invoice-addon'); ?></th>
					<th><?php esc_html_e('Description', 'wt-woocommerce-invoice-addon'); ?></th>
					<th><?php esc_html_e('ID', 'wt-woocommerce-invoice-addon'); ?></th>			
					<th>
						<?php
						esc_html_e('Connection Status', 'wt-woocommerce-invoice-addon');
						$tooltip_html = Wf_Woocommerce_Packing_List_Admin::set_tooltip('connection_status', $main_obj->module_id);
						echo wp_kses_post( $tooltip_html );
						?>						
					</th>
					<th style="width:230px;">
						<?php 
						esc_html_e('Actions', 'wt-woocommerce-invoice-addon');
						$tooltip_html = Wf_Woocommerce_Packing_List_Admin::set_tooltip('actions', $main_obj->module_id);
						echo wp_kses_post( $tooltip_html ); 
						?>
					</th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach($printer_arr as $printer)
				{ 
					?>
					<tr>
						<td class="wt_pklist_printnode_printer_name"><?php echo esc_html( $printer['name'] ); ?></td>
						<td class="wt_pklist_printnode_printer_display_name"><?php echo esc_html( $printer['display_name'] ); ?></td>
						<td><?php echo esc_html( $printer['id'] ); ?></td>						
						<td>
							<?php
							$status_label=__('Offline', 'wt-woocommerce-invoice-addon');
							$status_color='#ccc';
							$test_printer_title=__('Printer is not online. Please check printer status.', 'wt-woocommerce-invoice-addon');
							if($printer['connection_status']=='online')
							{
								$status_label=__('Online', 'wt-woocommerce-invoice-addon');
								$status_color='#35ac19';
								
								$test_printer_title=__('Test printer by printing a sample document', 'wt-woocommerce-invoice-addon');
							}
							?>
							<span class="wt_pklist_printnode_status_info" style="background:<?php echo esc_attr( $status_color ); ?>;"></span><span class="wt_pklist_printnode_status_info_text"><?php echo esc_html( $status_label ); ?></span>
						</td>	
						<td>
							<a class="wt_pklist_printnode_printer_action_btn" onclick="wt_pklist_printnode.test_printer(this, '<?php echo esc_js( $printer['id'] ); ?>', '<?php echo esc_js( $printer['connection_status'] ); ?>');" <?php echo ($printer['connection_status']!='online' ? 'style="opacity:.5; cursor:not-allowed;"' : ''); ?> title="<?php echo esc_attr( $test_printer_title ); ?>"><?php esc_html_e('Test printer', 'wt-woocommerce-invoice-addon');?></a>
							 | <a class="wt_pklist_printnode_printer_action_btn wt_pklist_printnode_printer_default_toggle_btn" data-id="<?php echo esc_attr( $printer['id'] ); ?>" onclick="wt_pklist_printnode.toggle_default_printer(this, '<?php echo esc_js( $printer['id'] ); ?>');"></a> 
						</td>	
					</tr>
					<?php	
				}
				?>
			</tbody>
		</table>
	<?php
	}else
	{
		?>
		<h4 style="text-align:center; background:#fff;">
			<?php esc_html_e('No printers found.', 'wt-woocommerce-invoice-addon') ?> <br />
			<?php esc_html_e('Need help?', 'wt-woocommerce-invoice-addon') ?> 
			<?php
			/* translators: %1$s: Opening anchor tag, %2$s: Closing anchor tag */
			echo wp_kses_post( sprintf( __('Click %1$shere%2$s to find how to set up your printer with Print Node', 'wt-woocommerce-invoice-addon'), '<a href="https://www.printnode.com/en/docs" target="_blank" rel="nofollow">', '</a>' ) );
			?>	
		</h4>
		<?php
	}
	?>
</div>