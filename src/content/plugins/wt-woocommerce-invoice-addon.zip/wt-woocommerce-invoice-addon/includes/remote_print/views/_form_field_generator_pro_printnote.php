<?php
if (!defined('ABSPATH')) {
	exit;
}

if(!class_exists('WT_Form_Field_Builder_Printnode') && class_exists('WT_Form_Field_Builder')){

class WT_Form_Field_Builder_Printnode extends WT_Form_Field_Builder{

	private static $instance = null;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.4
	 */
	public function __construct() {

	}

	/**
     *  Get Instance
     * 
     *  @since 1.0.4
     */
    public static function get_instance()
    {
        if(is_null(self::$instance))
        {
            self::$instance = new WT_Form_Field_Builder_Printnode();
        }
        return self::$instance;
    }
}
}