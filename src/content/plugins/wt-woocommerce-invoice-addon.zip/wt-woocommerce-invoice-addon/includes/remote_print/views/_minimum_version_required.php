<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div style="background:#fcf8e3; padding:10px; border:solid 1px #faebcc; color:#a66d3c; margin:50px 0px;">
	<b><?php esc_html_e('Oops !!!', 'wt-woocommerce-invoice-addon'); ?></b> <?php esc_html_e('Remote print add-on(PrintNode) requires WooCommerce PDF Invoice v4.1.4 or above', 'wt-woocommerce-invoice-addon'); ?>. <a href="<?php echo esc_url( admin_url("plugins.php?s=WooCommerce PDF Invoices, Packing Slips, Delivery Notes & Shipping Labels") ); ?>"><?php esc_html_e('Update now', 'wt-woocommerce-invoice-addon');?></a>
</div>