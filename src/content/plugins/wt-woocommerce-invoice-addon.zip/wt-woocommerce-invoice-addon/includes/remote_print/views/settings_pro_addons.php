<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<style type="text/css">
.wt_pklist_printnode_test_connection{ width:350px; height:200px; }
.wt_pklist_printnode_test_connection_loader{ width:100%; height:75px; margin-top:70px; text-align:center; font-size:14px; }

.wt_pklist_printnode_printers{ width:900px; height:500px; }
.wt_pklist_printnode_printers_loader{ width:100%; height:200px; margin-top:70px; text-align:center; font-size:14px; }

.wt_pklist_printnode_printers_tb th{ font-weight:bold; text-align:center; }
.wt_pklist_printnode_printers_tb td{text-align:center; }

.wt_pklist_printnode_action_btn{ cursor:pointer; }
.wt_pklist_printnode_status_info{ display:inline-block; width:15px; height:15px; border-radius:10px; margin-right:5px; }
.wt_pklist_printnode_status_info_text{ display:inline-block; margin-top:-2px; }
.wt_pklist_printnode_test_msg_box{margin-bottom: 15px; clear:both;}
.wt_pklist_printnode_default_printer_info{ color:green; }

.wt_pklist_printnode_search_printers_btn{ margin-left:15px; text-decoration:underline;}
.wt_pklist_printnode_printer_action_btn, .wt_pklist_printnode_search_printers_btn{ cursor:pointer; }
.wt_pklist_printnode_default_printer_info{ color:green; }
.wt_pklist_printnode_default_printer_name{ font-style:italic; }

.wt_pklist_default_printer_info{ margin-top:10px; display:inline-block;}

.wt_pklist_printnode_manual_print_button_preview{ cursor:pointer; }
.wt_pklist_printnode_manual_print_button_preview_pop{display:none; position:absolute; z-index:1000; border:solid 1px #ccc; padding:2px; background:#fff; box-shadow:0px 5px 5px #ccc; }
.wt_pklist_printnode_manual_print_button_preview:hover .wt_pklist_printnode_manual_print_button_preview_pop{ display:block; }

.wt_pklist_printnode_refresh_printers_list{ float:right; margin-bottom:10px !important; }
/* Ensure popup and overlay are above all other elements including Update Settings button */
.wf_cst_overlay { position: fixed !important; z-index: 100000010 !important; width: 100% !important; height: 100% !important; top: 0 !important; left: 0 !important; background-color: rgba(0, 0, 0, 0.5) !important; }
.wf_pklist_popup,
.wt_pklist_printnode_printers.wf_pklist_popup,
.wt_pklist_printnode_test_connection.wf_pklist_popup { position: fixed !important; z-index: 100000011 !important; }
.wf-plugin-toolbar.bottom,
.wf-plugin-toolbar.bottom[style*="position: fixed"],
.wf-plugin-toolbar.bottom[style*="position:fixed"],
#wf-plugin-toolbar,
#wf-plugin-toolbar.wf-plugin-toolbar,
#wf-plugin-toolbar.wf-plugin-toolbar.bottom,
.wt_pklist_update_settings_btn,
.wt_pklist_update_settings_btn_div,
div.wf-plugin-toolbar.bottom,
div#wf-plugin-toolbar { z-index: 999998 !important; }
.wt-popup-force-below,
.wt-popup-force-below.wf-plugin-toolbar,
.wt-popup-force-below#wf-plugin-toolbar,
#wf-plugin-toolbar.wt-popup-force-below,
.wf-plugin-toolbar.bottom.wt-popup-force-below { z-index: 1 !important; position: relative !important; }

</style>

<!-- Test connection popup -->
<div class="wt_pklist_printnode_test_connection wf_pklist_popup">
	<div class="wf_pklist_popup_hd">
		<span class="dashicons dashicons-admin-generic" style="line-height:40px;"></span> <?php esc_html_e('Test connection','wt-woocommerce-invoice-addon');?>
		<div class="wf_pklist_popup_close">X</div>
	</div>
	<div class="wf_pklist_popup_body"></div>
</div>

<!-- Printers popup -->
<div class="wt_pklist_printnode_printers wf_pklist_popup">
	<div class="wf_pklist_popup_hd">
		<span class="dashicons dashicons-printer" style="line-height:40px;"></span> <?php esc_html_e('Setup a printer','wt-woocommerce-invoice-addon');?>
		<div class="wf_pklist_popup_close">X</div>
	</div>
	<div class="wf_pklist_popup_body"></div>
</div>

<form method="post" class="wf_settings_form">
	<input type="hidden" value="<?php echo esc_attr($module_base); ?>" class="wf_settings_base" />
    <input type="hidden" value="wf_save_settings" class="wf_settings_action" />
    <input type="hidden" value="wt_remote_print" name="wt_tab_name" class="wt_tab_name" />
	<p>
		<?php
		/* translators: %1$s: Opening anchor tag, %2$s: Closing anchor tag */
		echo wp_kses_post( sprintf( __( "Use API key from the PrintNode developer %1\$s dashboard %2\$s to setup a remote print option for the same.", 'wt-woocommerce-invoice-addon' ), '<a href="https://app.printnode.com/app/login" target="_blank">', '</a>' ) );
		?>
		<?php
		/* translators: %1$s: Opening anchor tag, %2$s: Closing anchor tag */
		echo wp_kses_post( sprintf( __( "Click here to find how to %1\$s set up %2\$s your remote printer for PrintNode.", 'wt-woocommerce-invoice-addon' ), '<a href="https://www.printnode.com/en/docs" target="_blank">', '</a>' ) );
		?>
	</p>
	<?php
        // Set nonce:
    if (function_exists('wp_nonce_field'))
    {
        wp_nonce_field('wf-update-invoice-'.WF_PKLIST_POST_TYPE, '_wpnonce', true, false);
    }
    ?>
	<table class="wf-form-table">
		<tbody>
			<?php 
			$btn_html='<button class="wf_button button button-primary wt_pklist_printnode_test_connection_btn" type="button" style="margin-top:10px;">'.__('Test connection', 'wt-woocommerce-invoice-addon').'</button>';
			$manual_print_preview_html='<div class="wt_pklist_printnode_manual_print_button_preview_pop">
					<img src="'.WT_PKLIST_INVOICE_ADDON_PLUGIN_URL.'includes/remote_print/assets/images/manual_print_button_preview.png">
				</div>';
			$settings_arr['print_node-general'] = array(
				'wt_pklist_remote_print_api_key' => array(
					'type' => 'wt_text',
					'label'=>__("API Key",'wt-woocommerce-invoice-addon'),
					'id' => 'wt_pklist_remote_print_api_key',
					'class' => 'wt_pklist_remote_print_api_key',
					'name' => 'wt_pklist_remote_print_api_key',
					'mandatory' => true,
					'after_form_field'=>$btn_html,
					'help_text'=>__('Specify the API Key obtained from PrintNode dashboard for authentication.', 'wt-woocommerce-invoice-addon'),
				),
				'wt_pklist_remote_print_manual' => array(
					'type'=>'wt_radio',
					'label'=>__("Enable manual printing",'wt-woocommerce-invoice-addon'),
					'id' => 'wt_pklist_remote_print_manual',
					'class' => 'wt_pklist_remote_print_manual',
					'name'=>"wt_pklist_remote_print_manual",
					/* translators: %1$s: Opening anchor tag with preview image, %2$s: Closing anchor tag */
					'help_text'=>sprintf(__("Choose `Yes` to have a `Send to PrintNode` button in the WooCommerce Orders admin page. %1\$s Preview. %2\$s", 'wt-woocommerce-invoice-addon'), '<a class="wt_pklist_printnode_manual_print_button_preview">'.wp_kses_post($manual_print_preview_html), '</a>'),
					'radio_fields'=>array(
						'Yes'=>__('Yes','wt-woocommerce-invoice-addon'),
						'No'=>__('No', 'wt-woocommerce-invoice-addon')
					),
					'alignment' => 'horizontal_with_label',
					'col' => 3,
				),
				array(
					'type'=>'wt_radio',
					'label'=>__("Enable automatic printing",'wt-woocommerce-invoice-addon'),
					'name'=>"wt_pklist_remote_print_automatic",
					'help_text'=>__("Prints the document automatically whenever an order status is updated. Ensure that a default printer is set up for this to work.", 'wt-woocommerce-invoice-addon'),
					'radio_fields'=>array(
						'Yes'=>__('Yes','wt-woocommerce-invoice-addon'),
						'No'=>__('No','wt-woocommerce-invoice-addon')
					),
					'form_toggler'=>array(
						'type'=>'parent',
						'target'=>'wt_pklist_remote_print_automatic',
					)
				),
				array(
					'type'=>'wt_radio',
					'label'=>__('Notify by email','wt-woocommerce-invoice-addon'),
					'name'=>"wt_pklist_remote_print_email_notification",
					/* translators: %s: Admin email address */
					'help_text'=>sprintf(__("Choose `Yes` to notify the site admin(%s) of print failures.", 'wt-woocommerce-invoice-addon'), get_option('admin_email')),
					'radio_fields'=>array(
						'Yes'=>__('Yes','wt-woocommerce-invoice-addon'),
						'No'=>__('No','wt-woocommerce-invoice-addon')
					),
					'form_toggler'=>array(
						'type'=>'child',
						'val'=>'Yes',
						'id'=>'wt_pklist_remote_print_automatic',
					)
				)
			);

			if(is_array($documents))
			{
				foreach ($documents as $doc_key => $doc_title)
				{
					$doc_module_id = Wf_Woocommerce_Packing_List::get_module_id( $doc_key );
					
					// Get the order status from the respective modules.
					if ('invoice' === $doc_key || 'creditnote' === $doc_key || 'proformainvoice' === $doc_key ) {
						
						$choosen_order_statuses = Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_generate_for_orderstatus', $doc_module_id);
						
						
						$document_order_statuses = array();
						foreach ($choosen_order_statuses as $key) {
							$document_order_statuses[$key] = isset($order_statuses[$key]) ? $order_statuses[$key] : $key;
						}
					} else {
						$document_order_statuses = $order_statuses;
					}

					/* translators: %s: Document type title */
					$help_text = sprintf(__('Choose the order statuses for which the %s has to be printed.', 'wt-woocommerce-invoice-addon'), esc_html($doc_title));

					if($doc_key === "invoice"){
						$help_text .= sprintf('<br><span style="color:#2271b1">%s</span>',__("Note: This option will generate the invoice number, if the order is not having invoice number yet.", 'wt-woocommerce-invoice-addon'));
					}

					if($doc_key === "creditnote"){
						$help_text .= sprintf('<br><span style="color:#2271b1">%s</span>',__("Note: This option will generate the invoice number and credit note number, if the order is not having invoice and credit note numbers yet.", 'wt-woocommerce-invoice-addon'));
					}

					if($doc_key === "proformainvoice"){
						$help_text .= sprintf('<br><span style="color:#2271b1">%s</span>',__("Note: This option will generate the proforma invoice number, if the order is not having proforma invoice number yet.", 'wt-woocommerce-invoice-addon'));
					}

					$settings_arr['print_node-general']["wt_pklist_remote_print_automatic_{$doc_key}_statuses"]=array(
							'type'=>'wt_select2_checkbox',
							'label'=>$doc_title,
							'name'=>"wt_pklist_remote_print_automatic_{$doc_key}_statuses",
							'value' => $document_order_statuses,
	                        'checkbox_fields' => $document_order_statuses,
							'help_text'=> $help_text,
							'form_toggler'=>array(
								'type'=>'child',
								'val'=>'Yes',
								'id'=>'wt_pklist_remote_print_automatic',
							)
						);
				}
			}
			$settings_arr['print_node-general']['wt_pklist_remote_print_enable_log']=
				array(
					'type'=>'wt_radio',
					'label'=>__("Enable log",'wt-woocommerce-invoice-addon'),
					'name'=>"wt_pklist_remote_print_enable_log",
					'help_text'=>__('Records print node api responses into WooCommerce status log.', 'wt-woocommerce-invoice-addon'),
					'radio_fields'=>array(
						'Yes'=>__('Yes','wt-woocommerce-invoice-addon'),
						'No'=>__('No', 'wt-woocommerce-invoice-addon')
					),
				);
			if(class_exists('WT_Form_Field_Builder_Printnode')){
                $Form_builder = new WT_Form_Field_Builder_Printnode();
            }else{
                $Form_builder = new WT_Form_Field_Builder();
            }
            foreach($settings_arr as $settings){
                $Form_builder->generate_form_fields($settings, $module_id);
            }

            $setup_printer_btn_text=$msgs['setup_default_printer'];
			$default_printer_name_css="color:red;";
			if($default_printer_id>0)
			{
				$setup_printer_btn_text=$msgs['change_default_printer'];
				$default_printer_name_css="";
			}else
			{
				$default_printer_name=$msgs['no_printer_label'];
			}
			$left_html='<span class="wt_pklist_default_printer_info"><b>'.__('Default printer', 'wt-woocommerce-invoice-addon').'</b>: <span style="'.wp_kses_post($default_printer_name_css).'" class="wt_pklist_printnode_default_printer_name">'.esc_html($default_printer_name).'</span> <a class="wt_pklist_printnode_search_printers_btn">'.esc_html($setup_printer_btn_text).'</a></span>';
			?>
			<tr valign="top">
				<td colspan="2"><?php echo wp_kses_post($left_html); ?></td>
			</tr>
		</tbody>
	</table>
	<?php
	include WF_PKLIST_PLUGIN_PATH."admin/views/admin-settings-save-button.php";
	?>
</form>