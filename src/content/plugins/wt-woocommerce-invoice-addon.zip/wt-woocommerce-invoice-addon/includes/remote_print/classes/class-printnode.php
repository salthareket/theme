<?php
if (!defined('ABSPATH')) {
    exit;
}
class Wt_Pklist_Printnode
{
	public static $test_url 	= "https://api.printnode.com/whoami";
	public static $search_url	= "https://api.printnode.com/printers";
    public static $jobs_url		= "https://api.printnode.com/printjobs";

    public static function connect($api_key)
    {
    	$headers=self::prepare_auth_header($api_key);
    	
    	$response=self::do_request(self::$test_url, 'get', array(), $headers);
        if($response && isset($response['body']))
        {	
        	if(isset($response['status'])){
    			if($response['status'] === true){
    				return $response['body'];
    			}
    		}
        }
    	return false;
    }

    public static function search_printers($api_key)
    {
    	$printers=array();
    	$headers=self::prepare_auth_header($api_key);
    	
    	$response=self::do_request(self::$search_url, 'get', array(), $headers);    	
    	
    	if($response && isset($response['body']))
    	{	
    		if(isset($response['status'])){
    			if($response['status'] === true){
    				/* process json object */
		    		$printers=self::process_printer_list($response['body']);
    			}
    		}	
    	}

    	return $printers;
    }

    /**
	*	Send Job data to printer
	*	@param $args array config data array
	*
	*	Sample argument array
	*	$args=array(
	* 		'printerId'=>$printer_id, //ID of printer
	* 		'title'=>$job_title, //job title
	* 		'contentType'=>$content_type, //content type
	* 		'content'=>$content, //document content
	* 		'source'=>$source, //A text description of how the print job was created or where the print job originated.
	*	);
	*/
    public static function send_to_printer($api_key, $args)
    {
    	$out=array(
    		'status' 		=>false,
    		'error_code' 	=>'',
    		'msg'			=>__('Request error / Null response', 'wt-woocommerce-invoice-addon'), 
    		'job_id' 		=>0
    	);
    	
    	/* headers */
		$headers=self::prepare_auth_header($api_key);

    	$response=self::do_request(self::$jobs_url, 'post', $args, $headers);
    	if($response)
    	{	
    		if($response['status'] === true){
    			$out_status = true;
    		}else{
    			$out_status = false;
    		}
            $out=array(
                'status'        =>$out_status,
                'error_code'    =>$response['code'],
                'msg'           =>$response['msg'], 
                'job_id'        =>$response['body'],
            );
    	}

		return $out;
    }

    protected static function prepare_auth_header($api_key)
    {
    	$headers=array(
    		'Authorization'=>"Basic ".base64_encode($api_key),
    	);
    	return $headers;
    }

    protected static function do_request($url, $method, $params, $headers=array())
    {	
    	$logger = wc_get_logger();
    	$args = self::prepare_request_args($params, $headers);

    	if($method=='post')
    	{
    		$response=wp_remote_post($url, $args);
    	}else
    	{
    		$response=wp_remote_get($url, $args);
    	}

    	$enable_printnode_log = Wf_Woocommerce_Packing_List::get_option('wt_pklist_remote_print_enable_log','wf_woocommerce_packing_list_printnode');
    	
	    /**
	    *	Request error
	    */
	    $response_header = wp_remote_retrieve_headers($response);
	    $response_code=wp_remote_retrieve_response_code($response);
	    $response_body=json_decode(wp_remote_retrieve_body($response), true);
	    $allowed_codes_arr=array(200, 201);
	    if(is_wp_error($response) || !in_array($response_code, $allowed_codes_arr))
		{
			$response=array(
	        	'status' => false,
	        	'header' => $response_header,
	            'body'=>$response_body,
	            'code'=>$response_code,
	            /* translators: %s: HTTP response code */
            'msg'=> sprintf(__('Invalid response code: %s', 'wt-woocommerce-invoice-addon'), $response_code),
	        );
	        if($enable_printnode_log == "Yes"){
	        	$logger_res_array = array('api_url' => $url, 'api_params' => $args, 'response' => $response );
	   			$logger->info( wc_print_r( $logger_res_array, true ), array( 'source' => 'wt_printnode_response' ) );
	        }
			return $response;
		}

	    /**
	    *	Unable to proccess the data
	    */
	    if(is_null($response_body))
	    {
	    	$response=array(
	        	'status' => false,
	        	'header' => $response_header,
	            'body'=>$response_body,
	            'code'=>$response_code,
	            'msg'=> __('Null response', 'wt-woocommerce-invoice-addon'),
	        );
	        if($enable_printnode_log == "Yes"){
	        	$logger_res_array = array('api_url' => $url, 'api_params' => $args, 'response' => $response );
   				$logger->info( wc_print_r( $logger_res_array, true ), array( 'source' => 'wt_printnode_response' ) );
   			}
			return $response;	
	    }

        $response=array(
        	'status' => true,
        	'header' => $response_header,
            'body'=>$response_body,
            'code'=>$response_code,
            'msg'=>wp_remote_retrieve_response_message($response),
        );

        if($enable_printnode_log == "Yes"){
        	$logger_res_array = array('api_url' => $url, 'api_params' => $args, 'response' => $response );
	   		$logger->info( wc_print_r( $logger_res_array, true ), array( 'source' => 'wt_printnode_response' ) );
        }
        
	    return $response;	
    }

    protected static function prepare_request_args($params, $headers=array())
	{
		global $wp_version;
		
		$args = array(
		    'timeout'     => 120,
		    'redirection' => 5,
		    'httpversion' => '1.0',
		    'user-agent'  => 'WordPress/' . $wp_version . '; ' . home_url(),
		    'blocking'    => true,
		    'headers'     => $headers,
		    'cookies'     => array(),
		    'body'        => $params,
		    'compress'    => false,
		    'decompress'  => true, 
			'stream'      => false,
		    'filename'    => null, 
		    'sslverify'   => false,
		);

		return $args;
	}

	

	private static function process_printer_list($printers_json)
    {
		$printers = array();
		if(is_array($printers_json))
		{
			foreach($printers_json as $printer)
			{
				$printers[]=array(
					'id' 				=> $printer['id'],
					'name' 				=> $printer['name'],
					'display_name' 		=> $printer['description'],
					'connection_status' => $printer['state'],
				);
			}
		}
		return $printers;
	}
}