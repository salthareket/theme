<?php
if (!defined('ABSPATH')) {
    exit;
}
class Wt_Pklist_Printnode_Ajax
{
	/**
	*	Search for printers (Ajax sub function)
	*
	*/
	public function search_printers($out, $main_obj)
	{
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verification is handled by ajax_main in the parent class
		$api_key=(isset($_POST['api_key']) ? sanitize_text_field(wp_unslash($_POST['api_key'])) : '');
		
		$out['status']=1;
		if(trim($api_key)=='')
		{
			$api_key=$main_obj->get_api_credentials();
			if(!$api_key || $api_key=="")
			{
				$out['status']=0;
				$out['msg']=__('API key missing', 'wt-woocommerce-invoice-addon');
			}
		}
		
		if($out['status']==1)
		{
			$main_obj->include_print_node();
			$printer_arr=Wt_Pklist_Printnode::search_printers($api_key);
			
			/** 
			 * Sample response
			 * $printer_arr=array(
			 * 	array(
			 * 		'id' => 0,
			 * 		'name' => '',
			 * 		'display_name' => '',
			 * 		'connection_status' => 'offline',
			 * 	), 
			 * 	array(
			 * 		'id' => 0,
			 * 		'name' => '',
			 * 		'display_name' => '',
			 * 		'connection_status' => 'online',
			 * 	),
			 * ); 
			 */
			
			$out['msg']='';
			$default_printer_id=$main_obj->get_default_printer();
			ob_start();
			include WT_PKLIST_INVOICE_ADDON_PLUGIN_PATH."includes/remote_print/views/_printer_list.php"; 
			$out['html']=ob_get_clean();
		}
		return $out;
	}

	/**
	*	Ajax sub hook
	*	Manual remote print
	*/
	public function manual_print($out, $main_obj)
	{
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verification is handled by ajax_main in the parent class
		$template_type=(isset($_POST['template_type']) ? sanitize_text_field(wp_unslash($_POST['template_type'])) : '');
		if($template_type=="")
		{
			$out['msg']=__('Invalid document type.', 'wt-woocommerce-invoice-addon');
			return $out;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verification is handled by ajax_main in the parent class
		$order_id=(isset($_POST['order_id']) ? absint(wp_unslash($_POST['order_id'])) : 0);
		if($order_id===0)
		{
			$out['msg']=__('Invalid order id.', 'wt-woocommerce-invoice-addon');
			return $out;
		}

		$api_key=$main_obj->get_api_credentials();
		if(!$api_key || $api_key=="")
		{
			$out['msg']=__('API key missing', 'wt-woocommerce-invoice-addon');
			return $out;
		}

		$printer_id=$main_obj->get_default_printer(); /* taking default printer id */
		if(!isset($printer_id) || !$printer_id)
		{
			$out['msg']=__('Please set up a default printer', 'wt-woocommerce-invoice-addon');
			return $out;
		}

		/* module needed to check their module base is avaialable for remote print. If yes then they need to return back the processed template HTML */
		$remote_print_arr=apply_filters('wt_pklist_do_remote_printing', array($template_type=>array()), $order_id, $main_obj->module_base);
		
		if(is_array($remote_print_arr) && isset($remote_print_arr[$template_type]) && $remote_print_arr[$template_type]['html']!="")
		{
			
			$main_obj->include_print_node(); /* include PrintNode library */
			
			$job_title=(isset($remote_print_arr[$template_type]['title']) ? $remote_print_arr[$template_type]['title'] : $template_type.'_'.$order_id);
			$args=array(
	    		'printerId'=>$printer_id,
	    		'title'=>$job_title,
	    		'contentType'=>'pdf_base64',
	    		'content'=>$main_obj->prepare_pdf_base64($remote_print_arr[$template_type]['pdf_file']),
	    		'source'=>__("Print from WP dashboard", 'wt-woocommerce-invoice-addon'),
	    	);
			$printer_response=Wt_Pklist_Printnode::send_to_printer($api_key, $args); /* send job to printer */
			
			/** Sample response
			* $printer_response=array(
			* 	'status'=>true,
			* 	'msg'=>'',
			* 	'job_id'=>1,
			* );
			*/
			
			/* process printer response */
			$out=$this->process_printer_response($printer_response, $out, $main_obj);
		}else
		{
			$out['status']=0;
			$out['msg']=__("Failed to generate document template.", 'wt-woocommerce-invoice-addon');
		}

		return $out;
	}

	/**
	*	Ajax sub hook
	*	Test printer by sending sample file
	*/
	public function test_printer($out, $main_obj)
	{
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verification is handled by ajax_main in the parent class
		$printer_id=(isset($_POST['printer_id']) ? sanitize_text_field(wp_unslash($_POST['printer_id'])) : '');
		if($printer_id!="")
		{
			
			$pdf_data=$main_obj->prepare_pdf_base64(WT_PKLIST_INVOICE_ADDON_PLUGIN_PATH."includes/remote_print/data/printer_test.pdf");
			if($pdf_data)
			{
				$api_key=$main_obj->get_api_credentials();
				if(!$api_key || $api_key=="")
				{
					$out['status']=0;
					$out['msg']=__('API key missing', 'wt-woocommerce-invoice-addon');
				}else
				{
					$main_obj->include_print_node();
					$args=array(
			    		'printerId'=>$printer_id,
			    		'title'=>__("Printer test", 'wt-woocommerce-invoice-addon'),
			    		'contentType'=>'pdf_base64',
			    		'content'=>$pdf_data,
			    		'source'=>__("Testing Printer from WP dashboard", 'wt-woocommerce-invoice-addon'),
			    	);

					$printer_response=Wt_Pklist_Printnode::send_to_printer($api_key, $args);

					/**  Sample response
					* $printer_response=array(
					* 	'status'=>true,
					* 	'msg'=>'',
					* 	'job_id'=>1,
					* );
					*/
					
					/* process printer response */
					$out=$this->process_printer_response($printer_response, $out, $main_obj);
				}
				
			}else
			{
				$out['status']=0;
				$out['msg']=__("Unable to read test PDF file", 'wt-woocommerce-invoice-addon');
			}
		}else
		{
			$out['status']=0;
			$out['msg']=__("Invalid Printer ID", 'wt-woocommerce-invoice-addon');
		}
		return $out;
	}

	/**
	*	Test the credential (Ajax sub function)
	*
	*/
	public function test_connection($out, $main_obj)
	{
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verification is handled by ajax_main in the parent class
		$api_key=(isset($_POST['api_key']) ? sanitize_text_field(wp_unslash($_POST['api_key'])) : '');
		
		$out['status']=1;
		if(trim($api_key)=='')
		{
			$out['status']=0;
			$out['msg']=__('API key is mandatory', 'wt-woocommerce-invoice-addon');
		}
		if($out['status']==1)
		{

			$main_obj->include_print_node();
			$connection_info=Wt_Pklist_Printnode::connect($api_key);
			
			/**  Sample response
			* $connection_info=array(
			* 	'firstname'=>'',
			* 	'lastname'=>'',
			* 	'email'=>'',
			* 	'state'=>'active',
			* ); 
			*/

			if($connection_info) //success
			{
				ob_start();
				?>
				<div style="line-height:18px; padding-top:25px;">
					<div style="color:#488e48; font-size:16px; font-weight:bold;"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e('Success', 'wt-woocommerce-invoice-addon'); ?></div>
					<div style="font-weight:bold; display:inline-block; padding-top:5px; border-bottom:dashed 1px #ccc; margin-bottom:2px; font-size:14px;"><?php esc_html_e('PrintNode account info', 'wt-woocommerce-invoice-addon');?></div>
					<div style="padding-left:15px;">
						<b><?php esc_html_e('Name', 'wt-woocommerce-invoice-addon');?>:</b> <?php echo esc_html($connection_info['firstname']).' '.esc_html($connection_info['lastname']);?> <br />
						<b><?php esc_html_e('Email', 'wt-woocommerce-invoice-addon');?>:</b> <?php echo esc_html($connection_info['email']);?> <br />
						<b><?php esc_html_e('Account State', 'wt-woocommerce-invoice-addon');?>:</b> <?php echo esc_html($connection_info['state']);?> <br />
					</div>
				</div>
				<?php
				$out['status']=1;
				$out['html']=ob_get_clean();
			}else
			{
				$out['status']=0;
				$out['msg']=__('Unable to connect', 'wt-woocommerce-invoice-addon');
			}			
		}
		return $out;
	}	

	/**
	*	Ajax sub hook
	*	Set/Remove default printer
	*/
	public function toggle_default_printer($out, $main_obj)
	{
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verification is handled by ajax_main in the parent class
		$api_key=(isset($_POST['api_key']) ? sanitize_text_field(wp_unslash($_POST['api_key'])) : '');		
		$out['status']=1;
		if(trim($api_key)=='')
		{
			$out['status']=0;
			$out['msg']=__('API key is missing', 'wt-woocommerce-invoice-addon');
		}

		if($out['status']==1)
		{
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verification is handled by ajax_main in the parent class
			$printer_id=(isset($_POST['printer_id']) ? sanitize_text_field(wp_unslash($_POST['printer_id'])) : '');
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verification is handled by ajax_main in the parent class
			$printer_name=(isset($_POST['printer_name']) ? sanitize_text_field(wp_unslash($_POST['printer_name'])) : '');
			if($printer_id!="")
			{
				$default_printer_id=$main_obj->get_default_printer();
				if($printer_id===$default_printer_id) /* current default printer ID equals the requested one then the action is remove */
				{
					$printer_id=0; /* reset the printer id */
					$printer_name='';
				}
				$main_obj->update_default_printer($printer_id);
				$main_obj->update_default_printer_name($printer_name);
				$out['default_printer_id']=$printer_id;
				$out['status']=1;
				$out['msg']=__("Success", 'wt-woocommerce-invoice-addon');

				$main_obj->update_api_credentails($api_key);
			}else
			{
				$out['status']=0;
				$out['msg']=__("Invalid Printer ID", 'wt-woocommerce-invoice-addon');
			}
		}
		return $out;
	}

	/**
	*	Process the response got from printer while adding a job
	*/
	private function process_printer_response($printer_response, $out, $main_obj)
	{
		return $main_obj->process_printer_response($printer_response, $out);
	}
}