<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://www.webtoffee.com/
 * @since      1.0.0
 *
 * @package    Wt_woocommerce_invoice_addon
 * @subpackage Wt_woocommerce_invoice_addon/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Wt_woocommerce_invoice_addon
 * @subpackage Wt_woocommerce_invoice_addon/includes
 * @author     WebToffee <info@webtoffee.com>
 */
class Wt_woocommerce_invoice_addon_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

		as_unschedule_all_actions( 'wt_pklist_invoice_addon_update_translation', array() );
		
		/**
		 * - Reset the invoice number option to "No".
		 * - Delete the schedule event of restart invoice number.
		 */
		$invoice_module_id = Wf_Woocommerce_Packing_List::get_module_id('invoice');
		Wf_Woocommerce_Packing_List::update_option( 'wt_pklist_invoice_number_reset', 'No', $invoice_module_id );
	}

}
