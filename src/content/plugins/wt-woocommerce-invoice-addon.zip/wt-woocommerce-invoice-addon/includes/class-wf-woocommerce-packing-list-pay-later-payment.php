<?php
/**
 * Pay Later Payment Gateway
 *
 * @link       
 * @since 1.0.0     
 *
 * @package  Wt_woocommerce_invoice_addon  
 */
if (!defined('ABSPATH')) {
    exit;
}
if((!class_exists('Wf_Woocommerce_Packing_List_Pay_Later_Payment')) && (class_exists('WC_Payment_Gateway')))
{
	class Wf_Woocommerce_Packing_List_Pay_Later_Payment extends WC_Payment_Gateway {
		
		private $plugin_name;
		private $version;
		public $instructions;
		private static $email_instructions_hook_added = false;

		public function __construct() {

			if( defined( 'WT_PKLIST_INVOICE_ADDON_VERSION' ) ) 
			{
				$this->version = WT_PKLIST_INVOICE_ADDON_VERSION;
			}else
			{
				$this->version = '1.7.5';
			}
			if(defined('WT_PKLIST_INVOICE_ADDON_PLUGIN_NAME'))
			{
				$this->plugin_name=WT_PKLIST_INVOICE_ADDON_PLUGIN_NAME;
			}else
			{
				$this->plugin_name='wt-woocommerce-invoice-addon';
			}

			$this->id = 'wf_pay_later';
			$this->icon               = apply_filters('woocommerce_offline_icon', '');
			$this->has_fields         = false;
			$this->method_title       = __( 'Pay Later', 'wt-woocommerce-invoice-addon' );
            $this->method_description = __( 'Allows a ‘Pay Later’ option at the checkout. Orders will be marked with the status ‘On hold’ on using this payment method.', 'wt-woocommerce-invoice-addon' );
			
			// Load the settings.
			$this->init_form_fields();
			$this->init_settings();

			// Define user set variables
			$this->title        = $this->get_option( 'title' );
			$this->description  = $this->get_option( 'description' );
			$this->instructions = $this->get_option( 'instructions', $this->description );

			// Actions
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
			add_action( 'init', array( $this, 'add_wf_pay_later_Instruction' ) );
			add_action( 'init', array( $this, 'add_wf_pay_later_email_instructions' ) );
		}

		/**
		 * Initialize Gateway Settings Form Fields
		 */
		public function init_form_fields() {
	  
			$this->form_fields = apply_filters( 'wf_pay_later_payment_form_fields', array(
		  
				'enabled' => array(
					'title'   => __( 'Enable/Disable', 'wt-woocommerce-invoice-addon' ),
					'type'    => 'checkbox',
					'label'   => __( 'Enable Pay Later Payment', 'wt-woocommerce-invoice-addon' ),
					'default' => 'no'
				),
				
				'title' => array(
					'title'       => __( 'Title', 'wt-woocommerce-invoice-addon' ),
					'type'        => 'text',
					'description' => __( 'This controls the title for the payment method the customer sees during checkout.', 'wt-woocommerce-invoice-addon' ),
					'default'     => __( 'Pay Later Payment', 'wt-woocommerce-invoice-addon' ),
					'desc_tip'    => true,
				),
				
				'description' => array(
					'title'       => __( 'Description', 'wt-woocommerce-invoice-addon' ),
					'type'        => 'textarea',
					'description' => __( 'Payment method description that the customer will see on your checkout.', 'wt-woocommerce-invoice-addon' ),
					'default'     => __( 'Please remit payment to Store Name upon pickup or delivery.', 'wt-woocommerce-invoice-addon' ),
					'desc_tip'    => true,
				),
				
				'instructions' => array(
					'title'       => __( 'Instructions', 'wt-woocommerce-invoice-addon' ),
					'type'        => 'textarea',
					'description' => __( 'Instructions that will be added to the thank you page and emails.', 'wt-woocommerce-invoice-addon' ),
					'default'     => '',
					'desc_tip'    => true,
				),
			) );
		}

		/**
		 * Fix added for version 1.6.3.
		 * Hooking into 'init' avoids duplication by ensuring the action is added only once after initialization.
		 */
		public function add_wf_pay_later_Instruction() {
			add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'thankyou_page' ) );
		}

		/**
		 * Fix added to prevent duplicate email instructions.
		 * Hooking into 'init' with a static flag avoids duplication by ensuring the action is added only once.
		 */
		public function add_wf_pay_later_email_instructions() {
			if ( ! self::$email_instructions_hook_added && ! has_action( 'woocommerce_email_before_order_table', array( $this, 'email_instructions' ) ) ) {
				add_action( 'woocommerce_email_before_order_table', array( $this, 'email_instructions' ), 10, 3 );
				self::$email_instructions_hook_added = true;
			}
		}

		/**
		 * Output for the order received page.
		 */
		public function thankyou_page() {
			if ( $this->instructions ) {
				echo wp_kses_post(wpautop( wptexturize( $this->instructions ) ));
			}
		}


		/**
		 * Add content to the WC emails.
		 *
		 * @access public
		 * @param WC_Order $order
		 * @param bool $sent_to_admin
		 * @param bool $plain_text
		 */
		public function email_instructions( $order, $sent_to_admin, $plain_text = false ) {
			$order_id = $order->get_id();
			$payment_method = $order->get_payment_method(); 
			if ( $this->instructions && ! $sent_to_admin && $this->id === $payment_method && $order->has_status( 'on-hold' ) ) {
				echo wp_kses_post(wpautop( wptexturize( $this->instructions ) )) . PHP_EOL;
			}
		}


		/**
		 * Process the payment and return the result
		 *
		 * @param int $order_id
		 * @return array
		 */
		public function process_payment( $order_id ) {

			$order = wc_get_order( $order_id );
			
			// Mark as on-hold (we're awaiting the payment)
            $order->update_status( 'on-hold', __( 'Pay later: ', 'wt-woocommerce-invoice-addon' ) );			
			
			// Remove cart
			WC()->cart->empty_cart();
			
			// Return thankyou redirect
			return array(
				'result' 	=> 'success',
				'redirect'	=> $this->get_return_url( $order )
			);
		}
	}
}
?>