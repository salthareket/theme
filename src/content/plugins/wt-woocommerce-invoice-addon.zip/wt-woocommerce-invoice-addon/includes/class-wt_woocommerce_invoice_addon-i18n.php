<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://www.webtoffee.com/
 * @since      1.0.0
 *
 * @package    Wt_woocommerce_invoice_addon
 * @subpackage Wt_woocommerce_invoice_addon/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Wt_woocommerce_invoice_addon
 * @subpackage Wt_woocommerce_invoice_addon/includes
 * @author     WebToffee <info@webtoffee.com>
 */
class Wt_woocommerce_invoice_addon_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		$text_domain	= 'wt-woocommerce-invoice-addon';
		$folder_name	= 'wt-woocommerce-invoice-addon';

		if ( function_exists( 'determine_locale' ) ) { // WP5.0+
			$locale = determine_locale();
		} else {
			$locale = is_admin() && function_exists( 'get_user_locale' ) ? get_user_locale() : get_locale();
		}
		
		$locale = apply_filters( 'plugin_locale', $locale, $text_domain );
		unload_textdomain( $text_domain );
		$dir    = trailingslashit( WP_LANG_DIR );

		/**
		 * Frontend/global Locale. Looks in:
		 *
		 * if text domain is wt-woocommerce-invoice-addon then
		 * 
		 * 		- WP_LANG_DIR/wt-woocommerce-invoice-addon/wt-woocommerce-invoice-addon-LOCALE.mo
		 * 	 	- WP_LANG_DIR/plugins/wt-woocommerce-invoice-addon/wt-woocommerce-invoice-addon-LOCALE.mo
		 * 		- WP_LANG_DIR/plugins/wt-woocommerce-invoice-addon-LOCALE.mo
		 * 		- WP_LANG_DIR/wt-woocommerce-invoice-addon-LOCALE.mo
		 *
		 * WP_LANG_DIR defaults to wp-content/languages
		 */
		
		$default_location 	= '/plugins/'.$folder_name.'/';
		$default_location	= get_option( 'wt_woocommerce_invoice_addon_language_location', $default_location );
		$default_location	= apply_filters( 'wt_pklist_alter_default_language_folder_location', $default_location, $locale, $text_domain );

		$default_mo_file	= $dir . $default_location . $text_domain . '-' . $locale . '.mo';
		load_textdomain( $text_domain, $default_mo_file ); // Custom mo file location
		
		// load mo files from the Wordpress language file locations
		load_textdomain( $text_domain, $dir . $folder_name . '/' . $text_domain .'-'. $locale .'.mo' ); 
		load_textdomain( $text_domain, $dir . 'plugins/' . $folder_name . '/' . $text_domain .'-'. $locale .'.mo' );
		load_textdomain( $text_domain, $dir . 'plugins/' . $text_domain .'-'. $locale .'.mo' );
		load_textdomain( $text_domain, $dir . $text_domain .'-'. $locale .'.mo' );
		
		// load mo files from default plugin location
		// phpcs:ignore PluginCheck.CodeAnalysis.DiscouragedFunctions.load_plugin_textdomainFound -- Kept for backward compatibility and non-WordPress.org hosted versions
		load_plugin_textdomain( $text_domain, false, dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/' );
	}
}
