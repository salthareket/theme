<?php
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'Wt_Pklist_Language_Switcher_IPC' ) ) {
	class Wt_Pklist_Language_Switcher_IPC {
		private static $instance = null;
		public $locale           = '';
		private $target_language_code = null; 
		
		public function __construct( ) {

			$this->locale      = $this->determine_locale();
			add_action( 'wt_pklist_language_switcher_for_invoice', array( $this, 'switch_document_language' ), 10, 3 );
			add_action( 'wt_pklist_language_switcher_for_packinglist', array( $this, 'switch_document_language' ), 10, 3 );
			add_action( 'wt_pklist_language_switcher_for_creditnote', array( $this, 'switch_document_language' ), 10, 3 );
			
			if ( defined('ICL_SITEPRESS_VERSION') && class_exists('WCML_Orders') ) {
				add_filter( 'wcml_get_order_items_language', array( $this, 'override_wcml_order_items_language' ), 10, 2 );
			}
		}

		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new Wt_Pklist_Language_Switcher_IPC();
			}
			return self::$instance;
		}

		public function switch_document_language( $lang, $template_type, $order_id ) {
			$this->locale = !empty( $lang ) ? $lang : get_locale();

			if ( defined('ICL_SITEPRESS_VERSION') ) {
				global $sitepress;
				
				$language_code = $this->locale;
				if ( $sitepress ) {
					$active_languages = $sitepress->get_active_languages();
					
					if ( strlen( $this->locale ) <= 3 && isset( $active_languages[ $this->locale ] ) ) {
						$language_code = $this->locale;
					} else {
						foreach ( $active_languages as $code => $language_data ) {
							if ( isset( $language_data['default_locale'] ) && $language_data['default_locale'] === $this->locale ) {
								$language_code = $code;
								break;
							}
						}
					}
					
					$this->target_language_code = $language_code;
					
					if ( isset( $active_languages[ $language_code ] ) ) {
						$sitepress->switch_lang( $language_code, false );
					}
				}
				
				if ( apply_filters('wt_pklist_switch_language_using_wpml_filter', true) ) {
					do_action( 'wpml_switch_language', $language_code );
				}
			}

			if( function_exists( 'switch_to_locale' ) ) {
				switch_to_locale( $this->locale );
			}

			if ( class_exists('\\Polylang') && function_exists( 'switch_to_locale' ) ) { // WP4.7+
				switch_to_locale( $this->locale );
			} else {
				add_filter( 'locale', array( $this, 'plugin_locale' ), 10, 2 );
				add_filter( 'plugin_locale', array( $this, 'plugin_locale' ), 10, 2 );
				add_filter( 'theme_locale', array( $this, 'plugin_locale' ), 10, 2 );
			}
		}

		
		public function basic_plugin_translation() {
			$locale = $this->locale;
			$dir    = trailingslashit( WP_LANG_DIR );

			$basic_text_domain = 'print-invoices-packing-slip-labels-for-woocommerce';
			unload_textdomain( $basic_text_domain );
			$basic_default_location = 'plugins/print-invoices-packing-slip-labels-for-woocommerce/';
			$basic_default_location	= get_option( 'print-invoices-packing-slip-labels-for-woocommerce_language_location', $basic_default_location );
			$basic_default_location	= apply_filters( 'wt_pklist_alter_default_language_folder_location', $basic_default_location, $locale, $basic_text_domain );
			
			$basic_default_mo_file	= $dir . $basic_default_location . $basic_text_domain . '-' . $locale . '.mo';
			$basic_translation_file_locations = array(
				$basic_default_mo_file,
				$dir . 'print-invoices-packing-slip-labels-for-woocommerce' . '/' . $basic_text_domain .'-'. $locale .'.mo',
				$dir . 'plugins/' . 'print-invoices-packing-slip-labels-for-woocommerce' . '/' . $basic_text_domain .'-'. $locale .'.mo',
				$dir . 'plugins/' . $basic_text_domain .'-'. $locale .'.mo',
				$dir . $basic_text_domain .'-'. $locale .'.mo'
			);
			$basic_valid_translation_file = '';
			foreach( $basic_translation_file_locations as $mo_file ) {
				if ( file_exists( $mo_file )) {
					$basic_valid_translation_file = $mo_file;
					break;
				}
			}

			if ( !empty( $basic_valid_translation_file ) ) {
				load_textdomain( $basic_text_domain, $basic_valid_translation_file );
			} else {
				// @codingStandardsIgnoreLine PluginCheck.CodeAnalysis.DiscouragedFunctions.load_plugin_textdomainFound -- Required for custom translation loading
				load_plugin_textdomain( $basic_text_domain, false, 'print-invoices-packing-slip-labels-for-woocommerce/languages' );
			}
		}

		public function invoice_plugin_translation( $locale = '' ) {
			if ( empty( $locale ) ) {
				$locale = !empty($this->locale) ? $this->locale : $this->determine_locale();
			}
			
			$dir    = trailingslashit( WP_LANG_DIR );

			// invoice add-on translation
			$ipc_text_domain = 'wt-woocommerce-invoice-addon';
			unload_textdomain( $ipc_text_domain );
			$ipc_default_location = 'plugins/wt-woocommerce-invoice-addon/';
			$ipc_default_location	= get_option( 'wt_woocommerce_invoice_addon_language_location', $ipc_default_location );
			$ipc_default_location	= apply_filters( 'wt_pklist_alter_default_language_folder_location', $ipc_default_location, $locale, $ipc_text_domain );
			
			$ipc_default_mo_file	= $dir . $ipc_default_location . $ipc_text_domain . '-' . $locale . '.mo';

			/**
			 * Filter to customize the file name.
			 * @since 1.6.4
			 */
			$ipc_default_mo_file = apply_filters('wt_pklist_alter_language_file_name', $ipc_default_mo_file, $dir, $ipc_default_location, $ipc_text_domain, $locale, 10, 5);

			$ipc_translation_file_locations = array(
				$ipc_default_mo_file,
				$dir . 'wt-woocommerce-invoice-addon' . '/' . $ipc_text_domain .'-'. $locale .'.mo',
				$dir . 'plugins/' . 'wt-woocommerce-invoice-addon' . '/' . $ipc_text_domain .'-'. $locale .'.mo',
				$dir . 'plugins/' . $ipc_text_domain .'-'. $locale .'.mo',
				$dir . $ipc_text_domain .'-'. $locale .'.mo'
			);
			$valid_translation_file = '';
			foreach( $ipc_translation_file_locations as $mo_file ) {
				if ( file_exists( $mo_file )) {
					$valid_translation_file = $mo_file;
					break;
				}
			}

			if ( !empty( $valid_translation_file ) ) {
				load_textdomain( $ipc_text_domain, $valid_translation_file );
			} else {
				// @codingStandardsIgnoreLine PluginCheck.CodeAnalysis.DiscouragedFunctions.load_plugin_textdomainFound -- Required for custom translation loading
				load_plugin_textdomain( $ipc_text_domain, false, 'wt-woocommerce-invoice-addon/languages' );
			}
		}

		public function plugin_locale( $locale, $domain = '' ) {
			$locale = $this->locale;
			return $locale;
		}

		public function determine_locale() {
			if ( function_exists( 'determine_locale' ) ) { // WP5.0+
				$locale = determine_locale();
			} else {
				$locale = is_admin() && function_exists( 'get_user_locale' ) ? get_user_locale() : get_locale();
			}

			return apply_filters( 'plugin_locale', $locale, 'wt-woocommerce-invoice-addon' );
		}

		/**
		 * Override WCML's order items language detection when generating documents
		 * This ensures product names are translated to the customer language, not admin language
		 * 
		 * @param string|false|null $language The language WCML detected
		 * @param \WC_Order $order The order object
		 * @return string|false|null The target language code
		 */
		public function override_wcml_order_items_language( $language, $order ) {
			// Only override if we have a target language set (meaning we're generating a document)
			// This happens when switch_document_language was called
			if ( ! empty( $this->target_language_code ) ) {
				if ( defined('ICL_SITEPRESS_VERSION') ) {
					global $sitepress;
					if ( $sitepress ) {
						$current_lang = $sitepress->get_current_language();
						// If WPML language was switched to our target, we're generating a document
						// Override WCML's detection to use the switched language instead of admin language
						if ( $current_lang === $this->target_language_code ) {
							return $this->target_language_code;
						}
					}
				}
			}
			
			// Otherwise, let WCML use its default detection
			return $language;
		}
	}
    new Wt_Pklist_Language_Switcher_IPC();
}
