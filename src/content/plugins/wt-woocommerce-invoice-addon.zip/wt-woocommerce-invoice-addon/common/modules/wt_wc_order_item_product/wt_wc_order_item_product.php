<?php
if (! defined('WPINC')) {
    die;
}

if (!class_exists('WT_WC_Order_Item_Product_IPC') && class_exists('WC_Order_Item_Product')) {
    class WT_WC_Order_Item_Product_IPC extends WC_Order_Item_Product
    {
        public $this_refund_item_id;

        public function __construct($item = 0)
        {
            if (!$item || !wc_get_order_item_meta($item, '_product_id', true)) {
                return; // Prevent fatal error by skipping invalid items
            }
            parent::__construct($item);
        }
    }
}