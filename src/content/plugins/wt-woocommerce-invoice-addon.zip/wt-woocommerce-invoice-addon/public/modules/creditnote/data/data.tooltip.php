<?php
if (!defined('ABSPATH')) {
    exit;
}
$arr=array(
	'woocommerce_wf_packinglist_variation_data' => __('Enable to include variation data in the product table of the creditnote.','wt-woocommerce-invoice-addon'),
	'woocommerce_wf_invoice_as_ordernumber' => __('By enabling this option, the WooCommerce order number can be mirrored as the credit note number or a custom credit note number can be specified by choosing Custom number series. Then set the Credit note start number option.','wt-woocommerce-invoice-addon'),
	'woocommerce_wf_invoice_start_number' => __('Allows to set the credit note number start number as other than 1. Click on reset button to revert to the default start number.','wt-woocommerce-invoice-addon'),
	'wf_creditnote_contactno_email'=>__('Include custom order meta by clicking on the Add/ Edit order meta field. Key in the field name and meta key to include an order meta. Previously added tab lists the order meta fields added in the past.','wt-woocommerce-invoice-addon'),
	'wf_creditnote_product_meta_fields'=>__('Include custom product meta by clicking on the Add/ Edit product meta field. Key in the field name and meta key to include a product meta. Previously added tab lists the product meta fields added in the past.','wt-woocommerce-invoice-addon'),
	'wt_creditnote_product_attribute_fields'=>__('Include custom product attributes by clicking on the Add/ Edit product attribute field. Key in the field name and meta key to include a product attribute. Previously added tab lists the product attributes added in the past.','wt-woocommerce-invoice-addon'),
	'wt_pklist_document_language' => __('Choose the language for credit note generation','wt-woocommerce-invoice-addon'),
);