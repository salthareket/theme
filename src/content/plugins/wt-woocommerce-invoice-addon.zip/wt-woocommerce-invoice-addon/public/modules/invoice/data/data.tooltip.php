<?php
if (!defined('ABSPATH')) {
    exit;
}
$arr = (isset($arr) && is_array($arr)) ? $arr : array();
$new_arr=array(
	"woocommerce_wf_enable_payment_link_in_invoice" => __('Adds a payment link besides the payment method in the invoice. Ensure to choose a template from the ‘Customize’ tab that supports the payment link.','wt-woocommerce-invoice-addon'),
	"sort_products_by" => __('Sort products in ascending/descending order based on Name or SKU','wt-woocommerce-invoice-addon'),
	'wf_'.$this->module_base.'_contactno_email' => __('Include custom order meta by clicking on the Add/ Edit order meta field. Key in the field name and meta key to include an order meta. Previously added tab lists the order meta fields added in the past.','wt-woocommerce-invoice-addon'),
	'wf_'.$this->module_base.'_product_meta_fields' => __('Include custom product meta by clicking on the Add/ Edit product meta field. Key in the field name and meta key to include a product meta. Previously added tab lists the product meta fields added in the past.','wt-woocommerce-invoice-addon'),
	'wt_'.$this->module_base.'_product_attribute_fields' => __('Include custom product attributes by clicking on the Add/ Edit product attributes field. Key in the field name and meta key to include a product attribute. Previously added tab lists the product attributes added in the past.','wt-woocommerce-invoice-addon'),
	"woocommerce_wf_packinglist_logo" => __('Overrides the common logo set in the General settings and allows inserting a unique logo in the invoice.','wt-woocommerce-invoice-addon'),
	"woocommerce_wf_packinglist_footer" => __('Overrides the common footer content specified in the General settings and allows inserting content that is specific only to invoices.','wt-woocommerce-invoice-addon'),
	'wt_pklist_document_language' => __('Choose the language for invoice generation','wt-woocommerce-invoice-addon'),
	'wt_pklist_invoice_number_reset' => __('Add any date format that includes \'year\' ( i.e, the placeholder [Y] ) in your \'prefix/suffix\' to prevent invoice number duplication','wt-woocommerce-invoice-addon'),
	/* translators: %1$s and %2$s are opening and closing bold tags for "Woocommerce Product Bundles", %3$s and %4$s are opening and closing bold tags for "YITH WooCommerce Product Bundle add-on", %5$s and %6$s are opening and closing bold tags for "Group by Category" */
	'bundled_product_display_option' => sprintf(__('Choose how to display bundled products in the invoice. Applicable only if you are using %1$s Woocommerce Product Bundles %2$s / %3$s YITH WooCommerce Product Bundle add-on %4$s. It may not work along with %5$sGroup by Category%6$s option.', 'wt-woocommerce-invoice-addon'), '<b>', '</b>', '<b>', '</b>', '<b>', '</b>'),

);
$arr = array_merge($new_arr,$arr);