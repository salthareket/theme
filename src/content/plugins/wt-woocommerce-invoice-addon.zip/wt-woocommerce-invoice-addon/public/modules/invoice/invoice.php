<?php

/**
 * Invoice Pro section of the plugin
 *
 * @link       
 * @since 1.0.0     
 *
 * @package  Wt_woocommerce_invoice_addon  
 */
if (!defined('ABSPATH')) {
    exit;
}

class Wf_Woocommerce_Packing_List_Invoice_Pro
{
    public $module_id = '';
    public static $module_id_static = '';
    public $module_base = 'invoice';
    public static $module_base_static = 'invoice';
    public $is_enable_invoice;
    public $customizer = null;
    public $parent_class = '';
    public $pay_later_title='';

    public function __construct()
    {
        $this->module_id = Wf_Woocommerce_Packing_List::get_module_id($this->module_base);
        self::$module_id_static = $this->module_id;
        self::$module_base_static = $this->module_base;
        add_filter('wt_pklist_add_additional_tab_item_into_module', array($this, 'add_additional_tab'), 10, 3);
        add_action('wt_pklist_add_additional_tab_content_into_module', array($this, 'add_additional_tab_content'), 10, 2);
        add_filter('wt_pklist_add_fields_to_settings', array($this, 'add_remove_fields_from_settings'), 10, 4);
        add_filter('wf_module_default_settings', array($this, 'default_settings'), 11, 2);
        add_filter('wf_module_single_checkbox_fields', array($this, 'single_checkbox_fields'), 11, 3);
        add_filter('wf_module_multi_checkbox_fields', array($this, 'multi_checkbox_fields'), 10, 3);
        add_filter('wt_pklist_intl_alter_validation_rule', array($this, 'alter_validation_rule'), 10, 2);

        add_filter('wt_pklist_add_pro_templates', array($this, 'add_pro_template'), 10, 2);
        add_filter('wf_module_customizable_items', array($this, 'get_customizable_items'), 10, 2);
        add_filter('wf_pklist_alter_customize_inputs', array($this, 'alter_customize_inputs'), 10, 3);
        add_filter('wf_module_non_options_fields', array($this, 'get_non_options_fields'), 10, 2);

        add_filter('wf_module_convert_to_design_view_html_for_' . $this->module_base, array($this, 'convert_to_design_view_html'), 10, 3);
        add_filter('wf_module_generate_template_html_for_' . $this->module_base, array($this, 'generate_template_html'), 10, 6);

        add_filter('wt_pklist_pro_customizer_' . $this->module_base, array($this, 'switch_to_pro_customizer'), 10, 2);
        add_filter('wt_pklist_enable_code_editor', array($this, 'enable_code_editor_customizer'), 10, 2);

        add_action('wt_run_payment_link_module', array($this, 'run_payment_link_module'), 10, 2);
        add_action('wf_pklist_intl_after_setting_update', array($this, 'after_setting_update'), 10, 2);

        $this->is_enable_invoice = Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_enable_invoice', $this->module_id);
        if ("Yes" === $this->is_enable_invoice) /* `print_it` method also have the same checking */ {
            // show document details
            add_filter('wt_print_docdata_metabox', array($this, 'add_docdata_metabox_pro'), 10, 3);
            add_filter('wt_print_actions', array($this, 'add_print_buttons'), 10, 4);
        }

        add_filter('wt_pklist_alter_tooltip_data_' . $this->module_base, array($this, 'register_tooltips'), 10, 2);
        add_filter('wt_pklist_bundled_product_css_' . $this->module_base, array($this, 'bundled_prod_css'), 10, 3);

        /**
         * @since 1.0.1 Add to remote printing
         */
        add_filter('wt_pklist_add_to_remote_printing', array($this, 'add_to_remote_printing'), 10, 2);

        /**
         * @since 1.0.1 Do remote printing
         */
        add_filter('wt_pklist_do_remote_printing', array($this, 'do_remote_printing'), 10, 2);

        add_filter('wt_pklist_check_prompt_' . $this->module_base, array($this, 'check_prompt_for_print_node_btn'), 10, 3);
        add_filter('wt_pklist_alter_document_language_for_' . $this->module_base, array($this, 'alter_document_language'), 10, 3);

        add_action('wt_pklist_restart_invoice_number_event', array($this, 'restart_invoice_no_event'));
        add_filter('wt_pklist_add_full_length_elements_in_settings', array($this, 'add_full_length_elements_in_settings'), 10, 2);
        add_filter('wt_pklist_export_bulk_report_pdfs_invoice', array($this, 'bulk_export_pdf'), 10, 3);
    }

    /**
     *   @since 1.0.1
     *   Add to remote printing, this will enable remote printing settings
     */
    public function add_to_remote_printing($arr, $remote_print_vendor)
    {
        $arr[$this->module_base] = __('Invoice', 'wt-woocommerce-invoice-addon');
        return $arr;
    }

    /**
     *   @since 1.0.1
     *   Do remote printing.
     */
    public function do_remote_printing($module_base_arr, $order_id)
    {
        $this_pro = new Wf_Woocommerce_Packing_List_Invoice();
        return Wt_woocommerce_invoice_addon_Admin::do_remote_printing($module_base_arr, $order_id, $this_pro);
    }

    public function check_prompt_for_print_node_btn($is_show_prompt, $order, $template_type)
    {
        if ($this->module_base === $template_type) {
            $is_show_prompt = 1;
            $order_id       = $order->get_id(); 
            $order_status   = $order->get_status();
            $invoice_number = Wf_Woocommerce_Packing_List_Invoice::generate_invoice_number($order, false);
            $generate_invoice_for   = Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_generate_for_orderstatus', $this->module_id);
            $free_order_enable      = Wf_Woocommerce_Packing_List::get_option('wf_woocommerce_invoice_free_orders', $this->module_id);

            if (in_array('wc-' . $order_status, $generate_invoice_for) || !empty($invoice_number)) {
                $is_show_prompt = 0;
            } else {
                if (empty($invoice_number)) {
                    $is_show_prompt = 1;
                }
            }

            if (empty($invoice_number)) {
                if ("No" === $free_order_enable) {
                    if (0 === \intval($order->get_total())) {
                        $is_show_prompt = 2;
                    }
                }
            }
        }
        return $is_show_prompt;
    }

    public function register_tooltips($arr, $template_type)
    {
        if ($template_type === $this->module_base) {
            include(plugin_dir_path(__FILE__) . 'data/data.tooltip.php');
        }
        return $arr;
    }

    public function add_print_buttons($item_arr, $order, $order_id, $button_location)
    {
        if ("detail_page" === $button_location && isset($item_arr['invoice_details_actions'])) {
            $item_arr = apply_filters('wt_pklist_after_' . $this->module_base . '_print_button_list', $item_arr, $order, $button_location, $this->module_base);
        }
        return $item_arr;
    }

    public function add_docdata_metabox_pro($data_arr, $order, $order_id)
    {

        $invoice_number = Wf_Woocommerce_Packing_List_Invoice::generate_invoice_number($order, false);
        if ("" !== $invoice_number) {
            $invoice_date = Wt_woocommerce_invoice_addon_Admin::get_sequential_date($order_id, 'wf_invoice_date', get_option('date_format'), $order);
            $data_arr['wf_meta_box_invoice_date'] = array(
                'label' => __('Invoice Date', 'wt-woocommerce-invoice-addon'),
                'value' => $invoice_date,
            );
        }
        return $data_arr;
    }

    public function switch_to_pro_customizer($enabled, $template_type)
    {
        if ($template_type === $this->module_base) {
            return true;
        } else {
            return false;
        }
    }

    public function enable_code_editor_customizer($enabled, $template_type)
    {
        if ($template_type === $this->module_base) {
            return true;
        }
        return $enabled;
    }

    public function add_additional_tab($tab_items, $template_type, $base_id)
    {
        if ($base_id === $this->module_id) {
            $new_element = array('advanced' => __('Advanced', 'wt-woocommerce-invoice-addon'));
            $tab_items = Wt_woocommerce_invoice_addon_Admin::wt_add_array_element_to_position($tab_items, $new_element, 'general');
        }
        return $tab_items;
    }

    public function add_additional_tab_content($template_type, $base_id)
    {

        if ($base_id === $this->module_id) {
            if (class_exists('Wf_Woocommerce_Packing_List_Pro_Common_Func')) {
                wp_enqueue_script($this->module_id . '_seq_pro', WT_PKLIST_INVOICE_ADDON_PLUGIN_URL . 'includes/js/sequential_number.js', array('jquery'), WT_PKLIST_INVOICE_ADDON_VERSION, true);
                include plugin_dir_path(WT_PKLIST_INVOICE_ADDON_FILENAME) . "includes/views/sequential_number_date_popup_pro.php";
            }
            $target_id = "advanced";
            $view_file = plugin_dir_path(__FILE__) . 'views/advanced.php';
            include $view_file;
        }
    }

    /**
     * Add the fields for invoice settings page
     *
     * @since 1.1.0 - Added an option to set the document language
     * @param array $settings
     * @param string $target_id
     * @param string $template_type
     * @param string $base_id
     * @return array
     */
    public function add_remove_fields_from_settings($settings, $target_id, $template_type, $base_id)
    {

        if ($base_id === $this->module_id) {

            // remove the free line option from other section (Basic version)
            if ("general" === $target_id) {

                if (isset($settings['invoice_general_others']['wf_woocommerce_invoice_free_line_items'])) {
                    unset($settings['invoice_general_others']['wf_woocommerce_invoice_free_line_items']);
                }
                if (isset($settings['invoice_general_invoice_details'])) {
                    unset($settings['invoice_general_invoice_details']);
                }

                if (isset($settings['invoice_general_general'])) {
                    $document_language = array(
                        // 'wt_pklist_document_language' => array(
                        //     'type' => 'multi_language_option',
                        //     'label' => __("Generate invoice in", "wt-woocommerce-invoice-addon"),
                        //     'id' => '',
                        //     'class' => 'wt_pklist_document_language',
                        //     'name' => 'wt_pklist_document_language',
                        //     'value' => '',
                        //     'radio_fields' => array(
                        //         'site' => __('Site language', 'wt-woocommerce-invoice-addon'),
                        //         'customer' => __('Customer language', 'wt-woocommerce-invoice-addon')
                        //     ),
                        //     'radio_fields_help_text' => array(
                        //         'site' => __("In multilingual sites, invoice language may differ from the default one set in WordPress Settings > General > Site Language, depending on customer`s  choice via the site`s language switcher.", "wt-woocommerce-invoice-addon"),
                        //         'customer' => __("To generate a invoice in the customer`s language, ensure that the plugin has the corresponding language file for the selected language. If not, add it to use the functionality.", "wt-woocommerce-invoice-addon")
                        //     ),
                        //     'col' => 3,
                        //     'tooltip' => true,
                        //     'alignment' => 'vertical_with_label',
                        //     'ref_id' => 'wt_pklist_document_language',
                        // )
                      
                      
                        'wt_pklist_document_language' => array(
                            'type' => 'wt_radio',
                            'label' => __('Generate invoice in', 'wt-woocommerce-invoice-addon'),
                            'id' => 'wt_pklist_document_language',
                            'class' => 'wt_pklist_document_language woocommerce_wf_custom_radio_style',
                            'name' => 'wt_pklist_document_language',
                            'value' => '', 
                            'radio_fields' => array(
                                'site' => __('Site language', 'wt-woocommerce-invoice-addon'),
                                'customer' => __('Customer language', 'wt-woocommerce-invoice-addon')
                            ),
                            'col' => 3,
                            'tooltip' => true,
                            'alignment' => 'vertical_with_label',
                            'ref_id' => 'wt_pklist_document_language',
                        )

                    );
                    $settings['invoice_general_general'] = Wt_woocommerce_invoice_addon_Admin::wt_add_array_element_to_position($settings['invoice_general_general'], $document_language, 'wf_woocommerce_invoice_show_print_button');
                }

                if (isset($settings['invoice_general_invoice_number']) && version_compare(Wf_Woocommerce_Packing_List::$base_version, '4.5.0') >= 0) {
                    // Check and update the database value if needed
                    $current_reset_value = Wf_Woocommerce_Packing_List::get_option('wt_pklist_invoice_number_reset', $this->module_id);
                    if ($current_reset_value === 'Yes') {
                        Wf_Woocommerce_Packing_List::update_option('wt_pklist_invoice_number_reset', 'january', $this->module_id);
                    }
                    
                    $reset_invoice_no_option    = array(
                        'wt_pklist_invoice_number_reset' => array(
                            'type'              => 'wt_select_dropdown',
                            'label'             => __("Auto reset invoice numbers annually", 'wt-woocommerce-invoice-addon'),
                            'name'              => "wt_pklist_invoice_number_reset",
                            'value'             => 'No',
                            'select_dropdown_fields' => array(
                                'No' => __('None', 'wt-woocommerce-invoice-addon'),
                                'january' => __('January', 'wt-woocommerce-invoice-addon'),
                                'february' => __('February', 'wt-woocommerce-invoice-addon'),
                                'march' => __('March', 'wt-woocommerce-invoice-addon'),
                                'april' => __('April', 'wt-woocommerce-invoice-addon'),
                                'may' => __('May', 'wt-woocommerce-invoice-addon'),
                                'june' => __('June', 'wt-woocommerce-invoice-addon'),
                                'july' => __('July', 'wt-woocommerce-invoice-addon'),
                                'august' => __('August', 'wt-woocommerce-invoice-addon'),
                                'september' => __('September', 'wt-woocommerce-invoice-addon'),
                                'october' => __('October', 'wt-woocommerce-invoice-addon'),
                                'november' => __('November', 'wt-woocommerce-invoice-addon'),
                                'december' => __('December', 'wt-woocommerce-invoice-addon')
                            ),
                            'class'             => 'wt_pklist_invoice_number_reset',
                            'id'                => 'wt_pklist_invoice_number_reset',
                            'help_text' => __('The invoice number will be reset on the first day of selected month.','wt-woocommerce-invoice-addon'),
                            'tooltip' => true,
                        ),
                        'wt_restart_invoice_number_confirm_popup' => array(
                            'type'              => 'wt_restart_invoice_number_confirm_popup',
                        )
                    );
                    $settings['invoice_general_invoice_number'] = Wt_woocommerce_invoice_addon_Admin::wt_add_array_element_to_position($settings['invoice_general_invoice_number'], $reset_invoice_no_option, 'invoice_number_format');
                }
            }

            $payment_link_default_order_statuses = array(
                'wc-pending'    => _x('Pending payment', 'Order status', 'wt-woocommerce-invoice-addon'),
                'wc-on-hold'    => _x('On hold', 'Order status', 'wt-woocommerce-invoice-addon'),
                'wc-failed'     => _x('Failed', 'Order status', 'wt-woocommerce-invoice-addon'),
            );

            // add the product display section after the general section in the invoice settings page
            $product_display_section = array(
                'invoice_general_product_display' => array(

                    'wt_sub_head_inv_gen_prod_display' => array(
                        'type'  =>  'wt_sub_head',
                        'class' =>  'wt_pklist_field_group_hd_sub',
                        'heading_number' => 2,
                        'label' =>  __('Product display', 'wt-woocommerce-invoice-addon'),
                    ),

                    'wf_woocommerce_product_category_wise_splitting' => array(
                        'type'  => 'wt_single_checkbox',
                        'label' => __('Group products by \'Category\'', 'wt-woocommerce-invoice-addon'),
                        'name'  => "wf_woocommerce_product_category_wise_splitting",
                        'value' => 'Yes',
                        'checkbox_fields' => array('Yes' => __('Enable to group products by category in the invoice', 'wt-woocommerce-invoice-addon')),
                        'class' => 'wf_woocommerce_product_category_wise_splitting',
                        'id'    => 'wf_woocommerce_product_category_wise_splitting',
                    ),

                    'sort_products_by' => array(
                        'type'  => 'wt_select_dropdown',
                        'label' => __('Sort products by', 'wt-woocommerce-invoice-addon'),
                        'name'  => "sort_products_by",
                        'select_dropdown_fields' => array(
                            ''          => __('None', 'wt-woocommerce-invoice-addon'),
                            'name_asc'  => __('Name ascending', 'wt-woocommerce-invoice-addon'),
                            'name_desc' => __('Name descending', 'wt-woocommerce-invoice-addon'),
                            'sku_asc'   => __('SKU ascending', 'wt-woocommerce-invoice-addon'),
                            'sku_desc'  => __('SKU descending', 'wt-woocommerce-invoice-addon'),
                            'name_desc' => __('Name descending', 'wt-woocommerce-invoice-addon'),
                            'sku_asc'   => __('SKU ascending', 'wt-woocommerce-invoice-addon'),
                            'sku_desc'  => __('SKU descending', 'wt-woocommerce-invoice-addon'),
                        ),
                        'class'     => 'sort_products_by',
                        'id'        => 'sort_products_by',
                        'tooltip'   => true,
                    ),

                    'woocommerce_wf_packinglist_variation_data' => array(
                        'type'      => 'wt_single_checkbox',
                        'label'     => __('Show variation data below each product', 'wt-woocommerce-invoice-addon'),
                        'name'      => "woocommerce_wf_packinglist_variation_data",
                        'value'     => 'Yes',
                        'checkbox_fields' => array('Yes' => __('Enable to include of product variation data in the product table', 'wt-woocommerce-invoice-addon')),
                        'class'     => 'woocommerce_wf_packinglist_variation_data',
                        'id'        => 'woocommerce_wf_packinglist_variation_data',
                    ),

                    // 'bundled_product_display_option' => array(
                    //     'id'        => 'bundled_product_display_option',
                    //     'class'     => 'bundled_product_display_option',
                    //     'tooltip'   => true,
                    //     'type'      => "wt_select_dropdown",
                    //     'label'     => __("Bundled product display options", 'wt-woocommerce-invoice-addon'),
                    //     'name'      => "bundled_product_display_option",
                    //     'help_text' => sprintf(__('Choose how to display bundled products in the invoice. Applicable only if you are using %s Woocommerce Product Bundles %s / %s YITH WooCommerce Product Bundle add-on %s. It may not work along with %sGroup by Category%s option.', 'wt-woocommerce-invoice-addon'), '<b>', '</b>', '<b>', '</b>', '<b>', '</b>'),
                    //     'select_dropdown_fields' => array(
                    //         'main-sub'  => __('Main product with bundle items', 'wt-woocommerce-invoice-addon'),
                    //         'main'      => __('Main product only', 'wt-woocommerce-invoice-addon'),
                    //         'sub'       => __('Bundle items only', 'wt-woocommerce-invoice-addon'),
                    //     ),
                    //     'help_text_conditional' => array(
                    //         array(
                    //             'help_text' => '<img src="' . WT_PKLIST_INVOICE_ADDON_PLUGIN_URL . 'assets/images/bundle-both-items.png"/>',
                    //             'condition' => array(
                    //                 array('field' => 'bundled_product_display_option', 'value' => 'main-sub')
                    //             )
                    //         ),
                    //         array(
                    //             'help_text' => '<img src="' . WT_PKLIST_INVOICE_ADDON_PLUGIN_URL . 'assets/images/bundle-parent-only.png"/>',
                    //             'condition' => array(
                    //                 array('field' => 'bundled_product_display_option', 'value' => 'main')
                    //             )
                    //         ),
                    //         array(
                    //             'help_text' => '<img src="' . WT_PKLIST_INVOICE_ADDON_PLUGIN_URL . 'assets/images/bundle-child-only.png"/>',
                    //             'condition' => array(
                    //                 array('field' => 'bundled_product_display_option', 'value' => 'sub')
                    //             )
                    //         ),
                    //     ),
                    // ),




                    // 'bundled_product_display_option' => array(
                    //     'id'        => 'bundled_product_display_option',
                    //     'class'     => 'bundled_product_display_option',
                    //     'tooltip'   => true,
                    //     'type'      => "wt_radio",
                    //     'label'     => __("Bundled product display options", 'wt-woocommerce-invoice-addon'),
                    //     'name'      => "bundled_product_display_option",
                    //     // 'help_text' => sprintf(__('Choose how to display bundled products in the invoice. Applicable only if you are using %s Woocommerce Product Bundles %s / %s YITH WooCommerce Product Bundle add-on %s. It may not work along with %sGroup by Category%s option.', 'wt-woocommerce-invoice-addon'), '<b>', '</b>', '<b>', '</b>', '<b>', '</b>'),
                    //     'tooltip' => true,
                    //     'radio_fields' => array(
                    //         'main-sub'  => __('Main product with bundle items', 'wt-woocommerce-invoice-addon'),
                    //         'main'      => __('Main product only', 'wt-woocommerce-invoice-addon'),
                    //         'sub'       => __('Bundle items only', 'wt-woocommerce-invoice-addon'),
                    //     ),
                    //     'help_text_conditional' => array(
                    //         array(
                    //             'help_text' => '<img src="' . WT_PKLIST_INVOICE_ADDON_PLUGIN_URL . 'assets/images/bundle-both-items.png"/>',
                    //             'condition' => array(
                    //                 array('field' => 'bundled_product_display_option', 'value' => 'main-sub')
                    //             )
                    //         ),
                    //         array(
                    //             'help_text' => '<img src="' . WT_PKLIST_INVOICE_ADDON_PLUGIN_URL . 'assets/images/bundle-parent-only.png"/>',
                    //             'condition' => array(
                    //                 array('field' => 'bundled_product_display_option', 'value' => 'main')
                    //             )
                    //         ),
                    //         array(
                    //             'help_text' => '<img src="' . WT_PKLIST_INVOICE_ADDON_PLUGIN_URL . 'assets/images/bundle-child-only.png"/>',
                    //             'condition' => array(
                    //                 array('field' => 'bundled_product_display_option', 'value' => 'sub')
                    //             )
                    //         ),
                    //     ),
                    // ),



                    'bundled_product_display_option' => array(
                        'id'        => 'bundled_product_display_option',
                        'class'     => 'bundled_product_display_option woocommerce_wf_custom_radio_style',
                        'tooltip'   => true,
                        'type'      => "wt_radio",
                        'label'     => __('Bundled product display options', 'wt-woocommerce-invoice-addon'),
                        'name'      => "bundled_product_display_option",
                        // 'help_text' => sprintf(__('Choose how to display bundled products in the invoice. Applicable only if you are using %s Woocommerce Product Bundles %s / %s YITH WooCommerce Product Bundle add-on %s. It may not work along with %sGroup by Category%s option.', 'wt-woocommerce-invoice-addon'), '<b>', '</b>', '<b>', '</b>', '<b>', '</b>'),
                        'tooltip' => true,
                        'radio_fields' => array(
                            'main-sub'  => __('Main product with bundle items', 'wt-woocommerce-invoice-addon'),
                            'main'      => __('Main product only', 'wt-woocommerce-invoice-addon'),
                            'sub'       => __('Bundle items only', 'wt-woocommerce-invoice-addon'),
                        ),


                        'tooltips' => array(
                            'main-sub' => '<img src="' . WT_PKLIST_INVOICE_ADDON_PLUGIN_URL . 'assets/images/bundle-both-items.png" alt="Tooltip Image" style="width:100%; height:100%;">',
                            'main'     => '<img src="' . WT_PKLIST_INVOICE_ADDON_PLUGIN_URL . 'assets/images/bundle-parent-only.png" alt="Tooltip Image" style="width:100%; height:100%;">',
                            'sub'      => '<img src="' . WT_PKLIST_INVOICE_ADDON_PLUGIN_URL . 'assets/images/bundle-child-only.png" alt="Tooltip Image" style="width:100%; height:100%;">',
                        ),
                        // 'help_text_conditional' => array(
                        //     array(
                        //         'help_text' => '<img src="' . WT_PKLIST_INVOICE_ADDON_PLUGIN_URL . 'assets/images/bundle-both-items.png"/>',
                        //         'condition' => array(
                        //             array('field' => 'bundled_product_display_option', 'value' => 'main-sub')
                        //         )
                        //     ),
                        //     array(
                        //         'help_text' => '<img src="' . WT_PKLIST_INVOICE_ADDON_PLUGIN_URL . 'assets/images/bundle-parent-only.png"/>',
                        //         'condition' => array(
                        //             array('field' => 'bundled_product_display_option', 'value' => 'main')
                        //         )
                        //     ),
                        //     array(
                        //         'help_text' => '<img src="' . WT_PKLIST_INVOICE_ADDON_PLUGIN_URL . 'assets/images/bundle-child-only.png"/>',
                        //         'condition' => array(
                        //             array('field' => 'bundled_product_display_option', 'value' => 'sub')
                        //         )
                        //     ),
                        // ),
                    ),








                    'wf_woocommerce_invoice_free_line_items' => array(
                        'type'      => 'wt_single_checkbox',
                        'label'     => __('Display free line items in the invoice', 'wt-woocommerce-invoice-addon'),
                        'id'        => 'wf_woocommerce_invoice_free_line_items',
                        'name'      => 'wf_woocommerce_invoice_free_line_items',
                        'value'     => "Yes",
                        'checkbox_fields' => array('Yes' => __('Include free(priced as 0) line items in the invoice', 'wt-woocommerce-invoice-addon')),
                        'class'     => "wf_woocommerce_invoice_free_line_items",
                        'col'       => 3,
                    ),

                    'wt_inv_gen_hr_line' => array(
                        'type'  => 'wt_hr_line',
                        'class' => 'wf_field_hr'
                    )
                )
            );

            $payment_link_section = array(
                'invoice_general_payment_link' => array(
                    'wt_sub_head_inv_gen_payment_link' => array(
                        'type'  =>  'wt_sub_head',
                        'class' =>  'wt_pklist_field_group_hd_sub',
                        'heading_number' => 2,
                        'label' =>  __("Payment link", 'wt-woocommerce-invoice-addon'),
                    ),
                    'woocommerce_wf_enable_payment_link_in_invoice' => array(
                        'type'  => 'wt_single_checkbox',
                        'label' => __('Show payment link on invoice', 'wt-woocommerce-invoice-addon'),
                        'id'    => 'woocommerce_wf_enable_payment_link_in_invoice',
                        'name'  => 'woocommerce_wf_enable_payment_link_in_invoice',
                        'value' => 1,
                        'checkbox_fields' => array('1' => __('Enable to add a payment link in the invoice', 'wt-woocommerce-invoice-addon')),
                        'class' => "woocommerce_wf_enable_payment_link_in_invoice",
                        'col'   => 3,
                        'form_toggler' => array(
                            'type'  => 'parent',
                            'target' => 'wf_paylink_for_order_status',
                        ),
                        'help_text' => __('Adds a payment link beside the payment method in the invoice. Ensure to choose a template from the ‘Customize’ tab that supports the payment link.', 'wt-woocommerce-invoice-addon'),
                        'tooltip'   => true,
                    ),

                    'woocommerce_wf_payment_link_in_order_status' => array(
                        'type'  => 'wt_multi_checkbox',
                        'label' => __('Choose order status', 'wt-woocommerce-invoice-addon'),
                        'name'  => 'woocommerce_wf_payment_link_in_order_status',
                        'id'    => 'woocommerce_wf_payment_link_in_order_status_st',
                        'value' => $payment_link_default_order_statuses,
                        'checkbox_fields' => $payment_link_default_order_statuses,
                        'class' => 'woocommerce_wf_payment_link_in_order_status',
                        'col'   => 3,
                        'help_text' => __('Adds payment link for selected order statuses. Even if nothing is selected, ‘On hold’ status will be considered.', 'wt-woocommerce-invoice-addon'),
                        'alignment' => 'vertical_with_label',
                        'form_toggler' => array(
                            'type'  => 'child',
                            'id'    => 'wf_paylink_for_order_status',
                            'val'   => '1',
                        ),
                        'tooltip' => true,
                    ),

                    'woocommerce_wf_show_pay_later_in_checkout' => array(
                        'type'  => 'wt_single_checkbox',
                        'label' => __('Show pay later on checkout', 'wt-woocommerce-invoice-addon'),
                        'id'    => 'woocommerce_wf_show_pay_later_in_checkout',
                        'name'  => 'woocommerce_wf_show_pay_later_in_checkout',
                        'value' => 1,
                        'checkbox_fields' => array('1' => __('Enable to show pay later option at the checkout', 'wt-woocommerce-invoice-addon')),
                        'class' => "woocommerce_wf_show_pay_later_in_checkout",
                        'col'   => 3,
                        'form_toggler' => array(
                            'type'  => 'parent',
                            'target' => 'wf_paylink_form_fields',
                        )
                    ),

                    'woocommerce_wf_pay_later_title' => array(
                        'type'  => "wt_text",
                        'label' => __('Title', 'wt-woocommerce-invoice-addon'),
                        'name'  => 'woocommerce_wf_pay_later_title',
                        'form_toggler' => array(
                            'type'  => 'child',
                            'id'    => 'wf_paylink_form_fields',
                            'val'   => '1',
                        ),
                        'tooltip' => true,
                    ),
                    'woocommerce_wf_pay_later_description' => array(
                        'type'  => "wt_text",
                        'label' => __('Description', 'wt-woocommerce-invoice-addon'),
                        'name'  => 'woocommerce_wf_pay_later_description',
                        'form_toggler'  => array(
                            'type'  => 'child',
                            'id'    => 'wf_paylink_form_fields',
                            'val'   => '1',
                        ),
                        'tooltip' => true,
                    ),
                    'woocommerce_wf_pay_later_instuction' => array(
                        'type'  => "wt_text",
                        'label' => __("Instruction", 'wt-woocommerce-invoice-addon'),
                        'name'  => 'woocommerce_wf_pay_later_instuction',
                        'form_toggler'  => array(
                            'type'  => 'child',
                            'id'    => 'wf_paylink_form_fields',
                            'val'   => '1',
                        ),
                        'tooltip'   => true,
                    ),

                    'wt_inv_gen_hr_line' => array(
                        'type'  => 'wt_hr_line',
                        'class' => 'wf_field_hr'
                    )
                )
            );

            if ("general" === $target_id) {
                // add the product display section after the general section in the invoice settings page
                $settings = Wt_woocommerce_invoice_addon_Admin::wt_add_array_element_to_position($settings, $payment_link_section, 'invoice_general_invoice_number');
                $settings = Wt_woocommerce_invoice_addon_Admin::wt_add_array_element_to_position($settings, $product_display_section, 'invoice_general_invoice_number');
            }
        }
        return $settings;
    }

    public function default_settings($settings, $base_id)
    {
        if ($base_id === $this->module_id) {
            $settings['wf_woocommerce_product_category_wise_splitting'] = "No";
            $settings['sort_products_by'] = "";
            $settings['woocommerce_wf_packinglist_variation_data'] = 'Yes';

            /* Possible values: 1.main-sub, 2.main, 3.sub */
            $settings['bundled_product_display_option'] = 'main-sub';
            $settings['woocommerce_wf_packinglist_footer'] = "";
            $settings['woocommerce_wf_packinglist_invoice_signature'] = '';
            $settings['wf_' . $this->module_base . '_product_meta_fields'] = array();
            $settings['wt_' . $this->module_base . '_product_attribute_fields'] = array();
            $settings['woocommerce_wf_enable_payment_link_in_invoice'] =  0;
            $settings['woocommerce_wf_show_pay_later_in_checkout']     =  0;
            $settings['woocommerce_wf_payment_link_in_order_status']   =  array();
            $settings['woocommerce_wf_pay_later_title']                =  $this->pay_later_title;
            $settings['woocommerce_wf_pay_later_description']          =  '';
            $settings['woocommerce_wf_pay_later_instuction']           =  '';
            $settings['wt_pklist_document_language']                   = 'site';
            $settings['wt_pklist_invoice_number_reset']                = 'No';
        }
        return $settings;
    }

    public function single_checkbox_fields($settings, $base_id, $tab_name)
    {
        if ($base_id === $this->module_id) {
            $settings['wt_invoice_general']['wf_woocommerce_product_category_wise_splitting']   = "No";
            $settings['wt_invoice_general']['woocommerce_wf_packinglist_variation_data']        = "No";
            $settings['wt_invoice_general']['woocommerce_wf_enable_payment_link_in_invoice']    =  0;
            $settings['wt_invoice_general']['woocommerce_wf_show_pay_later_in_checkout']        =  0;
            $settings['wt_invoice_general']['wt_pklist_invoice_number_reset']                   = "No";
        }
        return $settings;
    }

    /**
     * Get the multi checkbox default value, $_POST is not have these fields.
     *
     * @since       1.5.0 - Removed the order meta fields from general tab and add it to the advance tab.
     * @param array $settings
     * @param string $base_id
     * @param string $tab_name
     * @return array
     */
    public function multi_checkbox_fields($settings, $base_id, $tab_name)
    {
        if ($base_id === $this->module_id) {
            if (isset($settings['wt_invoice_general']['wf_' . $this->module_base . '_contactno_email'])) {
                unset($settings['wt_invoice_general']['wf_' . $this->module_base . '_contactno_email']);
            }
            $settings['wt_invoice_general']['woocommerce_wf_payment_link_in_order_status'] = array('wc-on-hold');
            $settings['wt_invoice_advanced']['wf_' . $this->module_base . '_contactno_email'] = array();
            $settings['wt_invoice_advanced']['wf_' . $this->module_base . '_product_meta_fields'] = array();
            $settings['wt_invoice_advanced']['wt_' . $this->module_base . '_product_attribute_fields'] = array();
        }
        return $settings;
    }

    public function alter_validation_rule($arr, $base_id)
    {
        if ($base_id === $this->module_id) {
            $arr['woocommerce_wf_packinglist_footer'] = array('type' => 'textarea');
            $arr['wf_' . $this->module_base . '_product_meta_fields'] = array('type' => 'text_arr');
            $arr['wt_' . $this->module_base . '_product_attribute_fields'] = array('type' => 'text_arr');

            $arr['woocommerce_wf_payment_link_in_order_status'] = array('type' =>  'text_arr');
            $arr['woocommerce_wf_pay_later_description']        = array('type' =>  'textarea');
            $arr['woocommerce_wf_pay_later_instuction']         = array('type' =>  'textarea');
        }
        return $arr;
    }

    public function add_pro_template($template_arr, $template_type)
    {

        $module_id = Wf_Woocommerce_Packing_List::get_module_id($template_type);
        if ($module_id === $this->module_id) {
            include plugin_dir_path(__FILE__) . 'data/data.templates.php';
            return $template_arr;
        }
        return $template_arr;
    }

    public function get_customizable_items($settings, $base_id)
    {

        if ($base_id === $this->module_id) {
            $pro_features_disabled = array(
                "tracking_number_disabled",
                "product_table_subtotal_disabled",
                "product_table_shipping_disabled",
                "product_table_cart_discount_disabled",
                "product_table_order_discount_disabled",
                "product_table_total_tax_disabled",
                "product_table_fee_disabled",
                "product_table_coupon_disabled",
                "product_table_payment_method_disabled",
                "product_table_payment_total_disabled"
            );
            foreach ($pro_features_disabled as $pro_feature) {
                if (isset($settings[$pro_feature])) {
                    unset($settings[$pro_feature]);
                }
            }

            $pro_settings = array(
                'doc_title'                     => __('Document title', 'wt-woocommerce-invoice-addon'),
                'company_logo'                  => __('Company Logo', 'wt-woocommerce-invoice-addon'),
                'invoice_number'                => __('Invoice Number', 'wt-woocommerce-invoice-addon'),
                'order_number'                  => __('Order Number', 'wt-woocommerce-invoice-addon'),
                'invoice_date'                  => __('Invoice Date', 'wt-woocommerce-invoice-addon'),
                'due_date'                      => __('Due Date', 'wt-woocommerce-invoice-addon'),
                'order_date'                    => __('Order Date', 'wt-woocommerce-invoice-addon'),
                'received_seal'                 => __('Payment received stamp', 'wt-woocommerce-invoice-addon'),
                'from_address'                  => __('From Address', 'wt-woocommerce-invoice-addon'),
                'billing_address'               => __('Billing Address', 'wt-woocommerce-invoice-addon'),
                'shipping_address'              => __('Shipping Address', 'wt-woocommerce-invoice-addon'),
                'email'                         => __('Email Field', 'wt-woocommerce-invoice-addon'),
                'tel'                           => __('Tel Field', 'wt-woocommerce-invoice-addon'),
                'vat_number'                    => __('VAT Field', 'wt-woocommerce-invoice-addon'),
                'ssn_number'                    => __('SSN Field', 'wt-woocommerce-invoice-addon'),
                'shipping_method'               => __('Shipping Method', 'wt-woocommerce-invoice-addon'),
                'tracking_number'               => __('Tracking Number', 'wt-woocommerce-invoice-addon'),
                'product_table'                 => __('Product Table', 'wt-woocommerce-invoice-addon'),
                'product_table_subtotal'        => __('Subtotal', 'wt-woocommerce-invoice-addon'),
                'product_table_shipping'        => __('Shipping', 'wt-woocommerce-invoice-addon'),
                'product_table_cart_discount'   => __('Cart Discount', 'wt-woocommerce-invoice-addon'),
                'product_table_order_discount'  => __('Order Discount', 'wt-woocommerce-invoice-addon'),
                'product_table_total_tax'       => __('Total Tax', 'wt-woocommerce-invoice-addon'),
                'product_table_tax_item'        => __('Tax items', 'wt-woocommerce-invoice-addon'),
                'product_table_fee'             => __('Fee', 'wt-woocommerce-invoice-addon'),
                'product_table_coupon'          => __('Coupon info', 'wt-woocommerce-invoice-addon'),
                'product_table_payment_method'  => __('Payment Method', 'wt-woocommerce-invoice-addon'),
                'payment_link'                  => __('Payment Link', 'wt-woocommerce-invoice-addon'),
                'product_table_payment_total'   => __('Total', 'wt-woocommerce-invoice-addon'),
                'barcode'                       => __('Bar Code', 'wt-woocommerce-invoice-addon'),
                'qrcode'                        => __('QR Code', 'wt-woocommerce-invoice-addon'),
                'signature'                     => __('Signature', 'wt-woocommerce-invoice-addon'),
                'footer'                        => __('Footer', 'wt-woocommerce-invoice-addon'),
                'return_policy'                 => __('Return Policy', 'wt-woocommerce-invoice-addon'),
            );
            $show_qrcode_placeholder = apply_filters('wt_pklist_show_qrcode_placeholder_in_template', false, $this->module_base);
            if (!$show_qrcode_placeholder) {
                unset($pro_settings['qrcode']);
            }
            $settings = array_unique(array_merge($pro_settings, $settings));
        }
        return $settings;
    }

    public function alter_customize_inputs($fields, $type, $template_type)
    {
        if ($template_type === $this->module_base) {
            if ("product_table" === $type) {
                foreach ($fields as $k => $f_val) {
                    if (is_array($f_val) && isset($f_val['trgt_elm']) && "product_table_head_tax" === $f_val['trgt_elm']) {
                        unset($fields[$k]);
                    }
                }
                $new_asset_arr = array(
                    array(
                        'label'         => '&nbsp;',
                        'type'          => 'checkbox',
                        'trgt_elm'      => 'product_table_head_tax_items',
                        'event_class'   => 'wf_cst_toggler',
                        'width'         => '10%',
                    ),
                    array(
                        'label'         => __('Tax items value', 'wt-woocommerce-invoice-addon'),
                        'type'          => 'select',
                        'select_options' => Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::get_customizer_presets('ind-tax'),
                        'css_prop'      => 'attr-data-ind-tax-display-option',
                        'trgt_elm'      => 'product_table_head_tax_items',
                        'event_class'   => 'wf_cst_change',
                        'width'         => '44%',
                    ),
                    array(
                        'label'         => __('Tax items text align', 'wt-woocommerce-invoice-addon'),
                        'type'          => 'select',
                        'select_options' => Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::get_customizer_presets('text-align'),
                        'css_prop'      => 'text-align',
                        'trgt_elm'      => 'product_table_head_tax_items',
                        'event_class'   => 'wf_cst_change',
                        'width'         => '44%',
                        'float'         => 'right',
                    ),

                    array(
                        'label'         => '&nbsp;',
                        'type'          => 'checkbox',
                        'trgt_elm'      => 'product_table_head_tax',
                        'event_class'   => 'wf_cst_toggler',
                        'width'         => '10%',
                    ),
                    array(
                        'label'         => __('Total Tax label', 'wt-woocommerce-invoice-addon'),
                        'css_prop'      => 'html',
                        'trgt_elm'      => 'product_table_head_tax',
                        'width'         => '44%',
                    ),
                    array(
                        'label'         => __('Total Tax text align', 'wt-woocommerce-invoice-addon'),
                        'type'          => 'select',
                        'select_options' => Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::get_customizer_presets('text-align'),
                        'css_prop'      => 'text-align',
                        'trgt_elm'      => 'product_table_head_tax',
                        'event_class'   => 'wf_cst_change',
                        'width'         => '44%',
                        'float'         => 'right',
                    ),
                    array(
                        'label'         => __('Total Tax value', 'wt-woocommerce-invoice-addon'),
                        'type'          => 'select',
                        'select_options' => Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::get_customizer_presets('total-tax'),
                        'css_prop'      => 'attr-data-total-tax-display-option',
                        'trgt_elm'      => 'product_table_head_tax',
                        'event_class'   => 'wf_cst_change',
                        'width'         => '90%',
                        'float'         => 'right',
                    ),

                );

                $fields = (array_merge($fields, $new_asset_arr));
            } elseif ("product_table_tax_items" === $type) {
                $summary_tax_items_fields = array(
                    array(
                        'label'         => __('Tax items value', 'wt-woocommerce-invoice-addon'),
                        'type'          => 'select',
                        'select_options' => Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::get_customizer_presets('ind-tax-summay'),
                        'css_prop'      => 'attr-data-ind-tax-summary',
                        'trgt_elm'      => 'product_table_tax_item',
                        'event_class'   => 'wf_cst_change',
                        'width'         => '90%',
                        'float'         => 'left',
                    ),
                );
                $fields = array_merge($fields, $summary_tax_items_fields);
            }
        }
        return $fields;
    }

    /*
    * These are the fields that have no customizable options, Just on/off
    * 
    */
    public function get_non_options_fields($settings, $base_id)
    {
        if ($base_id === $this->module_id) {
            $template_type = $this->module_base;
            $show_qrcode_placeholder = apply_filters('wt_pklist_show_qrcode_placeholder_in_template', false, $template_type);
            if (!$show_qrcode_placeholder) {
                return array(
                    'footer',
                    'return_policy',
                    'product_table_tax_item',
                );
            } else {
                return array(
                    'qrcode',
                    'footer',
                    'return_policy',
                    'product_table_tax_item',
                );
            }
        }
        return $settings;
    }

    public function bundled_prod_css($pro_css, $template_type, $order)
    {
        if ($template_type === $this->module_base) {
            $category_wise_split = Wf_Woocommerce_Packing_List::get_option('wf_woocommerce_product_category_wise_splitting', $this->module_id);
            $bundle_display_option = Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::get_bundle_display_option($template_type, $order);

            if ($bundle_display_option && "No" === $category_wise_split) {
                $pro_css .= 'tr.wfte_product_row_bundle_child .product_td{ padding-left:20px !important; }';
            }
        }
        return $pro_css;
    }

    public function after_setting_update($the_options, $base_id)
    {
        if ($this->module_id === $base_id) {
            $checkout_paylater  =   Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_show_pay_later_in_checkout', $this->module_id);
            if ((1 === $checkout_paylater) || ("1" === $checkout_paylater)) {
                $enable_paylater    =   "yes";
            } else {
                $enable_paylater    =   "no";
            }

            $paylater_title =   Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_pay_later_title', $this->module_id);
            $paylater_desc  =   Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_pay_later_description', $this->module_id);
            $paylater_inst  =   Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_pay_later_instuction', $this->module_id);
            $paylater_arr   =   array(
                'title'         =>  sanitize_text_field($paylater_title),
                'description'   =>  sanitize_textarea_field($paylater_desc),
                'instructions'  =>  sanitize_textarea_field($paylater_inst),
                'enabled'       =>  $enable_paylater
            );
            $installed_payment_methods = WC()->payment_gateways->payment_gateways();

            if (array_key_exists("wf_pay_later", $installed_payment_methods)) {
                if (get_option('woocommerce_gateway_order')) {
                    $all_gateways = get_option('woocommerce_gateway_order');
                    if (!array_key_exists('wf_pay_later', $all_gateways)) {
                        $paylater__serial_no            = count($all_gateways);
                        $all_gateways['wf_pay_later']   = $paylater__serial_no;
                        update_option('woocommerce_gateway_order', $all_gateways, false);
                    }
                }
            }
            update_option('woocommerce_wf_pay_later_settings', $paylater_arr, false);

            // Restart invoice number - schedule event
            // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verification is handled by the settings form submission
            if (isset($_POST['wt_tab_name']) && "wt_invoice_general" === sanitize_text_field(wp_unslash($_POST['wt_tab_name']))) {

                // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verification is handled by the settings form submission
                $reset_option = isset($_POST['wt_pklist_invoice_number_reset']) ? sanitize_text_field(wp_unslash($_POST['wt_pklist_invoice_number_reset'])) : 'No';
                
                // Check if reset should be disabled based on settings
                if ($reset_option !== 'No') {
                    // phpcs:disable WordPress.Security.NonceVerification.Missing -- Nonce verification is handled by the settings form submission
                    if ((isset($_POST['woocommerce_wf_invoice_as_ordernumber_pdf_fw'])
                        &&  "Yes" === sanitize_text_field(wp_unslash($_POST['woocommerce_wf_invoice_as_ordernumber_pdf_fw']))
                    ) || (isset($_POST['woocommerce_wf_invoice_number_prefix_pdf_fw'])
                        && false === strpos(sanitize_text_field(wp_unslash($_POST['woocommerce_wf_invoice_number_prefix_pdf_fw'])), '[Y]')
                        && isset($_POST['woocommerce_wf_invoice_number_postfix_pdf_fw'])
                        && false === strpos(sanitize_text_field(wp_unslash($_POST['woocommerce_wf_invoice_number_postfix_pdf_fw'])), '[Y]')
                    )) {
                        $reset_option = 'No';
                    }
                    // phpcs:enable WordPress.Security.NonceVerification.Missing
                }
                
                Wf_Woocommerce_Packing_List::update_option('wt_pklist_invoice_number_reset', $reset_option, $this->module_id);

                $current_reset_option = Wf_Woocommerce_Packing_List::get_option('wt_pklist_invoice_number_reset', $this->module_id);
                
                if (
                    $current_reset_option !== 'No'
                    && "No" === Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_invoice_as_ordernumber', $this->module_id)
                    && (false !== strpos(Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_invoice_number_prefix', $this->module_id), '[Y]')
                        || false !== strpos(Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_invoice_number_postfix', $this->module_id), '[Y]'))
                ) {
                    if (false === as_next_scheduled_action('wt_pklist_restart_invoice_number_event')) {
                        // Determine the reset date based on the selected option
                        $month_options = array(
                            'january' => 'January 1st',
                            'february' => 'February 1st',
                            'march' => 'March 1st',
                            'april' => 'April 1st',
                            'may' => 'May 1st',
                            'june' => 'June 1st',
                            'july' => 'July 1st',
                            'august' => 'August 1st',
                            'september' => 'September 1st',
                            'october' => 'October 1st',
                            'november' => 'November 1st',
                            'december' => 'December 1st'
                        );
                        
                        if (isset($month_options[$current_reset_option])) {
                            // Calculate the next occurrence of the selected month
                            $month_day = $month_options[$current_reset_option]; // e.g., "January 1st"
                            $current_timestamp = time();
                            
                            // Try this year first
                            $this_year_timestamp = strtotime($month_day . ' ' . gmdate('Y'));
                            
                            // If this year's date has already passed, use next year
                            if ($this_year_timestamp <= $current_timestamp) {
                                $next_year_timestamp = strtotime($month_day . ' ' . (gmdate('Y') + 1));
                            } else {
                                $next_year_timestamp = $this_year_timestamp;
                            }
                        } else {
                            $next_year_timestamp = strtotime('January 1st ' . (gmdate('Y') + 1)); // Default fallback
                        }

                        // Schedule the action for the selected date of the next year
                        as_schedule_recurring_action(
                            $next_year_timestamp, // Start time
                            DAY_IN_SECONDS * 365, // Interval (1 year)
                            'wt_pklist_restart_invoice_number_event', // Action hook
                            array(), // Arguments for the action
                            'wt_pklist_restart_invoice_number'
                        );
                    }
                } else {
                    $action = as_next_scheduled_action('wt_pklist_restart_invoice_number_event');
                    // If the action is found and its status is either queue or pending, unschedule it
                    if ($action) {
                        as_unschedule_all_actions('wt_pklist_restart_invoice_number_event', array(), 'wt_pklist_restart_invoice_number');
                    }
                }
            }
        }
    }

    public function run_payment_link_module($plugin_name, $plugin_version)
    {
        /**
         * The class responsible for pay later payment method to add the pay link in invoice
         * side of the site.
         */
        if ((class_exists('Wf_Woocommerce_Packing_List_Pay_Later_Payment')) && (class_exists('WC_Payment_Gateway'))) {
            add_filter('woocommerce_payment_gateways', array($this, 'wf_paylater_add_to_gateways'), 10, 1);
            add_action('init', array($this, 'save_paylater_settings_admin'), 10, 1);
            add_filter('woocommerce_valid_order_statuses_for_payment', array($this, 'wf_allow_payment_for_order_status'), 11, 2);
            add_filter('woocommerce_available_payment_gateways', array($this, 'hide_pay_later_payment_in_order_pay_page'), 10, 2);
            add_action('woocommerce_update_options_payment_gateways_wf_pay_later', array($this, 'save_paylater_settings_admin'), 10);
        }
    }

    public function wf_paylater_add_to_gateways($gateways)
    {
        $gateways[] = 'Wf_Woocommerce_Packing_List_Pay_Later_Payment';
        return $gateways;
    }

    public function save_paylater_settings_admin()
    {
        $paylater_details = get_option('woocommerce_wf_pay_later_settings', array(
            'title'         => __('Pay Later', 'wt-woocommerce-invoice-addon'),
            'description'   => '',
            'instructions'  => '',
            'enabled'       => "no"
        ));

        $show_paylater = isset($paylater_details['enabled']) && 'yes' === $paylater_details['enabled'] ? 1 : 0;

        // pay later enabled or not.
        if ($show_paylater !== (int) Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_show_pay_later_in_checkout', $this->module_id)) {
            Wf_Woocommerce_Packing_List::update_option('woocommerce_wf_show_pay_later_in_checkout', $show_paylater, $this->module_id);
        }

        // pay later title change check.
        if (isset($paylater_details['title']) && $paylater_details['title'] !== Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_pay_later_title', $this->module_id)) {
            Wf_Woocommerce_Packing_List::update_option('woocommerce_wf_pay_later_title', sanitize_text_field($paylater_details['title']), $this->module_id);
        }

        // pay later description change check.
        if (isset($paylater_details['description']) && $paylater_details['description'] !== Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_pay_later_description', $this->module_id)) {
            Wf_Woocommerce_Packing_List::update_option('woocommerce_wf_pay_later_description', sanitize_textarea_field($paylater_details['description']), $this->module_id);
        }

        // pay later instruction change check.
        if (isset($paylater_details['instructions']) && $paylater_details['instructions'] !== Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_pay_later_instuction', $this->module_id)) {
            Wf_Woocommerce_Packing_List::update_option('woocommerce_wf_pay_later_instuction', sanitize_textarea_field($paylater_details['instructions']), $this->module_id);
        }
    }

    public function wf_allow_payment_for_order_status($statuses, $order)
    {
        $order_status = $order->get_status(); 
        $order_payment_method = $order->get_payment_method();
        if ("wf_pay_later" === $order_payment_method) {
            if (!in_array('on-hold', $statuses) && ("on-hold" === $order_status)) {
                $statuses[] = 'on-hold';
            } elseif (!in_array('failed', $statuses) && ("failed" === $order_status)) {
                $statuses[] = 'failed';
            }
        }
        return $statuses;
    }

    public function hide_pay_later_payment_in_order_pay_page($available_gateways)
    {
        // 1. On Order Pay page
        if (is_wc_endpoint_url('order-pay')) {
            // Get an instance of the WC_Order Object
            $order = wc_get_order(get_query_var('order-pay'));

            // Loop through payment gateways 'pending', 'on-hold', 'processing'
            foreach ($available_gateways as $gateways_id => $gateways) {
                // Keep paypal only for "pending" order status
                if ("wf_pay_later" === $gateways_id && ($order->has_status('pending') || $order->has_status('on-hold') || $order->has_status('failed'))) {
                    unset($available_gateways[$gateways_id]);
                }
            }
        }

        $pay_later_role_access  = apply_filters('wt_pklist_alter_pay_later_role_access', array());
        $pay_later_role_access  = (!is_array($pay_later_role_access) ? array() : $pay_later_role_access);

        if (!empty($pay_later_role_access)) {
            $user = wp_get_current_user();
            foreach ($pay_later_role_access as $role) //checking access
            {
                if (in_array($role, $user->roles)) { //any of the role present in the role array then restrict the access for the payment gateway
                    unset($available_gateways['wf_pay_later']);
                    break;
                }
            }
        }
        return $available_gateways;
    }

    public function convert_to_design_view_html($find_replace, $html, $template_type)
    {
        if ($template_type === $this->module_base) {
            $find_replace = Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::set_shipping_from_address($find_replace, $template_type, $html);
            $find_replace = Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::set_billing_address($find_replace, $template_type, $html);
            $find_replace = Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::set_shipping_address($find_replace, $template_type, $html);
            $find_replace = Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::set_default_order_fields($find_replace, $template_type, $html);
            $find_replace = Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::set_product_table($find_replace, $template_type, $html);
            $find_replace = Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::set_extra_charge_fields($find_replace, $template_type, $html);
            $find_replace = Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::set_other_data($find_replace, $template_type, $html);
            $find_replace = Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::set_tax_table($find_replace, $template_type, $html);
            $find_replace = $this->toggle_qrcode($find_replace, $html);
            $find_replace['[wfte_received_seal_extra_text]'] = '';
        }
        return $find_replace;
    }

    /**
     *  Items needed to be converted to HTML for print/download
     */
    public function generate_template_html($find_replace, $html, $template_type, $order, $box_packing = null, $order_package = null)
    {
        if ($template_type === $this->module_base) {
            //Generate invoice number while printing invoice
            Wf_Woocommerce_Packing_List_Invoice::generate_invoice_number($order);
            $find_replace = Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::set_logo($find_replace, $template_type, $html);
            $find_replace = Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::set_shipping_from_address($find_replace, $template_type, $html, $order);
            $find_replace = Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::set_billing_address($find_replace, $template_type, $html, $order);
            $find_replace = Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::set_shipping_address($find_replace, $template_type, $html, $order);
            $find_replace = Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::set_default_order_fields($find_replace, $template_type, $html, $order);
            $find_replace = Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::set_product_table($find_replace, $template_type, $html, $order);
            $find_replace = Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::set_order_data($find_replace, $template_type, $html, $order);
            $find_replace = Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::add_missing_placeholders($find_replace, $template_type, $html, $order);
            $find_replace = Wf_Woocommerce_Packing_List_Customizer_Ipc_PRO::set_tax_table($find_replace, $template_type, $html, $order);

            $find_replace = $this->toggle_qrcode($find_replace, $html);
            $find_replace = self::set_received_seal_extra_text($find_replace, $template_type, $html, $order);
        }
        return $find_replace;
    }

    private function toggle_qrcode($find_replace, $html)
    {
        $show_qrcode_placeholder = apply_filters('wt_pklist_show_qrcode_placeholder_in_template', false, $this->module_base);
        if (false === $show_qrcode_placeholder) {
            $find_replace['wfte_qrcode'] = 'wfte_qrcode wfte_hidden';
            $find_replace['wfte_img_qrcode'] = 'wfte_img_qrcode wfte_hidden';
        } else {
            if (false !== strpos($html, 'wfte_product_table_head_tax_items')) {
                $find_replace['wfte_img_qrcode wfte_hidden'] = 'wfte_img_qrcode';
            }
        }
        return $find_replace;
    }

    /**
     * Adding received seal extra text
     *   @since  1.0.0
     */
    private static function set_received_seal_extra_text($find_replace, $template_type, $html, $order)
    {
        if (false !== strpos($html, '[wfte_received_seal_extra_text]')) //if extra text placeholder exists then only do the process
        {
            $extra_text = '';
            $find_replace['[wfte_received_seal_extra_text]'] = apply_filters('wf_pklist_received_seal_extra_text', $extra_text, $template_type, $order);
        }
        return $find_replace;
    }

    /**
     * Get the document language as per the settings
     *
     * @since 1.1.0
     * @param string $lang
     * @param string $template_type
     * @param int|string $order_id
     * @return string
     */
    public function alter_document_language($lang, $template_type, $order_id)
    {
        if ($this->module_base === $template_type && !empty($order_id)) {
            $document_language_to = Wf_Woocommerce_Packing_List::get_option('wt_pklist_document_language', $this->module_id);
            if (!empty($document_language_to)) {
                switch ($document_language_to) {
                    case 'site':
                        $lang   = !empty(get_option('WPLANG')) ? get_option('WPLANG') : get_locale();
                        return $lang;
                        break;
                    case 'customer':
                        $clang  = Wt_Pklist_Common_Ipc::get_order_meta($order_id, 'wt_pklist_order_language', true);
                        $lang   = !empty($clang) ? $clang : $lang;
                        return $lang;
                    default:
                        return $lang;
                        break;
                }
            }
        }
        return $lang;
    }

    public function restart_invoice_no_event()
    {
        $start_number           = (int) Wf_Woocommerce_Packing_List::get_option('woocommerce_wf_invoice_start_number', $this->module_id);
        $current_invoice_number = (int) $start_number - 1;
        Wf_Woocommerce_Packing_List::update_option('woocommerce_wf_Current_Invoice_number', $current_invoice_number, $this->module_id);
    }

    public function add_full_length_elements_in_settings($row_full_length, $base_id)
    {
        if ($this->module_id === $base_id) {
            if (!in_array('wt_restart_invoice_number_confirm_popup', $row_full_length)) {
                array_push($row_full_length, 'wt_restart_invoice_number_confirm_popup');
            }
        }
        return $row_full_length;
    }

    public function bulk_export_pdf($attachments, $all_order_ids, $document_module_id)
    {
        $attachments['file_list'] = array();
        $attachments['success']    = array();

        if ($this->module_id === $document_module_id && !empty($all_order_ids)) {
            $this->parent_class = new Wf_Woocommerce_Packing_List_Invoice();
            $this->customizer   = Wf_Woocommerce_Packing_List::load_modules('customizer');
            $this->customizer->template_for_pdf = true;
            foreach ($all_order_ids as $order_ids) {
                $order_ids_arr  = array($order_ids);
                $pdf_name       = $this->customizer->generate_pdf_name($this->module_base, $order_ids_arr);
                $html           = $this->parent_class->generate_order_template($order_ids_arr, $pdf_name);
                $attachments['file_list'][] = $attachments['success'][$order_ids] = $this->customizer->generate_template_pdf($html, $this->module_base, $pdf_name, 'attach');
            }

            // clear the object of parent class and its customizer, once done generating the pdfs.
            unset($this->parent_class);
            unset($this->customizer);
        }

        return $attachments;
    }
}
new Wf_Woocommerce_Packing_List_Invoice_Pro();
