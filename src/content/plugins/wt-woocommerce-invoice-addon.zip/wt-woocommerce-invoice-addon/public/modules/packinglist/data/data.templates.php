<?php
$template_arr_pro=array(
	array(
		'id'=>'template_premium_1',
		'title'=>__('Premium layout - 1', 'wt-woocommerce-invoice-addon'),
		'preview_img'=>'template1.png',
		'version' => 'pro',
		'pro_template_path' => plugin_dir_path(__FILE__),
		'pro_template_url' => WT_PKLIST_INVOICE_ADDON_PLUGIN_URL.'public/modules/packinglist/data/',
	),
	array(
		'id'=>'template_premium_2',
		'title'=>__('Premium layout - 2', 'wt-woocommerce-invoice-addon'),
		'preview_img'=>'template2.png',
		'version' => 'pro',
		'pro_template_path' => plugin_dir_path(__FILE__),
		'pro_template_url' => WT_PKLIST_INVOICE_ADDON_PLUGIN_URL.'public/modules/packinglist/data/',
	),
	array(
		'id'=>'template_premium_3',
		'title'=>__('Premium layout - 3', 'wt-woocommerce-invoice-addon'),
		'preview_img'=>'template3.png',
		'version' => 'pro',
		'pro_template_path' => plugin_dir_path(__FILE__),
		'pro_template_url' => WT_PKLIST_INVOICE_ADDON_PLUGIN_URL.'public/modules/packinglist/data/',
	),
	array(
		'id'=>'template_premium_4',
		'title'=>__('Premium layout - 4', 'wt-woocommerce-invoice-addon'),
		'preview_img'=>'template4.png',
		'version' => 'pro',
		'pro_template_path' => plugin_dir_path(__FILE__),
		'pro_template_url' => WT_PKLIST_INVOICE_ADDON_PLUGIN_URL.'public/modules/packinglist/data/',
	),
);

$template_arr = array_merge($template_arr_pro, $template_arr);