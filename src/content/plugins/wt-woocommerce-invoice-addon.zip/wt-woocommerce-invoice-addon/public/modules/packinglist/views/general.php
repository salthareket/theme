<?php
if (!defined('ABSPATH')) {
    exit;
}

// remove the basic plugin fields of packingslip from general settings
if(isset($settings['packingslip_general_general'])){
    unset($settings['packingslip_general_general']);
}

$new_order_email_label = sprintf('%1$s <code>(%2$s)</code>',__('New order','wt-woocommerce-invoice-addon'),get_option( 'admin_email' ));
$order_statuses = wc_get_order_statuses();
$order_statuses_new = array(
    'wfte_new_order' => $new_order_email_label,
    'wfte_seperate_email' => __('Custom email','wt-woocommerce-invoice-addon')
);
$order_statuses = array_merge($order_statuses_new,$order_statuses);



$email_settings_path=admin_url('admin.php?page=wc-settings&tab=email&section=wf_woocommerce_packing_list_'.$this->module_base.'_email');

// add pro plugin fields of the packingslip in the general settings
$settings["packingslip_general_general"] = array(
    'wt_sub_head_pkslip_gen_general' => array(
        'type'  =>  'wt_sub_head',
        'class' =>  'wt_pklist_field_group_hd_sub',
        'heading_number' => 1,
        'label' =>  __('General','wt-woocommerce-invoice-addon'),
    ),

    'woocommerce_wf_generate_for_orderstatus' => array(
        'type' => 'wt_select2_checkbox',
        'label' => __('Email packingslip automatically to','wt-woocommerce-invoice-addon'),
        'name' => 'woocommerce_wf_generate_for_orderstatus',
        'id' => 'woocommerce_wf_generate_for_orderstatus_st',
        'value' => $order_statuses,
        'checkbox_fields' => $order_statuses,
        'class' => 'woocommerce_wf_generate_for_orderstatus',
        'col' => 3,
        'placeholder' => __('Choose order status','wt-woocommerce-invoice-addon'),
        /* translators: %1$s and %2$s: bold tags, %3$s and %4$s: link tags */
        'help_text' => sprintf(__('Packing slip as PDF will be sent to the selected recipients. To configure email recipients, choose %1$s `custom email` %2$s and click on %1$s update settings. %2$s You can then configure the email notification from %3$s here. %4$s','wt-woocommerce-invoice-addon'),'<b>','</b>','<a href="'.esc_url($email_settings_path).'" target="_blank">','</a>'),
        'alignment' => 'vertical_with_label',
        'ref_id' => 'woocommerce_wf_generate_for_orderstatus',
        'tooltip' => true,
    ),

    'wf_woocommerce_invoice_show_print_button' => array(
        'type' => 'wt_multi_checkbox',
        'label' => __('Show print packingslip button for customers','wt-woocommerce-invoice-addon'),
        'id' => '',
        'class' => 'wf_woocommerce_invoice_show_print_button',
        'name' => 'wf_woocommerce_invoice_show_print_button',
        'value' => '',
        'checkbox_fields' => array(
            'order_listing' => __('My account - Order lists page','wt-woocommerce-invoice-addon'),
            'order_details' => __('My account - Order details page', 'wt-woocommerce-invoice-addon'),
        ),
        'col' => 3,
        'alignment' => 'vertical_with_label',
        'tooltip' => true,
    ),

    'wt_pklist_document_language' => array(
        'type' => 'multi_language_option',
        'label' => __('Generate packing slip in','wt-woocommerce-invoice-addon'),
        'id' => '',
        'class' => 'wt_pklist_document_language',
        'name' => 'wt_pklist_document_language',
        'value' => '',
        'radio_fields' => array(
            'site'=>__('Site language','wt-woocommerce-invoice-addon'),
            'customer'=>__('Customer language','wt-woocommerce-invoice-addon'),
            'current_user'=> __('Current user profile language','wt-woocommerce-invoice-addon'),
        ),
        'radio_fields_help_text' => array(
            'site'=> __('In multilingual sites, packing slip language may differ from the default one set in WordPress Settings > General > Site Language, depending on customer`s  choice via the site`s language switcher.','wt-woocommerce-invoice-addon'),
            'customer'=> __('To generate a packing slip in the customer`s language, ensure that the plugin has the corresponding language file for the selected language. If not, add it to use the functionality.','wt-woocommerce-invoice-addon'),
            'current_user'=> __('Current user profile language can vary with users and can be configured under WordPress Users > All Users > User edit page.','wt-woocommerce-invoice-addon')
        ),
        'col' => 3,
        'tooltip' => true,
        'alignment' => 'vertical_with_label',
        'ref_id' => 'wt_pklist_document_language',
    ),

    'wt_inv_gen_hr_line_1' => array(
        'type' => 'wt_hr_line',
        'class' => 'wf_field_hr',
    )
);

$settings['packingslip_general_product_display'] = array(

    'wt_sub_head_pkslip_gen_prod_display' => array(
        'type'  =>  'wt_sub_head',
        'class' =>  'wt_pklist_field_group_hd_sub',
        'heading_number' => 2,
        'label' =>  __('Product display','wt-woocommerce-invoice-addon'),
    ),

    'wf_woocommerce_product_category_wise_splitting' => array(
        'type' => 'wt_single_checkbox',
        'label'=>__('Group products by \'Category\'','wt-woocommerce-invoice-addon'),
        'name'=>"wf_woocommerce_product_category_wise_splitting",
        'value' => 'Yes',
        'checkbox_fields' => array('Yes'=> __('Enable to display and group product by category','wt-woocommerce-invoice-addon')),
        'class' => 'wf_woocommerce_product_category_wise_splitting',
        'id' => 'wf_woocommerce_product_category_wise_splitting',
        'tooltip' => true,
    ),

    'sort_products_by' => array(
        'type'=>'wt_select_dropdown',
        'label'=>__('Sort products by', 'wt-woocommerce-invoice-addon'),
        'name'=>"sort_products_by",
        'select_dropdown_fields'=>array(
            ''=>__('None', 'wt-woocommerce-invoice-addon'),
            'name_asc'=>__('Name ascending', 'wt-woocommerce-invoice-addon'),
            'name_desc'=>__('Name descending', 'wt-woocommerce-invoice-addon'),
            'sku_asc'=>__('SKU ascending', 'wt-woocommerce-invoice-addon'),
            'sku_desc'=>__('SKU descending', 'wt-woocommerce-invoice-addon'),
        ),
        'class' => 'sort_products_by',
        'id' => 'sort_products_by',
        'help_text'=>__('Sort products in ascending/descending order based on Name or SKU','wt-woocommerce-invoice-addon')
    ),

    'woocommerce_wf_packinglist_variation_data' => array(
        'type' => 'wt_single_checkbox',
        'label'=>__('Show variation data below each product','wt-woocommerce-invoice-addon'),
        'name'=>"woocommerce_wf_packinglist_variation_data",
        'value' => 'Yes',
        'checkbox_fields' => array('Yes'=> __('Enable to include variation data beneath the product name','wt-woocommerce-invoice-addon')),
        'class' => 'woocommerce_wf_packinglist_variation_data',
        'id' => 'woocommerce_wf_packinglist_variation_data',
        'tooltip' => true,
    ),

    'wt_pklist_skip_vitual_backorder_items' => array(
        'type' => 'wt_multi_checkbox',
        'label' => __('Skip displaying','wt-woocommerce-invoice-addon'),
        'id' => '',
        'class' => 'wt_pklist_skip_vitual_backorder_items',
        'name' => 'wt_pklist_skip_vitual_backorder_items',
        'value' => '',
        'checkbox_fields' => array(
            'backorder_items' => __('Back order items', 'wt-woocommerce-invoice-addon'),
            'virtual_items' => __('Virtual items','wt-woocommerce-invoice-addon'),
        ),
        'col' => 3,
        'alignment' => 'vertical_with_label',
        'tooltip' => true,
    ),

    'bundled_product_display_option' => array(
        'id' => 'bundled_product_display_option',
        'class' => 'bundled_product_display_option',
        'type'=>"wt_select_dropdown",
        'label'=>__('Bundled product display options','wt-woocommerce-invoice-addon'),
        'name'=>"bundled_product_display_option",
        /* translators: %1$s, %3$s, %5$s: opening bold tags, %2$s, %4$s, %6$s: closing bold tags */
        'help_text'=>sprintf(__('Choose how to display bundled products in the packing slip. Applicable only if you are using %1$s Woocommerce Product Bundles %2$s / %3$s YITH WooCommerce Product Bundle add-on %4$s. It may not work along with %5$sGroup by Category%6$s option.','wt-woocommerce-invoice-addon'), '<b>', '</b>', '<b>', '</b>', '<b>', '</b>' ),
        'select_dropdown_fields'=>array(
            'main-sub'=>__('Main product with bundle items', 'wt-woocommerce-invoice-addon'),
            'main'=>__('Main product only', 'wt-woocommerce-invoice-addon'),
            'sub'=>__('Bundle items only', 'wt-woocommerce-invoice-addon'),
        ),
        'help_text_conditional'=>array(
            array(
                'help_text'=>'<img src="'.WT_PKLIST_INVOICE_ADDON_PLUGIN_URL.'assets/images/bundle-both-items.png"/>',
                'condition'=>array(
                    array('field'=>'bundled_product_display_option', 'value'=>'main-sub')
                )
            ),
            array(
                'help_text'=>'<img src="'.WT_PKLIST_INVOICE_ADDON_PLUGIN_URL.'assets/images/bundle-parent-only.png"/>',
                'condition'=>array(
                    array('field'=>'bundled_product_display_option', 'value'=>'main')
                )
            ),
            array(
                'help_text'=>'<img src="'.WT_PKLIST_INVOICE_ADDON_PLUGIN_URL.'assets/images/bundle-child-only.png"/>',
                'condition'=>array(
                    array('field'=>'bundled_product_display_option', 'value'=>'sub')
                )
            ),
        ),
    ),
);
?>