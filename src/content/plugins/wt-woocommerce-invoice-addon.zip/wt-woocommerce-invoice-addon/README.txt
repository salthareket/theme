=== WooCommerce PDF Invoices, Packing Slips and Credit Notes (Pro) ===
Contributors: Webtoffee
Version: 1.7.5
Tags: woocommerce invoice, woocommerce invoice generator, woocommerce send invoice, woocommerce invoice email, woocommerce receipt plugin, woocommerce vat invoice, woocommerce pdf invoices, woocommerce custom invoice, Packinglist, Invoice printing, Credit note, Wordpress
Requires at least: 3.0.1
Requires PHP: 5.6
Tested up to: 7.0
Stable tag: 1.7.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WooCommerce PDF Invoices, Packing Slips and Credit Notes (Pro)

== Description ==

== Screenshots ==

== Installation ==

1. Upload `wt-woocommerce-invoice-addon` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog == 

= 1.7.5 2026-04-13 =
* [Add] - Added support for using a custom meta key/tracking number as the barcode value.
* [Add] - Extended 'Item Tax' and 'Total Tax' display options in Credit Notes to support Amount, Percentage, or both.
* [Add] - Added Due Date functionality to invoice documents.
* [Tweak] - Enabled automatic printing for dispatch labels across all order statuses.
* [Fix] - Fixed an issue preventing tax items from being added.
* [Compatibility] - WordPress 7.0
* [Compatibility] - WooCommerce 10.6.2

= 1.7.4 2026-02-25 =
* [Fix] – Resolved product name translation issue in invoice document.
* [Tweak] - Optimize PDF generation by embedding images as base64.
* [Compatibility] - WooCommerce 10.5.2

= 1.7.3 2026-02-11 =
* [Compatibility] – Tested OK with Plugin Check plugin. 
* [Compatibility] - WooCommerce 10.5.1
* [Compatibility] - WordPress 6.9.1

= 1.7.2 2025-12-19 =
* [Fix] - Prevent duplicated payment link instructions in customer on-hold emails.
* [Fix] - Remove duplicated GTIN from the invoice document.
* [Tweak] - Display additional custom fields under the shipping address instead of the billing address for block checkout.
* [Compatibility] - Tested OK with WordPress 6.9
* [Compatibility] - Tested OK with WooCommerce 10.4.2

= 1.7.1 2025-11-14 =
* [Fix] - Fixed PHP fatal error: Uncaught Error: Call to undefined function wp_verify_nonce().
* [Fix] - Resolved the "Order properties should not be accessed directly" warning that occurred when placing an order.
* [Compatibility] - Tested OK with WooCommerce 10.3.5

= 1.7.0 2025-11-05 =
* [Fix] - Fixed mismatch between the selected template design and its preview. 
* [Fix] - Display the shipping address when the shipping method is Local Pickup.  
* [Fix] - Currency symbol missing for total tax and total tax not shown for partial refunds in credit note.
* [Fix] - Fixed jquery-tiptip deprecated warning.
* [Add] - Merged Remote PrintNode add-on functionality into the Invoice add-on. 
* [Add] - Added global unique ID (GTIN, UPC, EAN, or ISBN) as a product column in the Invoice document.
* [Add] - Implemented Cloud Storage module.
* [Add] - Displayed Print/Download Credit Note buttons for canceled orders. 
* [Add] - Added a filter to modify the discount type of Total Tax and Tax items in the product table.
* [Add] - Automatically install and activate the mPDF plugin when the user clicks the provided link.
* [Tweak] - Set the order status to 'On Hold' instead of 'Pending Payment' for orders placed via the Pay Later option.
* [Tweak] – Commented out the enqueue of public-facing JS and CSS files.
* [Compatibility] - Tested OK with WordPress 6.8.3
* [Compatibility] - Tested OK with WooCommerce 10.3.4

= 1.6.6 2025-07-23 =
* [Fix] – Fixed packing slip footer missing issue.
* [Fix] – Fixed critical error when downgraded the php version to 7.4.3.
* [Fix] – Parent SKU and Image displayed instead of Variation SKU and Variation Image in the Packing slip document.
* [Add] - Implemented annual invoice number reset on the 1st day of each selected month.
* [Add] - Remove Fee Total line when only one Fee is present in the Invoice document.
* [Tweak] - Set order status to "pending payment" instead of "on-hold" for orders placed via the pay later.
* [Compatibility] - Tested OK with WordPress 6.8.2
* [Compatibility] - Tested OK with WooCommerce 10.0.3

= 1.6.5 2025-05-21 =
* [Fix] – Fixed translation issue in the Dutch language.
* [Fix] – Translation loading was triggered too early.
* [Tweak] - Show “–” for non-taxable products and “0” when the tax amount is zero in the tax value field.
* [Compatibility] - Tested OK with WordPress 6.8.1
* [Compatibility] - Tested OK with WooCommerce 9.8.5

= 1.6.4 2025-03-13 =
* [Fix] - Resolved the issue where the update button in the Customizer was not enabling.
* [Fix] - notice: “Function wpdb::prepare was called incorrectly” on the report page issue.
* [Fix] - WooCommerce now falls back to get_post_meta() when meta data added via update_post_meta() isn't recognized.
* [Fix] - HPOS compatibility: The Print Credit Note button now appears on the WooCommerce order edit page by replacing get_refunds() with get_total_refunded().
* [Tweak]  - New Filter: wf_pklist_alter_product_before_packge_creation allows modifying the product object before package creation.
* [Tweak]  - wt_pklist_alter_language_file_name enables customization of the language file name before loading the domain file.
* [Enhancement] - WPML Compatibility: Translated dynamic strings are now retrieved using WPML filters, resolving footer and "From" address translation issues and enabling dynamic translation.
* [Enhancement] - Updated GDPA Banner
* [Compatibility] - Tested OK with WordPress 6.7.
* [Compatibility] - Tested OK with WooCommerce 9.7.1.

= 1.6.3 2024-12-19 =
* [Fix] - notice: “Function wpdb::prepare was called incorrectly” on the report page issue.
* [Fix] - “Export as Zip” button did not work when payment methods were selected in the report module.
* [Fix] - Pay Later instructions appearing twice on the order received page.
* [Fix] - The issue with notice: “Function _load_textdomain_just_in_time was called incorrectly.”
* [Tweak] - Filter added: “wt_pklist_packinglist_restrict_mail_trigger”.
* [Tweak - ]Ensured that total tax and tax items are displayed on credit notes, irrespective of tax settings.
* [Enhancement] - Invoice number layout changed.
* [Enhancement] - Invoice number preview layout changed.
* [Enhancement] - Added rename functionality to documents and changed the document layout in the Customize section.
* [Enhancement] - Added an option to set the date filter based on either the invoice date or the order date for the invoice document in the report module.
* [Compatibility] - Tested OK with WordPress v6.7.1.
* [Compatibility] - Tested OK with WooCommerce v9.4.3.

= 1.6.2 2024-09-26 =
* [Fix] - Print preview issue on mobile devices.
* [Compatibility] - Tested OK with WooCommerce v9.3.3

= 1.6.1 2024-08-28 =
* [Fix] - Resolved the issue where the automatic cleanup interval time could be set below 1440 minutes
* [Tweak] - Directly open the print window without showing a preview in the browser when the preview option is disabled
* [Tweak] - Added a notification message for the payment received stamp when the mPDF add-on is active
* [Tweak] - Defaulted the RTL support option to enabled
* [Compatibility] - Tested OK with WooCommerce v9.2.3

= 1.6.0 2024-07-22 =
* [New] - Added an option to use currency code instead of currency symbol in all documents
* [New] - Added an option to use an extended library to support the currency symbol
* [Tweak] - Hide unnecessary data when using the Smart Coupon Bogo feature by WebToffee
* [Tweak] - Remove the shipping address phone number label by default
* [Tweak] - Maintain consistency in line heights
* [Tweak] - Changed the document title color in all templates
* [Tweak] - Hide the "inclusive of tax" text when the order has no tax
* [Enhancement] - Decimal quantity support
* [Compatibility] - Tested OK with WordPress v6.6
* [Compatibility] - Tested OK with WooCommerce v9.1.2

= 1.5.1 2024-06-10 =
* [Fix] - Resolved issue where the total fee was displaying on individual fee descriptions when multiple fees were applied
* [Fix] - Fixed a division by zero error occurring when quantity becomes zero
* [Tweak] - Enhanced translation for better localization
* [Compatibility] - Tested OK with WooCommerce v8.9.2
* [Compatibility] - Tested OK with WordPress v6.5.4

= 1.5.0 2024-04-16 =
* [Fix] - When no prefix is specified, credit note names will default to "Creditnote_"
* [Add] - Implemented the report module
* [Add] - Included an automatic reset feature for invoice numbers in the invoice module
* [Enhancement] - Enhanced translation capabilities for smoother plugin and documentation translation
* [Compatibility] - Tested OK with WooCommerce v8.7.0
* [Compatibility] - Tested OK with WordPress v6.5.2

= 1.4.0 2024-03-14 =
* [Fix] - Resolved the error message "Uncaught Error: Interface" that occurred upon activating the plugin
* [Tweak] -Implemented user role restrictions to display the "Pay Later" payment gateway on the checkout page
* [Enhancement] - Updated the license manager with EDD updater functionality
* [Compatibility] - Tested OK with WooCommerce v8.6.1

= 1.3.0 2024-02-13 =
* [Tweak] - Hide the shipping address if it is empty
* [Tweak] - Hide the shipping address if order has the only local pickup as the shipping option
* [Enhancement] - WooCommerce Checkout block compatibility - Custom fields
* [Enhancement] - WooCommerce Checkout block compatibility - Paylater payment gateway
* [Compatibility] - Tested OK with WooCommerce v8.5.2

= 1.2.0 2024-01-17 =
* [Enhancement] - Added a filter to sort the category names when the group by category option is checked in the invoice and packing slip settings page
* [Enhancement] - Filter to alter the print and download document button label in email, my account order listing, and my account order details page
* [Enhancement] - Sync the Address format in the document with the WC formatted address
* [Compatibility] - Tested OK with WooCommerce v8.5.1

= 1.1.0 2023-12-11 =
* [Fix] - Remove str_contains() to avoid the PHP lower version error
* [Tweak] - Templates of invoices, packing slips, and credit notes are improved
* [Tweak] - Display the value of the checkout field added using this plugin on the order details page
* [Tweak] - Weight - Hide if it is 0 or not available
* [Enhancement] - Multi-language compatibility
* [Enhancement] - Option to skip to print the virtual items and back order items on the packing slip product table
* [Enhancement] - Display YITH gift card details on the invoice when applied to the order
* [Compatibility] - Tested OK with WooCommerce v8.3.1

= 1.0.6 2023-11-13 =
* [Fix] - Tax classes placeholder was shown even if there is no tax applied on the order
* [Add] - Added an option to show the vendor address on the vendor’s order documents if the dokan multi vendor plugin is active
* [Add] - Added an option to customize the credit note PDF document name
* [Enhancement] - Showed the deleted/imported products on the documents
* [Enhancement] - Updated the UI of invoice number format and credit note number format settings
* [Compatibility] - Added the compatibility with the WebToffee Email decorator and Kadence Email decorator plugins
* [Compatibility] - Tested okay with WordPress v6.4.1
* [Compatibility] - Tested okay with WooCommerce v8.2.2

= 1.0.5 2023-09-21 =
* [Compatibility] - Tested okay with WordPress v6.3.1
* [Compatibility] - Tested okay with WooCommerce v8.1.1

= 1.0.4 2023-09-06 =
* [Fix] - wf_pklist_alter_shipping_from_address filter is not working properly in invoice basic template with invoice add-on
* [Fix] - The value for order meta was not showing on the invoice when the ACF plugin was active
* [Fix] - Compatibility fatal error with the Kadence email customizer plugin
* [Fix] - Value not displayed when adding product meta as a separate column in the product table using the customizer add-on
* [Fix] - Plugin update check through the license manager
* [Fix] - Changing the file name for the packing slip
* [Fix] - Show the value for the regular price and regular total price column in the invoice and the packing slip when working with customizer add-on
* [Fix] - Updated and fixed the German translation issue
* [Tweak] - Added the support to show the value for the discount price column added through the customizer add-on
* [Enhancement] - The user can add product attributes as a separate column in the product table using the customizer add-on
* [Enhancement] - Displaying the bundle product depends on the packaging type and the bundle product display option in the packing slip
* [Enhancement] - Improved the translation
* [Compatibility] - Tested okay with the customizer add-on v1.0.1
* [Compatibility] - Tested okay with WordPress v6.3.1
* [Compatibility] - Tested okay with WooCommerce v8.0.3

= 1.0.3 2023-07-07 =
* [Tweak] - Added customer note, VAT, and SSN as separate placeholders in the templates
* [Tweak] - Added Save and Activate button in the Invoice, Packing slip, and Credit note customizer
* [Enhancement] - Optimized loading time when bulk printing the documents
* [Enhancement] - Icons to identify whether an invoice or packing slip is already printed or downloaded
* [Enhancement] - Added compatibility with WooCommerce High-Performance Order Storage (HPOS) Table feature
* [Enhancement] - Moved the default order meta fields such as email, phone number, customer note, VAT, and SSN from the Settings page to the Customizer
* [Enhancement] - Added compatibility with Customizer for WooCommerce PDF Invoices add-on (Pro) by WebToffee
* [Compatibility] - Tested OK with WooCommerce v7.8.2

= 1.0.2 2023-03-06 =
* [Fix] - CRITICAL Uncaught Error: Access to an undeclared static property of $return_dummy_invoice_number variable
* [Fix] - The order meta option in the packing slip - advanced tab could not be saved
* [Fix] - Unable to hide the tax items column in product table
* [Tweak] - Notify the user when using the basic template in the pro-add-on or when using the premium template in the basic plugin
* [Compatibility] - Compatibility with WooCommerce upto v7.4.1

= 1.0.1 =
* [Fix] - Added the placeholder for the payment received a stamp for the premium invoice templates
* [Fix] - SKU Based sorting was not working properly when SKUs are numerical order
* [Tweak] - Added a filter to use the billing address as the shipping address or hide the shipping address field when the shipping address is empty
* [Enhancement] - Added an option to create the credit notes for the chosen orders statuses only if the respective order has any refund
* [Enhancement] - Added an option to create credit notes manually from the order details page if the order has any refund
* [Compatibility] - Added the compatibility of the print node add-on from v1.0.4
* [Compatibility] - with WC v7.3.0

= 1.0.0 =
* Initial version

== Upgrade Notice ==

= 1.7.5 =
* [Add] - Added support for using a custom meta key/tracking number as the barcode value.
* [Add] - Extended 'Item Tax' and 'Total Tax' display options in Credit Notes to support Amount, Percentage, or both.
* [Add] - Added Due Date functionality to invoice documents.
* [Tweak] - Enabled automatic printing for dispatch labels across all order statuses.
* [Fix] - Fixed an issue preventing tax items from being added.
* [Compatibility] - WordPress 7.0
* [Compatibility] - WooCommerce 10.6.2