<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName
/**
 * YITH WooCommerce Ajax Search plugin support
 *
 * @author  YITH <plugins@yithemes.com>
 * @package YITH\AjaxProductFilter\Classes\Compatibility
 * @version 5.12.0
 */

if ( ! defined( 'YITH_WCAN' ) ) {
	exit;
} // Exit if accessed directly

if ( ! class_exists( 'YITH_WCAN_Ajax_Search_Compatibility' ) ) {
	/**
	 * Class that implements methods required to integrate Ajax Search and filter in overlay template
	 *
	 * @since 5.12.0
	 */
	class YITH_WCAN_Ajax_Search_Compatibility {

		/**
		 * Main instance
		 *
		 * @var YITH_WCAN_Ajax_Search_Compatibility
		 * @since 5.12.0
		 */
		protected static $instance = null;

		public $my_filter_function       = null;
		public $my_custom_query_function = null;

		/**
		 * Init integration, hooking all required methods
		 *
		 * @return void
		 */
		public function init() {
			// clear transients when C&L options change.
			add_action( 'yith_wcan_before_render_filter', array( $this, 'ajax_before_render_filter' ) );
			add_action( 'yith_wcan_after_render_filter', array( $this, 'ajax_after_render_filter' ) );
			add_filter( 'yith_wcan_shortcodes_script_args', array( $this, 'add_script_args' ), 999 );
		}

		/**
		 * Add custom hooks to get the right filter with the current search
		 *
		 * @return void
		 */
		public function ajax_before_render_filter() {
			$product_ids    = isset( $_REQUEST['_product_ids'] ) ? $_REQUEST['_product_ids'] : [];
			$current_search = isset( $_REQUEST['_ywcas_search'] ) ? sanitize_text_field( $_REQUEST['_ywcas_search'] ) : '';

			$this->my_filter_function = function ( $query ) use ( $product_ids ) {
				$query['post__in'] = $product_ids;

				return $query;
			};

			$this->my_custom_query_function = function ( $query_vars ) use ( $current_search ) {
				$query_vars['ywcas_search'] = $current_search;

				return $query_vars;
			};
			if ( count( $product_ids ) > 0 || ! empty( $current_search ) ) {
				add_filter( 'yith_wcan_filter_tax_get_term_children_count', '__return_false', 999 );
				add_filter( 'yith_wcan_filtered_products_query', $this->my_filter_function, 999 );
				add_filter( 'yith_wcan_query_vars_for_cache_index', $this->my_custom_query_function, 999 );
			}
		}

		/**
		 * Remove the custom hooks
		 *
		 * @return void
		 */
		public function ajax_after_render_filter() {
			$product_ids    = isset( $_REQUEST['_product_ids'] ) ? $_REQUEST['_product_ids'] : [];
			$current_search = isset( $_REQUEST['_ywcas_search'] ) ? sanitize_text_field( $_REQUEST['_ywcas_search'] ) : '';
			if ( count( $product_ids ) > 0 || ! empty( $current_search ) ) {
				remove_filter( 'yith_wcan_filter_tax_get_term_children_count', '__return_false', 999 );
				remove_filter( 'yith_wcan_query_vars_for_cache_index', $this->my_filter_function, 999 );
				remove_filter( 'yith_wcan_filtered_products_query', $this->my_custom_query_function, 999 );
			}
		}


		/**
		 * Add custom script args
		 *
		 * @param array $args The script args.
		 *
		 * @return array
		 */
		public function add_script_args( $args ) {

			$args['active_filters_position'] = get_option( 'yith_wcan_active_labels_position', 'before_filters' );
			$args['reset_button_position']   = get_option( 'yith_wcan_reset_button_position', 'after_filters' );

			$args['urls']['render_active_filters'] = WC_AJAX::get_endpoint( 'yith_wcan_render_active_filters' );

			$args['nonces']['render_active_filters'] = wp_create_nonce( 'render_active_filters' );

			if ( isset( $_GET['ywcas'] ) ) {
				$args['change_browser_url'] = false;
			}

			return $args;
		}

		/**
		 * Compatibility class instance
		 *
		 * @return YITH_WCAN_Ajax_Search_Compatibility Class unique instance
		 */
		public static function instance() {

			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}
	}
}

// init compatibility.
if ( defined( 'YITH_WCAS_PREMIUM' ) ) {
	YITH_WCAN_Ajax_Search_Compatibility::instance()->init();
}
