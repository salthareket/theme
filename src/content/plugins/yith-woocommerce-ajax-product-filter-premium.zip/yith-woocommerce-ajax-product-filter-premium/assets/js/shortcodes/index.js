'use strict';

/* global globalThis, jQuery, yith_wcan_shortcodes, accounting */

import YITH_WCAN_Filter from './modules/yith-wcan-filter';
import YITH_WCAN_Filter_Labels from './modules/yith-wcan-filter-labels';
import YITH_WCAN_Reset_Button from './modules/yith-wcan-reset-button';
import YITH_WCAN_Modal_Opener from './modules/yith-wcan-modal-opener';
import YITH_WCAN_Preset from './modules/yith-wcan-preset-premium';

jQuery( function ( $ ) {
	let filters = [];
	const initFilters = ( extra = false ) => {
		if ( extra ) {
			initFilterOverlay( extra );
		} else {
			jQuery( '.yith-wcan-filters' )
				.not( '.enhanced' )
				.each( function () {
					new YITH_WCAN_Preset( jQuery( this ) );
				} );

			jQuery( '.yith-wcan-active-filters' )
				.not( '.enhanced' )
				.each( function () {
					new YITH_WCAN_Filter_Labels( jQuery( this ) );
				} );

			jQuery( '.yith-wcan-reset-filters' )
				.not( '.enhanced' )
				.each( function () {
					new YITH_WCAN_Reset_Button( jQuery( this ) );
				} );

			jQuery( '.yith-wcan-filters-opener' )
				.not( '.enhanced' )
				.each( function () {
					new YITH_WCAN_Modal_Opener( jQuery( this ) );
				} );
		}
	};

	const initFilterOverlay = ( extra ) => {
		const parent = $( document ).find( '.ywcas-overlay-wrapper-search' );

		parent
			.find( '.yith-wcan-filters' )
			.not( '.enhanced' )
			.each( function () {
				filters.push( new YITH_WCAN_Preset( $( this ), extra ) );
			} );

		$.ajax( {
			method: 'GET',
			url: yith_wcan_shortcodes.base_url,
			data: {
				'wc-ajax': 'yith_wcan_render_active_filters',
				security: yith_wcan_shortcodes.nonces.render_active_filters,
				_preset_filters: extra?.filters ?? [],
			},
			success( response ) {
				if ( response.success ) {
					const active = initActiveLabels( response.data, parent );
					initResetButton( response.data, parent, active > 0 );
				}
			},
		} );
	};

	const initActiveLabels = ( data, parent ) => {
		let position = yith_wcan_shortcodes.active_filters_position;
		const active_filters = data.active_filters;
		const presets = Object.keys( active_filters );

		presets.forEach( ( preset ) => {
			const template = active_filters[ preset ];
			const parentDiv =
				'before_products' !== position
					? parent
							.find( '#preset_' + preset )
							.find( '.filters-container form' )
					: parent.find(
							'.ywcas-overlay-filled-content .ywcas-overlay-grid-block'
					  );

			if ( parentDiv ) {
				if (
					'before_filters' === position ||
					'before_products' === position
				) {
					parentDiv.prepend( template );
				} else {
					parentDiv.append( template );
				}
			}
		} );
		parent
			.find( '.yith-wcan-active-filters' )
			.not( '.enhanced' )
			.each( function () {
				new YITH_WCAN_Filter_Labels( jQuery( this ) );
			} );

		return presets.length;
	};

	const initResetButton = ( data, parent, show ) => {
		let position = yith_wcan_shortcodes.reset_button_position;

		const button = data.reset_button,
			parentDiv =
				'before_products' !== position
					? parent.find( '.filters-container form' )
					: parent.find(
							'.ywcas-overlay-filled-content .ywcas-overlay-grid-block'
					  );
		parent.find( '.yith-wcan-reset-filters' ).remove();
		if ( parentDiv && show ) {
			if (
				'before_filters' === position ||
				'before_products' === position
			) {
				parentDiv.prepend( button );
			} else if ( 'after_filters' === position ) {
				parentDiv.append( button );
			} else {
				parent.find( '.yith-wcan-active-filters' ).append( button );
			}
		}
		parent
			.find( '.yith-wcan-reset-filters' )
			.not( '.enhanced' )
			.each( function () {
				new YITH_WCAN_Reset_Button( jQuery( this ) );
			} );
	};
	const maybeResetFilters = () => {
		const parent = $( document ).find( '.ywcas-overlay-filled-content' );
		parent.find( '.yith-wcan-filters' ).removeClass( 'enhanced' );
		parent.find( '.yith-wcan-active-filters' ).remove();
		parent.find( '.yith-wcan-reset-filters' ).remove();
		filters = [];
	};

	$( document )
		.on( 'yith_wcan_init_shortcodes', function ( e ) {
			console.log( e );
			initFilters();
		} )
		.trigger( 'yith_wcan_init_shortcodes' );

	$( document ).on(
		'yith_plugin_fw_gutenberg_success_do_shortcode',
		function ( e, shortcode ) {
			if ( shortcode.startsWith( '[yith_wcan_' ) ) {
				initFilters();
			}
		}
	);
	globalThis.product_filter = new YITH_WCAN_Filter();

	window.addEventListener( 'ywcasSearchCompleted', function ( e ) {
		if ( ! e.detail.isSearching ) {
			maybeResetFilters();
			initFilters( e.detail );
		}
	} );

	$( document ).on( 'yith_wcan_filter_updated', function ( e ) {
		let active_filters = {};

		filters.forEach( function ( filter ) {
			active_filters = $.extend(
				active_filters,
				filter.getFiltersProperties()
			);
		} );

		const event = new CustomEvent( 'ywcanFilterChanged', {
			detail: {
				filters: active_filters,
			},
		} );
		window.dispatchEvent( event );
	} );
} );
