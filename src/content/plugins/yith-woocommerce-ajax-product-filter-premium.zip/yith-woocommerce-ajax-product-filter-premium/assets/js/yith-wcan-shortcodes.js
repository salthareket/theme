/******/ (() => { // webpackBootstrap
/******/ 	"use strict";

;// ./assets/js/shortcodes/globals.js


/* global globalThis, jQuery, yith_wcan_shortcodes, accounting */
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
var $ = jQuery,
  // we can do this as WebPack will compact all together inside a closure.
  $body = $('body'),
  globals_block = function block($el) {
    var _yith_wcan_shortcodes;
    if (typeof $.fn.block === 'undefined') {
      return;
    }
    var background = '#fff center center no-repeat';
    if ('undefined' !== typeof yith_wcan_shortcodes && (_yith_wcan_shortcodes = yith_wcan_shortcodes) !== null && _yith_wcan_shortcodes !== void 0 && _yith_wcan_shortcodes.loader) {
      background = "url('".concat(yith_wcan_shortcodes.loader, "') ").concat(background);
    }
    $el.block({
      message: null,
      overlayCSS: {
        background: background,
        opacity: 0.7
      }
    });
  },
  globals_unblock = function unblock($el) {
    if (typeof $.fn.unblock === 'undefined') {
      return;
    }
    $el.unblock();
  },
  serialize = function serialize($el, _ref) {
    var formatName = _ref.formatName,
      filterItems = _ref.filterItems;
    var result = {},
      inputs = $el.find(':input').not('[disabled]');
    if (typeof filterItems === 'function') {
      inputs = inputs.filter(filterItems);
    }
    inputs.each(function () {
      var t = $(this),
        name = t.attr('name'),
        value;
      if (!name) {
        return;
      }

      // removes ending brackets, since are not needed
      name = name.replace(/^(.*)\[]$/, '$1');

      // offers additional name formatting from invoker
      if (typeof formatName === 'function') {
        name = formatName(name);
      }

      // retrieve value, depending on input type
      if (t.is('[type="radio"]') && !t.is(':checked')) {
        return;
      }
      value = t.val();

      // if name is composite, try to recreate missing structure
      if (-1 !== name.indexOf('[')) {
        var components = name.split('[').map(function (c) {
            return c.replace(/[\[, \]]/g, '');
          }),
          firstComponent = components.shift(),
          newItem = components.reverse().reduce(function (res, key) {
            return _defineProperty({}, key, res);
          }, value);
        if (typeof result[firstComponent] === 'undefined') {
          result[firstComponent] = newItem;
        } else {
          result[firstComponent] = $.extend(true, result[firstComponent], newItem);
        }
      }
      // else simply append value to result object
      else {
        result[name] = value;
      }
    });
    return result;
  },
  removeHierarchyFromString = function removeHierarchyFromString(value) {
    return value.replace(/^(.*>)([^>]+)$/, '$2').replace('&amp;', '&').trim();
  },
  keys = {
    esc: 27,
    enter: 32,
    space: 13,
    up: 38,
    down: 40
  };

;// ./assets/js/shortcodes/modules/yith-wcan-filter.js


/* global globalThis, jQuery, yith_wcan_shortcodes, accounting */
function yith_wcan_filter_typeof(o) { "@babel/helpers - typeof"; return yith_wcan_filter_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, yith_wcan_filter_typeof(o); }
function _classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function _defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, yith_wcan_filter_toPropertyKey(o.key), o); } }
function _createClass(e, r, t) { return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function yith_wcan_filter_defineProperty(e, r, t) { return (r = yith_wcan_filter_toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function yith_wcan_filter_toPropertyKey(t) { var i = yith_wcan_filter_toPrimitive(t, "string"); return "symbol" == yith_wcan_filter_typeof(i) ? i : i + ""; }
function yith_wcan_filter_toPrimitive(t, r) { if ("object" != yith_wcan_filter_typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != yith_wcan_filter_typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }

var YITH_WCAN_Filter = /*#__PURE__*/function () {
  // init object
  function YITH_WCAN_Filter() {
    _classCallCheck(this, YITH_WCAN_Filter);
    // currently executing xhr
    yith_wcan_filter_defineProperty(this, "xhr", null);
    // flag set during ajax call handling
    yith_wcan_filter_defineProperty(this, "doingAjax", false);
    // register original url search param
    yith_wcan_filter_defineProperty(this, "originalSearch", location.search);
    // flag set once init has executed
    yith_wcan_filter_defineProperty(this, "initialized", false);
    // flag set when page has at least one active filter.
    yith_wcan_filter_defineProperty(this, "filtered", false);
    this.initPopState();
    this.initialized = true;
  }

  // init page reload when popstate event alter filters
  return _createClass(YITH_WCAN_Filter, [{
    key: "initPopState",
    value: function initPopState() {
      if (!yith_wcan_shortcodes.reload_on_back) {
        return;
      }
      this.pushUrlToHistory(window.location, document.title, null, true);
      $(window).on('popstate', function () {
        var _window$history$state;
        if (!((_window$history$state = window.history.state) !== null && _window$history$state !== void 0 && _window$history$state._yithWcan)) {
          return;
        }
        window.location.reload(true);
      });
    }

    // execute call to filter products in current view
  }, {
    key: "doFilter",
    value: function doFilter(filters, target, preset) {
      var _this = this;
      var targetUrl,
        $target = target ? $(target) : $('body'),
        customFilters;

      // filter properties
      customFilters = $(document).triggerHandler('yith_wcan_filters_parameters', [filters]);
      if (!!customFilters) {
        filters = customFilters;
      }

      // block elements before filtering
      $target && this.block($target);

      // calculate target url
      targetUrl = this.buildUrl(filters);

      // if no ajax, simply change page url
      if (!yith_wcan_shortcodes.ajax_filters) {
        this.pushUrlToHistory(targetUrl, document.title, filters);
        window.location = targetUrl;
        return;
      }

      // start doing ajax
      this.doingAjax = true;
      return this._doAjax(targetUrl).done(function (response) {
        targetUrl = _this.searchAlternativeUrl(response, targetUrl);
        _this._beforeFilter(response, filters);
        _this.refreshFragments(target, preset, response);
        _this.pushUrlToHistory(targetUrl, response.pageTitle, filters);
        _this.originalSearch = location.search;
        $target && _this.unblock($target);
        _this._afterFilter(response, filters);
        _this.doingAjax = false;
      });
    }

    // actions performed before filter
  }, {
    key: "_beforeFilter",
    value: function _beforeFilter(response, filters) {
      $(document).trigger('yith-wcan-ajax-loading', [response, filters]);
      yith_wcan_shortcodes.query_vars = filters;
    }

    // actions performed after filter
  }, {
    key: "_afterFilter",
    value: function _afterFilter(response, filters) {
      $('.woocommerce-ordering').on('change', 'select.orderby', function () {
        $(this).closest('form').submit();
      });
      this.filtered = filters && !!Object.keys(filters).length;
      this.filtered ? $body.addClass('filtered') : $body.removeClass('filtered');
      $(window).trigger('scroll');
      $(document).trigger('yith-wcan-ajax-filtered', [response, filters]).trigger('yith_wcwl_reload_after_ajax');
    }

    // build url to show
  }, {
    key: "buildUrl",
    value: function buildUrl(filters) {
      var _this2 = this;
      var queryParam = yith_wcan_shortcodes.query_param,
        params = {},
        location = window.location,
        url = !!yith_wcan_shortcodes.base_url ? yith_wcan_shortcodes.base_url : (location === null || location === void 0 ? void 0 : location.origin) + (location === null || location === void 0 ? void 0 : location.pathname),
        search = '',
        self = this;
      var haveFilters = yith_wcan_filter_typeof(filters) === 'object' && Object.keys(filters).length;

      // remove filter session from current url, if any
      if (!!yith_wcan_shortcodes.session_param) {
        url = url.replace(new RegExp('/' + yith_wcan_shortcodes.session_param + '/[^/]*/'), '');
      }
      if (haveFilters) {
        params[queryParam] = 1;
      }
      if (!!this.originalSearch) {
        var searchParams = this.originalSearch.replace('?', '').split('&').reduce(function (a, v) {
          var items = v.split('=');
          if (items.length === 2) {
            if (_this2.isFilterParam(items[0])) {
              return a;
            }
            a[items[0]] = items[1];
          }
          return a;
        }, {});
        params = $.extend(params, searchParams);
      }
      if (haveFilters) {
        params = $.extend(params, filters);
      }
      search = Object.keys(params).reduce(function (a, i) {
        var v = params[i];
        if (!v || !i) {
          return a;
        }
        a += self._cleanParam(i) + '=' + self._cleanParam(v) + '&';
        return a;
      }, '?').replace(/&$/g, '').replace(/%2B/g, '+').replace(/%2C/g, ',');
      if (search.length > 1) {
        url += search;
      }
      return url;
    }

    // retrieves alternative sharing url in response body
  }, {
    key: "searchAlternativeUrl",
    value: function searchAlternativeUrl(response) {
      var defaultUrl = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
      var url = defaultUrl,
        matches;
      if (-1 === response.indexOf('yith_wcan:sharing_url')) {
        return url;
      }
      matches = response.match(/<meta name="yith_wcan:sharing_url" content="([^"]*)">/);
      url = matches && 1 in matches ? matches[1] : url;
      return url;
    }

    // push url to browser history
  }, {
    key: "pushUrlToHistory",
    value: function pushUrlToHistory(url, title, filters, current) {
      if (!yith_wcan_shortcodes.change_browser_url || navigator.userAgent.match(/msie/i)) {
        return;
      }
      var method = 'pushState';
      if (!!current) {
        method = 'replaceState';
      }
      window.history[method]({
        _yithWcan: true,
        pageTitle: title,
        filters: filters
      }, '', url);
    }

    // replaces elements in the page with refreshed ones
  }, {
    key: "refreshFragments",
    value: function refreshFragments(target, preset, response) {
      var responseDom = document.createElement('html'),
        $response = $(responseDom);
      responseDom.innerHTML = response;
      if (target) {
        var $preset = $(preset),
          $target = $(target),
          $destination;
        if ($preset.length) {
          $destination = $response.find(preset);
          if ($destination.length) {
            $preset.replaceWith($destination.first());
          }
        }
        if ($target.length) {
          $destination = $response.find(target);
          if ($destination.length) {
            $target.replaceWith($destination.first());
          }
        }
      } else {
        var content = $(yith_wcan_shortcodes.content);
        if (content.length) {
          content.replaceWith($response.find(yith_wcan_shortcodes.content));
        } else {
          $('body').replaceWith($response.find('body'));
        }
      }
      $(document).trigger('yith_wcan_init_shortcodes');
    }

    // clean url parameters
  }, {
    key: "_cleanParam",
    value: function _cleanParam(param) {
      var _yith_wcan_shortcodes, _yith_wcan_shortcodes2;
      if (!((_yith_wcan_shortcodes = yith_wcan_shortcodes) !== null && _yith_wcan_shortcodes !== void 0 && _yith_wcan_shortcodes.process_sanitize) || (_yith_wcan_shortcodes2 = yith_wcan_shortcodes) !== null && _yith_wcan_shortcodes2 !== void 0 && _yith_wcan_shortcodes2.skip_sanitize) {
        return param;
      }
      return encodeURIComponent(param);
    }

    // executes Ajax calls
  }, {
    key: "_doAjax",
    value: function _doAjax(url, params) {
      if (this.xhr) {
        this.xhr.abort();
      }
      params = $.extend({
        url: url,
        headers: {
          'X-YITH-WCAN': 1
        }
      }, params);
      this.xhr = $.ajax(params);
      return this.xhr;
    }

    // block dom elements
  }, {
    key: "block",
    value: function block($el) {
      return globals_block($el);
    }

    // unblock dom elements
  }, {
    key: "unblock",
    value: function unblock($el) {
      return globals_unblock($el);
    }

    // checks if param is one used by layared nav to filter products.
  }, {
    key: "isFilterParam",
    value: function isFilterParam(param) {
      var supportedParams = ['rating_filter', 'min_price', 'max_price', 'price_ranges', 'onsale_filter', 'instock_filter', 'featured_filter', 'orderby', 'product-page', yith_wcan_shortcodes.query_param],
        customParams;

      // filter properties
      customParams = $(document).triggerHandler('yith_wcan_supported_filters_parameters', [supportedParams]);
      if (!!customParams) {
        supportedParams = customParams;
      }
      supportedParams = supportedParams.concat(yith_wcan_shortcodes.supported_taxonomies.map(function (i) {
        return i.replace('pa_', 'filter_');
      }));
      if (-1 !== supportedParams.indexOf(param)) {
        return true;
      }
      if (-1 !== param.indexOf('filter_')) {
        return true;
      }
      if (-1 !== param.indexOf('query_type_')) {
        return true;
      }
      return false;
    }
  }]);
}();

;// ./assets/js/shortcodes/modules/yith-wcan-filter-labels.js


/* global globalThis, jQuery, yith_wcan_shortcodes, accounting */
function yith_wcan_filter_labels_typeof(o) { "@babel/helpers - typeof"; return yith_wcan_filter_labels_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, yith_wcan_filter_labels_typeof(o); }
function yith_wcan_filter_labels_classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function yith_wcan_filter_labels_defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, yith_wcan_filter_labels_toPropertyKey(o.key), o); } }
function yith_wcan_filter_labels_createClass(e, r, t) { return r && yith_wcan_filter_labels_defineProperties(e.prototype, r), t && yith_wcan_filter_labels_defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function yith_wcan_filter_labels_defineProperty(e, r, t) { return (r = yith_wcan_filter_labels_toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function yith_wcan_filter_labels_toPropertyKey(t) { var i = yith_wcan_filter_labels_toPrimitive(t, "string"); return "symbol" == yith_wcan_filter_labels_typeof(i) ? i : i + ""; }
function yith_wcan_filter_labels_toPrimitive(t, r) { if ("object" != yith_wcan_filter_labels_typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != yith_wcan_filter_labels_typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }

var YITH_WCAN_Filter_Labels = /*#__PURE__*/function () {
  // init object
  function YITH_WCAN_Filter_Labels(el) {
    var extra = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    yith_wcan_filter_labels_classCallCheck(this, YITH_WCAN_Filter_Labels);
    // current label set
    yith_wcan_filter_labels_defineProperty(this, "$label_set", null);
    // labels of current set
    yith_wcan_filter_labels_defineProperty(this, "$labels", false);
    yith_wcan_filter_labels_defineProperty(this, "withAjaxSearch", false);
    // current label set
    this.$label_set = el;
    this._initLabels();
    this.withAjaxSearch = extra !== false;
    this.$label_set.data('filter_labels', this).addClass('enhanced');
  }

  // init labels
  return yith_wcan_filter_labels_createClass(YITH_WCAN_Filter_Labels, [{
    key: "_initLabels",
    value: function _initLabels() {
      var self = this;
      this.getLabels().each(function () {
        var $label = $(this);
        self._initLabel($label);
      });
    }

    // init label
  }, {
    key: "_initLabel",
    value: function _initLabel($label) {
      var _this = this;
      $label.on('click', function (ev) {
        if (_this.disableLabel($label)) {
          ev.preventDefault();
        }
      });
    }

    // get labels
  }, {
    key: "getLabels",
    value: function getLabels() {
      if (false === this.$labels) {
        this.$labels = this.$label_set.find('.active-filter-label');
      }
      return this.$labels;
    }

    // disable filter
  }, {
    key: "disableLabel",
    value: function disableLabel($label) {
      var properties = $label.data('filters');
      var result = false;

      // search for preset
      $('.yith-wcan-filters').each(function () {
        var preset = $(this).data('preset');
        result = result || preset.deactivateFilterByProperties(properties, true);
      });
      return result;
    }
  }]);
}();

;// ./assets/js/shortcodes/modules/yith-wcan-reset-button.js


/* global globalThis, jQuery, yith_wcan_shortcodes, accounting */
function yith_wcan_reset_button_typeof(o) { "@babel/helpers - typeof"; return yith_wcan_reset_button_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, yith_wcan_reset_button_typeof(o); }
function yith_wcan_reset_button_defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, yith_wcan_reset_button_toPropertyKey(o.key), o); } }
function yith_wcan_reset_button_createClass(e, r, t) { return r && yith_wcan_reset_button_defineProperties(e.prototype, r), t && yith_wcan_reset_button_defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function yith_wcan_reset_button_classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function yith_wcan_reset_button_defineProperty(e, r, t) { return (r = yith_wcan_reset_button_toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function yith_wcan_reset_button_toPropertyKey(t) { var i = yith_wcan_reset_button_toPrimitive(t, "string"); return "symbol" == yith_wcan_reset_button_typeof(i) ? i : i + ""; }
function yith_wcan_reset_button_toPrimitive(t, r) { if ("object" != yith_wcan_reset_button_typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != yith_wcan_reset_button_typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }

var YITH_WCAN_Reset_Button = /*#__PURE__*/yith_wcan_reset_button_createClass(
// init object
function YITH_WCAN_Reset_Button(el) {
  yith_wcan_reset_button_classCallCheck(this, YITH_WCAN_Reset_Button);
  // current button
  yith_wcan_reset_button_defineProperty(this, "$reset", null);
  // current button
  this.$reset = el;
  this.$reset.on('click', function (ev) {
    ev.preventDefault();
    $('.yith-wcan-filters').each(function () {
      var preset = $(this).data('preset');
      preset.deactivateAllFilters(true);
      preset.closeModal();
    });
  });
  this.$reset.data('reset', this).addClass('enhanced');
});

;// ./assets/js/shortcodes/modules/yith-wcan-modal-opener.js


/* global globalThis, jQuery, yith_wcan_shortcodes, accounting */
function yith_wcan_modal_opener_typeof(o) { "@babel/helpers - typeof"; return yith_wcan_modal_opener_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, yith_wcan_modal_opener_typeof(o); }
function yith_wcan_modal_opener_classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function yith_wcan_modal_opener_defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, yith_wcan_modal_opener_toPropertyKey(o.key), o); } }
function yith_wcan_modal_opener_createClass(e, r, t) { return r && yith_wcan_modal_opener_defineProperties(e.prototype, r), t && yith_wcan_modal_opener_defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function yith_wcan_modal_opener_defineProperty(e, r, t) { return (r = yith_wcan_modal_opener_toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function yith_wcan_modal_opener_toPropertyKey(t) { var i = yith_wcan_modal_opener_toPrimitive(t, "string"); return "symbol" == yith_wcan_modal_opener_typeof(i) ? i : i + ""; }
function yith_wcan_modal_opener_toPrimitive(t, r) { if ("object" != yith_wcan_modal_opener_typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != yith_wcan_modal_opener_typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }

var YITH_WCAN_Modal_Opener = /*#__PURE__*/function () {
  // init object
  function YITH_WCAN_Modal_Opener(el) {
    yith_wcan_modal_opener_classCallCheck(this, YITH_WCAN_Modal_Opener);
    // current button
    yith_wcan_modal_opener_defineProperty(this, "$button", null);
    // YITH_WCAN_Preset object
    yith_wcan_modal_opener_defineProperty(this, "preset", null);
    // preset dom node
    yith_wcan_modal_opener_defineProperty(this, "$preset", null);
    // is mobile flag
    yith_wcan_modal_opener_defineProperty(this, "isMobile", false);
    // current button
    this.$button = el;
    this._initPreset();
    this._initResponsive();
    this._initActions();
    this.$button.data('modalOpener', this).addClass('enhanced');
  }

  // search for related preset
  return yith_wcan_modal_opener_createClass(YITH_WCAN_Modal_Opener, [{
    key: "_initPreset",
    value: function _initPreset() {
      var target = this.$button.data('target'),
        $target;
      if (target) {
        $target = $("#".concat(target));
      } else {
        $target = $('.yith-wcan-filters');
      }
      if (!$target.length) {
        return;
      }
      this.$preset = $target.first();
      this.preset = this.$preset.data('preset');
    }

    // init responsive
  }, {
    key: "_initResponsive",
    value: function _initResponsive() {
      var _this = this;
      if (!yith_wcan_shortcodes.modal_on_mobile || !this.preset) {
        this.$button.hide();
        return;
      }
      var media = window.matchMedia("(max-width: ".concat(yith_wcan_shortcodes.mobile_media_query, "px)"));
      $(window).on('resize', function () {
        var isMobile = !!media.matches;
        if (isMobile !== _this.isMobile) {
          _this.isMobile = isMobile;
          _this._afterLayoutChange();
        }
      }).resize();
    }

    // init actions
  }, {
    key: "_initActions",
    value: function _initActions() {
      var _this$$preset;
      if (!((_this$$preset = this.$preset) !== null && _this$$preset !== void 0 && _this$$preset.length)) {
        return;
      }
      var self = this;
      this.$button.on('click', function (ev) {
        ev.preventDefault();
        self.preset.openModal();
      });
    }

    // hide/show button when needed
  }, {
    key: "_afterLayoutChange",
    value: function _afterLayoutChange() {
      this.isMobile ? this.$button.show() : this.$button.hide();
    }
  }]);
}();

;// ./assets/js/shortcodes/modules/yith-wcan-dropdown.js


/* global globalThis, jQuery, yith_wcan_shortcodes, accounting */
function yith_wcan_dropdown_typeof(o) { "@babel/helpers - typeof"; return yith_wcan_dropdown_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, yith_wcan_dropdown_typeof(o); }
function _toConsumableArray(r) { return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _iterableToArray(r) { if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r); }
function _arrayWithoutHoles(r) { if (Array.isArray(r)) return _arrayLikeToArray(r); }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function _regenerator() { /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE */ var e, t, r = "function" == typeof Symbol ? Symbol : {}, n = r.iterator || "@@iterator", o = r.toStringTag || "@@toStringTag"; function i(r, n, o, i) { var c = n && n.prototype instanceof Generator ? n : Generator, u = Object.create(c.prototype); return _regeneratorDefine2(u, "_invoke", function (r, n, o) { var i, c, u, f = 0, p = o || [], y = !1, G = { p: 0, n: 0, v: e, a: d, f: d.bind(e, 4), d: function d(t, r) { return i = t, c = 0, u = e, G.n = r, a; } }; function d(r, n) { for (c = r, u = n, t = 0; !y && f && !o && t < p.length; t++) { var o, i = p[t], d = G.p, l = i[2]; r > 3 ? (o = l === n) && (u = i[(c = i[4]) ? 5 : (c = 3, 3)], i[4] = i[5] = e) : i[0] <= d && ((o = r < 2 && d < i[1]) ? (c = 0, G.v = n, G.n = i[1]) : d < l && (o = r < 3 || i[0] > n || n > l) && (i[4] = r, i[5] = n, G.n = l, c = 0)); } if (o || r > 1) return a; throw y = !0, n; } return function (o, p, l) { if (f > 1) throw TypeError("Generator is already running"); for (y && 1 === p && d(p, l), c = p, u = l; (t = c < 2 ? e : u) || !y;) { i || (c ? c < 3 ? (c > 1 && (G.n = -1), d(c, u)) : G.n = u : G.v = u); try { if (f = 2, i) { if (c || (o = "next"), t = i[o]) { if (!(t = t.call(i, u))) throw TypeError("iterator result is not an object"); if (!t.done) return t; u = t.value, c < 2 && (c = 0); } else 1 === c && (t = i["return"]) && t.call(i), c < 2 && (u = TypeError("The iterator does not provide a '" + o + "' method"), c = 1); i = e; } else if ((t = (y = G.n < 0) ? u : r.call(n, G)) !== a) break; } catch (t) { i = e, c = 1, u = t; } finally { f = 1; } } return { value: t, done: y }; }; }(r, o, i), !0), u; } var a = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} t = Object.getPrototypeOf; var c = [][n] ? t(t([][n]())) : (_regeneratorDefine2(t = {}, n, function () { return this; }), t), u = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(c); function f(e) { return Object.setPrototypeOf ? Object.setPrototypeOf(e, GeneratorFunctionPrototype) : (e.__proto__ = GeneratorFunctionPrototype, _regeneratorDefine2(e, o, "GeneratorFunction")), e.prototype = Object.create(u), e; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, _regeneratorDefine2(u, "constructor", GeneratorFunctionPrototype), _regeneratorDefine2(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = "GeneratorFunction", _regeneratorDefine2(GeneratorFunctionPrototype, o, "GeneratorFunction"), _regeneratorDefine2(u), _regeneratorDefine2(u, o, "Generator"), _regeneratorDefine2(u, n, function () { return this; }), _regeneratorDefine2(u, "toString", function () { return "[object Generator]"; }), (_regenerator = function _regenerator() { return { w: i, m: f }; })(); }
function _regeneratorDefine2(e, r, n, t) { var i = Object.defineProperty; try { i({}, "", {}); } catch (e) { i = 0; } _regeneratorDefine2 = function _regeneratorDefine(e, r, n, t) { function o(r, n) { _regeneratorDefine2(e, r, function (e) { return this._invoke(r, n, e); }); } r ? i ? i(e, r, { value: n, enumerable: !t, configurable: !t, writable: !t }) : e[r] = n : (o("next", 0), o("throw", 1), o("return", 2)); }, _regeneratorDefine2(e, r, n, t); }
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
function yith_wcan_dropdown_classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function yith_wcan_dropdown_defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, yith_wcan_dropdown_toPropertyKey(o.key), o); } }
function yith_wcan_dropdown_createClass(e, r, t) { return r && yith_wcan_dropdown_defineProperties(e.prototype, r), t && yith_wcan_dropdown_defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function yith_wcan_dropdown_defineProperty(e, r, t) { return (r = yith_wcan_dropdown_toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function yith_wcan_dropdown_toPropertyKey(t) { var i = yith_wcan_dropdown_toPrimitive(t, "string"); return "symbol" == yith_wcan_dropdown_typeof(i) ? i : i + ""; }
function yith_wcan_dropdown_toPrimitive(t, r) { if ("object" != yith_wcan_dropdown_typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != yith_wcan_dropdown_typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }

var YITH_WCAN_Dropdown = /*#__PURE__*/function () {
  // init object
  function YITH_WCAN_Dropdown(el, opts) {
    var _yith_wcan_shortcodes, _yith_wcan_shortcodes2, _yith_wcan_shortcodes3, _yith_wcan_shortcodes4;
    yith_wcan_dropdown_classCallCheck(this, YITH_WCAN_Dropdown);
    // current button
    yith_wcan_dropdown_defineProperty(this, "$originalSelect", null);
    // list of current items.
    yith_wcan_dropdown_defineProperty(this, "_items", []);
    // main element
    yith_wcan_dropdown_defineProperty(this, "$_main", null);
    // label element
    yith_wcan_dropdown_defineProperty(this, "$_label", null);
    // dropdown
    yith_wcan_dropdown_defineProperty(this, "$_dropdown", null);
    // search input
    yith_wcan_dropdown_defineProperty(this, "$_search", null);
    // show more link
    yith_wcan_dropdown_defineProperty(this, "$_showMore", null);
    // items list
    yith_wcan_dropdown_defineProperty(this, "$_items", null);
    // whether select should paginate.
    yith_wcan_dropdown_defineProperty(this, "paginate", false);
    // whether select has more items than those shown.
    yith_wcan_dropdown_defineProperty(this, "hasMore", false);
    // whether items list needs update.
    yith_wcan_dropdown_defineProperty(this, "needsRefresh", true);
    // whether select is multiple
    yith_wcan_dropdown_defineProperty(this, "multiple", false);
    // current page
    yith_wcan_dropdown_defineProperty(this, "currentPage", 1);
    // options
    yith_wcan_dropdown_defineProperty(this, "options", {});
    this.$originalSelect = el;
    if (!this.$originalSelect.is('select')) {
      return;
    }
    var defaultPerPage = this.$originalSelect.data('per_page'),
      defaultOrder = this.$originalSelect.data('order'),
      defaultAll = this.$originalSelect.data('all-label'),
      defaults = {
        showSearch: this.$originalSelect.data('show_search'),
        paginate: this.$originalSelect.data('paginate'),
        perPage: defaultPerPage ? defaultPerPage : 10,
        hasMore: false,
        order: defaultOrder ? defaultOrder : 'ASC',
        getElements: null,
        labels: {
          emptyLabel: defaultAll ? defaultAll : (_yith_wcan_shortcodes = yith_wcan_shortcodes.labels) === null || _yith_wcan_shortcodes === void 0 ? void 0 : _yith_wcan_shortcodes.empty_option,
          searchPlaceholder: (_yith_wcan_shortcodes2 = yith_wcan_shortcodes.labels) === null || _yith_wcan_shortcodes2 === void 0 ? void 0 : _yith_wcan_shortcodes2.search_placeholder,
          noItemsFound: (_yith_wcan_shortcodes3 = yith_wcan_shortcodes.labels) === null || _yith_wcan_shortcodes3 === void 0 ? void 0 : _yith_wcan_shortcodes3.no_items,
          showMore: (_yith_wcan_shortcodes4 = yith_wcan_shortcodes.labels) === null || _yith_wcan_shortcodes4 === void 0 ? void 0 : _yith_wcan_shortcodes4.show_more
        }
      };
    this.multiple = this.$originalSelect.prop('multiple');
    this.options = $.extend(defaults, opts);
    this.paginate = this.options.paginate || false;
    this.hasMore = this.options.hasMore || false;
    this._hideSelect();
    this._initTemplate();
    this._initActions();
    this.$originalSelect.data('dropdown', this).addClass('enhanced');
  }

  // hide select
  return yith_wcan_dropdown_createClass(YITH_WCAN_Dropdown, [{
    key: "_hideSelect",
    value: function _hideSelect() {
      this.$originalSelect.hide();
    }

    // create dropdown
  }, {
    key: "_initTemplate",
    value: function _initTemplate() {
      var $mainSpan = $('<div/>', {
          "class": 'yith-wcan-dropdown closed',
          'aria-label': this.$originalSelect.attr('aria-label'),
          tabindex: 0
        }),
        $labelSpan = $('<div/>', {
          "class": 'dropdown-label',
          html: this.getLabel()
        }),
        $dropdownSpan = $('<div>', {
          "class": 'dropdown-wrapper'
        }),
        $matchingItemsList = $('<ul/>', {
          "class": 'matching-items filter-items'
        });
      $dropdownSpan.append($matchingItemsList);
      $mainSpan.append($labelSpan).append($dropdownSpan);
      if (this.options.showSearch) {
        this._initSearchTemplate($dropdownSpan);
      }
      if (this.options.paginate) {
        this._initShowMoreTemplate($dropdownSpan);
      }
      this.$originalSelect.after($mainSpan);
      this.$_main = $mainSpan;
      this.$_label = $labelSpan;
      this.$_dropdown = $dropdownSpan;
      this.$_items = $matchingItemsList;
    }

    // create search field
  }, {
    key: "_initSearchTemplate",
    value: function _initSearchTemplate($dropdwonSpan) {
      var $container = $('<div/>', {
          "class": 'search-field-container'
        }),
        $search = $('<input/>', {
          name: 's',
          "class": 'search-field',
          type: 'search',
          placeholder: this.options.labels.searchPlaceholder
        }).attr('autocomplete', 'off');
      $container.append($search).prependTo($dropdwonSpan);
      this.$_search = $search;
    }

    // create showMore field
  }, {
    key: "_initShowMoreTemplate",
    value: function _initShowMoreTemplate($dropdwonSpan) {
      var _this$options$labels$;
      var $showMore = $('<a/>', {
        "class": 'show-more',
        text: (_this$options$labels$ = this.options.labels.showMore) === null || _this$options$labels$ === void 0 ? void 0 : _this$options$labels$.replace('%d', this.options.perPage)
      });
      $showMore.on('click', this.loadNextPage.bind(this)).hide();
      $dropdwonSpan.append($showMore);
      this.$_showMore = $showMore;
    }

    // init actions performed over dropdown elements
  }, {
    key: "_initActions",
    value: function _initActions() {
      var _this$$_main,
        _this = this,
        _this$$_search;
      // main open event
      (_this$$_main = this.$_main) === null || _this$$_main === void 0 || (_this$$_main = _this$$_main.on('click', function (ev) {
        ev.stopPropagation();
        _this.toggleDropdown();
      })) === null || _this$$_main === void 0 || _this$$_main.on('keyup', function (ev) {
        if (!Object.values(keys).includes(ev.keyCode)) {
          return;
        }
        ev.preventDefault();
        if ([keys.enter, keys.space].includes(ev.keyCode)) {
          _this.toggleDropdown();
          return false;
        } else if (keys.esc === ev.keyCode) {
          _this.closeDropdown();
          return false;
        }
      });
      this.$_dropdown.on('click', function (ev) {
        ev.stopPropagation();
      });

      // search event
      (_this$$_search = this.$_search) === null || _this$$_search === void 0 || _this$$_search.on('keyup search', function (_ref) {
        var keyCode = _ref.keyCode;
        if (keyCode && keyCode === keys.esc) {
          return;
        }
        _this.paginate = false;
        _this._populateItems().then(function () {
          _this.needsRefresh = true;
        });
        return false;
      }).on('change', function () {
        return false;
      });

      // select event
      this.$_items.on('change', ':input', function (ev) {
        var $li = $(ev.target).closest('li'),
          value = $li.data('value'),
          isActive = false;
        if ($li.hasClass('disabled') && !_this.isValueSelected(value)) {
          return false;
        }
        $li.toggleClass('active');
        isActive = $li.hasClass('active');
        _this._changeItemStatus(value, isActive);
        return false;
      });
      this.$_items.on('click', 'li:not(.checkbox) a', function (ev) {
        var $li = $(ev.target).closest('li'),
          value = $li.data('value'),
          isActive = false;
        ev.preventDefault();
        if ($li.hasClass('disabled') && !_this.isValueSelected(value)) {
          return false;
        }
        $li.toggleClass('active');
        isActive = $li.hasClass('active');
        if (isActive) {
          $li.siblings().removeClass('active');
        }
        _this._changeItemStatus(value, isActive);
        return false;
      });
      this.$_items.on('click', 'label > a', function (ev) {
        var input = $(ev.target).parent().find(':input');
        ev.preventDefault();
        if (input.is('[type="radio"]') || input.is('[type="checkbox"]')) {
          input.prop('checked', !input.prop('checked'));
        }
        input.change();
      });

      // select change
      this.$originalSelect.on('change', function (ev, selfOriginated) {
        if (selfOriginated) {
          return;
        }
        _this.updateLabel();
      });

      // close dropdown on external click; do this handler only once for any dropdown in the page
      if (!(globalThis !== null && globalThis !== void 0 && globalThis.yith_wcan_dropdown_init)) {
        $(document).on('click', this._closeAllDropdowns);
        globalThis.yith_wcan_dropdown_init = true;
      }
    }

    // open dropdown
  }, {
    key: "openDropdown",
    value: function openDropdown() {
      var _this$$_main2;
      (_this$$_main2 = this.$_main) === null || _this$$_main2 === void 0 || _this$$_main2.addClass('open').removeClass('closed');
      this._afterDropdownOpen();
    }

    // close dropdown
  }, {
    key: "closeDropdown",
    value: function closeDropdown() {
      var _this$$_main3;
      (_this$$_main3 = this.$_main) === null || _this$$_main3 === void 0 || _this$$_main3.removeClass('open').addClass('closed');
    }

    // close all dropdowns
  }, {
    key: "_closeAllDropdowns",
    value: function _closeAllDropdowns() {
      var dropdowns = $(document).find('select.enhanced').filter(function (i, select) {
        var $el = $(select);
        return !!$el.data('dropdown');
      });
      dropdowns.each(function () {
        $(this).data('dropdown').closeDropdown();
      });
    }

    // close other dropdowns
  }, {
    key: "_closeOtherDropdowns",
    value: function _closeOtherDropdowns() {
      var _this2 = this;
      var dropdowns = $(document).find('select.enhanced').filter(function (i, select) {
        var $el = $(select);
        return !!$el.data('dropdown') && !$el.is(_this2.$originalSelect);
      });
      dropdowns.each(function () {
        $(this).data('dropdown').closeDropdown();
      });
    }

    // toggle dropdown
  }, {
    key: "toggleDropdown",
    value: function toggleDropdown() {
      var _this$$_main4, _this$$_main5;
      (_this$$_main4 = this.$_main) === null || _this$$_main4 === void 0 || _this$$_main4.toggleClass('open').toggleClass('closed');
      if ((_this$$_main5 = this.$_main) !== null && _this$$_main5 !== void 0 && _this$$_main5.hasClass('open')) {
        this._afterDropdownOpen();
      }
    }

    // perform operations after dropdown is open
  }, {
    key: "_afterDropdownOpen",
    value: function _afterDropdownOpen() {
      var _this$$_search2;
      this._closeOtherDropdowns();
      if ((_this$$_search2 = this.$_search) !== null && _this$$_search2 !== void 0 && _this$$_search2.length) {
        this.$_search.val('');
      }
      this._maybePopulateItems();
    }
  }, {
    key: "getItems",
    value: function () {
      var _getItems = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee(search) {
        var _this3 = this;
        var $options, items, perPage;
        return _regenerator().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              if (!this._items.length) {
                $options = this.getOptions();
                $options.each(function (i, el) {
                  var t = $(el),
                    value = t.val(),
                    label = t.html();
                  _this3._items.push({
                    value: value,
                    label: label
                  });
                });
              }
              _context.n = 1;
              return this.getMatchingElements(search);
            case 1:
              items = _context.v;
              perPage = this.paginate ? this.options.perPage : 0;
              if (perPage && items.length > perPage) {
                this.hasMore = true;
                items = items.slice(0, perPage);
              }
              return _context.a(2, items);
          }
        }, _callee, this);
      }));
      function getItems(_x) {
        return _getItems.apply(this, arguments);
      }
      return getItems;
    }() // get elements
  }, {
    key: "getMatchingElements",
    value: function getMatchingElements(search) {
      var _this4 = this;
      var matchingElements = this._items,
        promise;
      promise = new Promise(function (resolve) {
        matchingElements = search ? matchingElements.filter(function (_ref2) {
          var label = _ref2.label,
            value = _ref2.value;
          var regex = new RegExp('.*' + search + '.*', 'i');
          return regex.test(value) || regex.test(label);
        }) : matchingElements;

        // then retrieve additional items
        if (_this4.options.getElements) {
          // we're expecting key => value pairs
          _this4.options.getElements.call(_this4, search).then(function (retrievedElements) {
            if (retrievedElements) {
              // reformat retrieved array
              retrievedElements = Object.keys(retrievedElements).reduce(function (a, i) {
                if (!!retrievedElements[i].label) {
                  a.push(retrievedElements[i]);
                  return a;
                }
                a.push({
                  label: retrievedElements[i],
                  value: i
                });
                return a;
              }, []);

              // merge found results with options
              matchingElements = [].concat(_toConsumableArray(matchingElements), _toConsumableArray(retrievedElements));
            }
            resolve(_this4._formatItems(matchingElements));
          });
        } else {
          resolve(_this4._formatItems(matchingElements));
        }
      });
      return promise;
    }

    // format items as key/value pairs for further processing
  }, {
    key: "_formatItems",
    value: function _formatItems(items) {
      var _this5 = this;
      var indexes = [];

      // remove duplicates and sort array of results
      return items.filter(function (_ref3) {
        var value = _ref3.value,
          label = _ref3.label;
        if (-1 === indexes.indexOf(value)) {
          indexes.push(value);

          // checks if select has a related option.
          if (!_this5.getOptionByValue(value).length) {
            _this5.$originalSelect.append("<option class=\"filter-item\" value=\"".concat(value, "\">").concat(label, "</option>"));
          }

          // add item to final array of elements.
          return true;
        }

        // item should not be included in the final set.
        return false;
      });
    }

    // generate item to append to items list
  }, {
    key: "_generateItem",
    value: function _generateItem(value, label) {
      var active = this.isValueSelected(value),
        option = this.getOptionByValue(value),
        $item = $('<li/>', {
          'data-value': value,
          "class": option.length ? option.attr('class') : '',
          tabindex: 0
        }),
        $anchor;
      if (option.length) {
        var template = option.data('template'),
          count = option.data('count');
        label = template ? template : label;
        if (!!count) {
          label += count;
        }
      }
      $anchor = $('<a/>', {
        href: option.length ? option.data('filter_url') : '#',
        html: label,
        rel: 'nofollow',
        'data-title': option.length ? option.data('title') : '',
        tabindex: -1
      });
      $item.on('keyup', function (ev) {
        if (!Object.values(keys).includes(ev === null || ev === void 0 ? void 0 : ev.keyCode)) {
          return;
        }
        ev.preventDefault();
        if ([keys.space, keys.enter].includes(ev === null || ev === void 0 ? void 0 : ev.keyCode)) {
          $anchor.click();
        } else if (keys.next === ev.keyCode) {
          $item.next().focus();
        } else if (keys.prev === ev.keyCode) {
          $item.prev().focus();
        }
      });
      if (this.multiple) {
        var $checkbox = $('<input/>', {
            type: 'checkbox',
            tabindex: -1,
            value: value
          }),
          $label = $('<label>');
        $checkbox.prop('checked', active);
        $label.prepend($checkbox).append($anchor);
        $item.append($label).addClass('checkbox');
      } else {
        $item.append($anchor);
      }
      active ? $item.addClass('active') : $item.removeClass('active');
      return $item;
    }
  }, {
    key: "_maybePopulateItems",
    value: function _maybePopulateItems() {
      if (!this.needsRefresh) {
        return;
      }
      this._populateItems();
    }
  }, {
    key: "_populateItems",
    value: function _populateItems() {
      var _this$$_search3,
        _this6 = this;
      var search = (_this$$_search3 = this.$_search) !== null && _this$$_search3 !== void 0 && _this$$_search3.length ? this.$_search.val() : false;
      return this.getItems(search).then(function (items) {
        _this6._emptyItems();
        _this6._hideLoadMore();
        _this6.$_items.append(items.map(function (_ref4) {
          var label = _ref4.label,
            value = _ref4.value;
          return _this6._generateItem(value, label);
        }));
        _this6.$originalSelect.trigger('yith_wcan_dropdown_updated');
        _this6.needsRefresh = false;
        if (_this6.paginate && _this6.hasMore) {
          _this6._showLoadMore();
        }
      });
    }

    // load next page of items
  }, {
    key: "loadNextPage",
    value: function () {
      var _loadNextPage = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee2() {
        var _this7 = this;
        return _regenerator().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              this.paginate = false;
              this._populateItems().then(function () {
                _this7.hasMore = false;
              });
            case 1:
              return _context2.a(2);
          }
        }, _callee2, this);
      }));
      function loadNextPage() {
        return _loadNextPage.apply(this, arguments);
      }
      return loadNextPage;
    }() // set an item as active
  }, {
    key: "_selectItem",
    value: function _selectItem(value) {
      return this._changeItemStatus(value, true);
    }

    // disable an item
  }, {
    key: "_deselectItem",
    value: function _deselectItem(value) {
      return this._changeItemStatus(value, false);
    }

    // change item status
  }, {
    key: "_changeItemStatus",
    value: function _changeItemStatus(value, status) {
      var $option = this.$originalSelect.find("option[value=\"".concat(value, "\"]"));
      if ($option.length) {
        $option.prop('selected', status);
        !yith_wcan_shortcodes.instant_filters && this.multiple || this.closeDropdown();
        this.updateLabel();
        this.$originalSelect.trigger('change', [true]);
        return true;
      }
      return false;
    }

    // empty items list
  }, {
    key: "_emptyItems",
    value: function _emptyItems() {
      this.$_items.html('');
    }

    // show "Load more" link
  }, {
    key: "_showLoadMore",
    value: function _showLoadMore() {
      this.$_showMore.show();
    }

    // hide "Load more" link
  }, {
    key: "_hideLoadMore",
    value: function _hideLoadMore() {
      this.$_showMore.hide();
    }

    // returns select label
  }, {
    key: "getLabel",
    value: function getLabel() {
      return this.hasSelectedValues() ? this.getSelectedLabels().join(', ') : this.options.labels.emptyLabel;
    }

    // update label to match new selection
  }, {
    key: "updateLabel",
    value: function updateLabel() {
      var _this$$_label;
      var label = this.getLabel();
      (_this$$_label = this.$_label) === null || _this$$_label === void 0 || _this$$_label.html(label);
    }

    // returns select options
  }, {
    key: "getOptions",
    value: function getOptions() {
      return this.$originalSelect.find('option');
    }

    // checks whether select has selected values
  }, {
    key: "hasSelectedValues",
    value: function hasSelectedValues() {
      return this.getSelectedOptions().length;
    }

    // checks whether a value is selected
  }, {
    key: "isValueSelected",
    value: function isValueSelected(value) {
      var found = this.getSelectedValues().indexOf(value.toString());
      return -1 !== found;
    }

    // retrieve selected options
  }, {
    key: "getSelectedOptions",
    value: function getSelectedOptions() {
      return this.$originalSelect.find('option').filter(':selected');
    }

    // retrieves an option node by value
  }, {
    key: "getOptionByValue",
    value: function getOptionByValue(value) {
      return this.$originalSelect.find("option[value=\"".concat(value, "\"]"));
    }

    // retrieve labels for selected options
  }, {
    key: "getSelectedLabels",
    value: function getSelectedLabels() {
      var labels = [];
      this.getSelectedOptions().each(function () {
        var $option = $(this),
          template = $option.data('template');
        template = template ? template : $option.html().replace(/\([0-9]*\)/, '');
        labels.push(template);
      });
      return labels;
    }

    // retrieve values for selected options
  }, {
    key: "getSelectedValues",
    value: function getSelectedValues() {
      var values = [];
      this.getSelectedOptions().each(function () {
        values.push($(this).val());
      });
      return values;
    }
  }, {
    key: "destroy",
    value: function destroy() {
      // TBD
    }
  }]);
}();

;// ./assets/js/shortcodes/modules/yith-wcan-preset.js


/* global globalThis, jQuery, yith_wcan_shortcodes, accounting */
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (!t) { if (Array.isArray(r) || (t = yith_wcan_preset_unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t["return"] || t["return"](); } finally { if (u) throw o; } } }; }
function yith_wcan_preset_unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return yith_wcan_preset_arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? yith_wcan_preset_arrayLikeToArray(r, a) : void 0; } }
function yith_wcan_preset_arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function yith_wcan_preset_typeof(o) { "@babel/helpers - typeof"; return yith_wcan_preset_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, yith_wcan_preset_typeof(o); }
function yith_wcan_preset_regenerator() { /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE */ var e, t, r = "function" == typeof Symbol ? Symbol : {}, n = r.iterator || "@@iterator", o = r.toStringTag || "@@toStringTag"; function i(r, n, o, i) { var c = n && n.prototype instanceof Generator ? n : Generator, u = Object.create(c.prototype); return yith_wcan_preset_regeneratorDefine2(u, "_invoke", function (r, n, o) { var i, c, u, f = 0, p = o || [], y = !1, G = { p: 0, n: 0, v: e, a: d, f: d.bind(e, 4), d: function d(t, r) { return i = t, c = 0, u = e, G.n = r, a; } }; function d(r, n) { for (c = r, u = n, t = 0; !y && f && !o && t < p.length; t++) { var o, i = p[t], d = G.p, l = i[2]; r > 3 ? (o = l === n) && (u = i[(c = i[4]) ? 5 : (c = 3, 3)], i[4] = i[5] = e) : i[0] <= d && ((o = r < 2 && d < i[1]) ? (c = 0, G.v = n, G.n = i[1]) : d < l && (o = r < 3 || i[0] > n || n > l) && (i[4] = r, i[5] = n, G.n = l, c = 0)); } if (o || r > 1) return a; throw y = !0, n; } return function (o, p, l) { if (f > 1) throw TypeError("Generator is already running"); for (y && 1 === p && d(p, l), c = p, u = l; (t = c < 2 ? e : u) || !y;) { i || (c ? c < 3 ? (c > 1 && (G.n = -1), d(c, u)) : G.n = u : G.v = u); try { if (f = 2, i) { if (c || (o = "next"), t = i[o]) { if (!(t = t.call(i, u))) throw TypeError("iterator result is not an object"); if (!t.done) return t; u = t.value, c < 2 && (c = 0); } else 1 === c && (t = i["return"]) && t.call(i), c < 2 && (u = TypeError("The iterator does not provide a '" + o + "' method"), c = 1); i = e; } else if ((t = (y = G.n < 0) ? u : r.call(n, G)) !== a) break; } catch (t) { i = e, c = 1, u = t; } finally { f = 1; } } return { value: t, done: y }; }; }(r, o, i), !0), u; } var a = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} t = Object.getPrototypeOf; var c = [][n] ? t(t([][n]())) : (yith_wcan_preset_regeneratorDefine2(t = {}, n, function () { return this; }), t), u = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(c); function f(e) { return Object.setPrototypeOf ? Object.setPrototypeOf(e, GeneratorFunctionPrototype) : (e.__proto__ = GeneratorFunctionPrototype, yith_wcan_preset_regeneratorDefine2(e, o, "GeneratorFunction")), e.prototype = Object.create(u), e; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, yith_wcan_preset_regeneratorDefine2(u, "constructor", GeneratorFunctionPrototype), yith_wcan_preset_regeneratorDefine2(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = "GeneratorFunction", yith_wcan_preset_regeneratorDefine2(GeneratorFunctionPrototype, o, "GeneratorFunction"), yith_wcan_preset_regeneratorDefine2(u), yith_wcan_preset_regeneratorDefine2(u, o, "Generator"), yith_wcan_preset_regeneratorDefine2(u, n, function () { return this; }), yith_wcan_preset_regeneratorDefine2(u, "toString", function () { return "[object Generator]"; }), (yith_wcan_preset_regenerator = function _regenerator() { return { w: i, m: f }; })(); }
function yith_wcan_preset_regeneratorDefine2(e, r, n, t) { var i = Object.defineProperty; try { i({}, "", {}); } catch (e) { i = 0; } yith_wcan_preset_regeneratorDefine2 = function _regeneratorDefine(e, r, n, t) { function o(r, n) { yith_wcan_preset_regeneratorDefine2(e, r, function (e) { return this._invoke(r, n, e); }); } r ? i ? i(e, r, { value: n, enumerable: !t, configurable: !t, writable: !t }) : e[r] = n : (o("next", 0), o("throw", 1), o("return", 2)); }, yith_wcan_preset_regeneratorDefine2(e, r, n, t); }
function yith_wcan_preset_asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function yith_wcan_preset_asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { yith_wcan_preset_asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { yith_wcan_preset_asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { yith_wcan_preset_defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function yith_wcan_preset_classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function yith_wcan_preset_defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, yith_wcan_preset_toPropertyKey(o.key), o); } }
function yith_wcan_preset_createClass(e, r, t) { return r && yith_wcan_preset_defineProperties(e.prototype, r), t && yith_wcan_preset_defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function yith_wcan_preset_defineProperty(e, r, t) { return (r = yith_wcan_preset_toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function yith_wcan_preset_toPropertyKey(t) { var i = yith_wcan_preset_toPrimitive(t, "string"); return "symbol" == yith_wcan_preset_typeof(i) ? i : i + ""; }
function yith_wcan_preset_toPrimitive(t, r) { if ("object" != yith_wcan_preset_typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != yith_wcan_preset_typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }


var YITH_WCAN_Preset = /*#__PURE__*/function () {
  // init object
  function YITH_WCAN_Preset(el) {
    var extra = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    yith_wcan_preset_classCallCheck(this, YITH_WCAN_Preset);
    // main preset node
    yith_wcan_preset_defineProperty(this, "preset", false);
    yith_wcan_preset_defineProperty(this, "$preset", false);
    // target of the filter, if any
    yith_wcan_preset_defineProperty(this, "target", false);
    yith_wcan_preset_defineProperty(this, "$target", false);
    // filters node
    yith_wcan_preset_defineProperty(this, "$filters", false);
    // filter button
    yith_wcan_preset_defineProperty(this, "$filterButtons", false);
    // nodes created just for modal layout
    yith_wcan_preset_defineProperty(this, "modalElements", {});
    // retains current status of filters
    yith_wcan_preset_defineProperty(this, "activeFilters", false);
    // mobile flag
    yith_wcan_preset_defineProperty(this, "isMobile", false);
    // slider timeout
    yith_wcan_preset_defineProperty(this, "sliderTimeout", false);
    // registers when status has changed
    yith_wcan_preset_defineProperty(this, "originalFilters", null);
    yith_wcan_preset_defineProperty(this, "dirty", false);
    // promise resolved when all async loading is complete.
    yith_wcan_preset_defineProperty(this, "loaded", void 0);
    // flag to disable filtering
    yith_wcan_preset_defineProperty(this, "inhibitFilters", false);
    yith_wcan_preset_defineProperty(this, "productIds", []);
    yith_wcan_preset_defineProperty(this, "withAjaxSearch", false);
    yith_wcan_preset_defineProperty(this, "search", '');
    // main preset node
    this.preset = '#' + el.attr('id');
    this.$preset = el;

    // target of the filter, if any
    this.target = this.$preset.data('target');
    this.$target = this.target ? $(this.target) : false;
    this.productIds = extra !== null && extra !== void 0 && extra.productIds ? extra.productIds : [];
    this.withAjaxSearch = extra !== false;
    this.search = extra !== null && extra !== void 0 && extra.query ? extra.query : '';
    this._regiterStatus();
    this._initFilterButton();
    this._initFilters();
    this._initResponsive();
    this._initActions();
    this.$preset.data('preset', this).addClass('enhanced').trigger('yith_wcan_preset_initialized', [this]);
  }

  // init filters
  return yith_wcan_preset_createClass(YITH_WCAN_Preset, [{
    key: "_initFilters",
    value: function _initFilters() {
      var _this = this;
      var filters = this.getFilters().get().map(function (filter) {
        return _this._initFilter($(filter));
      });
      this.loaded = Promise.all(filters);
      this.maybeShowClearAllFilters();
    }

    // init filter button
  }, {
    key: "_initFilterButton",
    value: function _initFilterButton() {
      var _this2 = this;
      this.$filterButtons = this.$preset.find('.apply-filters');
      if (!this.$filterButtons.length) {
        return;
      }

      // manage filter button
      this.$filterButtons.on('click', function (ev) {
        ev.preventDefault();
        _this2.filter();
      }).hide();
    }

    // init generic actions
  }, {
    key: "_initActions",
    value: function _initActions() {
      this.$preset.find('form').on('submit', function (ev) {
        ev.preventDefault();
      });
    }

    // init responsive
  }, {
    key: "_initResponsive",
    value: function _initResponsive() {
      var _this3 = this;
      if (!yith_wcan_shortcodes.modal_on_mobile) {
        return;
      }
      var media = window.matchMedia("(max-width: ".concat(yith_wcan_shortcodes.mobile_media_query, "px)"));
      $(window).on('resize', function () {
        var isMobile = !!media.matches;
        if (isMobile !== _this3.isMobile) {
          _this3.isMobile = isMobile;
          _this3._afterLayoutChange();
        }
      }).resize();
    }

    // init filter
  }, {
    key: "_initFilter",
    value: function _initFilter($filter) {
      var _this4 = this;
      var self = this,
        handleChange = function handleChange(ev) {
          var t = $(this),
            $currentFilter = t.closest('.yith-wcan-filter'),
            multiple = $currentFilter.length ? 'yes' === $currentFilter.data('multiple') : false,
            $item = t.closest('.filter-item'),
            $items = $item.length ? $currentFilter.find('.filter-item').not($item) : [];
          if ($currentFilter.is('.filter-price-slider')) {
            return false;
          }
          if ($item.is('.disabled') && !$item.is('.active')) {
            return false;
          }
          ev.preventDefault();
          $items.length && !multiple && $items.removeClass('active').children('label').find(':input').prop('checked', false).parent('.checked').removeClass('checked');
          $item.length && $item.toggleClass('active');

          // reset active filters.
          self.activeFilters = false;
          self.maybeFilter($currentFilter);
          self.maybeToggleClearAllFilters();
          self.maybeToggleClearFilter($currentFilter);
        };
      if (self.withAjaxSearch) {
        $filter.addClass('filter-placeholder');
        if ($filter.hasClass('filter-tax')) {
          $filter.find('.filter-items li a').addClass('item-placeholder');
        }
        if ($filter.hasClass('filter-price-slider')) {
          $filter.find('.price-slider').addClass('slider-placeholder');
        }
      }
      // load filter when needed and then init it.
      // eslint-disable-next-line no-shadow
      return this._maybeLoadFilter($filter).then(function ($filter) {
        // handle filter activation/deactivation by click on label (no input involved)
        $filter.on('click', 'a', function (ev) {
          var t = $(this),
            $item = t.closest('.filter-item');
          if (!$item.length || $item.is('.checkbox') || $item.is('.radio')) {
            return;
          }
          handleChange.call(this, ev);
        });

        // handle filter activation/deactivation from input change
        $filter.on('change', ':input', function (ev) {
          var t = $(this),
            $item = t.closest('.filter-item');
          if ($item.is('.disabled') && !$item.is('.active')) {
            t.prop('checked', false);
            return false;
          }
          handleChange.call(this, ev);
        });

        // handle filter activation/deactivation by click on label (there is an input whose state can be switched)
        $filter.on('click', 'label > a', function (ev) {
          var t = $(this),
            $item = t.closest('.filter-item');
          ev.preventDefault();
          if ($item.is('.disabled') && !$item.is('.active')) {
            return false;
          }
          var $input = t.parent().find(':input');
          if ($input.is('[type="radio"]') || $input.is('[type="checkbox"]')) {
            $input.prop('checked', !$input.prop('checked'));
          }
          $input.change();
        });

        // init children items, such as tooltip, dropdowns, etc.
        _this4._initFilterChildren($filter);

        // init clear anchors
        _this4.maybeShowClearFilter($filter);
        return $filter;
      });
    }

    // performs additional operations after filter init, such as adding tooltip, collapsable handles, custom dropdowns, etc.
  }, {
    key: "_initFilterChildren",
    value: function _initFilterChildren($filter) {
      var _this$$preset,
        _this5 = this;
      // init tooltip
      this._initTooltip($filter);

      // init price slider
      this._initPriceSlider($filter);

      // init dropdown
      this._initDropdown($filter);

      // init collapsable
      this._initCollapsable($filter);

      // init show more link
      this._initShowMore($filter);

      // init custom inputs
      if ((_this$$preset = this.$preset) !== null && _this$$preset !== void 0 && _this$$preset.hasClass('custom-style')) {
        this._initCustomInput($filter);
        $filter.on('yith_wcan_dropdown_updated', function (ev) {
          var $dropdown = $(ev.target),
            $current = $dropdown.closest('.yith-wcan-filter');
          _this5._initCustomInput($current);
        });
      }
    }

    // load filter via AJAX
  }, {
    key: "_maybeLoadFilter",
    value: function _maybeLoadFilter($filter) {
      var _this6 = this;
      // if filter doesn't require loading, return it as Promise resolve value.
      if (!$filter.hasClass('filter-placeholder')) {
        return Promise.resolve($filter);
      }
      var extraData = {
        _preset_id: this.getId(),
        _filter_id: $filter.data('filter-id')
      };
      if (this.withAjaxSearch) {
        extraData = _objectSpread(_objectSpread({}, extraData), {}, {
          _product_ids: this.productIds,
          _ywcas_search: this.search
        });
      }

      // otherwise load filter via AJAX.
      return new Promise(function (resolve) {
        var _yith_wcan_shortcodes;
        $.ajax({
          method: 'GET',
          url: yith_wcan_shortcodes.base_url,
          data: _objectSpread(_objectSpread({
            'wc-ajax': 'yith_wcan_render_filter',
            security: (_yith_wcan_shortcodes = yith_wcan_shortcodes.nonces) === null || _yith_wcan_shortcodes === void 0 ? void 0 : _yith_wcan_shortcodes.render_filter
          }, _this6.originalFilters), extraData)
        }).then(function (data) {
          var _data$data;
          return resolve(_this6._loadFilter($filter, data.success ? data === null || data === void 0 || (_data$data = data.data) === null || _data$data === void 0 ? void 0 : _data$data.html : ''));
        });
      });
    }

    // replace placeholder with actual filter template.
  }, {
    key: "_loadFilter",
    value: function _loadFilter($filter, filterHTML) {
      if (!filterHTML) {
        return this.withAjaxSearch ? $filter.hide() : $filter.remove();
      }
      var $newFilter = $(filterHTML);
      $filter.replaceWith($newFilter);

      // old filters are outdated, clear them until next .getFilters()
      this.$filters = false;
      return $newFilter;
    }

    // init tooltip
  }, {
    key: "_initTooltip",
    value: function _initTooltip($filter, position) {
      $filter.find('[data-title]').each(function () {
        var t = $(this);
        if (t.hasClass('tooltip-added') || !t.data('title')) {
          return;
        }
        t.on('mouseenter', function () {
          var th = $(this),
            tooltip = null,
            wrapperWidth = th.outerWidth(),
            left = 0,
            width = 0;
          if (!position || 'top' !== position && 'right' !== position) {
            var container = th.closest('.filter-item');
            position = container.hasClass('color') || container.hasClass('label') ? 'top' : 'right';
          }
          tooltip = $('<span>', {
            "class": 'yith-wcan-tooltip',
            html: th.data('title')
          });
          th.append(tooltip);
          width = tooltip.outerWidth() + 6;
          tooltip.outerWidth(width);
          if ('top' === position) {
            left = (wrapperWidth - width) / 2;
          } else {
            left = wrapperWidth + 15;
          }
          tooltip.css({
            left: left.toFixed(0) + 'px'
          }).fadeIn(200);
          th.addClass('with-tooltip');
        }).on('mouseleave', function () {
          var th = $(this);
          th.find('.yith-wcan-tooltip').fadeOut(200, function () {
            th.removeClass('with-tooltip').find('.yith-wcan-tooltip').remove();
          });
        });
        t.addClass('tooltip-added');
      });
    }

    // init dropdown
  }, {
    key: "_initDropdown",
    value: function _initDropdown($filter) {
      var $dropdown = $filter.find('select.filter-dropdown');
      if (!$dropdown.length || $dropdown.hasClass('enhanced')) {
        return;
      }
      if ($dropdown.hasClass('select2-hidden-accessible') && 'undefined' !== typeof $.fn.selectWoo) {
        $dropdown.selectWoo('destroy');
      }
      var self = this,
        hasMore = $dropdown.data('has-more');
      this._initDropdownObject($dropdown, _objectSpread({
        paginate: true,
        hasMore: hasMore,
        perPage: parseInt(yith_wcan_shortcodes.terms_per_page)
      }, hasMore ? {
        getElements: function getElements(search) {
          var _this7 = this;
          return yith_wcan_preset_asyncToGenerator(/*#__PURE__*/yith_wcan_preset_regenerator().m(function _callee() {
            return yith_wcan_preset_regenerator().w(function (_context) {
              while (1) switch (_context.n) {
                case 0:
                  if (!((_this7.paginate || !_this7.hasMore) && !search)) {
                    _context.n = 1;
                    break;
                  }
                  return _context.a(2, _this7._items);
                case 1:
                  return _context.a(2, self._getTerms($filter, search));
              }
            }, _callee);
          }))();
        }
      } : {}));
    }

    // init dropdown object
  }, {
    key: "_initDropdownObject",
    value: function _initDropdownObject($dropdown, opts) {
      return new YITH_WCAN_Dropdown($dropdown, opts);
    }

    // init price slider
  }, {
    key: "_initPriceSlider",
    value: function _initPriceSlider($filter) {
      var _this8 = this;
      if (!$filter.hasClass('filter-price-slider')) {
        return;
      }
      var self = this,
        $container = $filter.find('.price-slider'),
        $minInput = $container.find('.price-slider-min'),
        $maxInput = $container.find('.price-slider-max'),
        min = parseFloat($container.data('min')),
        max = parseFloat($container.data('max')),
        currentMin = parseFloat($minInput.val()),
        currentMax = parseFloat($maxInput.val()),
        step = parseFloat($container.data('step')),
        handleSliderChange = function handleSliderChange() {
          if (self.sliderTimeout) {
            clearTimeout(self.sliderTimeout);
          }
          self.sliderTimeout = setTimeout(function () {
            self.maybeFilter($filter);
          }, 300);
        };
      $filter.find('.price-slider-ui').off('change').ionRangeSlider({
        skin: 'round',
        type: 'double',
        min: min,
        max: max,
        step: step,
        from: currentMin,
        to: currentMax,
        min_interval: step,
        values_separator: ' - ',
        prettify: function prettify(v) {
          return _this8.formatPrice(v);
        },
        onChange: function onChange(data) {
          $minInput.val(data.from);
          $maxInput.val(data.to);
        },
        onFinish: handleSliderChange
      });
      $minInput.add($maxInput).off('change').on('change', handleSliderChange).on('keyup', function (ev) {
        if (!ev.key.match(/[0-9,.]/)) {
          ev.preventDefault();
          return false;
        }
        if (!$minInput.val() || !$maxInput.val()) {
          return;
        }
        handleSliderChange();
      });
    }

    // init collapsable
  }, {
    key: "_initCollapsable",
    value: function _initCollapsable($filter) {
      this._initTitleCollapsable($filter);
      this._initHierarchyCollapsable($filter);
    }

    // init show more filters on click.
  }, {
    key: "_initShowMore",
    value: function _initShowMore($filter) {
      var _this9 = this;
      var $showMore = $filter.find('.filter-content').children('.show-more');
      if (!$showMore.length || $showMore.hasClass('initialized')) {
        return;
      }
      $showMore.addClass('initialized').on('click', function () {
        return _this9._loadItems($filter).then(function () {
          return $showMore.remove();
        });
      });
    }
  }, {
    key: "_getTerms",
    value: function _getTerms($filter, search) {
      var _this0 = this;
      return new Promise(function (resolve) {
        $.ajax({
          method: 'GET',
          beforeSend: function beforeSend() {
            return globals_block($filter);
          },
          complete: function complete() {
            return globals_unblock($filter);
          },
          url: yith_wcan_shortcodes.base_url,
          data: _objectSpread({
            'wc-ajax': 'yith_wcan_get_filter_terms',
            _preset_id: _this0.getId(),
            _filter_id: $filter.data('filter-id'),
            security: yith_wcan_shortcodes.nonces.get_filter_terms,
            search: search
          }, _this0.originalFilters)
        }).then(function (data) {
          var _data$data2;
          var $items = data.success ? data === null || data === void 0 || (_data$data2 = data.data) === null || _data$data2 === void 0 ? void 0 : _data$data2.items : {};
          resolve($items);
        });
      });
    }

    // load new page of terms via AJAX
  }, {
    key: "_loadItems",
    value: function _loadItems($filter) {
      var _this1 = this;
      return new Promise(function (resolve) {
        $.ajax({
          method: 'GET',
          beforeSend: function beforeSend() {
            return globals_block($filter);
          },
          complete: function complete() {
            return globals_unblock($filter);
          },
          url: yith_wcan_shortcodes.base_url,
          data: _objectSpread({
            'wc-ajax': 'yith_wcan_render_remaining_terms',
            _preset_id: _this1.getId(),
            _filter_id: $filter.data('filter-id'),
            security: yith_wcan_shortcodes.nonces.render_remaining_terms
          }, _this1.originalFilters)
        }).then(function (data) {
          var _data$data3;
          var $items = $filter.find('.filter-content .filter-items.level-0');

          // append new items to filter existing ones.
          $items.append(data.success ? data === null || data === void 0 || (_data$data3 = data.data) === null || _data$data3 === void 0 ? void 0 : _data$data3.html : '');

          // perform additional initalization of the new items in the filter.
          _this1._initFilterChildren($filter);

          // resolve promise returning jQuery set of the new elements.
          resolve($items);
        });
      });
    }

    // init toggle on click of the title
  }, {
    key: "_initTitleCollapsable",
    value: function _initTitleCollapsable($filter) {
      var $title = $filter.find('.collapsable');
      if (!$title.length || $title.hasClass('toggle-initialized')) {
        return;
      }
      this._initToggle($title, $title, $filter.find('.filter-content'));
    }

    // init toggle on click of the parent li
  }, {
    key: "_initHierarchyCollapsable",
    value: function _initHierarchyCollapsable($filter) {
      var $items = $filter.find('.hierarchy-collapsable');
      if (!$items.length) {
        return;
      }

      // set parents of currently active term as open
      var self = this,
        active = $filter.find('.active');
      if (active.length) {
        active.parents('.hierarchy-collapsable').removeClass('closed').addClass('opened');
        if (active.hasClass('hierarchy-collapsable') && yith_wcan_shortcodes.show_current_children) {
          active.removeClass('closed').addClass('opened');
        }
      }
      $items.each(function () {
        var $t = $(this);
        if ($t.hasClass('toggle-initialized')) {
          return;
        }
        var $toggle = $('<span/>', {
          "class": 'toggle-handle'
        });
        $toggle.appendTo($t);
        self._initToggle($toggle, $t, $t.children('ul.filter-items'));
      });
    }

    // init toggle to generic toggle/target pair
  }, {
    key: "_initToggle",
    value: function _initToggle($toggle, $container, $target) {
      var _this10 = this;
      if ($container.hasClass('toggle-initialized')) {
        return;
      }
      if ($container.hasClass('closed')) {
        $target.hide();
      }
      $toggle.off('click').on('click', function (ev) {
        ev.stopPropagation();
        ev.preventDefault();
        _this10.toggle($target, $container);
        $target.trigger('yith_wcan_after_toggle_element', [$container]);
      });
      $container.addClass('toggle-initialized');
    }

    // init custom input
  }, {
    key: "_initCustomInput",
    value: function _initCustomInput($filter) {
      $filter.find(':input').each(function () {
        var input = $(this),
          type = input.attr('type'),
          containerClass = "".concat(type, "button"),
          container;
        if ('checkbox' !== type && 'radio' !== type) {
          return;
        }
        if (input.closest(".".concat(containerClass)).length) {
          return;
        }
        if (input.is(':checked')) {
          containerClass += ' checked';
        }
        container = $('<span/>', {
          "class": containerClass
        });
        input.wrap(container).on('change', function () {
          var t = $(this);
          t.prop('checked') ? t.parent().addClass('checked') : t.parent().removeClass('checked');
        });
      });
    }

    // register initial status
  }, {
    key: "_regiterStatus",
    value: function _regiterStatus() {
      var _yith_wcan_shortcodes2;
      var query_vars = (_yith_wcan_shortcodes2 = yith_wcan_shortcodes.query_vars) !== null && _yith_wcan_shortcodes2 !== void 0 ? _yith_wcan_shortcodes2 : [];
      this.originalFilters = this.mergeProperties(this.withAjaxSearch ? [] : query_vars, this.getFiltersProperties());
    }

    // trigger handling after layout change
  }, {
    key: "_afterLayoutChange",
    value: function _afterLayoutChange() {
      var _this11 = this;
      if (this.isMobile) {
        var _this$$filterButtons;
        this.$preset.addClass('filters-modal').attr('role', 'dialog').attr('tabindex', '-1').hide();
        this._addCloseModalButton();
        this._addApplyFiltersModalButton();
        this.loaded.then(function () {
          return _this11._switchToCollapsables();
        });
        (_this$$filterButtons = this.$filterButtons) === null || _this$$filterButtons === void 0 || _this$$filterButtons.hide();
      } else {
        var _this$$filterButtons2;
        this.$preset.removeClass('filters-modal').removeClass('open').removeAttr('role').removeAttr('tabindex').show();
        $('body').css('overflow', 'auto').removeClass('yith-wcan-preset-modal-open');
        this._removeCloseModalButton();
        this._removeApplyFiltersModalButton();
        this.loaded.then(function () {
          return _this11._switchBackCollapsables();
        });
        (_this$$filterButtons2 = this.$filterButtons) === null || _this$$filterButtons2 === void 0 || _this$$filterButtons2.show();
      }
    }

    // add modal close button
  }, {
    key: "_addCloseModalButton",
    value: function _addCloseModalButton() {
      var $closeButton = $('<a/>', {
        "class": 'close-button',
        html: '&times;',
        'data-dismiss': 'modal',
        'aria-label': yith_wcan_shortcodes.labels.close
      });
      $closeButton.prependTo(this.$preset).on('click', this.closeModal.bind(this));
      this.modalElements.closeButton = $closeButton;
    }

    // remove modal close button
  }, {
    key: "_removeCloseModalButton",
    value: function _removeCloseModalButton() {
      var _this$modalElements;
      (_this$modalElements = this.modalElements) === null || _this$modalElements === void 0 || (_this$modalElements = _this$modalElements.closeButton) === null || _this$modalElements === void 0 || _this$modalElements.remove();
    }

    // show main filter button for the modal
  }, {
    key: "_addApplyFiltersModalButton",
    value: function _addApplyFiltersModalButton() {
      var _this12 = this;
      var $filterButton = $('<button/>', {
        "class": 'apply-filters main-modal-button',
        html: yith_wcan_shortcodes.labels.show_results,
        'data-dismiss': 'modal'
      });
      $filterButton.appendTo(this.$preset).on('click', function () {
        _this12.filter();
        _this12.closeModal();
      });
      this.modalElements.applyFiltersButton = $filterButton;
    }

    // hide main filter button for the modal
  }, {
    key: "_removeApplyFiltersModalButton",
    value: function _removeApplyFiltersModalButton() {
      var _this$modalElements2;
      (_this$modalElements2 = this.modalElements) === null || _this$modalElements2 === void 0 || (_this$modalElements2 = _this$modalElements2.applyFiltersButton) === null || _this$modalElements2 === void 0 || _this$modalElements2.remove();
    }

    // convert all filters to collapsable
  }, {
    key: "_switchToCollapsables",
    value: function _switchToCollapsables() {
      var self = this;
      this.getFilters().each(function () {
        var $filter = $(this),
          $title = $filter.find('.filter-title');
        if (!$title.length || $title.hasClass('collapsable')) {
          return;
        }
        $title.addClass('collapsable').data('disable-collapse', true);
        self._initTitleCollapsable($filter);
      });
    }

    // switch back filters to their previous collapsable state
  }, {
    key: "_switchBackCollapsables",
    value: function _switchBackCollapsables() {
      this.getFilters().each(function () {
        var $filter = $(this),
          $title = $filter.find('.filter-title');
        if (!$title.length || !$title.hasClass('collapsable') || !$title.data('disable-collapse')) {
          return;
        }
        $title.removeClass('collapsable').removeData('disable-collapse', true).off('click');
        $filter.find('.filter-content').show();
      });
    }

    // close all collpasable before showing modal
  }, {
    key: "_openAllCollapsables",
    value: function _openAllCollapsables() {
      var _this13 = this;
      this.getFilters().not('.no-title').not(function (i, v) {
        return _this13.isFilterActive($(v));
      }).find('.filter-content').show().end().find('.filter-title').removeClass('closed').addClass('opened');
    }

    // close all collpasable before showing modal
  }, {
    key: "_closeAllCollapsables",
    value: function _closeAllCollapsables() {
      var _this14 = this;
      this.getFilters().not('.no-title').not(function (i, v) {
        return _this14.isFilterActive($(v));
      }).find('.filter-content').hide().end().find('.filter-title').addClass('closed').removeClass('opened');
    }

    // update status change flag, if filters have changed
  }, {
    key: "maybeRegisterStatusChange",
    value: function maybeRegisterStatusChange() {
      var currentFilters = this.getFiltersProperties(),
        currentStr = JSON.stringify(currentFilters),
        originalStr = JSON.stringify(this.originalFilters);
      this.dirty = currentStr !== originalStr;
    }

    // apply filters when possible
  }, {
    key: "maybeFilter",
    value: function maybeFilter($initiator) {
      // register status change
      this.maybeRegisterStatusChange();

      // skip if filters are inhibited.
      if (this.inhibitFilters) {
        return;
      }

      // filter, or show filter button.
      if (yith_wcan_shortcodes.instant_filters && !this.isMobile) {
        this.filter();
      } else if (!yith_wcan_shortcodes.instant_filters && !this.isMobile) {
        var _this$$filterButtons3, _this$$filterButtons4;
        this.dirty ? (_this$$filterButtons3 = this.$filterButtons) === null || _this$$filterButtons3 === void 0 ? void 0 : _this$$filterButtons3.show() : (_this$$filterButtons4 = this.$filterButtons) === null || _this$$filterButtons4 === void 0 ? void 0 : _this$$filterButtons4.hide();
      } else if (this.isMobile && this.dirty) {
        var _this$modalElements$a;
        this.$preset.addClass('with-filter-button');
        (_this$modalElements$a = this.modalElements.applyFiltersButton) === null || _this$modalElements$a === void 0 || _this$modalElements$a.show();
      }
    }

    // main filtering method
  }, {
    key: "filter",
    value: function filter() {
      var _this15 = this;
      if (this.withAjaxSearch) {
        this._regiterStatus();
        $(document).trigger('yith_wcan_filter_updated', [this]);
      } else {
        var _window, _filter$doFilter;
        var _filter = (_window = window) === null || _window === void 0 ? void 0 : _window.product_filter;
        _filter === null || _filter === void 0 || (_filter$doFilter = _filter.doFilter(this.getFiltersProperties(), this.target, this.preset)) === null || _filter$doFilter === void 0 || _filter$doFilter.done(function () {
          var newPreset = $(_this15.preset);
          if (newPreset.length && yith_wcan_shortcodes.scroll_top) {
            // by default, scroll till top of first preset in the page.
            var targetOffset = newPreset.offset().top;
            if (!!yith_wcan_shortcodes.scroll_target) {
              // when we have a specific target, use that for the offset.
              var $scrollTarget = $(yith_wcan_shortcodes.scroll_target);
              targetOffset = $scrollTarget.length ? $scrollTarget.offset().top : targetOffset;
            } else if (_this15.isMobile) {
              // otherwise, if we're on mobile, scroll to the top of the page
              // (preset could be in an unexpected location).
              targetOffset = 100;
            }
            $('body, html').animate({
              scrollTop: targetOffset - 100
            });
          }

          // register new filters, clear status flag
          _this15._regiterStatus();
          _this15.dirty = false;
        });
        if (this.isMobile) {
          var _this$modalElements$a2;
          this.$preset.removeClass('with-filter-button');
          (_this$modalElements$a2 = this.modalElements.applyFiltersButton) === null || _this$modalElements$a2 === void 0 || _this$modalElements$a2.hide();
          this.closeModal();
        }
      }
    }

    // returns preset id
  }, {
    key: "getId",
    value: function getId() {
      return this.$preset.data('preset-id');
    }

    // get all filter nodes
  }, {
    key: "getFilters",
    value: function getFilters() {
      if (false === this.$filters) {
        this.$filters = this.$preset.find('.yith-wcan-filter');
      }
      return this.$filters;
    }

    // retrieves all filters that we want to apply
  }, {
    key: "getActiveFilters",
    value: function getActiveFilters() {
      if (false === this.activeFilters) {
        this.activeFilters = this.getFiltersProperties();
      }
      return this.activeFilters;
    }

    // check whether there is any filter active
  }, {
    key: "isAnyFilterActive",
    value: function isAnyFilterActive() {
      return !!Object.keys(this.getActiveFilters()).length;
    }

    // checks whether current filter is active
  }, {
    key: "isFilterActive",
    value: function isFilterActive($filter) {
      var filterType = $filter.data('filter-type'),
        active,
        filteredActive;
      switch (filterType) {
        case 'tax':
        case 'review':
        case 'price_range':
          var $dropdown = $filter.find('.filter-dropdown');
          if ($dropdown.length) {
            var val = $dropdown.val();
            active = 'object' === yith_wcan_preset_typeof(val) ? !!(val !== null && val !== void 0 && val.length) : !!val;
            break;
          }

        // if we use type other than dropdown, fallthrough
        case 'stock_sale':
          active = $filter.find('.filter-item').filter('.active').length;
          break;
        case 'price_slider':
          var step = parseFloat($filter.find('.price-slider').data('step')),
            min = parseFloat($filter.find('.price-slider').data('min')),
            max = parseFloat($filter.find('.price-slider').data('max')),
            currentMin = parseFloat($filter.find('.price-slider-min').val()),
            currentMax = parseFloat($filter.find('.price-slider-max').val());
          active = Math.abs(currentMin - min) >= step || Math.abs(currentMax - max) >= step;
          break;
        case 'orderby':
          active = 'menu_order' !== $filter.find('.filter-order-by').val();
          break;
        default:
          active = false;
          break;
      }
      filteredActive = $filter.triggerHandler('yith_wcan_is_filter_active', [active, this]);
      active = typeof filteredActive !== 'undefined' ? filteredActive : active;
      return active;
    }

    // count the number of active items per filter
  }, {
    key: "countActiveItems",
    value: function countActiveItems($filter) {
      var filterType = $filter.data('filter-type'),
        count;
      switch (filterType) {
        case 'tax':
        case 'review':
        case 'price_range':
          var $dropdown = $filter.find('.filter-dropdown');
          if ($dropdown.length) {
            var val = $dropdown.val();
            count = 'object' === yith_wcan_preset_typeof(val) ? val === null || val === void 0 ? void 0 : val.length : +!!val;
            break;
          }

        // if we use type other than dropdown, fallthrough
        case 'stock_sale':
          count = $filter.find('.filter-items').find('.active').length;
          break;
        case 'orderby':
          if (this.isFilterActive($filter)) {
            count = 1;
          }
          break;
        case 'price_slider':
        default:
          count = 0;
          break;
      }
      return count;
    }

    // retrieves filter properties for the filter
  }, {
    key: "getFilterProperties",
    value: function getFilterProperties($filter) {
      var filterType = $filter.data('filter-type'),
        multiple = 'yes' === $filter.data('multiple'),
        $dropdown = $filter.find('.filter-dropdown'),
        properties = {},
        filteredProperties,
        $active;
      switch (filterType) {
        case 'tax':
          var activeTerms = [],
            taxonomy = $filter.data('taxonomy'),
            isAttr = 0 === taxonomy.indexOf('filter'),
            relation = $filter.data('relation');
          if ($dropdown.length) {
            if (multiple) {
              activeTerms = $dropdown.val();
            } else {
              activeTerms.push($dropdown.val());
            }
          } else {
            $active = $filter.find('.filter-item').filter('.active').children('a, label');
            activeTerms = $active.get().reduce(function (a, v) {
              var val;
              v = $(v);
              val = v.is('label') ? v.find(':input').val() : v.data('term-slug');
              if (!val) {
                return a;
              }
              a.push(val);
              return a;
            }, activeTerms);
          }
          if (!multiple) {
            properties[taxonomy] = activeTerms.pop();
          } else {
            var glue = !isAttr && 'and' === relation ? '+' : ',';
            properties[taxonomy] = activeTerms.join(glue);
          }
          if (isAttr) {
            properties[taxonomy.replace('filter_', 'query_type_')] = relation;
          }
          break;
        case 'review':
          if ($dropdown.length) {
            properties.rating_filter = $dropdown.val();
          } else {
            $active = $filter.find('.filter-item').filter('.active').children('a, label');
            if (!multiple) {
              $active = $active.first();
              properties.rating_filter = $active.is('label') ? $active.find(':input').val() : $active.data('rating');
            } else {
              properties.rating_filter = $active.get().reduce(function (a, v) {
                var val;
                v = $(v);
                val = v.is('label') ? v.find(':input').val() : v.data('rating');
                if (!val) {
                  return a;
                }
                a.push(val);
                return a;
              }, []).join(',');
            }
          }
          break;
        case 'price_range':
          if ($dropdown.length) {
            if (multiple) {
              properties.price_ranges = $dropdown.val().join(',');
            } else {
              properties.min_price = $dropdown.val().split('-')[0];
              properties.max_price = $dropdown.val().split('-')[1];
            }
          } else {
            $active = $filter.find('.filter-item').filter('.active').children('a, label');
            if (multiple) {
              properties.price_ranges = $active.get().reduce(function (a, v) {
                var min = $(v).data('range-min'),
                  max = $(v).data('range-max');
                a += (max ? "".concat(min, "-").concat(max) : min) + ',';
                return a;
              }, '').replace(/^(.*),$/, '$1');
            } else {
              properties.min_price = parseFloat($active.first().data('range-min'));
              properties.max_price = parseFloat($active.first().data('range-max'));
            }
          }
          break;
        case 'price_slider':
          properties.min_price = parseFloat($filter.find('.price-slider-min').val());
          properties.max_price = parseFloat($filter.find('.price-slider-max').val());
          break;
        case 'stock_sale':
          if ($filter.find('.filter-on-sale').is('.active')) {
            properties.onsale_filter = 1;
          }
          if ($filter.find('.filter-in-stock').is('.active')) {
            properties.instock_filter = 1;
          }
          if ($filter.find('.filter-featured').is('.active')) {
            properties.featured_filter = 1;
          }
          break;
        case 'orderby':
          properties.orderby = $filter.find('.filter-order-by').val();
          break;
        default:
          break;
      }
      filteredProperties = $filter.triggerHandler('yith_wcan_filter_properties', [properties, self]);
      properties = typeof filteredProperties !== 'undefined' ? filteredProperties : properties;
      return properties;
    }

    // retrieves properties for all filters of the preset
  }, {
    key: "getFiltersProperties",
    value: function getFiltersProperties() {
      var properties = {};
      var self = this;
      this.getFilters().each(function () {
        var $filter = $(this);
        if (self.isFilterActive($filter)) {
          var filterProperties = self.getFilterProperties($filter);
          properties = self.mergeProperties(properties, filterProperties, $filter);
        }
      });
      return properties;
    }

    // retrieve filters matching any of the properties passed
  }, {
    key: "getFiltersByProperties",
    value: function getFiltersByProperties(properties) {
      var self = this;
      return this.getFilters().filter(function () {
        var $filter = $(this);
        if (self.isFilterActive($filter)) {
          var filterProperties = self.getFilterProperties($filter),
            hasProp = false;
          var _iterator = _createForOfIteratorHelper(properties),
            _step;
          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              var prop = _step.value;
              if (['min_price', 'max_price', 'price_ranges'].includes(prop) && (filterProperties.min_price || filterProperties.price_ranges)) {
                hasProp = true;
                break;
              } else if (filterProperties[prop]) {
                hasProp = true;
                break;
              }
            }
          } catch (err) {
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
          return hasProp;
        }
        return false;
      });
    }

    // show clear selection anchor
  }, {
    key: "maybeToggleClearFilter",
    value: function maybeToggleClearFilter($filter) {
      if (!this.isFilterActive($filter)) {
        this.maybeHideClearFilter($filter);
      } else {
        this.maybeShowClearFilter($filter);
      }
    }

    // show clear all selections anchor
  }, {
    key: "maybeToggleClearAllFilters",
    value: function maybeToggleClearAllFilters() {
      if (!this.isAnyFilterActive()) {
        this.maybeHideClearAllFilters();
      } else {
        this.maybeShowClearAllFilters();
      }
    }

    // show clear selection anchor
  }, {
    key: "maybeShowClearFilter",
    value: function maybeShowClearFilter($filter) {
      var _this16 = this;
      if (!this.isFilterActive($filter) || !yith_wcan_shortcodes.show_clear_filter) {
        return;
      }

      // remove clear selection link if already added.
      $filter.find('.clear-selection').remove();

      // add new clear selection link.
      $('<a/>', {
        "class": 'clear-selection',
        text: yith_wcan_shortcodes.labels.clear_selection,
        role: 'button'
      }).prependTo($filter.find('.filter-content')).on('click', function (ev) {
        ev.preventDefault();
        _this16.deactivateFilter($filter, false, yith_wcan_shortcodes.instant_filters);
        _this16.maybeHideClearFilter($filter);
        if (yith_wcan_shortcodes.instant_filters) {
          _this16.closeModal();
        }
      });
    }

    // show clearAll anchor, when on mobile layout
  }, {
    key: "maybeShowClearAllFilters",
    value: function maybeShowClearAllFilters() {
      var _this17 = this;
      if (!this.isAnyFilterActive() || !this.isMobile) {
        return;
      }

      // remove clear selection link if already added.
      this.$preset.find('.clear-selection').remove();

      // add new clear selection link.
      $('<a/>', {
        "class": 'clear-selection',
        text: yith_wcan_shortcodes.labels.clear_all_selections,
        role: 'button'
      }).prependTo(this.$preset.find('.filters-container')).on('click', function (ev) {
        ev.preventDefault();
        _this17.deactivateAllFilters(yith_wcan_shortcodes.instant_filters);
        _this17.maybeHideClearAllFilters();
        if (yith_wcan_shortcodes.instant_filters) {
          _this17.closeModal();
        }
      });
    }

    // hide clear selection anchor
  }, {
    key: "maybeHideClearFilter",
    value: function maybeHideClearFilter($filter) {
      if (this.isFilterActive($filter) || !yith_wcan_shortcodes.show_clear_filter) {
        return;
      }

      // remove clear selection link.
      $filter.find('.clear-selection').remove();
    }

    // show clearAll anchor, when on mobile layout
  }, {
    key: "maybeHideClearAllFilters",
    value: function maybeHideClearAllFilters() {
      if (this.isAnyFilterActive()) {
        return;
      }

      // remove clear selection link.
      this.$preset.find('.filters-container').children('.clear-selection').remove();
    }

    // deactivate filter
  }, {
    key: "deactivateFilter",
    value: function deactivateFilter($filter, properties, doFilter) {
      var filterType = $filter.data('filter-type'),
        $items = $filter.find('.filter-item'),
        $activeItems = $items.filter('.active'),
        $dropdown = $filter.find('.filter-dropdown');
      this.inhibitFilters = true;
      switch (filterType) {
        case 'tax':
          var taxonomy = $filter.data('taxonomy');
          if ($dropdown.length) {
            if (!properties) {
              $dropdown.find('option').prop('selected', false);
            } else {
              $dropdown.find('option').each(function () {
                var $option = $(this);
                if ($option.val().toString() === properties[taxonomy].toString()) {
                  $option.prop('selected', false);
                }
              });
            }
            $dropdown.change();
          } else if (!properties) {
            $activeItems.children('label').children('a').click();
            $activeItems.removeClass('active');
          } else {
            $activeItems.each(function () {
              var $item = $(this),
                $label = $item.children('label'),
                $anchor = $item.children('a'),
                value;
              value = $label.length ? $label.find(':input').val() : $anchor.data('term-slug');
              if (value.toString() === properties[taxonomy].toString()) {
                $item.children('label').children('a').click();
                $item.removeClass('active');
              }
            });
          }
          break;
        case 'review':
          if ($dropdown.length) {
            if (!properties) {
              $dropdown.find('option').prop('selected', false);
            } else {
              $dropdown.find('option').each(function () {
                var $option = $(this);
                if ($option.val() === properties.rating_filter) {
                  $option.prop('selected', false);
                }
              });
            }
            $dropdown.change();
          } else if (!properties) {
            $activeItems.children('label').children('a').click();
            $activeItems.removeClass('active');
          } else {
            $activeItems.each(function () {
              var $item = $(this),
                $label = $item.children('label'),
                $anchor = $item.children('a'),
                value;
              value = $label.length ? $label.find(':input').val() : $anchor.data('rating');
              if (value === properties.rating_filter) {
                $item.children('label').children('a').click();
                $item.removeClass('active');
              }
            });
          }
          break;
        case 'price_range':
          if ($dropdown.length) {
            if (!properties) {
              $dropdown.find('option').prop('selected', false);
            } else {
              $dropdown.find('option').each(function () {
                var $option = $(this),
                  formattedRange = properties.min_price + (properties.max_price ? "-".concat(properties.max_price) : '');
                if ($option.val() === formattedRange) {
                  $option.prop('selected', false);
                }
              });
            }
            $dropdown.change();
          } else if (!properties) {
            $activeItems.children('label').children('a').click();
            $activeItems.removeClass('active');
          } else {
            $activeItems.each(function () {
              var $item = $(this),
                $label = $item.children('label'),
                $anchor = $item.children('a'),
                formattedRange,
                value;
              value = $label.length ? $label.find(':input').val() : $anchor.data('min_price') + ($anchor.data('max_price') ? '-' + $anchor.data('max_price') : '');
              if (properties.min_price) {
                formattedRange = properties.min_price + (properties.max_price ? '-' + properties.max_price : '');
              } else if (properties.price_ranges) {
                formattedRange = properties.price_ranges;
              }
              if (value === formattedRange) {
                $item.children('label').children('a').click();
                $item.removeClass('active');
              }
            });
          }
          break;
        case 'price_slider':
          var $priceSlider = $filter.find('.price-slider');
          $filter.find('.price-slider-min').val($priceSlider.data('min'));
          $filter.find('.price-slider-max').val($priceSlider.data('max')).change();
          break;
        case 'orderby':
          $filter.find('select').val('menu_order');
          break;
        case 'stock_sale':
          if (!properties) {
            $filter.find('.filter-in-stock').find(':input').prop('checked', false).change();
            $filter.find('.filter-on-sale').find(':input').prop('checked', false).change();
            $filter.find('.filter-featured').find(':input').prop('checked', false).change();
            $items.removeClass('active');
          } else {
            if (properties !== null && properties !== void 0 && properties.instock_filter) {
              $filter.find('.filter-in-stock').find(':input').prop('checked', false).change().closest('.filter-item').removeClass('active');
            }
            if (properties !== null && properties !== void 0 && properties.onsale_filter) {
              $filter.find('.filter-on-sale').find(':input').prop('checked', false).change().closest('.filter-item').removeClass('active');
            }
            if (properties !== null && properties !== void 0 && properties.featured_filter) {
              $filter.find('.filter-featured').find(':input').prop('checked', false).change().closest('.filter-item').removeClass('active');
            }
          }
          break;
        default:
          $items.removeClass('active');
          break;
      }
      this.inhibitFilters = false;
      this.activeFilters = false;
      if (doFilter) {
        this.filter();
      }
    }

    // deactivate all filters
  }, {
    key: "deactivateAllFilters",
    value: function deactivateAllFilters(doFilter) {
      var self = this,
        $filters = this.getFilters();
      $filters.each(function () {
        var $filter = $(this);
        self.deactivateFilter($filter);
      });
      this.activeFilters = false;
      if (doFilter) {
        this.filter();
      }
      return true;
    }

    // deactivate filters that matches a specific set of properties
  }, {
    key: "deactivateFilterByProperties",
    value: function deactivateFilterByProperties(properties, doFilter) {
      var self = this,
        $filters = this.getFiltersByProperties(Object.keys(properties));
      if (!$filters.length) {
        return false;
      }
      $filters.each(function () {
        var $filter = $(this);
        self.deactivateFilter($filter, properties, doFilter);
      });
      return true;
    }

    // open toggle
  }, {
    key: "toggle",
    value: function toggle($target, $container, status) {
      if ('undefined' === typeof status) {
        status = $container.hasClass('closed');
      }
      var method = status ? 'slideDown' : 'slideUp',
        classToAdd = status ? 'opened' : 'closed',
        classToRemove = status ? 'closed' : 'opened';
      $target[method](400, function () {
        $container.addClass(classToAdd).removeClass(classToRemove);
        $target.trigger('yith_wcan_toggle_element', [$container, status]);
      });
    }

    // open filter if title is collapsable
  }, {
    key: "openFilter",
    value: function openFilter($filter) {
      var $title = $filter.find('.collapsable');
      if (!$title.length) {
        return;
      }
      this.toggle($filter.find('.filter-content'), $title, true);
    }

    // open all filters in a preset
  }, {
    key: "openAllFilters",
    value: function openAllFilters($filter) {
      var self = this,
        $filters = this.getFilters();
      $filters.each(function () {
        self.openFilter($(this));
      });
    }

    // close filter if title is collapsable
  }, {
    key: "closeFilter",
    value: function closeFilter($filter) {
      var $title = $filter.find('.collapsable');
      if (!$title.length) {
        return;
      }
      this.toggle($filter.find('.filter-content'), $title, false);
    }

    // close all filters in a preset; if a specific filter is pased as parameter, system will keep it open
  }, {
    key: "closeAllFilters",
    value: function closeAllFilters($filter) {
      var self = this,
        $filters = this.getFilters();
      $filters.each(function () {
        self.closeFilter($(this));
      });
      if ('undefined' !== typeof $filter) {
        this.openFilter($filter);
      }
    }

    // open filters as a modal, when in mobile layout
  }, {
    key: "openModal",
    value: function openModal() {
      var _this18 = this;
      if (!this.isMobile) {
        return;
      }
      if (yith_wcan_shortcodes.toggles_open_on_modal) {
        this._openAllCollapsables();
      } else {
        this._closeAllCollapsables();
      }
      $('body').css('overflow', 'hidden').addClass('yith-wcan-preset-modal-open');
      this.$preset.show();
      setTimeout(function () {
        _this18.$preset.addClass('open');
      }, 100);
    }

    // close filters modal, when in mobile layout
  }, {
    key: "closeModal",
    value: function closeModal() {
      var _this19 = this;
      if (!this.isMobile) {
        return;
      }
      this.$preset.removeClass('open');
      setTimeout(function () {
        _this19.$preset.hide();
        $('body').css('overflow', 'auto').removeClass('yith-wcan-preset-modal-open');
      }, 300);
    }

    // utility that formats the price according to store configuration.
  }, {
    key: "formatPrice",
    value: function formatPrice(price) {
      if ('undefined' !== typeof accounting) {
        var _yith_wcan_shortcodes3, _yith_wcan_shortcodes4, _yith_wcan_shortcodes5, _yith_wcan_shortcodes6;
        price = accounting.formatMoney(price, {
          symbol: (_yith_wcan_shortcodes3 = yith_wcan_shortcodes.currency_format) === null || _yith_wcan_shortcodes3 === void 0 ? void 0 : _yith_wcan_shortcodes3.symbol,
          decimal: (_yith_wcan_shortcodes4 = yith_wcan_shortcodes.currency_format) === null || _yith_wcan_shortcodes4 === void 0 ? void 0 : _yith_wcan_shortcodes4.decimal,
          thousand: (_yith_wcan_shortcodes5 = yith_wcan_shortcodes.currency_format) === null || _yith_wcan_shortcodes5 === void 0 ? void 0 : _yith_wcan_shortcodes5.thousand,
          precision: 0,
          format: (_yith_wcan_shortcodes6 = yith_wcan_shortcodes.currency_format) === null || _yith_wcan_shortcodes6 === void 0 ? void 0 : _yith_wcan_shortcodes6.format
        });
      }
      return price;
    }

    // utility that merges together sets of filter properties
  }, {
    key: "mergeProperties",
    value: function mergeProperties(set1, set2, $filter) {
      // search for common properties
      for (var prop in set2) {
        if (!set2.hasOwnProperty(prop)) {
          continue;
        }
        if (!!set1[prop]) {
          switch (prop) {
            case 'rating_filter':
            case 'min_price':
            case 'max_price':
            case 'onsale_filter':
            case 'instock_filter':
            case 'orderby':
              // just override default value
              set1[prop] = set2[prop];
              break;
            default:
              if (0 === prop.indexOf('query_type_')) {
                // query_type param
                set1[prop] = set2[prop];
              } else {
                // we're dealing with taxonomy
                var relation = ($filter === null || $filter === void 0 ? void 0 : $filter.data('relation')) || 'and',
                  isAttr = 0 === prop.indexOf('filter_'),
                  glue = !isAttr && 'and' === relation ? '+' : ',';
                var newValue = set1[prop].replace(',', glue) + glue + set2[prop].replace(',', glue);
                newValue = newValue.split(glue).filter(function (value, index, arr) {
                  return arr.indexOf(value) === index;
                }).join(glue);
                set1[prop] = newValue;
                if (isAttr) {
                  var queryTypeParam = prop.replace('filter_', 'query_type_');
                  set1[queryTypeParam] = 'and';
                  set2[queryTypeParam] = 'and';
                }
              }
          }
          delete set2[prop];
        }
      }
      $.extend(set1, set2);
      return set1;
    }
  }]);
}();

;// ./assets/js/shortcodes/modules/yith-wcan-dropdown-premium.js


/* global globalThis, jQuery, yith_wcan_shortcodes, accounting */
function yith_wcan_dropdown_premium_typeof(o) { "@babel/helpers - typeof"; return yith_wcan_dropdown_premium_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, yith_wcan_dropdown_premium_typeof(o); }
function yith_wcan_dropdown_premium_classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function yith_wcan_dropdown_premium_defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, yith_wcan_dropdown_premium_toPropertyKey(o.key), o); } }
function yith_wcan_dropdown_premium_createClass(e, r, t) { return r && yith_wcan_dropdown_premium_defineProperties(e.prototype, r), t && yith_wcan_dropdown_premium_defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _possibleConstructorReturn(t, e) { if (e && ("object" == yith_wcan_dropdown_premium_typeof(e) || "function" == typeof e)) return e; if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined"); return _assertThisInitialized(t); }
function _assertThisInitialized(e) { if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); return e; }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
function _superPropGet(t, o, e, r) { var p = _get(_getPrototypeOf(1 & r ? t.prototype : t), o, e); return 2 & r && "function" == typeof p ? function (t) { return p.apply(e, t); } : p; }
function _get() { return _get = "undefined" != typeof Reflect && Reflect.get ? Reflect.get.bind() : function (e, t, r) { var p = _superPropBase(e, t); if (p) { var n = Object.getOwnPropertyDescriptor(p, t); return n.get ? n.get.call(arguments.length < 3 ? e : r) : n.value; } }, _get.apply(null, arguments); }
function _superPropBase(t, o) { for (; !{}.hasOwnProperty.call(t, o) && null !== (t = _getPrototypeOf(t));); return t; }
function _getPrototypeOf(t) { return _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) { return t.__proto__ || Object.getPrototypeOf(t); }, _getPrototypeOf(t); }
function _inherits(t, e) { if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function"); t.prototype = Object.create(e && e.prototype, { constructor: { value: t, writable: !0, configurable: !0 } }), Object.defineProperty(t, "prototype", { writable: !1 }), e && _setPrototypeOf(t, e); }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
function yith_wcan_dropdown_premium_defineProperty(e, r, t) { return (r = yith_wcan_dropdown_premium_toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function yith_wcan_dropdown_premium_toPropertyKey(t) { var i = yith_wcan_dropdown_premium_toPrimitive(t, "string"); return "symbol" == yith_wcan_dropdown_premium_typeof(i) ? i : i + ""; }
function yith_wcan_dropdown_premium_toPrimitive(t, r) { if ("object" != yith_wcan_dropdown_premium_typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != yith_wcan_dropdown_premium_typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }


var YITH_WCAN_Dropdown_Premium = /*#__PURE__*/function (_YITH_WCAN_Dropdown) {
  function YITH_WCAN_Dropdown_Premium() {
    var _this;
    yith_wcan_dropdown_premium_classCallCheck(this, YITH_WCAN_Dropdown_Premium);
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    _this = _callSuper(this, YITH_WCAN_Dropdown_Premium, [].concat(args));
    // preset DOM
    yith_wcan_dropdown_premium_defineProperty(_this, "$preset", false);
    return _this;
  }
  _inherits(YITH_WCAN_Dropdown_Premium, _YITH_WCAN_Dropdown);
  return yith_wcan_dropdown_premium_createClass(YITH_WCAN_Dropdown_Premium, [{
    key: "getPreset",
    value:
    // retrieve preset containing, if any
    function getPreset() {
      if (this.preset) {
        return this.preset;
      }
      this.$preset = this.$originalSelect.closest('.yith-wcan-filters');
      if (!this.$preset.length) {
        return false;
      }
      return this.$preset;
    }

    // create dropdown
  }, {
    key: "_initTemplate",
    value: function _initTemplate() {
      var _this$getPreset;
      if (!((_this$getPreset = this.getPreset()) !== null && _this$getPreset !== void 0 && _this$getPreset.hasClass('horizontal'))) {
        _superPropGet(YITH_WCAN_Dropdown_Premium, "_initTemplate", this, 3)([]);
      } else {
        var $dropdownSpan = $('<div>', {
            "class": 'dropdown-wrapper'
          }),
          $matchingItemsList = $('<ul/>', {
            "class": 'matching-items filter-items'
          });
        $dropdownSpan.append($matchingItemsList);
        if (this.options.showSearch) {
          this._initSearchTemplate($dropdownSpan);
        }
        if (this.options.paginate) {
          this._initShowMoreTemplate($dropdownSpan);
        }
        this.$originalSelect.after($dropdownSpan);
        this.$_main = null;
        this.$_label = null;
        this.$_dropdown = $dropdownSpan;
        this.$_items = $matchingItemsList;
        this._populateItems();
      }
    }
  }]);
}(YITH_WCAN_Dropdown);

;// ./assets/js/shortcodes/modules/yith-wcan-preset-premium.js


/* global globalThis, jQuery, yith_wcan_shortcodes, accounting */
function yith_wcan_preset_premium_typeof(o) { "@babel/helpers - typeof"; return yith_wcan_preset_premium_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, yith_wcan_preset_premium_typeof(o); }
function yith_wcan_preset_premium_classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function yith_wcan_preset_premium_defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, yith_wcan_preset_premium_toPropertyKey(o.key), o); } }
function yith_wcan_preset_premium_createClass(e, r, t) { return r && yith_wcan_preset_premium_defineProperties(e.prototype, r), t && yith_wcan_preset_premium_defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function yith_wcan_preset_premium_toPropertyKey(t) { var i = yith_wcan_preset_premium_toPrimitive(t, "string"); return "symbol" == yith_wcan_preset_premium_typeof(i) ? i : i + ""; }
function yith_wcan_preset_premium_toPrimitive(t, r) { if ("object" != yith_wcan_preset_premium_typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != yith_wcan_preset_premium_typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function yith_wcan_preset_premium_callSuper(t, o, e) { return o = yith_wcan_preset_premium_getPrototypeOf(o), yith_wcan_preset_premium_possibleConstructorReturn(t, yith_wcan_preset_premium_isNativeReflectConstruct() ? Reflect.construct(o, e || [], yith_wcan_preset_premium_getPrototypeOf(t).constructor) : o.apply(t, e)); }
function yith_wcan_preset_premium_possibleConstructorReturn(t, e) { if (e && ("object" == yith_wcan_preset_premium_typeof(e) || "function" == typeof e)) return e; if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined"); return yith_wcan_preset_premium_assertThisInitialized(t); }
function yith_wcan_preset_premium_assertThisInitialized(e) { if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); return e; }
function yith_wcan_preset_premium_isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); } catch (t) {} return (yith_wcan_preset_premium_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
function yith_wcan_preset_premium_superPropGet(t, o, e, r) { var p = yith_wcan_preset_premium_get(yith_wcan_preset_premium_getPrototypeOf(1 & r ? t.prototype : t), o, e); return 2 & r && "function" == typeof p ? function (t) { return p.apply(e, t); } : p; }
function yith_wcan_preset_premium_get() { return yith_wcan_preset_premium_get = "undefined" != typeof Reflect && Reflect.get ? Reflect.get.bind() : function (e, t, r) { var p = yith_wcan_preset_premium_superPropBase(e, t); if (p) { var n = Object.getOwnPropertyDescriptor(p, t); return n.get ? n.get.call(arguments.length < 3 ? e : r) : n.value; } }, yith_wcan_preset_premium_get.apply(null, arguments); }
function yith_wcan_preset_premium_superPropBase(t, o) { for (; !{}.hasOwnProperty.call(t, o) && null !== (t = yith_wcan_preset_premium_getPrototypeOf(t));); return t; }
function yith_wcan_preset_premium_getPrototypeOf(t) { return yith_wcan_preset_premium_getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) { return t.__proto__ || Object.getPrototypeOf(t); }, yith_wcan_preset_premium_getPrototypeOf(t); }
function yith_wcan_preset_premium_inherits(t, e) { if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function"); t.prototype = Object.create(e && e.prototype, { constructor: { value: t, writable: !0, configurable: !0 } }), Object.defineProperty(t, "prototype", { writable: !1 }), e && yith_wcan_preset_premium_setPrototypeOf(t, e); }
function yith_wcan_preset_premium_setPrototypeOf(t, e) { return yith_wcan_preset_premium_setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, yith_wcan_preset_premium_setPrototypeOf(t, e); }



var YITH_WCAN_Preset_Premium = /*#__PURE__*/function (_YITH_WCAN_Preset) {
  // init object
  function YITH_WCAN_Preset_Premium(el) {
    var _this;
    var extra = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    yith_wcan_preset_premium_classCallCheck(this, YITH_WCAN_Preset_Premium);
    _this = yith_wcan_preset_premium_callSuper(this, YITH_WCAN_Preset_Premium, [el, extra]);
    if (_this.isHorizontal() && !globalThis.yith_wcan_backdrop_init) {
      _this._initBackdropClick();
      globalThis.yith_wcan_backdrop_init = true;
    }
    return _this;
  }

  // handles click outside of toggles, to close them in horizontal mode
  yith_wcan_preset_premium_inherits(YITH_WCAN_Preset_Premium, _YITH_WCAN_Preset);
  return yith_wcan_preset_premium_createClass(YITH_WCAN_Preset_Premium, [{
    key: "_initBackdropClick",
    value: function _initBackdropClick() {
      var _this2 = this;
      var isHorizontal = this.isHorizontal();
      if (isHorizontal) {
        this.getFilters().on('click', function (ev) {
          return ev.stopPropagation();
        });
        $(document).on('click', function () {
          if (_this2.isMobile) {
            return;
          }
          _this2.maybeCloseAllHorizontalToggles();
        });
      }
    }

    // check if preset has horizontal layout
  }, {
    key: "isHorizontal",
    value: function isHorizontal() {
      var _this$$preset;
      return (_this$$preset = this.$preset) === null || _this$$preset === void 0 ? void 0 : _this$$preset.hasClass('horizontal');
    }

    // apply filters when possible
  }, {
    key: "maybeFilter",
    value: function maybeFilter($initiator) {
      var $filter = $initiator.closest('.yith-wcan-filter');

      // register status change
      this.maybeRegisterStatusChange();
      if (this.isHorizontal() && !this.isMobile && this.isHorizontalToggle($filter.find('.filter-title'))) {
        // show count when necessary
        this.maybeUpdateFiltersCount($filter);

        // skip filtering when started from anything but Save and Clear buttons, in horizontal mode.
        if (!$initiator.hasClass('apply-filters') && !$initiator.hasClass('clear-selection') && !yith_wcan_shortcodes.instant_horizontal_filter) {
          return;
        }
      }
      if (yith_wcan_shortcodes.instant_filters && yith_wcan_shortcodes.instant_horizontal_filter) {
        this.maybeCloseAllHorizontalToggles();
      }
      yith_wcan_preset_premium_superPropGet(YITH_WCAN_Preset_Premium, "maybeFilter", this, 3)([]);
    }

    // show clear selection anchor
  }, {
    key: "maybeShowClearFilter",
    value: function maybeShowClearFilter($filter) {
      var _this3 = this;
      if (!this.isFilterActive($filter) || !yith_wcan_shortcodes.show_clear_filter) {
        return;
      }
      if (!this.isHorizontal() || this.isMobile) {
        yith_wcan_preset_premium_superPropGet(YITH_WCAN_Preset_Premium, "maybeShowClearFilter", this, 3)([$filter]);
      } else {
        // remove clear selection link if already added.
        $filter.find('.clear-selection').remove();

        // add new clear selection link.
        var $clearButton = $('<a/>', {
          "class": 'clear-selection button',
          text: yith_wcan_shortcodes.labels.clear_selection,
          role: 'button'
        });
        $clearButton.prependTo($filter.find('.filter-content-footer')).on('click', function (ev) {
          ev.preventDefault();
          _this3.deactivateFilter($filter, false, yith_wcan_shortcodes.instant_filters);
          _this3.maybeUpdateFiltersCount($filter);
          _this3.maybeHideClearFilter($filter);
          _this3.maybeFilter($clearButton);
          _this3.maybeCloseHorizontalToggle($filter.find('.filter-title.collapsable'));
        });
      }
    }

    // init filter
  }, {
    key: "_initFilter",
    value: function _initFilter($filter) {
      var _this4 = this;
      // eslint-disable-next-line no-shadow
      return yith_wcan_preset_premium_superPropGet(YITH_WCAN_Preset_Premium, "_initFilter", this, 3)([$filter]).then(function ($filter) {
        _this4.maybeUpdateFiltersCount($filter);
        _this4.isHorizontal() && $filter.on('click', function (ev) {
          return ev.stopPropagation();
        });
      });
    }

    // init tooltip
  }, {
    key: "_initTooltip",
    value: function _initTooltip($filter, position) {
      if (this.isHorizontal()) {
        return;
      }
      yith_wcan_preset_premium_superPropGet(YITH_WCAN_Preset_Premium, "_initTooltip", this, 3)([$filter, position]);
    }

    // trigger handling after layout change
  }, {
    key: "_afterLayoutChange",
    value: function _afterLayoutChange() {
      yith_wcan_preset_premium_superPropGet(YITH_WCAN_Preset_Premium, "_afterLayoutChange", this, 3)([]);
      if (this.isMobile) {
        this._removeAllHorizontalTogglesFooter();
      } else {
        this._addAllHorizontalTogglesFooter();
      }
    }

    // init dropdown object
  }, {
    key: "_initDropdownObject",
    value: function _initDropdownObject($dropdown, opts) {
      return new YITH_WCAN_Dropdown_Premium($dropdown, opts);
    }

    // init toggle to generic toggle/target pair
  }, {
    key: "_initToggle",
    value: function _initToggle($toggle, $container, $target) {
      var _this5 = this;
      var isHorizontal = this.isHorizontal();
      if ($container.hasClass('closed')) {
        $target.hide();
      }
      if (isHorizontal) {
        this._addHorizontalToggleFooter($toggle);
      }
      $toggle.off('click').on('click', function (ev) {
        ev.stopPropagation();
        if (isHorizontal && !_this5.isMobile && $toggle.hasClass('filter-title')) {
          // first of all, close other toggles.
          _this5.maybeCloseAllHorizontalToggles($target);

          // now open current one.
          $target.toggle(0, function () {
            $container.toggleClass('opened').toggleClass('closed');
          });
        } else {
          _this5.toggle($target, $container);
        }
        $target.trigger('yith_wcan_after_toggle_element', [$container]);
      });
    }

    // check if a specific toggle should be shown in Horizontal mode
  }, {
    key: "isHorizontalToggle",
    value: function isHorizontalToggle($toggle) {
      if (!this.isHorizontal()) {
        return false;
      }
      return $toggle.is('.collapsable');
    }

    // close toggle for horizontal layout
  }, {
    key: "maybeCloseHorizontalToggle",
    value: function maybeCloseHorizontalToggle($toggle) {
      var $content = $toggle.next('.filter-content');
      if (!$content.length || !this.isHorizontal() || this.isMobile || !$toggle.hasClass('filter-title') || !this.isHorizontalToggle($toggle)) {
        return;
      }
      $content.hide();
      $toggle.toggleClass('opened').toggleClass('closed');
    }

    // close all Horizontal toggles
  }, {
    key: "maybeCloseAllHorizontalToggles",
    value: function maybeCloseAllHorizontalToggles($exclude) {
      $('.yith-wcan-filters.horizontal.enhanced').find('.filter-title.collapsable').next('.filter-content').not($exclude).hide().prev('.filter-title').removeClass('opened').addClass('closed');
    }

    // add filter content footer for horizontal layout
  }, {
    key: "_addHorizontalToggleFooter",
    value: function _addHorizontalToggleFooter($toggle) {
      var _this6 = this;
      var $content = $toggle.next('.filter-content');
      if (!$content.length || !this.isHorizontal() || this.isMobile || !$toggle.hasClass('filter-title') || !this.isHorizontalToggle($toggle) || yith_wcan_shortcodes.instant_horizontal_filter) {
        return;
      }
      var $currentFilter = $toggle.closest('.yith-wcan-filter'),
        $footer = $('<div/>', {
          "class": 'filter-content-footer'
        }),
        $applyFilterButton = $('<a/>', {
          "class": 'apply-filters button alt',
          text: yith_wcan_shortcodes.labels.save
        });
      $applyFilterButton.on('click', function () {
        _this6.maybeFilter($applyFilterButton);
        _this6.maybeCloseAllHorizontalToggles($toggle);
      });
      $footer.append($applyFilterButton).appendTo($content);
    }

    // add filter content footer for all horizontal toggles
  }, {
    key: "_addAllHorizontalTogglesFooter",
    value: function _addAllHorizontalTogglesFooter() {
      var self = this;
      this.getFilters().each(function () {
        var $filter = $(this),
          $toggle = $filter.find('.filter-title.collapsable');
        if (!$toggle.length) {
          return;
        }
        self._addHorizontalToggleFooter($toggle);
      });
    }

    // remove filter content footer for horizontal layout
  }, {
    key: "_removeHorizontalToggleFooter",
    value: function _removeHorizontalToggleFooter($toggle) {
      var $content = $toggle.next('.filter-content');
      if (!$content.length) {
        return;
      }
      $content.find('.filter-content-footer').remove();
    }

    // add filter content footer for all horizontal toggles
  }, {
    key: "_removeAllHorizontalTogglesFooter",
    value: function _removeAllHorizontalTogglesFooter() {
      var self = this;
      this.getFilters().each(function () {
        var $filter = $(this),
          $toggle = $filter.find('.filter-title.collapsable');
        if (!$toggle.length) {
          return;
        }
        self._removeHorizontalToggleFooter($toggle);
      });
    }

    // show filters count
  }, {
    key: "maybeUpdateFiltersCount",
    value: function maybeUpdateFiltersCount($filter) {
      var $toggle = $filter.find('.filter-title.collapsable');

      // remove current count
      $toggle.find('.filter-count').remove();
      if (!$toggle.length || !this.isHorizontalToggle($toggle) || !this.isFilterActive($filter)) {
        return;
      }
      var count = this.countActiveItems($filter);

      // if there is any filter active, show count
      if (!count) {
        return;
      }
      var $counter = $('<span/>', {
        "class": 'filter-count',
        text: count
      });
      $toggle.append($counter);
    }
  }]);
}(YITH_WCAN_Preset);

;// ./assets/js/shortcodes/index.js


/* global globalThis, jQuery, yith_wcan_shortcodes, accounting */





jQuery(function ($) {
  var filters = [];
  var initFilters = function initFilters() {
    var extra = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
    if (extra) {
      initFilterOverlay(extra);
    } else {
      jQuery('.yith-wcan-filters').not('.enhanced').each(function () {
        new YITH_WCAN_Preset_Premium(jQuery(this));
      });
      jQuery('.yith-wcan-active-filters').not('.enhanced').each(function () {
        new YITH_WCAN_Filter_Labels(jQuery(this));
      });
      jQuery('.yith-wcan-reset-filters').not('.enhanced').each(function () {
        new YITH_WCAN_Reset_Button(jQuery(this));
      });
      jQuery('.yith-wcan-filters-opener').not('.enhanced').each(function () {
        new YITH_WCAN_Modal_Opener(jQuery(this));
      });
    }
  };
  var initFilterOverlay = function initFilterOverlay(extra) {
    var _extra$filters;
    var parent = $(document).find('.ywcas-overlay-wrapper-search');
    parent.find('.yith-wcan-filters').not('.enhanced').each(function () {
      filters.push(new YITH_WCAN_Preset_Premium($(this), extra));
    });
    $.ajax({
      method: 'GET',
      url: yith_wcan_shortcodes.base_url,
      data: {
        'wc-ajax': 'yith_wcan_render_active_filters',
        security: yith_wcan_shortcodes.nonces.render_active_filters,
        _preset_filters: (_extra$filters = extra === null || extra === void 0 ? void 0 : extra.filters) !== null && _extra$filters !== void 0 ? _extra$filters : []
      },
      success: function success(response) {
        if (response.success) {
          var active = initActiveLabels(response.data, parent);
          initResetButton(response.data, parent, active > 0);
        }
      }
    });
  };
  var initActiveLabels = function initActiveLabels(data, parent) {
    var position = yith_wcan_shortcodes.active_filters_position;
    var active_filters = data.active_filters;
    var presets = Object.keys(active_filters);
    presets.forEach(function (preset) {
      var template = active_filters[preset];
      var parentDiv = 'before_products' !== position ? parent.find('#preset_' + preset).find('.filters-container form') : parent.find('.ywcas-overlay-filled-content .ywcas-overlay-grid-block');
      if (parentDiv) {
        if ('before_filters' === position || 'before_products' === position) {
          parentDiv.prepend(template);
        } else {
          parentDiv.append(template);
        }
      }
    });
    parent.find('.yith-wcan-active-filters').not('.enhanced').each(function () {
      new YITH_WCAN_Filter_Labels(jQuery(this));
    });
    return presets.length;
  };
  var initResetButton = function initResetButton(data, parent, show) {
    var position = yith_wcan_shortcodes.reset_button_position;
    var button = data.reset_button,
      parentDiv = 'before_products' !== position ? parent.find('.filters-container form') : parent.find('.ywcas-overlay-filled-content .ywcas-overlay-grid-block');
    parent.find('.yith-wcan-reset-filters').remove();
    if (parentDiv && show) {
      if ('before_filters' === position || 'before_products' === position) {
        parentDiv.prepend(button);
      } else if ('after_filters' === position) {
        parentDiv.append(button);
      } else {
        parent.find('.yith-wcan-active-filters').append(button);
      }
    }
    parent.find('.yith-wcan-reset-filters').not('.enhanced').each(function () {
      new YITH_WCAN_Reset_Button(jQuery(this));
    });
  };
  var maybeResetFilters = function maybeResetFilters() {
    var parent = $(document).find('.ywcas-overlay-filled-content');
    parent.find('.yith-wcan-filters').removeClass('enhanced');
    parent.find('.yith-wcan-active-filters').remove();
    parent.find('.yith-wcan-reset-filters').remove();
    filters = [];
  };
  $(document).on('yith_wcan_init_shortcodes', function (e) {
    console.log(e);
    initFilters();
  }).trigger('yith_wcan_init_shortcodes');
  $(document).on('yith_plugin_fw_gutenberg_success_do_shortcode', function (e, shortcode) {
    if (shortcode.startsWith('[yith_wcan_')) {
      initFilters();
    }
  });
  globalThis.product_filter = new YITH_WCAN_Filter();
  window.addEventListener('ywcasSearchCompleted', function (e) {
    if (!e.detail.isSearching) {
      maybeResetFilters();
      initFilters(e.detail);
    }
  });
  $(document).on('yith_wcan_filter_updated', function (e) {
    var active_filters = {};
    filters.forEach(function (filter) {
      active_filters = $.extend(active_filters, filter.getFiltersProperties());
    });
    var event = new CustomEvent('ywcanFilterChanged', {
      detail: {
        filters: active_filters
      }
    });
    window.dispatchEvent(event);
  });
});
/******/ })()
;
//# sourceMappingURL=yith-wcan-shortcodes.js.map