=== ACF Gradient Picker ===
Contributors: tolgakocak
Tags: acf, custom field, gradient, color picker
Requires at least: 5.0
Tested up to: 6.8
Requires PHP: 7.4
Requires Plugins: advanced-custom-fields
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html


A beautiful and user-friendly custom gradient picker field for Advanced Custom Fields (ACF), inspired by Gutenberg's native gradient tools.

== Description ==

This plugin adds a new ACF field type called "Gradient Picker", allowing you to select linear or radial gradients with angle control and preset themes.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/acf-gradient-picker` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Use the new "Gradient Picker" field in your ACF field groups.

== Frequently Asked Questions ==

= Does this work with ACF Pro? =
Yes.

= Can I define custom gradient presets? =
Not yet — that feature is planned for future updates.

== Changelog ==

= 1.0.0 =
* Initial release.

== Upgrade Notice ==
= 1.0.0 =
First public release.
