<?php
/**
 * Plugin Name: ACF Gradient Picker
 * Description: A beautiful and professional gradient picker field for ACF, inspired by Gutenberg's native gradient tool.
 * Version: 1.0.0
 * Author: Tolga Kocak
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: acf-gradient-picker
 */

if (!defined('ABSPATH')) exit;

add_action('plugins_loaded', function () {

    if (!class_exists('acf')) {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-error"><p>';
            echo esc_html__('ACF Gradient Picker requires the Advanced Custom Fields plugin to be installed and activated.', 'acf-gradient-picker');
            echo '</p></div>';
        });
        return;
    }

    add_action('acf/include_field_types', function ($version) {
        include_once __DIR__ . '/fields/class-acf-field-gradient-picker.php';
        if (class_exists('acf_field_gradient_picker')) {
            acf_register_field_type(new acf_field_gradient_picker());
        }
    });

    add_action('acf/input/admin_enqueue_scripts', function () {
        $dir = plugin_dir_url(__FILE__);

        // CSS
        wp_enqueue_style('acf-gradient-picker', $dir . 'assets/css/gradient-picker.css', [], '1.0.0');

        // JS: WordPress components must be loaded first
        wp_enqueue_script('acf-gradient-picker', $dir . 'assets/js/gradient-picker.js', [
            'wp-element', 'wp-components', 'wp-i18n', 'wp-compose', 'wp-primitives'
        ], '1.0.0', true);

        // Ensure Gutenberg styles are present
        wp_enqueue_style('wp-components');
    });
});