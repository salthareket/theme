<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    XT_WOOVAS
 * @subpackage XT_WOOVAS/admin
 * @author     XplodedThemes
 */
class XT_WOOVAS_Admin
{

    /**
     * Core class reference.
     *
     * @since    1.0.0
     * @access   private
     * @var      XT_WOOVAS $core Core Class
     */
    protected $core;

    /**
     * Initialize the class and set its properties.
     *
     * @param XT_WOOVAS $core Plugin core class.
     * @since    1.0.0
     */
    public function __construct(&$core)
    {

        $this->core = $core;

        // Add Ajax Events
        add_filter($core->plugin_prefix('ajax_add_events'), array($this, 'ajax_add_events'), 1);

        // Plugin admin setting tabs
        add_filter($core->plugin_prefix('setting_tabs'), array($this, 'add_setting_tabs'), 1, 1);

        // Check if Default variation Visibility has changed after saving settings, add notice to process visibility
        add_filter($this->core->plugin_prefix('settings_saving'), array($this, 'save_previous_process_visibility'));
        add_filter($this->core->plugin_prefix('settings_saved'), array($this, 'check_if_process_visibility_required'));

        if(is_admin()) {

            if($this->core->enabled()) {
                add_action('woocommerce_order_status_changed', array($this, 'order_status_changed'), 10, 3);
                add_action('woocommerce_process_shop_order_meta', array($this, 'process_shop_order'), 10, 2);

                if($this->core->transient()->exists('process_visibility_required_flag')) {
                    $this->add_process_visibility_required_notice();
                }
            }

        }
    }

    /**
     * Add ajax events
     *
     * @param array $ajax_events
     * @return mixed
     */
    public function ajax_add_events($ajax_events) {

        $prefix = $this->core->plugin_short_prefix().'_';

        $ajax_events[] = array(
            'function' =>  $prefix.'get_product_count',
            'callback' => array($this, 'ajax_get_product_count')
        );

        $ajax_events[] = array(
            'function' => $prefix.'process_product_visibility',
            'callback' => array($this, 'ajax_process_product_visibility')
        );

        return $ajax_events;
    }

    /**
     * @param array $tabs
     * @return mixed
     */
    public function add_setting_tabs($tabs)
    {

        $tabs[] = array(
            'id' => 'settings',
            'title' => esc_html__('Settings', 'xt-woo-variations-as-single'),
            'action_link' => true,
            'settings' => array($this, 'get_settings'),
            'order' => 10,
            'callback' => array($this, 'setting_tab_callback')
        );

        return $tabs;
    }


    /**
     * Returns settings array for use by render/save/install default settings methods
     *
     * @return array settings
     * @since 1.0
     */
    public function get_settings()
    {

        $settings = array();

        $settings[] = array(
            'title' => esc_html__('Plugin enabled', 'xt-woo-variations-as-single'),
            'desc' => esc_html__('Enable the plugin once you\'re ready.', 'xt-woo-variations-as-single'),
            'id' => 'enabled',
            'default' => '',
            'type' => 'checkbox'
        );

        $settings[] = array(
            'title' => esc_html__('Hide Variation Parent Products', 'xt-woo-variations-as-single'),
            'desc' => esc_html__('This will hide all variation parents and cannot be overridden at the product level. If you only wish to hide specific variation parents, leave this option disabled and hide them at the product level instead.', 'xt-woo-variations-as-single'),
            'id' => 'hide_parent',
            'default' => '',
            'type' => 'checkbox',
            'conditions' => array(
                array(
                    'id' => 'enabled',
                    'value' => 'yes'
                )
            )
        );

        $settings[] = array(
            'title' => esc_html__('Hide Out Of Stock Products', 'xt-woo-variations-as-single'),
            'desc' => esc_html__('This will hide all out of stock products including variations from the shop. They will still appear on the the single product page.', 'xt-woo-variations-as-single'),
            'id' => 'hide_out_of_stock_products',
            'default' => '',
            'type' => 'checkbox',
            'conditions' => array(
                array(
                    'id' => 'enabled',
                    'value' => 'yes'
                )
            )
        );

        $settings[] = array(
            'title' => esc_html__('Default Variation Visibility', 'xt-woo-variations-as-single'),
            'desc' => esc_html__('Leave empty if you only wish to individually enable visibility for each variation at the product level.', 'xt-woo-variations-as-single'),
            'id' => 'visibility',
            'options' => array(
                'catalog' => 'Catalog Pages',
                'filtered' => 'Filtered Page',
                'search' => 'Search Page'
            ),
            'default' => array(),
            'type' => 'multiselect',
            'conditions' => array(
                array(
                    'id' => 'enabled',
                    'value' => 'yes'
                )
            )
        );

        $settings[] = array(
            'title' => esc_html__('Process product visibility', 'xt-woo-variations-as-single'),
            'desc' => esc_html__('Run this to ensure the visibility of all products (including variations) reflects your default visibility settings', 'xt-woo-variations-as-single'),
            'button_text' => esc_html__('Process', 'xt-woo-variations-as-single'),
            'type' => 'admin_action',
            'id' => 'process_product_visibility',
            'after' => array($this, 'render_process_progressbar'),
            'conditions' => array(
                array(
                    'id' => 'enabled',
                    'value' => 'yes'
                )
            )
        );

        return $settings;
    }

    /**
     * Setting tab callback function
     *
     * @since    1.0.0
     */
    public function setting_tab_callback() {

        add_action( 'admin_enqueue_scripts', array($this, 'enqueue_settings_assets'));
    }

    /**
     * Register settings assets
     *
     * @since    1.0.0
     */
    public function enqueue_settings_assets()
    {

        $handle = $this->core->plugin_slug();

        wp_enqueue_style( $handle, $this->core->plugin_url( 'admin/assets/css', 'settings.css'), array(), $this->core->plugin_version() );

        wp_enqueue_script( $handle, $this->core->plugin_url( 'admin/assets/js', 'settings'.XTFW_SCRIPT_SUFFIX.'.js'), array( 'jquery' ), $this->core->plugin_version() );

        wp_localize_script( $handle, 'XT_WOOVAS', array(
            'enabled' => $this->core->enabled(),
            'ajax_action' => $this->core->ajax()->get_ajax_action('%%action%%'),
            'prefix' => $this->core->plugin_short_prefix(),
            'loading' => esc_html__( 'Loading...', 'xt-woo-variations-as-single' ),
            'processing' => esc_html__( 'Processing', 'xt-woo-variations-as-single' ),
            'to' => esc_html__( 'to', 'xt-woo-variations-as-single' ),
            'of' => esc_html__( 'of', 'xt-woo-variations-as-single' ),
            'products' => esc_html__( 'products', 'xt-woo-variations-as-single' ),
            'process_complete' => esc_html__( 'Process complete', 'xt-woo-variations-as-single' ),
            'products_processed' => esc_html__( 'items were processed.', 'xt-woo-variations-as-single' )
        ));

    }

    /**
     * Output process modal.
     */
    public function render_process_progressbar() {
        ?>
        <div class="xt_woovas-progress">
            <div class="xt_woovas-progress-loading">
                <?php esc_html_e( 'Preparing process...', 'xt-woo-variations-as-single' ); ?>
            </div>
            <div class="xt_woovas-progress-processing">
                <span>
                    <?php esc_html_e( 'Processing', 'xt-woo-variations-as-single' ); ?>:
                    <span class="xt_woovas-progress-count-from"></span> <?php esc_html_e( 'to', 'xt-woo-variations-as-single' ); ?>
                    <span class="xt_woovas-progress-count-to"></span> <?php esc_html_e( 'of', 'xt-woo-variations-as-single' ); ?>
                    <span class="xt_woovas-progress-count-total"></span> <?php esc_html_e( 'items', 'xt-woo-variations-as-single' ); ?>
                </span>
                <div class="xt_woovas-progress-bar">
                    <div class="xt_woovas-progress-bar-fill"></div>
                </div>
            </div>
            <div class="xt_woovas-progress-complete">
                <strong><?php esc_html_e( 'Process completed!', 'xt-woo-variations-as-single' ); ?></strong>
                <span class="xt_woovas-progress-count-total"></span> <?php esc_html_e( 'items were processed.', 'xt-woo-variations-as-single' ); ?>
            </div>
        </div>
        <?php
    }

    /**
     * Get product count.
     */
    public function ajax_get_product_count() {

        global $wpdb;

        $query = "
			SELECT COUNT(*) as count
			FROM $wpdb->posts
			WHERE post_type IN( 'product', 'product_variation' )
		";

        $count = $wpdb->get_var( $query );

        $response = array(
            'success' => true,
            'count' => intval($count)
        );

        wp_send_json( $response );
    }

    /**
     * Process product visibility.
     */
    public function ajax_process_product_visibility() {

        global $wpdb;

        $this->core->transient()->delete('process_visibility_required_flag');

        $query = "
			SELECT $wpdb->posts.*
			FROM $wpdb->posts
			WHERE $wpdb->posts.post_type IN( 'product', 'product_variation' )
			LIMIT %d OFFSET %d
		";

        $products = $wpdb->get_results( $wpdb->prepare( $query, absint( $_POST['limit'] ), absint( $_POST['offset'] ) ) );

        if(!empty( $products ) ) {
            foreach( $products as $product ) {
                if( $product->post_type !== "product_variation" ) {
                    $this->core->product->after_product_object_save( $product->ID );
                } else {
                    $this->core->product_variation->on_variation_save( $product->ID );
                }
            }
        }

        wp_reset_postdata();
        wp_send_json( array( 'success' => true ) );
    }

    /**
     * Save previous Default Variation Visibility setting before saving new settings
     */
    public function save_previous_process_visibility() {

        $visibility = $this->core->settings()->get_option('visibility');

        $this->core->transient()->set('previous_variation_visibility', $visibility);
    }

    /**
     * Check if Default Variation Visibility setting has changed after saving settings, add notice to process visibility
     */
    public function check_if_process_visibility_required() {

        $this->core->cache()->flush();

        $visibility = $this->core->settings()->get_option('visibility');
        $previous_visibility = $this->core->transient()->get('previous_variation_visibility');

        if($visibility !== $previous_visibility) {

            $this->core->transient()->set('process_visibility_required_flag', true);

            if($this->core->enabled()) {
                $this->add_process_visibility_required_notice();
            }

        }else{

            $this->core->transient()->delete('process_visibility_required_flag');
        }
    }

    /**
     * Add process visibility required notice
     */
    public function add_process_visibility_required_notice() {

        $process_url = $this->core->plugin_admin_url('', array('process_visibility' => 1 ));
        $is_settings_page = $this->core->plugin_is_admin_url();

        $button = '<a class="button-primary" id="process-variation-visibility" href="'.esc_url($process_url).'">'.esc_html__('Process', 'xt-woo-variations-as-single').'</a>';
        $this->core->plugin_notices()->add_warning_message( array(
            sprintf(
                esc_html__('%sDefault variation visibility has changed! Please process product visibility to ensure the visibility of all product variations reflects your settings.', 'xt-woo-variations-as-single'),
                (!$is_settings_page ? '{title}: ' : '')
            ),
            $button
        ));
    }

    /**
     * When the order status changes
     *
     * @param int $order_id
     * @param str $old_status
     * @param str $new_status
     */
    public function order_status_changed( $order_id, $old_status, $new_status ) {
        $accepted_status = array( 'completed', 'processing', 'on-hold' );

        if ( in_array( $new_status, $accepted_status ) ) {
            $this->record_variation_sales( $order_id );
        }
    }


    /**
     * When an Admin manually creates an order
     *
     * @param int       $post_id
     * @param WP_Post   $post
     */
    public function process_shop_order( $post_id, $post ) {
        $accepted_status = array( 'wc-completed', 'wc-processing', 'wc-on-hold' );

        if ( in_array( $post->post_status, $accepted_status ) ) {
            $this->record_variation_sales( $post_id );
        }
    }

    /**
     * Record variation sales
     *
     * Updates the variation sales count for an order
     *
     * @param int $order_id
     */
    public function record_variation_sales( $order_id ) {
        if ( 'yes' === get_post_meta( $order_id, '_recorded_variation_sales', true ) ) {
            return;
        }

        $order = wc_get_order( $order_id );

        if ( sizeof( $order->get_items() ) > 0 ) {
            foreach ( $order->get_items() as $item ) {
                if ( $item['variation_id'] > 0 ) {
                    $sales = (int) get_post_meta( $item['variation_id'], 'total_sales', true );
                    $sales += (int) $item['qty'];
                    if ( $sales ) {
                        update_post_meta( $item['variation_id'], 'total_sales', $sales );
                    }
                }
            }
        }

        update_post_meta( $order_id, '_recorded_variation_sales', 'yes' );

        /**
         * Called when sales for an order are recorded
         *
         * @param int $order_id order id
         */
        do_action( 'woocommerce_recorded_variation_sales', $order_id );
    }
}
