(function( $ ) {
	'use strict';

	$(function() {

		// To avoid scope issues, use 'self' instead of 'this'
		// to reference this class from internal events and functions.

		var self = {};

		self.events = {};

		self.progress = {
			count: {
				product: null
			},
			elements: {
				container: $('.xt_woovas-progress'),
				processing: $('.xt_woovas-progress-processing'),
				loading: $('.xt_woovas-progress-loading'),
				complete: $('.xt_woovas-progress-complete'),
				from: $('.xt_woovas-progress-count-from'),
				to: $('.xt_woovas-progress-count-to'),
				total: $('.xt_woovas-progress-count-total'),
				bar_fill: $('.xt_woovas-progress-bar-fill')
			}
		};

		self.init = function() {

			self.bindEvents();
		};

		self.bindEvents = function() {

			$(document.body).on( xtfw_settings.api.eventType('process_product_visibility'), self.events.onProcessProductVisibility);

			$(document.body).on( 'click', '#process-variation-visibility', function(evt) {

				evt.preventDefault();
				self.triggerProcessProductVisibility();
			});

			if(xtfw_settings.api.getUrlParam('process_visibility') === '1') {

				self.triggerProcessProductVisibility(500);

				// reset url to avoid re-process on page reload
				window.history.pushState("", "", location.href.split('&')[0]);
			}
		};

		self.getCount = function(type, callback) {

			if( self.progress.count[type] !== null ) {
				if( typeof callback === 'function' ) {
					callback( self.progress.count[type] );
				}
				return;
			}

			var data = {
				action: xtfw_settings.api.getAjaxAction('get_'+type+'_count')
			};

			$.post(ajaxurl, data, function(response) {

				if(response.success) {

					if (typeof callback === 'function') {
						callback(response.count);
					}

					self.progress.count[type] = response.count;
				}

			});
		};

		self.triggerProcessProductVisibility = function(delay) {

			delay = delay || 0;

			var process_button = $('#xt_woovas_process_product_visibility');
			var row = process_button.closest('tr');

			xtfw_settings.api.scrollTo(row, {delay: delay}, function() {

				row.addClass('xtfw-highlight');
				process_button.click();
				setTimeout(function() {
					row.removeClass('xtfw-highlight')
				}, 2500)
			});
		};

		self.processProductVisibility = function(callback) {

			var limit = 10;

			self.progress.start();

			self.getCount( 'product', function( count ) {

				self.progress.resetPercent();
				self.progress.updateCount( 1, limit, count );

				self.process( 'process_product_visibility', count, limit, 0, function( processing, noffset ){

					if( ! processing ) {

						self.progress.setPercent( count, count );
						self.progress.finish();

						if(typeof(callback) !== 'undefined') {
							callback();
						}

					} else {

						var to = noffset + limit;

						to = (to >= count) ? count : to;

						self.progress.updateCount( noffset, to, count );
						self.progress.setPercent( noffset, count );
					}

				});

			});
		};

		self.process = function(action, total, limit, offset, callback) {

			var processing = true;

			var data = {
				'action': xtfw_settings.api.getAjaxAction(action),
				'limit': limit,
				'offset': offset
			};

			$.post(ajaxurl, data, function( response ) {

				if(response.success) {

					var noffset = offset + limit;

					if (noffset < total) {
						self.process(action, total, limit, noffset, callback);
					} else {
						processing = false;
					}

					if (typeof callback === 'function') {
						callback(processing, noffset);
					}
				}

			});
		};

		self.progress.start = function() {

			self.progress.elements.container.fadeIn();
			self.progress.elements.loading.fadeIn();
			self.progress.elements.processing.hide();
			self.progress.elements.complete.hide();
		};

		self.progress.updateCount = function( count_from, count_to, count_total ) {

			self.progress.elements.loading.hide();
			self.progress.elements.processing.show();

			self.progress.elements.from.text( count_from );
			self.progress.elements.to.text( count_to );
			self.progress.elements.total.text( count_total );
		};

		self.progress.finish = function() {

			self.progress.elements.loading.hide();
			self.progress.elements.processing.hide();
			self.progress.elements.complete.fadeIn();

			self.action_button.show();
		};

		self.progress.setPercent = function(complete, total) {

			var percentage = (complete/total)*100;

			self.progress.elements.bar_fill.css( 'width', percentage+'%' );
		};

		self.progress.resetPercent = function() {

			self.progress.elements.bar_fill.css('width', '0%');
		};

		self.events.onProcessProductVisibility = function(e, button, callback) {

			e.preventDefault();

			xtfw_settings.api.saveSettings(true, function() {

				self.action_button = button;
				self.processProductVisibility(callback);
			});

			return true;
		};

		$(document.body).on( 'xtfw_settings_init', function() {

			self.init();
		});

	});

})( jQuery );	