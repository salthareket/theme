<?php

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    XT_WOOVAS
 * @subpackage XT_WOOVAS/Query
 * @author     XplodedThemes
 */
class XT_WOOVAS_Query {

    /**
     * Core class reference.
     *
     * @since    1.0.0
     * @access   private
     * @var      XT_WOOVAS    $core    Core Class
     */
    private $core;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param    XT_WOOVAS    $core    Plugin core class
     */
    public function __construct( &$core ) {

        $this->core = $core;

        if(!$this->core->enabled()) {
            return;
        }

        if ( !is_admin() ) {

            // Alter Products Query
            add_action( 'woocommerce_product_query', array($this, 'alter_products_query'), 50, 2 );
            add_filter( 'woocommerce_shortcode_products_query', array($this, 'alter_shortcode_products_query'), 10, 2 );
            add_filter( 'woocommerce_product_related_posts_query', array($this, 'alter_related_products_query'), 10, 2 );

            // Alter Products Query Clauses
            add_filter( 'posts_clauses', array( $this, 'alter_products_query_clauses' ), 10, 2 );

            // Term counts
            add_filter( 'woocommerce_get_filtered_term_product_counts_query', array( $this, 'filtered_term_product_counts_where_clause' ), 10, 1 );
            add_filter( 'get_terms', array( $this, 'change_term_counts' ), 100, 2 );

            // Hide out of stock products
            $hide_out_of_stock = $this->core->settings()->get_option_bool('hide_out_of_stock_products', false);
            if($hide_out_of_stock) {
                add_action('pre_get_posts', array($this, 'hide_out_of_stock_products'));
            }

        }

        add_action( 'deleted_transient', array( $this, 'delete_child_term_count_transient' ), 10, 1 );

    }

    /**
     * Add variations to the product query.
     *
     * @param WP_Query      $query
     * @param bool|WC_Query $wc_query
     */
    public function alter_products_query( $query, $wc_query = false ) {

        $post_type = (array) $query->get( 'post_type' );
        $post_type = array_filter( $post_type );

        if (
            ( ! in_array( 'product', $post_type ) && empty( $wc_query ) ) ||
            ( ! is_woocommerce() || ! $query->is_main_query() || empty( $query->query_vars['wc_query'] ) ) ) {
            return;
        }

        if ( empty( $post_type ) ) {
            $post_type[] = 'product';
        }

        // Set xt_woovas_query custom query flag
        $query->set( 'xt_woovas_query', true );

        // Add product variations to the query

        $post_type[] = 'product_variation';

        $query->set( 'post_type', array_filter( $post_type ) );

        // Exclude orphan variations

        $orphan_variation_ids = $this->get_orphan_variation_ids();
        if ( ! empty( $orphan_variation_ids ) ) {
            $post__not_in = (array) $query->get( 'post__not_in' );
            $query->set( 'post__not_in', array_merge( $post__not_in, $orphan_variation_ids ) );
        }

        // Exclude unpublished variations

        $unpublished_variation_ids = $this->get_unpublished_variation_ids();
        if ( ! empty( $unpublished_variation_ids ) ) {
            $post_parent__not_in = (array) $query->get( 'post_parent__not_in' );
            $query->set( 'post_parent__not_in', array_merge( $post_parent__not_in, $unpublished_variation_ids ) );
        }

        // Include variations

        $tax_query = (array) $query->get( 'tax_query' );
        $tax_query = $this->update_tax_query( $tax_query );
        $query->set( 'tax_query', $tax_query );
    }

    /*
     * Add variations to shortcode queries
     *
     * @param arr $query_args
     * @param arr $shortcode_args
     */
    public function alter_shortcode_products_query( $query_args, $shortcode_args ) {

        $post_type = (array) $query_args['post_type'];

        // Set xt_woovas_query custom query flag
        $query_args['xt_woovas_query'] = true;

        // Add product variations to the query

        $post_type[] = 'product_variation';

        $query_args['post_type'] = $post_type;

        // Exclude orphan variations

        $orphan_variation_ids = $this->get_orphan_variation_ids();
        if ( $orphan_variation_ids ) {
            $post__not_in               = isset( $query_args['post__not_in'] ) ? (array) $query_args['post__not_in'] : array();
            $query_args['post__not_in'] = array_merge( $post__not_in, $orphan_variation_ids );
        }

        // Exclude unpublished variations

        $unpublished_variation_ids = $this->get_unpublished_variation_ids();
        if ( $unpublished_variation_ids ) {
            $post_parent__not_in               = isset( $query_args['post_parent__not_in'] ) ? (array) $query_args['post_parent__not_in'] : array();
            $query_args['post_parent__not_in'] = array_merge( $post_parent__not_in, $unpublished_variation_ids );
        }

        // Include variations

        $tax_query               = (array) $query_args['tax_query'];
        $tax_query               = $this->update_tax_query( $tax_query );
        $query_args['tax_query'] = $tax_query;

        return $query_args;
    }

    /**
     * Get unpublished variation IDs
     *
     * Get's an array of product IDs where the product
     * is variable and has not been published (i.e. is in the bin)
     *
     * @since 1.0.0
     * @return array
     */
    public function get_unpublished_variation_ids() {

        return $this->core->cache()->result('unpublished_variations', function() {

            global $wpdb;

            $unpublished_variation_ids = array();

            $product_type = get_term_by('slug', 'variable', 'product_type');

            if (!$product_type) {
                return $unpublished_variation_ids;
            }

            $products = $wpdb->get_results($wpdb->prepare(
                "
			SELECT *
			FROM $wpdb->posts 
			LEFT JOIN $wpdb->term_relationships
			ON ($wpdb->posts.ID = $wpdb->term_relationships.object_id)
			WHERE 1=1 
			AND ( $wpdb->term_relationships.term_taxonomy_id IN (%d) )
			AND $wpdb->posts.post_type = 'product'
			AND ((
				$wpdb->posts.post_status = 'future' OR 
				$wpdb->posts.post_status = 'draft' OR 
				$wpdb->posts.post_status = 'pending' OR 
				$wpdb->posts.post_status = 'trash' OR 
				$wpdb->posts.post_status = 'auto-draft'
			))
			GROUP BY $wpdb->posts.ID
			ORDER BY $wpdb->posts.post_date DESC
			", $product_type->term_taxonomy_id),
                ARRAY_A
            );

            $unpublished_variation_ids = wp_list_pluck($products, 'ID');

            return array_map('intval', $unpublished_variation_ids);
        });
    }

    /**
     * Get orphan variation IDs
     *
     * @since 1.0.0
     * @return array
     */
    public function get_orphan_variation_ids() {

        return $this->core->cache()->result('missing_parent_variations', function() {

            global $wpdb;

            $variation_ids = $wpdb->get_results(
                "
			SELECT  p1.ID
			FROM $wpdb->posts p1
			WHERE p1.post_type = 'product_variation'
			AND p1.post_parent NOT IN (
				SELECT DISTINCT p2.ID
				FROM $wpdb->posts p2
				WHERE p2.post_type = 'product'
			)
			", ARRAY_A
            );

            $orphan_variation_ids = wp_list_pluck( $variation_ids, 'ID' );

            return $orphan_variation_ids;

        });

    }

    /**
     * Update tax query.
     *
     * @param array $tax_query
     * @param bool  $filtered
     *
     * @return array
     */
    public function update_tax_query( $tax_query, $filtered = false ) {

        $term_excluded_from_filtered = get_term_by( 'slug', 'exclude-from-filtered', 'product_visibility' );

        if ( $term_excluded_from_filtered && ( $filtered || is_filtered() ) ) {

            if ( empty( $tax_query ) ) {

                $tax_query['relation'] = 'AND';
                $tax_query[]           = array(
                    'taxonomy'         => 'product_visibility',
                    'field'            => 'term_taxonomy_id',
                    'terms'            => array( $term_excluded_from_filtered->term_taxonomy_id ),
                    'operator'         => 'NOT IN',
                    'include_children' => 1,
                );

            } else {

                $term_excluded_from_catalog = get_term_by( 'slug', 'exclude-from-catalog', 'product_visibility' );

                foreach ( $tax_query as $i => $tax_query_item ) {

                    if (
                        !is_array( $tax_query_item ) ||
                        empty( $tax_query_item['taxonomy'] ) ||
                        $tax_query_item['taxonomy'] !== 'product_visibility' ||
                        $tax_query_item['operator'] !== 'NOT IN'
                    ) {
                        continue;
                    }

                    // Visibility query
                    $visibility_query                     = $tax_query[ $i ];
                    $visibility_query['terms']            = (array) $visibility_query['terms'];
                    $visibility_query['terms'][]          = $term_excluded_from_filtered->term_taxonomy_id;
                    $visibility_query['include_children'] = 1;

                    // Alt visibility query
                    $alt_visibility_query = $visibility_query;

                    // Replace 'exclude form catalog' with 'exclude form filtered'
                    foreach ( $alt_visibility_query['terms'] as $term_index => $term_id ) {
                        if ( $term_id === $term_excluded_from_catalog->term_taxonomy_id ) {
                            unset( $alt_visibility_query['terms'][ $term_index ] );
                        }
                    }

                    $tax_query[ $i ] = array(
                        'relation' => 'OR',
                        $visibility_query,
                        $alt_visibility_query
                    );
                }
            }
        }

        return $tax_query;
    }

    /**
     * @param array $query
     * @param int   $product_id
     *
     * @return array
     */
    public function alter_related_products_query( $query, $product_id ) {

        $find    = "AND p.post_type = 'product'";
        $replace = "AND ( p.post_type = 'product' OR p.post_type = 'product_variation' )";

        $query['where'] = str_replace( $find, $replace, $query['where'] );

        return $query;
    }

    /**
     * Alter product query clauses
     *
     * - Hide variation parents id global option is enabled
     * - Remove private variations from listings.
     * - Re-order product so parent products come first then it's variations
     *
     * @param array $clauses
     * @param WP_Query $query
     * @return array
     */
    public function alter_products_query_clauses( array $clauses, WP_Query $query ) {

        global $wpdb;

        // Skip if in admin or empty orderby param or not woovas query
        if ( is_admin() || empty( $clauses['orderby'] ) || empty($query->get('xt_woovas_query'))) {
            return $clauses;
        }

        $hide_parent = $this->core->settings()->get_option_bool('hide_parent', false);

        if($hide_parent) {
            // Hide variation parents if global option is enabled
            $where = " AND {$wpdb->posts}.post_parent != 0";
            $where = "
            AND ( {$wpdb->posts}.ID NOT IN (

                SELECT
                    {$wpdb->posts}.id
                FROM {$wpdb->posts}
                INNER JOIN {$wpdb->term_relationships} ON {$wpdb->posts}.ID = {$wpdb->term_relationships}.object_id
                INNER JOIN {$wpdb->term_taxonomy} ON {$wpdb->term_relationships}.term_taxonomy_id = {$wpdb->term_taxonomy}.term_taxonomy_id
                INNER JOIN {$wpdb->terms} ON {$wpdb->term_taxonomy}.term_id = {$wpdb->terms}.term_id
                WHERE 
                    {$wpdb->term_taxonomy}.taxonomy = 'product_type' AND
                    {$wpdb->terms}.slug = 'variable'		
            ))
            ";

            $clauses['where'] = $clauses['where'].$where;
        }

        // Remove private variations from listings.
        $find    = "OR {$wpdb->posts}.post_author = 1 AND {$wpdb->posts}.post_status = 'private'";
        $replace = "OR ( {$wpdb->posts}.post_author = 1 AND {$wpdb->posts}.post_status = 'private' AND {$wpdb->posts}.post_type != 'product_variation' )";
        $clauses['where'] = str_replace( $find, $replace, $clauses['where'] );


        // Skip if the orderby is not by menu or title
        if (
            $clauses['orderby'] !== "{$wpdb->posts}.menu_order ASC, {$wpdb->posts}.post_title ASC" &&
            $clauses['orderby'] !== "{$wpdb->posts}.menu_order, {$wpdb->posts}.menu_order ASC, {$wpdb->posts}.post_title ASC"
        ) {
            return $clauses;
        }

        // Re-order product so parent products come first then it's variations
        $custom_order_select = "CONCAT(IF({$wpdb->posts}.post_parent = '0','',CONCAT('/',{$wpdb->posts}.post_parent)),'/',{$wpdb->posts}.id) AS xt_woovas_order";
        $clauses['fields'] = $clauses['fields'].', '.$custom_order_select;
        $clauses['orderby'] = "xt_woovas_order, " . $clauses['orderby'];

        return $clauses;
    }

    /**
     * Modify the "filtered term product counts" where clause
     *
     * Adds post_type and post_parent__not_in parameter so unpublished variable
     * product variations are ignored in the filter counts
     *
     * @since 1.1.0
     *
     * @param array $query The term's post count query.
     *
     * @return array
     */
    public function filtered_term_product_counts_where_clause( $query ) {

        global $wpdb, $wp_the_query;

        $query['where'] = str_replace( "'product'", "'product', 'product_variation'", $query['where'] );

        if ( ! empty( $wp_the_query->query_vars['post_parent__not_in'] ) ) {
            $query['where'] = sprintf( "%s AND %s.post_parent NOT IN ('%s')", $query['where'], $wpdb->posts, implode( "','", $wp_the_query->query_vars['post_parent__not_in'] ) );
        }

        if ( ! is_filtered() ) {
            $current_tax_query     = WC_Query::get_main_tax_query();
            $current_tax_query_obj = new WP_Tax_Query( $current_tax_query );
            $current_tax_query_sql = $current_tax_query_obj->get_sql( $wpdb->posts, 'ID' );

            $new_tax_query     = $this->update_tax_query( $current_tax_query, true );
            $new_tax_query_obj = new WP_Tax_Query( $new_tax_query );
            $new_tax_query_sql = $new_tax_query_obj->get_sql( $wpdb->posts, 'ID' );

            $query['where'] = str_replace( $current_tax_query_sql, $new_tax_query_sql, $query['where'] );
        }

        return $query;
    }

    /**
     * Frontend: Change Term Counts
     *
     * @param array $terms
     * @param array $taxonomies
     *
     * @return array
     */
    public function change_term_counts( $terms, $taxonomies ) {
        
        if ( is_admin() || defined( 'DOING_AJAX' ) ) {
            return $terms;
        }

        if ( ! isset( $taxonomies[0] ) || ! in_array( $taxonomies[0], apply_filters( 'woocommerce_change_term_counts', array( 'product_cat', 'product_tag' ) ), true ) ) {
            return $terms;
        }

        $variation_term_counts = array();

        foreach ( $terms as &$term ) {
            if ( ! is_object( $term ) ) {
                continue;
            }

            $variation_term_counts[ $term->term_id ] = $this->get_term_variations_count( $term );
        }

        $term_counts = get_transient( 'wc_term_counts' );

        foreach ( $terms as &$term ) {
            if ( ! is_object( $term ) ) {
                continue;
            }

            if ( ! isset( $term_counts[ $term->term_id ] ) ) {
                continue;
            }

            $child_term_count = isset( $variation_term_counts[ $term->term_id ] ) ? (int) $variation_term_counts[ $term->term_id ] : 0;
            $term_count = (int) $term_counts[ $term->term_id ];

            $term_counts[ $term->term_id ] = $term_count + $child_term_count;

            if ( empty( $term_counts[ $term->term_id ] ) ) {
                continue;
            }

            $term->count = absint( $term_counts[ $term->term_id ] );
        }

        return $terms;
    }

    /**
     * Get Variations count in term
     *
     * @param WP_Term $term
     *
     * @return int
     */
    public function get_term_variations_count( $term ) {

        $terms_variations_count = $this->core->transient()->get('terms_variations_count');

        if(empty($terms_variations_count)) {
            $terms_variations_count = array();
        }

        if(empty($terms_variations_count[$term->term_id])) {

            global $wpdb;

            // Add parent term to count.
            $terms_to_count = array( absint( $term->term_id ) );

            // Add children terms to count as well.
            if ( is_taxonomy_hierarchical( $term->taxonomy ) ) {
                // We need to get the $term's hierarchy so we can count its children too.
                $children = get_term_children( $term->term_id, $term->taxonomy );

                if ( $children && ! is_wp_error( $children ) ) {
                    $terms_to_count = array_unique( array_map( 'absint', array_merge( $terms_to_count, $children ) ) );
                }
            }

            $query = array(
                'fields' => "
					SELECT COUNT( DISTINCT ID ) FROM {$wpdb->posts} wp
				",
                'join'   => "
					INNER JOIN {$wpdb->postmeta} wm ON (wm.`post_id` = wp.`ID` AND wm.`meta_key`='_visibility')
					INNER JOIN {$wpdb->term_relationships} wtr ON (wp.`ID` = wtr.`object_id`)
					INNER JOIN {$wpdb->term_taxonomy} wtt ON (wtr.`term_taxonomy_id` = wtt.`term_taxonomy_id`)
					INNER JOIN {$wpdb->terms} wt ON (wt.`term_id` = wtt.`term_id`)
				",
                'where'  => "
					WHERE 1=1
					AND wtt.taxonomy = '%s' AND wt.`term_id` IN (" . implode( ',', array_map( 'absint', $terms_to_count ) ) . ")
					AND wp.post_status = 'publish' AND ( wm.meta_value LIKE '%%visible%%' OR wm.meta_value LIKE '%%catalog%%' )
					AND wp.post_type = 'product_variation'
				",
            );

            $exclude_term_ids            = array();
            $product_visibility_term_ids = wc_get_product_visibility_term_ids();

            if ( 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) && $product_visibility_term_ids['outofstock'] ) {
                $exclude_term_ids[] = $product_visibility_term_ids['outofstock'];
            }

            if ( count( $exclude_term_ids ) ) {
                $query['join']  .= " LEFT JOIN ( SELECT object_id FROM {$wpdb->term_relationships} WHERE term_taxonomy_id IN ( " . implode( ',', array_map( 'absint', $exclude_term_ids ) ) . " ) ) AS exclude_join ON exclude_join.object_id = wp.ID";
                $query['where'] .= " AND exclude_join.object_id IS NULL";
            }

            $sql = $wpdb->prepare(
                implode( ' ', $query ),
                $term->taxonomy
            );

            $count = absint( $wpdb->get_var( $sql ) );
            $terms_variations_count[$term->term_id] = $count;

            $this->core->transient()->set('terms_variations_count', $terms_variations_count);
            
        }

        return apply_filters( 'xt_woovas_variations_count_in_term', $terms_variations_count, $term );
    }

    /**
     * Delete variations term counts.
     *
     * @param string $transient
     */
    public function delete_child_term_count_transient( $transient ) {
        
        if ( $transient !== 'wc_term_counts' ) {
            return;
        }

        $this->core->transient()->delete( 'terms_variations_count' );
    }

    function hide_out_of_stock_products( $q ) {

        if ( ! $q->is_main_query() || is_admin() ) {
            return;
        }

        if ( $outofstock_term = get_term_by( 'name', 'outofstock', 'product_visibility' ) ) {

            $tax_query = (array) $q->get('tax_query');

            $tax_query[] = array(
                'taxonomy' => 'product_visibility',
                'field' => 'term_taxonomy_id',
                'terms' => array( $outofstock_term->term_taxonomy_id ),
                'operator' => 'NOT IN'
            );

            $q->set( 'tax_query', $tax_query );

        }

        remove_action( 'pre_get_posts', 'iconic_hide_out_of_stock_products' );

    }
}
