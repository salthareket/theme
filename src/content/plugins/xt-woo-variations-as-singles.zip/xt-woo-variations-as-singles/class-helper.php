<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    XT_WOOVAS
 * @subpackage XT_WOOVAS/Product_Admin
 * @author     XplodedThemes
 */
class XT_WOOVAS_Helpers
{

    /**
     * Delete term counts transient
     *
     * When recount terms is run in backend of woo,
     * delete our additional term counts transient, too.
     */
    public static function delete_term_counts_transient() {
        delete_transient( 'xt_woovas_term_counts' );
    }

    /**
     * Delete count transient
     *
     * @param string $taxonomy
     * @param integer $taxonomy_id
     */
    public static function delete_count_transient( $taxonomy, $taxonomy_id ) {

        $transient_key = 'wc_ln_count_' . md5( sanitize_key( $taxonomy ) . sanitize_key( $taxonomy_id ) );

        delete_transient( $transient_key );
    }

    /**
     * Unset array item by the value
     *
     * @param  array $areay
     * @param  string $value
     *
     * @return array
     */
    public static function unset_item_by_value( $array, $value ) {
        if ( ( $key = array_search( $value, $array ) ) !== false ) {
            unset( $array[ $key ] );
        }

        return $array;
    }

    /**
     * Get kses title
     *
     * @param  string $title

     * @return array
     */
    public static function wp_kses_title($title) {

        $allowed = wp_kses_allowed_html();

        $allowed['span'] = array();
        $allowed['br'] = array();

        return wp_kses( $title, $allowed );
    }
}
