=== XT Variations As Singles for WooCommerce ===

Plugin Name: XT Variations As Singles for WooCommerce
Contributors: XplodedThemes
Author: XplodedThemes
Author URI: https://www.xplodedthemes.com
Tags: woocommerce, single variation, display single variation, variations
Requires at least: 4.8
Tested up to: 6.7
Stable tag: 1.2.5
Requires PHP: 5.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

XT Variations As Singles for WooCommerce plugin incorporates code from WooCommerce Show Single Variations on Shop Page plugin by IconicWP, Copyright 2015 James Kemp.
WooCommerce Show Single Variations on Shop Page by IconicWP is distributed under the terms of the GNU GPL, version 2, https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Display WooCommerce product variations on the shop page as though they are separate products. This will improve customer experience and enhance product browsing.

**Demo**

[https://demos.xplodedthemes.com/woo-variations-as-singles/](https://demos.xplodedthemes.com/woo-variations-as-singles/)

**Features**

- Pro features

**Translations**

- English - default

*Note:* All our plugins are localized / translatable by default. This is very important for all users worldwide. So please contribute your language to the plugin to make it even more useful.

== Installation ==

Installing "Variations As Singles for WooCommerce" can be done by following these steps:

1. Download the plugin from the customer area at "XplodedThemes.com" 
2. Upload the plugin ZIP file through the 'Plugins > Add New > Upload' screen in your WordPress dashboard
3. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

#### V.1.2.5 - 10.03.2025
- **fix**: Minor CSS fixed within the customizer panels
- **update**: XT Framework update

#### V.1.2.4 - 04.11.2024
- **security**: Removed SVG upload support for security reasons. To enable SVG uploads, please use a plugin like "Safe SVG" https://wordpress.org/plugins/safe-svg/
- **update**: XT Framework update

#### V.1.2.3 - 04.11.2024
- **update**: Freemius SDK update v2.9.0
- **support**: Fixed deprecated code causing "Creation of dynamic property" log errors in PHP 8.2

#### V.1.2.2 - 29.07.2024
- **update**: Freemius SDK update v2.7.3
- **support**: WordPress 6.6
- **support**: WooCommerce 9.1

#### V.1.2.1 - 01.02.2024
- **update**: Freemius SDK update v2.6.2
- **support**: WordPress 6.4

#### V.1.2.0 - 25.08.2023
- **update**: Added WooCommerce HPOS Support

#### V.1.1.1 - 24.07.2023
- **update**: Freemius SDK update v2.5.10

#### V.1.1.0 - 08.03.2023
- **update**: XT Framework update
- **update**: Freemius SDK update

#### V.1.0.9 - 12.09.2022
- **update**: XT Framework update
- **update**: Freemius SDK update

#### V.1.0.8 - 03.03.2022
- **fix**: Freemius Security Fix
- **update**: XT Framework update

#### V.1.0.7 - 02.02.2022
- **update**: XT Framework update

#### V.1.0.6 - 15.09.2021
- **fix**: Removed automated support of all custom product taxonomies introduced in v1.0.5 which was causing unexpected issues.
- **support**: Added hook **xt_woovas_variation_taxonomies** to filter which product custom taxonomies will be also registered to product variations. Needed to support filtering by custom taxonomies. https://d.pr/i/OmcQZD

#### V.1.0.5 - 15.09.2021
- **fix**: Remove warnings
- **support**: Support all custom product taxonomies

#### V.1.0.3 - 10.08.2021
- **support**: Support PHP v8.x. Removed deprecated warnings.

#### V.1.0.2 - 02.07.2021
- **new**: Added option to hide out of stock products and variations from the shop page.
- **new**: For out of stock variations, replace the "Select Options" button text by "Out of stock" on the shop page
- **support**: Added support for **Woocommerce Brands** & **Perfect Brands for WooCommerce** plugins
- **update**: Updated language files

#### V.1.0.1 - 27.06.2021
- **fix**: Fixed issue with product variation titles overriding menu item titles.

#### V.1.0.0 - 02.06.2021
- **Initial**: Initial Version

