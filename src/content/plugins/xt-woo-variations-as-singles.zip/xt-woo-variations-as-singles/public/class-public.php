<?php
/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    XT_WOOVAS
 * @subpackage XT_WOOVAS/public
 * @author     XplodedThemes 
 */
class XT_WOOVAS_Public {

	/**
	 * Core class reference.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      XT_WOOVAS    $core    Core Class
	 */
	private $core;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param    XT_WOOVAS    $core    Plugin core class
	 */
	public function __construct( &$core ) {

		$this->core = $core;

		if(is_admin() || !$this->core->enabled()) {
		    return;
        }

        add_filter( 'post_class', array( $this, 'add_post_classes_in_loop' ) );
        add_action( 'delete_transient_wc_term_counts', array( XT_WOOVAS_Helpers::class, 'delete_term_counts_transient' ), 10, 1 );

	}

    /**
     * Add relevant product classes to loop item
     *
     * @param array $classes
     *
     * @return array
     */
    public function add_post_classes_in_loop( $classes ) {
        global $product;

        if ( ! $product || ! is_object( $product ) && !$product->is_type( 'variation' )) {
            return $classes;
        }

        $classes   = array_diff( $classes, array( 'hentry', 'post' ) );
        $classes[] = "product";
        // Improve compatibility with themes that rely on the type-product class
        $classes[] = "type-product";

        if(get_post_meta( $product->get_id(), '_featured', true) === 'yes') {
            $classes[] = "featured";
        }

        return $classes;
    }

}
