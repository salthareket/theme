<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    XT_WOOVAS
 * @subpackage XT_WOOVAS/Product_Variation
 * @author     XplodedThemes
 */
class XT_WOOVAS_Product_Variation
{

    /**
     * Core class reference.
     *
     * @since    1.0.0
     * @access   private
     * @var      XT_WOOVAS $core Core Class
     */
    protected $core;

    /**
     * Initialize the class and set its properties.
     *
     * @param XT_WOOVAS $core Plugin core class.
     * @since    1.0.0
     */
    public function __construct(&$core)
    {
        $this->core = $core;

        if(!$this->core->enabled()) {
            return;
        }

        // Product & Variation visibility
        add_filter( 'woocommerce_product_is_visible', array($this, 'variation_is_visible'), 10, 2 );
        add_filter( 'woocommerce_product_is_visible', array( $this, 'product_is_visible' ), 10, 2 );

        add_filter( 'woocommerce_get_children', array($this, 'remove_listing_only_variations'), 10, 1);
        add_filter( 'woocommerce_available_variation', array($this, 'disable_listing_only_variation'), 10, 1);

        // Variation ratings inherit from parent
        add_filter( 'woocommerce_product_variation_get_rating_counts', array($this, 'get_rating_counts'), 10, 2 );
        add_filter( 'woocommerce_product_variation_get_review_count', array($this, 'get_review_count'), 10, 2 );
        add_filter( 'woocommerce_product_variation_get_average_rating', array($this, 'get_average_rating'), 10, 2 );
        add_action( 'comment_post', array($this, 'assign_ratings_to_child_products'), 11, 2 );

        // Variation title
        add_filter( 'woocommerce_product_title', array( $this, 'variation_title' ), 10, 2 );
        add_filter( 'woocommerce_product_variation_title', array( $this, 'variation_title' ), 10, 4 );

        // Variation link
        add_filter( 'post_type_link', array( $this, 'change_post_permalink' ), 10, 2 );
        add_filter( 'woocommerce_loop_product_link', array( $this, 'change_variation_permalink' ), 10, 2 );
        add_filter( 'woocommerce_cart_item_permalink', array($this, 'cart_item_permalink'), 10, 3 );

        // Variation Add to cart (loop)
        add_filter( 'woocommerce_product_add_to_cart_text', array( $this, 'add_to_cart_text' ), 10, 2 );
        add_filter( 'woocommerce_product_add_to_cart_url', array( $this, 'add_to_cart_url' ), 10, 2 );
        add_filter( 'woocommerce_loop_add_to_cart_link', array($this, 'change_variation_add_to_cart_link'), 10, 2 );

        add_filter( 'woocommerce_price_filter_post_type', array( $this, 'add_product_variation_to_price_filter' ), 10, 1 );

        // Single page variation description & add to cart (For Quick Views)
        add_filter('woocommerce_short_description', array($this, 'variation_single_short_description'), 10, 1 );
        add_action('woocommerce_variation_add_to_cart', array( $this, 'variation_single_add_to_cart' ), 10);

        if(isset($GLOBALS['Product_Addon_Display'])) {
            remove_action('woocommerce_before_variations_form', array($GLOBALS['Product_Addon_Display'], 'reposition_display_for_variable_product'), 10);
        }

        if(is_admin()) {

            add_action('woocommerce_product_after_variable_attributes', array($this, 'add_variation_fields'), 10, 3);
            add_action('woocommerce_variable_product_bulk_edit_actions', array($this, 'add_variation_bulk_edit_actions'), 10);
            add_action('woocommerce_bulk_edit_variations_default', array($this, 'bulk_edit_variations'), 10, 4);

            add_action('set_object_terms', array($this, 'set_variation_terms'), 10, 6);

            add_action( 'woocommerce_save_product_variation', array( $this, 'on_variation_save' ), 100, 2 );
            add_action( 'woocommerce_new_product_variation', array( $this, 'on_variation_save' ), 10 );
            add_action( 'woocommerce_update_product_variation', array( $this, 'on_variation_save' ), 10 );
        }

        $this->register_taxonomy_for_object_type();

    }


    /**
     * Filter variation is_visible.
     *
     * @param bool $visible
     * @param int  $product_id
     *
     * @return bool
     */
    public function variation_is_visible( $visible, $product_id ) {

        if ( get_post_type($product_id) === 'product_variation' ) {
            return $visible;
        }

        $action  = filter_input( INPUT_POST, 'action' );
        $wc_ajax = filter_input( INPUT_GET, 'wc-ajax' );

        if ( $action === 'woocommerce_get_refreshed_fragments' || $wc_ajax === 'get_refreshed_fragments' ) {
            // If variation is in cart, always return true.
            return true;
        }

        $visibility = $this->get_visibility( $product_id );

        if ( in_array( 'hidden', $visibility ) ) {
            return false;
        }

        $parent_id     = wp_get_post_parent_id( $product_id );
        $parent_status = get_post_status( $parent_id );

        if ( $parent_status !== 'publish' ) {
            return false;
        }

        return true;
    }


    /**
     * Filter product visibility
     *
     * Set variation to is_visible() if the options are selected
     *
     * @param  bool $visible
     * @param  bool $id
     *
     * @return bool
     */
    public function product_is_visible( $visible, $product_id ) {

        $visibility = get_post_meta( $product_id, '_visibility', true );
        //var_dump($visibility);
        if ( is_array( $visibility ) ) {
            // visible in search

            if ( $this->is_visible_when( 'search', $product_id ) ) {
                $visible = true;
            }

            // visible in filtered

            if ( $this->is_visible_when( 'filtered', $product_id ) ) {
                $visible = true;
            }

            // visible in catalog

            if ( $this->is_visible_when( 'catalog', $product_id ) ) {
                $visible = true;
            }
        }

        return $visible;
    }


    /**
     * Is visible when...
     *
     * Check if a variation is visible when search, filtered, catalog
     *
     * @param  string $when
     * @param  int    $id
     *
     * @return bool
     */
    public function is_visible_when( $when, $id ) {

        $visibility = get_post_meta( $id, '_visibility', true );

        if ( is_array( $visibility ) ) {
            // visible in search

            if ( is_search() && in_array( $when, $visibility ) ) {
                return true;
            }

            // visible in filtered

            if ( is_filtered() && in_array( $when, $visibility ) ) {
                return true;
            }

            // visible in catalog

            if ( ! is_filtered() && ! is_search() && in_array( $when, $visibility ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Remove variations that are set as Listing Only
     *
     * @param array $children
     *
     * @return array $children
     */
    public function remove_listing_only_variations( $children ) {

        if ( is_admin() || empty( $children ) ) {
            return $children;
        }

        foreach ( $children as $i => $variation_id ) {

            $listing_only = $this->get_listings_only( $variation_id );

            if ( ! $listing_only ) {
                continue;
            }

            unset( $children[ $i ] );
        }

        return $children;
    }

    /**
     * When retrieving a variation via Ajax, Disable the ones that are set as Listing Only
     *
     * @param array $variation
     *
     * @return array
     */
    public function disable_listing_only_variation($variation = array()) {

        if ( empty( $variation )) {
            return $variation;
        }

        $listing_only = $this->get_listings_only( $variation['variation_id'] );

        if ( $listing_only ) {
            $variation['is_purchasable'] = false;
            $variation['variation_is_visible'] = false;
            $variation['variation_is_active'] = false;
        }

        return $variation;
    }

    /**
     * Inherit parent rating count.
     *
     * @param float      $value
     * @param WC_Product $product
     *
     * @return float
     */
    public function get_rating_counts( $value, $product ) {


        $parent_product = wc_get_product( $product->get_parent_id() );

        if ( ! $parent_product ) {
            return $value;
        }

        return $parent_product->get_rating_counts();
    }

    /**
     * Inherit parent rating count.
     *
     * @param float      $value
     * @param WC_Product $product
     *
     * @return float
     */
    public function get_review_count( $value, $product ) {

        $parent_product = wc_get_product( $product->get_parent_id() );

        if ( ! $parent_product ) {
            return $value;
        }

        return $parent_product->get_review_count();
    }

    /**
     * Inherit parent average rating.
     *
     * @param float      $value
     * @param WC_Product $product
     *
     * @return float
     */
    public function get_average_rating( $value, $product ) {

        $parent_product = wc_get_product( $product->get_parent_id() );

        if ( ! $parent_product ) {
            return $value;
        }

        return $parent_product->get_average_rating();
    }

    /**
     * Assign ratings to child product.
     *
     * @return void
     */
    public function assign_ratings_to_child_products() {
        $rating          = intval( filter_input( INPUT_POST, 'rating', FILTER_SANITIZE_NUMBER_INT ) );
        $comment_post_id = absint( filter_input( INPUT_POST, 'comment_post_ID', FILTER_SANITIZE_NUMBER_INT ) );

        if ( $rating && $comment_post_id && 'product' === get_post_type( $comment_post_id ) ) {
            $this->sync_average_rating_to_child( $comment_post_id );
        }
    }

    /**
     * Sync ratings with child
     *
     * @param int $product_id
     */
    public function sync_average_rating_to_child( $product_id ) {

        global $wpdb;

        $product = wc_get_product( $product_id );

        if ( ! $product->is_type( 'variable' ) ) {
            return;
        }

        $average_rating    = $product->get_average_rating();
        $rating_count      = $product->get_rating_count();
        $child_product_ids = $product->get_children();

        $query = $wpdb->prepare( "
			UPDATE {$wpdb->prefix}wc_product_meta_lookup 
			SET rating_count = %d, average_rating = %f
			WHERE product_id IN 
			( SELECT ID FROM $wpdb->posts WHERE post_parent = %d )
		", $rating_count, $average_rating, $product_id );

        $wpdb->query( $query );

        foreach ( $child_product_ids as $child_product_id ) {
            update_post_meta( $child_product_id, '_wc_average_rating', $average_rating );
            update_post_meta( $child_product_id, '_wc_review_count', $rating_count );
        }
    }

    /**
     * Get default variation title
     *
     * @param  WC_Product_Variation $product
     *
     * @return string
     */
    public function get_variation_title( $product ) {

        if ( empty($product) ) {
            return "";
        }

        $variation_custom_title = get_post_meta( $product->get_id(), '_xt_woovas_display_title', true );

        return ( $variation_custom_title ) ?: $this->generate_variation_title($product);
    }

    /**
     * Generates a title with attribute information for a variation.
     * Products will get a title of the form "Name - Value, Value" or just "Name".
     *
     * @param $product
     * @return string
     */
    public function generate_variation_title( $product ) {

        $attributes = (array) $product->get_attributes();

        // Do not include attributes if the product has 3+ attributes.
        $should_include_attributes = count( $attributes ) < 3;

        // Do not include attributes if an attribute name has 2+ words and the
        // product has multiple attributes.
        if ( $should_include_attributes && 1 < count( $attributes ) ) {
            foreach ( $attributes as $name => $value ) {
                if ( false !== strpos( $name, '-' ) ) {
                    $should_include_attributes = false;
                    break;
                }
            }
        }

        $should_include_attributes = apply_filters( 'woocommerce_product_variation_title_include_attributes', $should_include_attributes, $product );
        $separator                 = apply_filters( 'woocommerce_product_variation_title_attributes_separator', ' - ', $product );
        $title_base                = get_post_field( 'post_title', $product->get_parent_id() );
        $title_suffix              = $should_include_attributes ? str_replace(",", $separator, wc_get_formatted_variation( $product, true, false )) : '';

        $variation_title = $title_suffix ? $title_base . $separator . ucwords($title_suffix) : $title_base;

        return apply_filters( 'woocommerce_product_variation_title', $variation_title, $product, $title_base, $title_suffix );
    }

    /**
     * Filter variation title.
     *
     * @param string $title
     * @param        $product
     * @param        $title_base
     * @param        $title_suffix
     *
     * @return string
     */
    public function variation_title( $title, $product, $title_base = false, $title_suffix = false ) {
        if ( ! $product->is_type( 'variation' ) ) {
            return $title;
        }

        $saved_title = get_post_meta( $product->get_id(), '_xt_woovas_display_title', true );

        if ( empty( $saved_title ) ) {
            return $title;
        }

        return $saved_title;
    }

    /**
     * Change post permalink
     *
     * @param  string $url
     * @param  WP_Post $post
     *
     * @return string
     */
    public function change_post_permalink( $url, $post ) {

        if ( 'product_variation' == $post->post_type ) {

            $variation = wc_get_product( absint( $post->ID ) );

            return $this->get_variation_url( $variation );
        }

        return $url;
    }

    /**
     * Change variation permalink
     *
     * @param $permalink
     * @param $product
     * @return string
     */
    public function change_variation_permalink( $permalink, $product ) {

        if($product->get_type() !== 'variation') {
            return $permalink;
        }

        return $this->get_variation_url( $product );
    }

    /**
     * Get variation URL
     *
     * @param  string [$variation]
     *
     * @return string
     */
    public function get_variation_url( $variation ) {

        $url                 = "";
        $variation_parent_id = $variation->get_parent_id();

        if ( $variation_parent_id ) {
            $variation_data     = array_filter( wc_get_product_variation_attributes( $variation->get_id() ) );
            $parent_product_url = get_the_permalink( $variation_parent_id );

            $url = add_query_arg( $variation_data, $parent_product_url );
        }

        return $url;
    }

    /**
     * Ignore custom visibility setting in cart.
     *
     * @param string $permalink
     * @param array  $cart_item
     * @param string $cart_item_key
     *
     * @return string
     */
    public function cart_item_permalink( $permalink, $cart_item, $cart_item_key ) {
        $_product = $cart_item['data'];

        remove_filter( 'woocommerce_product_is_visible', array( $this, 'variation_is_visible' ), 10 );

        // If variation is in cart, always return true.
        $permalink = $_product->get_permalink( $cart_item );
        add_filter( 'woocommerce_product_is_visible', array( $this, 'variation_is_visible' ), 10, 2 );

        return $permalink;
    }

    /**
     * Add to Cart Text
     *
     * @param  string $text
     * @param  WC_Product $product
     *
     * @return string
     */
    public function add_to_cart_text( $text, $product = false ) {

        if ( $product->get_type() !== 'variation' ) {
            return $text;
        }

        if ( ! $this->is_purchasable( $product ) ) {
            return esc_html__( 'Select options', 'xt-woo-variations-as-singles' );
        }

        if(!$product->is_in_stock()) {
            return __( 'Out of stock', 'xt-woo-variations-as-singles' );
        }

        return $text;
    }

    /**
     * Add to Cart URL
     *
     * @param  string $url
     * @param  WC_Product $product
     *
     * @return string
     */
    public function add_to_cart_url( $url, $product ) {

        if ( $product->get_id() && $product->get_type() === "variation" ) {
            $url = $this->is_purchasable( $product ) && $product->is_in_stock() ? $url : $this->get_variation_url( $product );
        }

        return $url;
    }

    /**
     * Change variation add to cart link
     *
     * @param string     $link
     * @param WC_Product $product
     *
     * @return string
     */
    public function change_variation_add_to_cart_link( $link, $product ) {

        if ( empty( $product ) ) {
            return $link;
        }

        if ( $product->get_type() !== "variation" ) {
            return $link;
        }

        $product_id = $product->get_id();

        $is_purchasable = $this->is_purchasable( $product );

        $defaults = array(
            'quantity'   => 1,
            'class'      => implode(
                ' ',
                array_filter(
                    array(
                        'button',
                        'product_type_' . $product->get_type(),
                        $is_purchasable && $product->is_in_stock() ? 'add_to_cart_button' : '',
                        $product->supports( 'ajax_add_to_cart' ) && $is_purchasable && $product->is_in_stock() ? 'ajax_add_to_cart' : '',
                    )
                )
            ),
            'is_purchasable' => $is_purchasable,
            'attributes' => array(
                'data-product_id'  => $product_id,
                'data-variation_id' => $product_id,
                'data-product_sku' => $product->get_sku(),
                'aria-label'       => $product->add_to_cart_description(),
                'rel'              => 'nofollow',
            ),
        );

        $args = apply_filters( 'woocommerce_loop_add_to_cart_args', $defaults, $product );

        $args['attributes'] = array_filter( (array) $args['attributes'] );

        if ( ! empty( $args['attributes'] ) && is_array( $args['attributes'] ) ) {
            foreach ( $args['attributes'] as $attribute => $attribute_value ) {
                $attributes[] = esc_attr( $attribute ) . '="' . esc_attr( $attribute_value ) . '"';
            }
        }

        return apply_filters(
            'xt_woovas_add_to_cart_button_class', // WPCS: XSS ok.
            sprintf(
                '<a href="%s" data-quantity="%s" class="%s" %s>%s</a>',
                esc_url( $product->add_to_cart_url() ),
                esc_attr( isset( $args['quantity'] ) ? $args['quantity'] : 1 ),
                esc_attr( isset( $args['class'] ) ? $args['class'] : 'button' ),
                isset( $args['attributes'] ) ? wc_implode_html_attributes( $args['attributes'] ) : '',
                apply_filters( 'xt_woovas_add_to_cart_button_text', $product->add_to_cart_text(), $product )
            ),
            $product,
            $args
        );
    }

    /**
     * Set variation description in single view.
     *
     * @param $post_excerpt
     * @return float
     */
    public function variation_single_short_description($post_excerpt) {

        global $product;

        if(!empty($product) && $product->get_type() === 'variation') {
            $post_excerpt = $product->get_description();
        }

        return $post_excerpt;
    }

    /**
     * Render simple add to cart in single variation view
     */
    public function variation_single_add_to_cart() {

        wc_get_template( 'single-product/add-to-cart/simple.php' );
    }

    /**
     * Check if product is purchasable
     *
     * @param  WC_Product $product
     *
     * @return bool
     */
    public function is_purchasable( $product ) {
        $purchasable = $product->is_purchasable();
        $product_id  = $product->get_id();

        if ( ! $product_id ) {
            return $purchasable;
        }

        $disable_add_to_cart = get_post_meta( $product_id, '_disable_add_to_cart', true );
        $listings_only       = $this->get_listings_only( $product_id );

        if ( $disable_add_to_cart || $listings_only ) {
            $purchasable = false;
        } else {
            $variation_data = wc_get_product_variation_attributes( $product_id );

            if ( empty( $variation_data ) ) {
                return $purchasable;
            }

            foreach ( $variation_data as $value ) {
                if ( ! empty( $value ) ) {
                    continue;
                }

                $purchasable = false;
            }
        }

        return $purchasable;
    }

    /**
     * Add variation fields
     *
     * @param  string $loop
     * @param  array $variation_data
     * @param  object $variation
     */
    public function add_variation_fields( $loop, $variation_data, $variation ) {

        $override_checkbox = $this->get_override_checkbox( $variation, $loop );
        $visibility_checkboxes = $this->get_visibility_checkboxes( $variation, $loop );
        $other_checkboxes = $this->get_other_checkboxes( $variation, $loop );
        $variation_fields = $this->get_variation_fields( $variation, $loop );

        $options_hidden_class = !$override_checkbox['checked'] ? 'hidden' : '';

        echo '<div class="options_group form-row form-row-full options">';

        echo xtfw_heading(esc_html__('Variation Visibility As Single', 'xt-woo-variations-as-single'), 'h4', array('xtfw-title-separator'));

        echo '<p>';
        foreach ( $other_checkboxes as $checkbox ) {
            $this->render_checkbox_field($checkbox);
        }
        echo '</p>';

        echo '<p>';
        $this->render_checkbox_field($override_checkbox);
        echo '</p>';

        echo '<p class="xt_woovas-visibility-options '.esc_attr($options_hidden_class).'">';

        foreach ( $visibility_checkboxes as $checkbox ) {
            $this->render_checkbox_field($checkbox);
        }

        echo '</p>';

        foreach($variation_fields as $field) {

            woocommerce_wp_text_input($field);
        }

        echo '</div>';

    }

    /**
     * Render checkbox field
     *
     * @param  object $field
     */
    public function render_checkbox_field( $field ) {
        ?>
        <label>
            <input type="checkbox" class="checkbox <?php echo $field['class']; ?>" id="<?php echo $field['id']; ?>" name="<?php echo $field['name']; ?>" <?php checked( $field['checked'], true ); ?> />
            <?php echo $field['label']; ?>
            <?php if ( ! empty( $field['desc'] ) ) { ?>
                <span class="woocommerce-help-tip" data-tip="<?php echo esc_attr( $field['desc'] ); ?>" style="font-size: 18px; margin-left: 4px;"></span>
            <?php } ?>
        </label>
        <?php
    }

    /**
     * Render text field
     *
     * @param  object $field
     */
    public function render_text_field( $field ) {
        ?>
        <label>
            <input type="text" class="regular-text <?php echo $field['class']; ?>" id="<?php echo $field['id']; ?>" name="<?php echo $field['name']; ?>" />
            <?php echo $field['label']; ?>
            <?php if ( ! empty( $field['desc'] ) ) { ?>
                <span class="woocommerce-help-tip" data-tip="<?php echo esc_attr( $field['desc'] ); ?>" style="font-size: 18px; margin-left: 4px;"></span>
            <?php } ?>
        </label>
        <?php
    }

    /**
     * Get variation checkboxes
     *
     * @param  WP_Post $variation
     * @param  int $index
     *
     * @return array
     */
    public function get_override_checkbox( $variation, $index ) {

        $override_global = $this->get_override_global($variation->ID);

        return array(
            'class'   => 'xt_woovas_variable_override_global',
            'name'    => sprintf( 'xt_woovas_variable_override_global[%d]', $index ),
            'id'      => sprintf( 'xt_woovas_variable_override_global-%d', $index ),
            'checked' => $override_global ? true : false,
            'label'   => __( 'Override Global Visibility Settings?', 'xt-woo-variations-as-single' ),
            'desc'    => __( 'By default, global settings are being used. Enable this option to override them.', 'xt-woo-variations-as-single' ),
        );
    }

    /**
     * Get visibility checkboxes
     *
     * @param  WP_Post $variation
     * @param  int $index
     *
     * @return array
     */
    public function get_visibility_checkboxes( $variation, $index ) {

        $visibility = $this->get_visibility($variation->ID, false);

        return array(
            array(
                'class'   => 'xt_woovas_variable_show_catalog',
                'name'    => sprintf( 'xt_woovas_variable_show_catalog[%d]', $index ),
                'id'      => sprintf( 'xt_woovas_variable_show_catalog-%d', $index ),
                'checked' => is_array( $visibility ) && in_array( 'catalog', $visibility ),
                'label'   => __( 'Show in Catalog?', 'xt-woo-variations-as-single' ),
            ),
            array(
                'class'   => 'xt_woovas_variable_show_filtered',
                'name'    => sprintf( 'xt_woovas_variable_show_filtered[%d]', $index ),
                'id'      => sprintf( 'xt_woovas_variable_show_filtered-%d', $index ),
                'checked' => is_array( $visibility ) && in_array( 'filtered', $visibility ),
                'label'   => __( 'Show in Filtered Results?', 'xt-woo-variations-as-single' ),
            ),
            array(
                'class'   => 'xt_woovas_variable_show_search',
                'name'    => sprintf( 'xt_woovas_variable_show_search[%d]', $index ),
                'id'      => sprintf( 'xt_woovas_variable_show_search-%d', $index ),
                'checked' => is_array( $visibility ) && in_array( 'search', $visibility ),
                'label'   => __( 'Show in Search Results?', 'xt-woo-variations-as-single' ),
            ),
        );

    }

    /**
     * Get other checkboxes
     *
     * @param  WP_Post $variation
     * @param  int $index
     *
     * @return array
     */
    public function get_other_checkboxes( $variation, $index ) {

        $featured            = $this->get_is_featured($variation->ID);
        $listings_only       = $this->get_listings_only($variation->ID);
        $disable_add_to_cart = $this->get_add_to_cart($variation->ID);

        return array(
            array(
                'class'   => 'xt_woovas_variable_featured',
                'name'    => sprintf( 'xt_woovas_variable_featured[%d]', $index ),
                'id'      => sprintf( 'xt_woovas_variable_featured-%d', $index ),
                'checked' => $featured === "yes",
                'label'   => __( 'Is Featured', 'xt-woo-variations-as-single' ),
            ),
            array(
                'class'   => 'xt_woovas_variable_disable_add_to_cart',
                'name'    => sprintf( 'xt_woovas_variable_disable_add_to_cart[%d]', $index ),
                'id'      => sprintf( 'xt_woovas_variable_disable_add_to_cart-%d', $index ),
                'checked' => $disable_add_to_cart ? true : false,
                'label'   => __( 'Disable "Add to Cart"?', 'xt-woo-variations-as-single' ),
                'desc'    => 'Use the "Select Options" button in product listings instead of "Add to Cart".',
            ),
            array(
                'class'   => 'xt_woovas_variable_listings_only',
                'name'    => sprintf( 'xt_woovas_variable_listings_only[%d]', $index ),
                'id'      => sprintf( 'xt_woovas_variable_listings_only-%d', $index ),
                'checked' => $listings_only ? true : false,
                'label'   => __( 'Listings Only?', 'xt-woo-variations-as-single' ),
                'desc'    => "Enable to only show this variation in product listings. It won't be purchasable on the single product page.",
            ),
        );

    }

    /**
    * Get variation fields
    *
    * @param  WP_Post $variation
    * @param  int $index
    *
    * @return array
    */
    public function get_variation_fields( $variation, $index ) {

        $product = wc_get_product($variation->ID);

        return array(
            array(
                'class' => 'xt_woovas_display_title',
                'id'    => sprintf( 'xt_woovas_display_title[%d]', $index ),
                'label' => __( 'Display Title', 'xt-woo-variations-as-single' ),
                'desc'  => __( 'Leave empty to generate a title based on variation options', 'xt-woo-variations-as-single' ),
                'value' => $this->get_variation_title( $product )
            )
        );
    }

    /**
     * Add variation bulk edit actions
     */
    public function add_variation_bulk_edit_actions() {
        ?>
        <optgroup label="<?php esc_attr_e( 'Visibility As Single', 'xt-woo-variations-as-single' ); ?>">
            <option value="toggle_override_global"><?php esc_html_e( 'Toggle "Override Global Visibility Settings"', 'xt-woo-variations-as-single' ); ?></option>
            <option value="toggle_show_in_search"><?php esc_html_e( 'Toggle "Show in Search Results"', 'xt-woo-variations-as-single' ); ?></option>
            <option value="toggle_show_in_filtered"><?php esc_html_e( 'Toggle "Show in Filtered Results"', 'xt-woo-variations-as-single' ); ?></option>
            <option value="toggle_show_in_catalog"><?php esc_html_e( 'Toggle "Show in Catalog"', 'xt-woo-variations-as-single' ); ?></option>
            <option value="toggle_is_featured"><?php esc_html_e( 'Toggle "Is Featured"', 'xt-woo-variations-as-single' ); ?></option>
        </optgroup>

        <optgroup label="<?php esc_attr_e( 'Add To Cart', 'xt-woo-variations-as-single' ); ?>">
            <option value="toggle_disable_add_to_cart"><?php esc_html_e( 'Toggle "Disable \'Add to Cart\'"', 'xt-woo-variations-as-single' ); ?></option>
        </optgroup>

        <optgroup label="<?php esc_attr_e( 'Filters', 'xt-woo-variations-as-single' ); ?>">
            <option value="update_filter_counts"><?php esc_html_e( 'Update "Filter Counts"', 'xt-woo-variations-as-single' ); ?></option>
        </optgroup>
        <?php
    }

    /**
     * Bulk edit actions
     *
     * @param  string $bulk_action
     * @param  array $data
     * @param  int   $product_id
     * @param  array $variations
     */
    public function bulk_edit_variations( $bulk_action, $data, $product_id, $variations ) {
        if ( method_exists( $this, "variation_bulk_action_$bulk_action" ) ) {
            call_user_func( array( $this, "variation_bulk_action_$bulk_action" ), $variations );
            XT_WOOVAS_Helpers::delete_term_counts_transient();
        }
    }


    /**
     * Bulk Action - Toggle Show in (x)
     *
     * @param array  $variations
     * @param string $show
     */
    private function variation_bulk_action_toggle_show_in( $variations, $show ) {
        foreach ( $variations as $i => $variation_id ) {
            $visibility = (array) get_post_meta( $variation_id, '_visibility', true );
            $visibility = XT_WOOVAS_Helpers::unset_item_by_value( $visibility, 'hidden' );

            if ( in_array( $show, $visibility ) ) {
                $visibility = XT_WOOVAS_Helpers::unset_item_by_value( $visibility, $show );

                if ( $show == "filtered" ) {
                    $this->add_attributes_to_variation( $variation_id, false, "remove" );
                }
            } else {
                $visibility[] = $show;

                if ( $show == "filtered" ) {
                    $this->add_attributes_to_variation( $variation_id, false, "add" );
                }
            }

            if ( empty( $visibility ) ) {
                $visibility[] = 'hidden';
            }

            $this->set_taxonomies( $variation_id );
            $this->set_visibility( $variation_id, $visibility );

            XT_WOOVAS_Helpers::delete_term_counts_transient();
        }
    }

    /**
     * Bulk Action - Toggle Show in Search
     *
     * @param  array $variations
     */

    private function variation_bulk_action_toggle_show_in_search( $variations ) {
        $this->variation_bulk_action_toggle_show_in( $variations, 'search' );
    }

    /**
     * Bulk Action - Toggle Show in Filtered
     *
     * @param  array $variations
     */

    private function variation_bulk_action_toggle_show_in_filtered( $variations ) {
        $this->variation_bulk_action_toggle_show_in( $variations, 'filtered' );
    }

    /**
     * Bulk Action - Toggle Show in Catalog
     *
     * @param  array $variations
     */
    private function variation_bulk_action_toggle_show_in_catalog( $variations ) {
        $this->variation_bulk_action_toggle_show_in( $variations, 'catalog' );
    }

    /**
     * Bulk Action - Toggle Is Featured
     *
     * @param array $variations
     */
    private function variation_bulk_action_toggle_is_featured( $variations ) {
        foreach ( $variations as $variation_id ) {

            $featured = $this->get_is_featured($variation_id) !== "yes";

            $this->set_is_featured( $variation_id, $featured );
        }
    }

    /**
     * Bulk Action - Toggle Override Global
     *
     * @param  array $variations
     */

    private function variation_bulk_action_toggle_override_global( $variations ) {

        foreach ( $variations as $variation_id ) {

            $override_global = $this->get_override_global($variation_id);

            if ( !$override_global ) {
                update_post_meta( $variation_id, '_override_global', true );
            } else {
                delete_post_meta( $variation_id, '_override_global' );
            }
        }
    }

    /**
     * Bulk Action - Toggle Disable "Add to Cart"
     *
     * @param  array $variations
     */

    private function variation_bulk_action_toggle_disable_add_to_cart( $variations ) {

        foreach ( $variations as $variation_id ) {

            $disable_add_to_cart = $this->get_add_to_cart($variation_id);

            if ( !$disable_add_to_cart ) {
                update_post_meta( $variation_id, '_disable_add_to_cart', true );
            } else {
                delete_post_meta( $variation_id, '_disable_add_to_cart' );
            }
        }
    }

    /**
     * Fired when a product's terms have been set.
     *
     * @param int    $object_id  Object ID.
     * @param array  $terms      An array of object terms.
     * @param array  $tt_ids     An array of term taxonomy IDs.
     * @param string $taxonomy   Taxonomy slug.
     * @param bool   $append     Whether to append new terms to the old terms.
     * @param array  $old_tt_ids Old array of term taxonomy IDs.
     */
    public function set_variation_terms( $object_id, $terms, $tt_ids, $taxonomy, $append, $old_tt_ids ) {

        $post_type = get_post_type( $object_id );

        if ( $post_type === "product" ) {
            return;
        }

        $taxonomies = $this->get_taxonomies();

        if ( empty( $taxonomies ) ) {
            return;
        }

        if ( in_array( $taxonomy, $taxonomies ) ) {

            $variations = get_children( array(
                'post_parent' => $object_id,
                'post_type'   => 'product_variation',
            ), ARRAY_A );

            if ( ! empty( $variations ) ) {

                $variation_ids = array_keys( $variations );

                foreach ( $variation_ids as $variation_id ) {
                    wp_set_object_terms( $variation_id, $terms, $taxonomy, $append );
                }
            }
        }
    }


    /**
     * On variation save
     *
     * @param int      $variation_id
     * @param int|bool $i
     */
    public function on_variation_save( $variation_id, $i = false ) {

        $action = filter_input( INPUT_POST, 'action' );

        // If saving variations (ajax)
        if ( $action === 'woocommerce_save_variations' && $i === false ) {
            return;
        }

        $this->save_product_variation( $variation_id, $i );
        $this->set_taxonomies( $variation_id );
        $this->add_attributes_to_variation( $variation_id, $i );
        XT_WOOVAS_Helpers::delete_term_counts_transient();

        $this->set_total_sales( $variation_id );
    }

    /**
     * Save variation options
     *
     * @param int $variation_id
     * @param int $i
     */
    public function save_product_variation( $variation_id, $i = false ) {

        // When the $i var is available, we are saving the product from within the backend product edit page.
        // If not, we are saving the product from the settings bulk visibility process

        $data = array(
            'visibility'      => array(),
            'override_global' => $i !== false ? isset( $_POST['xt_woovas_variable_override_global'][ $i ] ) : $this->get_override_global( $variation_id ),
            'add_to_cart'     => $i !== false ? isset( $_POST['xt_woovas_variable_disable_add_to_cart'][ $i ] ) : $this->get_add_to_cart( $variation_id ),
            'is_featured'     => $i !== false ? isset( $_POST['xt_woovas_variable_featured'][ $i ] ) : $this->get_is_featured( $variation_id ),
            'listings_only'   => $i !== false ? isset( $_POST['xt_woovas_variable_listings_only'][ $i ] ) : $this->get_listings_only( $variation_id ),
            'title'           => $i !== false && isset( $_POST['xt_woovas_display_title'][ $i ] ) ? $_POST['xt_woovas_display_title'][ $i ] : '',
        );

        // set visibility

        if( $i !== false && !empty($data['override_global'])) {

            if (isset($_POST['xt_woovas_variable_show_catalog'][$i])) {
                $data['visibility'][] = "catalog";
            }

            if (isset($_POST['xt_woovas_variable_show_filtered'][$i])) {
                $data['visibility'][] = "filtered";
            }

            if (isset($_POST['xt_woovas_variable_show_search'][$i])) {
                $data['visibility'][] = "search";
            }

        }

        if(empty($data['visibility'])) {

            if($i !== false) {
                $data['visibility'] = empty($data['override_global']) ? $this->get_global_visibility() : array('hidden');
            }else {
                $data['visibility'] = $this->get_visibility($variation_id);
            }
        }

        // Save data.

        foreach ( $data as $method => $value ) {
            $method_name = sprintf( 'set_%s', $method );
            $this->$method_name($variation_id, $value);
        }
    }

    /**
     * Add product_variation to tags and categories
     */
    public function register_taxonomy_for_object_type() {

        $taxonomies = $this->get_taxonomies();

        if ( empty( $taxonomies ) ) {
            return;
        }

        foreach ( $taxonomies as $taxonomy ) {

            register_taxonomy_for_object_type( $taxonomy, 'product_variation' );
        }

    }

    /**
     * Save variation attributes
     *
     * @param int      $variation_id
     * @param int|bool $i
     * @param bool     $force
     */
    public function add_attributes_to_variation( $variation_id, $i = false, $force = false ) {
        $show_in_filtered = isset( $_POST['xt_woovas_variable_show_filtered'][ $i ] ) && $_POST['xt_woovas_variable_show_filtered'][ $i ] == "on";
        $attributes       = wc_get_product_variation_attributes( $variation_id );

        // If $i is not set - i.e. bulk edit or API call - get the current visibility
        // and ensure attributes are set if the variation is visible in filtered.
        if ( ! $i ) {
            $visibility       = $this->get_visibility( $variation_id );
            $show_in_filtered = in_array( 'filtered', $visibility );
        }

        if ( $attributes && ! empty( $attributes ) ) {
            foreach ( $attributes as $taxonomy => $value ) {
                $taxonomy = str_replace( 'attribute_', '', $taxonomy );
                $term     = get_term_by( 'slug', $value, $taxonomy );

                delete_transient( 'wc_layered_nav_counts_' . $taxonomy );

                // If we're forcing attributes to be added, or the variation
                // is set to show in filtered.
                if ( $force == "add" || $show_in_filtered ) {
                    wp_set_object_terms( $variation_id, $value, $taxonomy );
                } else {
                    if ( $term && ( ! $force || $force == "remove" ) ) {
                        $products_in_term = wc_get_term_product_ids( $term->term_id, $taxonomy );

                        if ( ( $key = array_search( $variation_id, $products_in_term ) ) !== false ) {
                            unset( $products_in_term[ $key ] );
                        }

                        update_term_meta( $term->term_id, 'product_ids', $products_in_term );
                        wp_remove_object_terms( $variation_id, $term->term_id, $taxonomy );
                    }
                }

                if ( $term ) {
                    XT_WOOVAS_Helpers::delete_count_transient( $taxonomy, $term->term_taxonomy_id );
                }
            }
        }
    }

    /**
     * Set catalog visibility.
     *
     * @param int   $variation_id
     * @param array $visibility
     * @param bool  $meta_only
     *
     * @return bool
     */
    public function set_visibility( $variation_id, $visibility = null, $meta_only = false ) {

        $set_visibility     = true;
        $current_visibility = $this->get_visibility( $variation_id );
        $visibility         = is_null( $visibility ) ? $current_visibility : $visibility;

        sort( $visibility );

        update_post_meta( $variation_id, '_visibility', $visibility, $current_visibility );

        if ( $meta_only ) {
            return $set_visibility;
        }

        $variation  = wc_get_product( $variation_id );
        $visibility = implode( '-', $visibility );

        $terms = array();
        $set_visibility = false;

        switch ( $visibility ) {
            case 'catalog' :
                $terms[] = "exclude-from-search";
                $terms[] = "exclude-from-filtered";
                break;
            case 'search' :
                $terms[] = "exclude-from-catalog";
                $terms[] = "exclude-from-filtered";
                break;
            case 'catalog-filtered' :
                $terms[] = "exclude-from-search";
                break;
            case 'catalog-search' :
                $terms[] = "exclude-from-filtered";
                break;
            case 'filtered' :
                $terms[] = "exclude-from-catalog";
                $terms[] = "exclude-from-search";
                break;
            case 'filtered-search' :
                $terms[] = "exclude-from-catalog";
                break;
            case 'hidden' :
                $terms[] = "exclude-from-catalog";
                $terms[] = "exclude-from-search";
                $terms[] = "exclude-from-filtered";
                break;
        }

        if ( $variation && $variation->get_stock_status() === "outofstock" ) {

            $terms[] = "outofstock";
        }

        $taxonomies = wp_set_post_terms( $variation_id, $terms, 'product_visibility' );

        if ( ! is_wp_error( $taxonomies ) ) {
            delete_transient( 'wc_featured_products' );
            do_action( 'woocommerce_product_set_visibility', $variation_id, $terms );
            $set_visibility = true;
        }

        return $set_visibility;
    }

    /**
     * Set featured visibility.
     *
     * @param int  $variation_id
     * @param bool $featured
     * @param bool $meta_only
     *
     * @return bool
     */
    public function set_is_featured( $variation_id, $featured = null, $meta_only = false ) {

        $set_featured = true;
        $featured     = is_null( $featured ) ? xtfw_string_to_bool( $this->get_is_featured($variation_id) ) : $featured;

        if ( $featured ) {
            update_post_meta( $variation_id, '_featured', "yes" );
        } else {
            delete_post_meta( $variation_id, '_featured' );
        }

        if ( $meta_only ) {
            return $set_featured;
        }

        if ( $featured ) {
            $set_featured = wp_set_object_terms( $variation_id, 'featured', 'product_visibility', true );
        } else {
            $set_featured = wp_remove_object_terms( $variation_id, 'featured', 'product_visibility' );
        }

        if ( is_wp_error( $set_featured ) ) {
            return false;
        }

        delete_transient( 'wc_featured_products' );

        return true;
    }

    /**
     * Add main product taxonomies to variation.
     *
     * @param int $variation_id
     */
    public function set_taxonomies( $variation_id ) {

        $taxonomies = $this->get_taxonomies();

        if ( empty( $taxonomies ) ) {
            return;
        }

        $parent_product_id = wp_get_post_parent_id( $variation_id );

        if ( $parent_product_id ) {
            foreach ( $taxonomies as $taxonomy ) {

                $terms = (array) wp_get_post_terms( $parent_product_id, $taxonomy, array( "fields" => "ids" ) );
                //echo '<pre>';var_dump($taxonomy, $terms);echo '</pre>';
                wp_set_post_terms( $variation_id, $terms, $taxonomy );
            }
           // die();
        }
    }

    /**
     * Get override global
     *
     * @param int $variation_id
     *
     * @return bool
     */
    public function get_override_global( $variation_id ) {
        return get_post_meta( $variation_id, '_override_global', true );
    }

    /**
     * Get variation visibility.
     *
     * @param int $variation_id
     *
     * @return array
     */
    public function get_visibility( $variation_id, $globalAsFallback = true ) {

        $override_global = xtfw_string_to_bool( $this->get_override_global($variation_id) );

        $default_visibility = array( "hidden" );

        if($override_global) {
            $visibility = get_post_meta($variation_id, '_visibility', true);
        }else if($globalAsFallback){
            $visibility = $this->get_global_visibility();
        }

        if ( empty( $visibility ) || !is_array( $visibility ) ) {
            $visibility = $default_visibility;
        }

        return $visibility;
    }

    /**
     * Get global variation visibility.
     *
     * @return array
     */
    public function get_global_visibility() {

        return $this->core->settings()->get_option( 'visibility', array( "hidden" ));
    }

    /**
     * Get featured visibility.
     *
     * @param int $variation_id
     *
     * @return mixed
     */
    public function get_is_featured( $variation_id ) {
        return get_post_meta( $variation_id, '_featured', true );
    }

    /**
     * Get add to cart setting.
     *
     * @param int $variation_id
     *
     * @return mixed
     */
    public function get_add_to_cart( $variation_id ) {
        return get_post_meta( $variation_id, '_disable_add_to_cart', true );
    }

    /**
     * Get listings only setting.
     *
     * @param int $variation_id
     *
     * @return mixed
     */
    public function get_listings_only( $variation_id ) {
        return get_post_meta( $variation_id, '_listings_only', true );
    }

    /**
     * Set total sales.
     *
     * @param int $variation_id
     *
     * @return bool
     */
    public function set_total_sales( $variation_id ) {
        $total_sales = $this->get_variation_sales( $variation_id );
        update_post_meta( $variation_id, 'total_sales', $total_sales );

        do_action( 'xt_woovas_set_total_sales', $variation_id, $total_sales );

        return true;
    }

    /**
     * Get total variation sales
     *
     * @param int $variation_id
     *
     * @return int
     */
    public function get_variation_sales( $variation_id ) {
        global $wpdb;

        $total_sales = $wpdb->get_var(
            $wpdb->prepare(
                "
                SELECT SUM(`quantities`.`meta_value`)
                FROM `{$wpdb->prefix}woocommerce_order_itemmeta` as `itemmeta`
                 LEFT JOIN  `{$wpdb->prefix}woocommerce_order_itemmeta` AS  `quantities` ON `itemmeta`.`order_item_id` = `quantities`.`order_item_id`
                  AND `quantities`.`meta_key` = '_qty'
                 LEFT JOIN `{$wpdb->prefix}woocommerce_order_items` as `items` ON `items`.`order_item_id`=`itemmeta`.`order_item_id`
                WHERE `itemmeta`.`meta_key` = '_variation_id'
                 AND `itemmeta`.`meta_value` = %d
                ",
                $variation_id
            )
        );

        return apply_filters( 'xt_woovas_variation_total_sales', $total_sales );
    }


    /**
     * Set variation title.
     *
     * @param int    $variation_id
     * @param string $title
     */
    public function set_title( $variation_id, $title ) {
        if ( empty( $title ) ) {
            return;
        }

        global $wpdb;

        $title = XT_WOOVAS_Helpers::wp_kses_title($title);

        update_post_meta( $variation_id, '_xt_woovas_display_title', $title );

        $wpdb->update( $wpdb->posts, array( 'post_title' => $title ), array( 'ID' => $variation_id ) );
    }

    /**
     * Update title based on meta.
     *
     * @param int $variation_id
     */
    public function update_title( $variation_id ) {
        global $wpdb;

        $title = get_post_meta( $variation_id, '_xt_woovas_display_title', true );

        if ( ! $title ) {
            return;
        }

        $wpdb->update( $wpdb->posts, array( 'post_title' => $title ), array( 'ID' => $variation_id ) );
    }
    
    /**
     * Set override global
     *
     * @param int  $variation_id
     * @param bool $override_global
     */
    public function set_override_global( $variation_id, $override_global ) {
        $this->set_checkbox_meta( $variation_id, '_override_global', $override_global );
    }

    /**
     * Set add to cart.
     *
     * @param int  $variation_id
     * @param bool $add_to_cart
     */
    public function set_add_to_cart( $variation_id, $add_to_cart ) {
        $this->set_checkbox_meta( $variation_id, '_disable_add_to_cart', $add_to_cart );
    }

    /**
     * Set listings only.
     *
     * @param int  $variation_id
     * @param bool $listings_only
     */
    public function set_listings_only( $variation_id, $listings_only ) {
        $this->set_checkbox_meta( $variation_id, '_listings_only', $listings_only );
    }

    /**
     * Set generic checkbox meta.
     *
     * @param $variation_id
     * @param $key
     * @param $value
     */
    public function set_checkbox_meta( $variation_id, $key, $value ) {
        if ( ! $value ) {
            delete_post_meta( $variation_id, $key );

            return;
        }

        update_post_meta( $variation_id, $key, $value );
    }

    /**
     * Get variation taxonomies.
     *
     * @return array
     */
    public function get_taxonomies()
    {

        return apply_filters( 'xt_woovas_variation_taxonomies', array(
            'product_cat',
            'product_tag',
            'product_brand',
            'pwb-brand'
        ) );
    }

    /**
     * Get attributes assigned to variation which are not "used for variations".
     *
     * @param int $variation_id
     *
     * @return array
     */
    public function get_non_variation_attributes( $variation_id ) {

        global $wpdb;

        $attributes = array();

        $query = "
        SELECT taxonomies.taxonomy 
        FROM {$wpdb->prefix}term_relationships as relationships
        LEFT JOIN {$wpdb->prefix}term_taxonomy as taxonomies on relationships.term_taxonomy_id = taxonomies.term_taxonomy_id
		WHERE relationships.object_id = %d AND taxonomies.taxonomy LIKE 'pa_%'
		";

        $results = $wpdb->get_results( $wpdb->prepare( $query, $variation_id ), ARRAY_A );

        if ( ! $results ) {
            return $attributes;
        }

        $attributes = wp_list_pluck( $results, 'taxonomy' );

        return $attributes;
    }

    /**
     * Get an array of unused attributes for a variation. Unused means it's not "used for variations"
     * or it doesn't belong to the parent product.
     *
     * @param WC_Product_Variation|int $variation
     * @param WC_Product_Variable|bool $product
     *
     * @return array
     */
    public function get_unused_attributes( $variation, $product = false ) {

        if ( is_numeric( $variation ) ) {
            $variation = wc_get_product( $variation );
        }

        if ( ! $product ) {
            $product = wc_get_product( $variation->get_parent_id() );
        }

        if ( ! is_a( $product, 'WC_Product_Variable' ) ) {
            return array();
        }

        $product_attributes   = array_keys( $product->get_attributes() );
        $variation_attributes = $this->get_non_variation_attributes( $variation->get_id() );

        return array_diff( $variation_attributes, $product_attributes );
    }

    /**
     * Remove any attributes of a variation which don't belong to the parent.
     *
     * @param WC_Product_Variation|int $variation
     * @param WC_Product_Variable|bool $product
     */
    public function remove_unused_attributes( $variation, $product = false ) {
        $variation_id      = is_numeric( $variation ) ? $variation : $variation->get_id();
        $unused_attributes = $this->get_unused_attributes( $variation );

        if ( empty( $unused_attributes ) ) {
            return;
        }

        foreach ( $unused_attributes as $unused_attribute ) {
            wp_set_object_terms( $variation_id, array(), $unused_attribute );
        }
    }

    /**
     * Assign all attributes from parent to child when child has "any" attribute value.
     * Otherwise variations don't show up in the filtered counts/results.
     *
     * @param int        $variation_id Variation Product ID.
     * @param WC_Product $product      Parent Product.
     *
     * @return void
     */
    public function apply__any__attribute( $variation_id, $product ) {
        $attributes = $product->get_attributes();

        if ( empty( $attributes ) ) {
            return;
        }

        foreach ( $attributes as $taxonomy => $attribute ) {
            if ( empty( $attribute ) || ! $attribute->is_taxonomy() ) {
                continue;
            }

            $terms = get_the_terms( $variation_id, $taxonomy );

            // set parent's attribute to variation if $terms is empty.
            if ( empty( $terms ) ) {
                $terms    = $attribute->get_terms();
                $term_ids = wp_list_pluck( $terms, 'term_id' );
                wp_set_object_terms( $variation_id, $term_ids, $taxonomy );
            }
        }
    }

    /**
     * Add product_variation to price filter widget
     *
     * @param array $post_types
     *
     * @return array
     */
    public function add_product_variation_to_price_filter( $post_types ) {

        $post_types[] = 'product_variation';

        return $post_types;
    }
}
