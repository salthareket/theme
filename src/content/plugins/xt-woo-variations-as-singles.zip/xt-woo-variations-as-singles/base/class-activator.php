<?php

/**
 * Fired during plugin activation
 *
 * @link       http://xplodedthemes.com
 * @since      1.0.0
 *
 * @package    XT_WOOVAS
 * @subpackage XT_WOOVAS/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    XT_WOOVAS
 * @subpackage XT_WOOVAS/includes
 * @author     XplodedThemes 
 */
class XT_WOOVAS_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

        do_action('xt_woovas_activate');
	}

}

XT_WOOVAS_Activator::activate();