<?php

/**
 * Fired during plugin deactivation
 *
 * @link       http://xplodedthemes.com
 * @since      1.0.0
 *
 * @package    XT_WOOVAS
 * @subpackage XT_WOOVAS/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    XT_WOOVAS
 * @subpackage XT_WOOVAS/includes
 * @author     XplodedThemes 
 */
class XT_WOOVAS_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

        do_action('xt_woovas_deactivate');
	}


}

XT_WOOVAS_Deactivator::deactivate();