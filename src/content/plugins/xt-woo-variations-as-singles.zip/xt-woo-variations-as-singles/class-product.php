<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    XT_WOOVAS
 * @subpackage XT_WOOVAS/Product_Admin
 * @author     XplodedThemes
 */
class XT_WOOVAS_Product
{

    /**
     * Core class reference.
     *
     * @since    1.0.0
     * @access   private
     * @var      XT_WOOVAS $core Core Class
     */
    protected $core;

    /**
     * Initialize the class and set its properties.
     *
     * @param XT_WOOVAS $core Plugin core class.
     * @since    1.0.0
     */
    public function __construct(&$core)
    {
        $this->core = $core;

        if(is_admin() && $this->core->enabled()) {

            add_action( 'admin_enqueue_scripts',  array($this, 'product_edit_script'), 10, 1 );
            add_action( 'save_post', array( $this, 'on_product_save' ), 100, 1 );
            add_action( 'woocommerce_after_product_object_save', array($this, 'after_product_object_save'), 10, 1 );
            add_action( 'post_submitbox_misc_actions', array($this, 'product_data_visibility'), 20 );
        }

    }



    function product_edit_script( $hook ) {

        global $post;

        if ( $hook == 'post-new.php' || $hook == 'post.php' ) {
            if ( 'product' === $post->post_type ) {
                xtfw_enqueue_js('
                    $(document).on("change", ".xt_woovas_variable_override_global", function() {
                        var options = $(this).closest(".options_group").find(".xt_woovas-visibility-options");
                        if($(this).is(":checked")) {
                            options.removeClass("hidden");
                        }else{
                            options.addClass("hidden");
                        }
                    });
                ');
            }
        }
    }

    /**
     * On product save
     *
     * @param int $post_id
     */
    public function on_product_save( $post_id ) {

        if ( wp_is_post_revision( $post_id ) ) {
            return;
        }

        $post_type = get_post_type( $post_id );

        if ( $post_type != "product" ) {
            return;
        }

        $product = wc_get_product( $post_id );

        if ( ! $product || ! $product->is_type( 'variable' ) ) {
            return;
        }

        $this->update_children( $post_id );
        XT_WOOVAS_Helpers::delete_term_counts_transient();
    }

    /**
     * Update children.
     *
     * @param int $post_id
     */
    public function update_children( $post_id ) {

        $product = wc_get_product( $post_id );

        if ( !$product || !$product->is_type( 'variable' )) {
            return;
        }

        $children = $product->get_children();

        if(!empty($children)) {
            foreach ($children as $variation_id) {
                $this->core->product_variation->set_taxonomies($variation_id);
                $this->core->product_variation->update_title($variation_id);
            }
        }
    }

    /**
     * After a product is saved.
     *
     * @param WC_Product_Variable $product
     */
    public function after_product_object_save( $product ) {

        if(!is_object($product)) {
            $product = wc_get_product($product);
        }

        if ( ! $product->is_type( 'variable' ) ) {
            return;
        }

        $this->update_visibility( $product->get_id() );
        $this->set_attributes_to_children( $product );
    }

    /**
     * Assign any attributes "not used for variations" to variations.
     * This means they show up when filtered.
     *
     * @param WC_Product_Variable|int $product
     */
    public function set_attributes_to_children( $product ) {

        if ( is_numeric( $product ) ) {
            $product = wc_get_product( $product );
        }

        if ( ! $product->is_type( 'variable' ) ) {
            return;
        }

        $variations = $product->get_children();

        if ( empty( $variations ) ) {
            return;
        }

        foreach ( $variations as $i => $variation_id ) {
            $this->core->product_variation->remove_unused_attributes( $variation_id, $product );

            // Assign all attributes from parent to child when child has "any" attribute value.
            $this->core->product_variation->apply__any__attribute( $variation_id, $product );
        }

        $attributes = $product->get_attributes();

        if ( empty( $attributes ) ) {
            return;
        }

        $product_id = $product->get_id();

        // Remove "non variation" attributes from variations when removed from parent.
        foreach ( $attributes as $taxonomy => $attribute_data ) {
            if ( $attribute_data['is_variation'] ) {
                continue;
            }

            $terms = wp_get_post_terms( $product_id, $taxonomy );

            if ( empty( $terms ) || is_wp_error( $terms ) ) {
                continue;
            }

            foreach ( $variations as $i => $variation_id ) {
                $term_ids = array();

                foreach ( $terms as $term ) {
                    $term_ids[] = $term->term_id;
                }

                wp_set_object_terms( $variation_id, $term_ids, $taxonomy );

                XT_WOOVAS_Helpers::delete_count_transient( $taxonomy, $terms[0]->term_taxonomy_id );
            }
        }

    }

    /**
     * On update visibility.
     *
     * @param int $product_id
     */
    public function update_visibility( $product_id ) {
        if ( version_compare( WC_VERSION, '3.0.0', '<' ) ) {
            return;
        }

        $ajax_action = $this->core->ajax()->get_ajax_action('process_product_visibility');

        $save = filter_input( INPUT_POST, 'save' );
        $action = filter_input( INPUT_POST, 'action' );

        if ( $save !== __( 'Update' ) && $action !== $ajax_action ) {
            return;
        }

        $product = wc_get_product( $product_id );

        if ( ! $product ) {
            return;
        }

        $visibility            = $this->get_catalog_visibility( $product );
        $exclude_from_filtered = isset( $_POST['xt_woovas_exclude_from_filtered'] );
        $visibility_terms      = $this->get_visibility_term_slugs( $product->get_id() );

        if ( ( $exclude_from_filtered || $visibility === "hidden" ) ) {
            if ( ! in_array( "exclude-from-filtered", $visibility_terms ) ) {
                $visibility_terms[] = "exclude-from-filtered";
            }
        } else {
            // Only remove setting when saving a product, not
            // when running the "process product visibility" action.
            if ( $action !== $ajax_action) {
                $visibility_terms = XT_WOOVAS_Helpers::unset_item_by_value( $visibility_terms, "exclude-from-filtered" );
            }
        }

        if ( ! is_wp_error( wp_set_post_terms( $product->get_id(), $visibility_terms, 'product_visibility' ) ) ) {
            $visibility = $this->get_catalog_visibility( $product );
            do_action( 'woocommerce_product_set_visibility', $product->get_id(), $visibility );
        }
    }

    /**
     * Get catalog visibility.
     *
     * @param WC_Product $product
     *
     * @return string
     */
    public function get_catalog_visibility( $product ) {

        if ( method_exists( $product, 'get_catalog_visibility' ) ) {
            return $product->get_catalog_visibility();
        } else {
            return get_post_meta( $product->get_id(), '_visibility', true );
        }
    }

    /**
     * Get parent ID.
     *
     * @param WC_Product $product
     *
     * @return int
     */
    public function get_parent_id( $product ) {
        if ( method_exists( $product, 'get_parent_id' ) ) {
            return $product->get_parent_id();
        } else {
            return $product->get_parent();
        }
    }

    public function product_data_visibility() {

        global $post;

        if ( 'product' !== $post->post_type ) {
            return;
        }

        $visibility_terms = $this->get_visibility_term_slugs( $post->ID );
        $exclude_from_filtered = in_array( 'exclude-from-filtered', $visibility_terms );
        ?>
        <div class="misc-pub-section show_if_variable" style="display: none;">
            <input type="checkbox" name="xt_woovas_exclude_from_filtered" id="xt_woovas-exclude-from-filtered" <?php checked( $exclude_from_filtered ); ?> />
            <label for="xt_woovas-exclude-from-filtered"><?php esc_html_e( 'Exclude from filtered results', 'xt-woo-variations-as-singles' ); ?></label>
        </div>
        <?php
    }

    /**
     * Get visibility term slugs.
     *
     * @param int $product_id
     *
     * @return array
     */
    public function get_visibility_term_slugs( $product_id ) {
        
        $terms = wp_get_post_terms( $product_id, 'product_visibility' );

        return wp_list_pluck( $terms, 'slug' );
    }

}
