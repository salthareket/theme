<?php
if ( isset( $rocket_path ) ) {
	require_once $rocket_path . 'inc/Logger/HTMLFormatter.php';
}
