<?php
/**
 * Plugin Name: WooCommerce Variations URL
 * Description: Adds support for variation-specific URLs for WooCommerce product variations. Polylang compatible.
 * Author: Václav Greif (refactored)
 * Version: 1.1
 */

namespace WCVariationsUrl;

if ( ! defined( 'ABSPATH' ) ) exit;

final class Init {

    private static ?Init $inst = null;

    public static function instance(): Init {
        if ( self::$inst === null ) {
            self::$inst = new self();
        }
        return self::$inst;
    }

    private function __construct() {
        add_filter( 'woocommerce_dropdown_variation_attribute_options_args', [ $this, 'variation_dropdown_args' ] );
        add_action( 'init', [ $this, 'register_query_var' ], 1 );
        add_action( 'init', [ $this, 'add_rewrite_rules' ], 10 );
        add_action( 'wp_footer', [ $this, 'add_js_to_footer' ] );
    }

    /**
     * Register the query var early so WP recognises it.
     */
    public function register_query_var(): void {
        add_rewrite_tag( '%variation%', '([^&]+)' );
    }

    /**
     * Add rewrite rules for every active language slug.
     * Works with or without Polylang.
     */
    public function add_rewrite_rules(): void {
        $slugs = $this->get_product_slugs_all_langs();

        foreach ( $slugs as $slug ) {
            $slug = trim( $slug, '/' );
            if ( empty( $slug ) ) continue;

            add_rewrite_rule(
                '^' . preg_quote( $slug, '/' ) . '/([^/]+)/([^/]+)/?$',
                'index.php?product=$matches[1]&variation=$matches[2]',
                'top'
            );
        }
    }

    /**
     * Returns all product URL slugs across all Polylang languages.
     * Falls back to the default WC slug when Polylang is not active.
     *
     * @return string[]
     */
    private function get_product_slugs_all_langs(): array {
        $slugs = [];

        // Default slug from WC post type object
        $pt_obj = get_post_type_object( 'product' );
        $default_slug = ( $pt_obj && ! empty( $pt_obj->rewrite['slug'] ) )
            ? $pt_obj->rewrite['slug']
            : 'product';

        $slugs[] = $default_slug;

        // Polylang: collect slugs for every registered language
        if ( function_exists( 'pll_languages_list' ) ) {
            $languages = pll_languages_list( [ 'fields' => 'slug' ] );

            foreach ( $languages as $lang ) {
                // pll_get_post_type_slug returns the translated slug for a post type + language
                if ( function_exists( 'pll_get_post_type_slug' ) ) {
                    $translated_slug = pll_get_post_type_slug( 'product', $lang );
                    if ( ! empty( $translated_slug ) ) {
                        $slugs[] = $translated_slug;
                    }
                }
            }
        }

        return array_unique( array_filter( $slugs ) );
    }

    /**
     * Pre-select the correct variation attribute based on the URL segment.
     */
    public function variation_dropdown_args( array $args ): array {
        $url_string = get_query_var( 'variation' );
        if ( empty( $url_string ) ) return $args;

        $parsed = $this->parse_variation_string( $url_string );
        if ( empty( $parsed ) ) return $args;

        // Normalise attribute key: strip "pa_" prefix
        $attribute_key = strtolower( str_replace( 'pa_', '', $args['attribute'] ) );

        if ( array_key_exists( $attribute_key, $parsed ) ) {
            $args['selected'] = $parsed[ $attribute_key ];
        }

        return $args;
    }

    /**
     * Parse a variation URL segment like "color-red-size-xl" into
     * [ 'color' => 'red', 'size' => 'xl' ].
     *
     * Strategy: collect all known attribute slugs, then split on them.
     *
     * @return array<string,string>
     */
    private function parse_variation_string( string $url_string ): array {
        $result = [];

        // Build ordered list of known attribute slugs (longest first to avoid prefix collisions)
        $attribute_slugs = [];
        foreach ( wc_get_attribute_taxonomies() as $attr ) {
            $attribute_slugs[] = strtolower( $attr->attribute_name );
        }
        usort( $attribute_slugs, fn( $a, $b ) => strlen( $b ) - strlen( $a ) );

        if ( empty( $attribute_slugs ) ) return $result;

        // Build a regex that splits on known attribute slugs preceded by a dash (or start)
        $pattern = '/(?:^|-)(' . implode( '|', array_map( 'preg_quote', $attribute_slugs ) ) . ')-([^-].*?)(?=(?:-(?:' . implode( '|', array_map( 'preg_quote', $attribute_slugs ) ) . '))|$)/';

        if ( preg_match_all( $pattern, '-' . $url_string, $matches, PREG_SET_ORDER ) ) {
            foreach ( $matches as $match ) {
                $result[ $match[1] ] = rtrim( $match[2], '-' );
            }
        }

        return $result;
    }

    /**
     * Output JS in footer (only on single product pages).
     * Updates the browser URL when the user selects variation attributes.
     */
    public function add_js_to_footer(): void {
        if ( ! function_exists( 'is_product' ) || ! is_product() ) return;

        global $post;
        $product_url = trailingslashit( get_permalink( $post->ID ) );
        ?>
        <script>
        (function($) {
            var baseUrl = <?php echo wp_json_encode( $product_url ); ?>;

            function buildVariationUrl() {
                var parts   = [];
                var allSet  = true;

                $('.variations select').each(function() {
                    var val = $(this).val();
                    if ( val ) {
                        // strip "attribute_pa_" prefix → keep only the slug
                        var attrSlug = $(this).attr('name').replace('attribute_pa_', '').replace('attribute_', '');
                        parts.push( attrSlug + '-' + val );
                    } else {
                        allSet = false;
                    }
                });

                if ( allSet && parts.length ) {
                    return baseUrl + parts.join('-');
                }
                return baseUrl;
            }

            $(document).ready(function() {
                // Delegate: works even when WC re-renders the form
                $(document).on('change', '.variations select', function() {
                    history.replaceState( null, '', buildVariationUrl() );
                });

                // Also handle WC's found_variation / reset_data events
                $(document).on('found_variation', function() {
                    history.replaceState( null, '', buildVariationUrl() );
                });
                $(document).on('reset_data', function() {
                    history.replaceState( null, '', baseUrl );
                });
            });
        }(jQuery));
        </script>
        <?php
    }
}

Init::instance();
