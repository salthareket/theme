<?php
/*
Plugin Name: WooCommerce Variations URL
Description: Adds support for variation-specific URL's for WooCommerce product variations
Author: Václav Greif
Version: 1.0
Author URI: https://wp-programator.cz
*/

namespace WCVariationsUrl;

final class Init{
    /**
     * Call this method to get singleton
     *
     * @return Init
     */
    public static function Instance(){
        static $inst = null;
        if ($inst === null) {
            $inst = new Init();
        }
        return $inst;
    }

    /**
     * Private ctor so nobody else can instance it
     *
     */
    private function __construct(){
        $this->add_actions();
    }

    /**
     * Add actions
     */
    function add_actions() {
        add_filter('woocommerce_dropdown_variation_attribute_options_args',array($this,'variation_dropdown_args'));
        add_action('init', array($this,'add_rewrite_rules'));
        add_action('wp_head', array($this,'add_js_to_head'));

    }

    function variation_dropdown_args($args) {
        // Get the WooCommerce atts
        $attributes =  wc_get_attribute_taxonomies();
        $atts = [];
        foreach ($attributes as $attribute) {
            $atts[] = $attribute->attribute_name;
        }

        // Get the variations part of URL
        $url_string = get_query_var('variation');

        if ($url_string) {
            $array = [];
            preg_replace_callback(
                "/(\w++)(?>-(\w+-?(?(?!" . implode("|", $atts) . ")(?-1))*))/",
                function($matches) use (&$array) {
                    $array[$matches[1]] = rtrim($matches[2], '-');
                },
                $url_string
            );

            if (!empty($array)) {
                $attribute_key = str_replace('pa_','',$args['attribute']);

                if (array_key_exists($attribute_key,$array)) {
                    $args['selected'] = $array[$attribute_key];
                }
            }
        }

        return $args;
    }

    function add_rewrite_rules() {
        //add_rewrite_rule('^product/([^/]*)/([^/]*)/?','index.php?product=$matches[1]&variation=$matches[2]','top');
        // Polylang aktif mi?
        $is_polylang = function_exists('pll_the_languages');

        // Varsayılan slug 'product'
        $product_slug = 'product';

        if ( $is_polylang ) {
            // Aktif dilin slug'ı
            $current_lang = pll_current_language();

            // WooCommerce 'product' post type'ının dil çevirilerini al
            $product_slugs = get_option('polylang');
            if ( function_exists('pll_get_post_type_translations') ) {
                $translated = pll_get_post_type_translations('product');
                if ( isset($translated[$current_lang]) ) {
                    $product_post_type_obj = get_post_type_object($translated[$current_lang]);
                    if ( $product_post_type_obj && isset($product_post_type_obj->rewrite['slug']) ) {
                        $product_slug = $product_post_type_obj->rewrite['slug'];
                    }
                }
            }
        } else {
            // Eğer Polylang yoksa, varsayılan WooCommerce 'product' post type'ından al
            $product_post_type_obj = get_post_type_object('product');
            if ( $product_post_type_obj && isset($product_post_type_obj->rewrite['slug']) ) {
                $product_slug = $product_post_type_obj->rewrite['slug'];
            }
        }

        // Rewrite kuralını ekle
        add_rewrite_rule(
            '^' . $product_slug . '/([^/]*)/([^/]*)/?',
            'index.php?product=$matches[1]&variation=$matches[2]',
            'top'
        );

        // Query var eklenmeli
        add_rewrite_tag('%variation%', '([^&]+)');
    }

    function add_js_to_head() {
        if (!function_exists('is_product') || !is_product())
            return;

        global $post;
        ?>

        <script type="text/javascript">
            var productUrl = '<?php echo get_permalink($post->ID);?>';
            jQuery( document ).ready(function($) {
                setTimeout(
                    function() {
                        $('.variations select').on('change',function() {
                            var attributes = [];
                            var allAttributesSet = true;
                            $('.variations select').each(function() {
                                var value = $(this).val();
                                if (value) {
                                    attributes.push({
                                        id: $(this).attr('name'),
                                        value: value
                                    });
                                } else {
                                    allAttributesSet = false;
                                }
                            });
                            var attrs = "";
                            var url = "";
                            if (allAttributesSet) {
                                $.each(attributes,function(key, val) {
                                    var attributeSlug = val.id.replace('attribute_pa_','');
                                    attrs += attributeSlug + '-' + val.value;
                                    if($(this)[0] !== $(attributes).last()[0]) {
                                        attrs = attrs + '-';
                                    }
                                });
                                url = productUrl + attrs;
                                history.pushState(null, null, url);
                                //window.location.replace(url);
                            }else{
                                history.pushState(null, null, productUrl);
                                //window.location.replace(productUrl);
                            }
                        });

                    }, 1000
                )
            });
        </script>
    <?php }
}

Init::Instance();