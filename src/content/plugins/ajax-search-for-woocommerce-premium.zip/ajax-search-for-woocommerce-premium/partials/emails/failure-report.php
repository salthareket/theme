<?php
// Exit if accessed directly
if ( ! defined( 'DGWT_WCAS_FILE' ) ) {
	exit;
}
?>
	<!doctype html>
	<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>FiboSearch Index Failure Report</title>
		<style>
			@media only screen and (max-width: 620px) {
				table.body h1 {
					font-size: 28px !important;
					margin-bottom: 10px !important;
				}

				table.body p,
				table.body ul,
				table.body ol,
				table.body td,
				table.body span,
				table.body a {
					font-size: 16px !important;
				}

				table.body .wrapper,
				table.body .article {
					padding: 10px !important;
				}

				table.body .content {
					padding: 0 !important;
				}

				table.body .container {
					padding: 0 !important;
					width: 100% !important;
				}

				table.body .main {
					border-left-width: 0 !important;
					border-radius: 0 !important;
					border-right-width: 0 !important;
				}

				table.body .btn table {
					width: 100% !important;
				}

				table.body .btn a {
					width: 100% !important;
				}

				table.body .img-responsive {
					height: auto !important;
					max-width: 100% !important;
					width: auto !important;
				}
			}

			@media all {
				.ExternalClass {
					width: 100%;
				}

				.ExternalClass,
				.ExternalClass p,
				.ExternalClass span,
				.ExternalClass font,
				.ExternalClass td,
				.ExternalClass div {
					line-height: 100%;
				}

				.apple-link a {
					color: inherit !important;
					font-family: inherit !important;
					font-size: inherit !important;
					font-weight: inherit !important;
					line-height: inherit !important;
					text-decoration: none !important;
				}

				#MessageViewBody a {
					color: inherit;
					text-decoration: none;
					font-size: inherit;
					font-family: inherit;
					font-weight: inherit;
					line-height: inherit;
				}

				.btn-primary table td:hover {
					background-color: #34495e !important;
				}

				.btn-primary a:hover {
					background-color: #34495e !important;
					border-color: #34495e !important;
				}
			}
		</style>
	</head>
	<body
		style="background-color: #f6f6f6; font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; line-height: 1.4; margin: 0; padding: 0; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;">
	<table role="presentation" border="0" cellpadding="0" cellspacing="0" class="body"
		   style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #f6f6f6; width: 100%;"
		   width="100%" bgcolor="#f6f6f6">
		<tr>
			<td style="font-family: sans-serif; font-size: 14px; vertical-align: top;" valign="top">&nbsp;</td>
			<td class="container"
				style="font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 580px; padding: 10px; width: 580px; margin: 0 auto;"
				width="580" valign="top">
				<div class="content"
					 style="box-sizing: border-box; display: block; margin: 0 auto; max-width: 580px; padding: 10px;">

					<!-- START CENTERED WHITE CONTAINER -->
					<table role="presentation" class="main"
						   style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; background: #ffffff; border-radius: 3px; width: 100%;"
						   width="100%">

						<!-- START MAIN CONTENT AREA -->
						<tr>
							<td class="wrapper"
								style="font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 20px;"
								valign="top">
								<table role="presentation" border="0" cellpadding="0" cellspacing="0"
									   style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;"
									   width="100%">
									<tr>
										<td style="font-family: sans-serif; font-size: 14px; vertical-align: top;"
											valign="top">
											<p style="font-family: sans-serif; font-size: 18px; font-weight: normal; margin: 0; margin-bottom: 15px;">
												The search index could not be built!</p>
											<p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; margin-bottom: 15px;">
												<strong>Last indexer error:</strong></p>
											<table role="presentation" border="0" cellpadding="0" cellspacing="0"
												   style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto; margin-bottom: 15px;">
												<tbody>
												<tr>
													<td style="font-family: monospace; font-size: 12px; vertical-align: top; text-align: left; background-color: #f5dede; border: 1px solid #f0c0c1; padding: 10px; word-break: break-word;"
														valign="top" align="left" bgcolor="#f5dede">
														<code
															style="font-family: monospace; font-size: 12px; vertical-align: top; text-align: left;">
															<?php echo esc_html( $data['last_error_message'] ); ?>
														</code>
													</td>
												</tr>
												</tbody>
											</table>
											<?php foreach ( $data['tables'] as $table ) { ?>
												<p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; margin-bottom: 10px;">
													<strong><?php echo esc_html( $table['header'] ); ?></strong></p>
												<table role="presentation" border="1" cellpadding="0" cellspacing="0"
													   style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; border: 1px solid #e5e5e5; margin-bottom: 10px;">
													<tbody>
													<?php foreach ( $table['rows'] as $row ) { ?>
														<tr>
															<td style="width: 50%; font-family: sans-serif; font-size: 14px; vertical-align: top; border: 1px solid #e5e5e5; padding: 10px; text-align: left;">
																<?php echo esc_html( $row['label'] ); ?>
															</td>
															<td style="width: 50%; font-family: sans-serif; font-size: 14px; vertical-align: top; border: 1px solid #e5e5e5; padding: 10px; text-align: left;">
																<?php echo esc_html( $row['value'] ); ?>
															</td>
														</tr>
													<?php } ?>
													</tbody>
												</table>
											<?php } ?>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<!-- END MAIN CONTENT AREA -->
					</table>
					<!-- END CENTERED WHITE CONTAINER -->

					<!-- START FOOTER -->
					<!-- END FOOTER -->
				</div>
			</td>
			<td style="font-family: sans-serif; font-size: 14px; vertical-align: top;" valign="top">&nbsp;</td>
		</tr>
	</table>
	</body>
	</html>
<?php
