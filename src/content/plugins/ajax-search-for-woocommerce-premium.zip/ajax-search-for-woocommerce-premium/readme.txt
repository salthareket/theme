=== FiboSearch - Ajax Search for WooCommerce  ===
Contributors: damian-gora, matczar
Tags: woocommerce search, ajax search, search by sku, product search, woocommerce
Requires at least: 5.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.30.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The most popular WooCommerce product search plugin. Gives your users a well-designed advanced AJAX search bar with live search suggestions.

== Description ==

The most popular **WooCommerce product search plugin**. It gives your users a well-designed advanced AJAX search bar with live search suggestions.

By default, WooCommerce provides a very simple search solution, without live product search or even SKU search. FiboSearch (formerly Ajax Search for WooCommerce) provides advanced search with live suggestions.

Who doesn’t love instant, as-you-type suggestions? In 2023, customers expect smart product search. Baymard Institute’s latest UX research reveals that search autocomplete, auto-suggest, or an instant search feature **is now offered on 96% of major e-commerce sites**. It's a must-have feature for every online business that can’t afford to lose customers. Why? FiboSearch helps users save time and makes shopping easier. As a result, Fibo really boosts sales.

= Features =
&#9989; **Search by product title, long and short description**
&#9989; **Search by SKU**
&#9989; Show **product image** in live search results
&#9989; Show **product price** in live search results
&#9989; Show **product description** in live search results
&#9989; Show **SKU** in live search results
&#9989; **Mobile first** – special mobile search mode for better UX
&#9989; **Details panels** with extended information – **“add to cart” button** with a **quantity field** and **extended product** data displayed on hovering over the live suggestion
&#9989; **Easy implementation** in your theme - embed the plugin using a **shortcode**, as a **menu item** or as a **widget**
&#9989; **Terms search** – search for product categories and tags
&#9989; **Search history** – the current search history is presented when the user clicked/taped on the search bar, but hasn't yet typed the query.
&#9989; **Limit** displayed suggestions – the number is customizable
&#9989; **The minimum number of characters** required to display suggestions – the number is customizable
&#9989; **Better ordering** – a smart algorithm ensures that the displayed results are as accurate as possible
&#9989; **Support for WooCommerce search results page** - after typing enter, users get the same results as in FiboSearch bar
&#9989; **Grouping instant search results by type** – displaying e.g. first matching categories, then matching products
&#9989; **Google Analytics** support
&#9989; Multilingual support including **WPML**, **Polylang** and **qTranslate-XT**
&#9989; **Personalization** of search bar and autocomplete suggestions - labels, colors, preloader, image and more

= Try the PRO version =
FiboSearch also comes in a Pro version, with a modern, inverted index-based search engine. FiboSearch Pro works up to **10× faster** than the Free version or other popular search solutions for WooCommerce.

[Upgrade to PRO and boost your sales!](https://fibosearch.com/pricing/?utm_source=readme&utm_medium=referral&utm_content=pricing&utm_campaign=asfw)

= PRO features =

&#9989; **Ultra-fast search engine** based on the inverted index – works very fast, even with 100,000+ products
&#9989; **Fuzzy search** – works even with minor typos
&#9989; **Search in custom fields** with dedicated support for ACF
&#9989; **Search in attributes**
&#9989; **Search in categories**. Supports category thumbnails.
&#9989; **Search in tags**
&#9989; **Search in brands** (We support WooCommerce Brands, Perfect Brands for WooCommerce, Brands for WooCommerce, YITH WooCommerce Brands). Supports brand thumbnails.
&#9989; **Search by variation product SKU** – also shows variable products in live search after typing in the exact matching SKU
&#9989; **Search for posts** – also shows matching posts in live search
&#9989; **Search for pages** – also shows matching posts in live search
&#9989; **Synonyms**
&#9989; **Conditional exclusion of products**
&#9989; **TranslatePress** compatible
&#9989; Professional and fast **help with embedding** or replacing the search bar in your theme
&#9989; and more...
&#9989; SEE ALL PRO [FEATURES](https://fibosearch.com/pro-vs-free/?utm_source=readme&utm_medium=referral&utm_content=features&utm_campaign=asfw)!

= Showcase =
See how it works for others: [Showcase](https://fibosearch.com/showcase/?utm_source=readme&utm_medium=referral&utm_campaign=asfw&utm_content=showcase&utm_gen=utmdc).

= Feedback =
Any suggestions or comments are welcome. Feel free to contact us via the [contact form](https://fibosearch.com/contact/?utm_source=readme&utm_medium=referral&utm_campaign=asfw&utm_content=contact&utm_gen=utmdc).

== Installation ==

1. Install the plugin from within the Dashboard or upload the directory `ajax-search-for-woocommerce` and all its contents to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to `WooCommerce → FiboSearch` and set your preferences.
4. Embed the search bar in your theme.

== Frequently Asked Questions ==

= How do I embed the search bar in my theme? =
There are many easy ways to display the FiboSearch bar in your theme:

– **Replacing the existing search bar with one click** - it is possible for dozens of popular themes
– **As a menu item** - in your WordPress admin panel, go to `Appearance → Menu` and add `FiboSearch bar` as a menu item
– **Using a shortcode**

`[fibosearch]`

– **As a widget** - in your WordPress admin panel, go to `Appearance → Widgets` and choose `FiboSearch`
– **As a block** - [learn how to use blocks](https://fibosearch.com/documentation/get-started/how-to-add-fibosearch-to-your-website/#add-fibosearch-with-the-dedicated-fibosearch-block) and FiboSearch together
– **Using PHP**

`<?php echo do_shortcode('[fibosearch]'); ?>`

– **We will do it for you!** - we offer free search bar implementation for Pro users. Become one now!

Or insert this function inside a PHP file (often, it is used to insert a form inside page template files):

= How do I replace the existing search bar in my theme with FiboSearch? =
We have prepared a one-click replacement of the search bar for the following themes:

*  Storefront
*  Divi
*  Flatsome
*  OceanWP
*  Astra
*  Avada
*  Sailent
*  and 46 more... See a complete list of integrated themes on [our documentation](https://fibosearch.com/documentation/themes-integrations/?utm_source=readme&utm_medium=referral&utm_campaign=asfw&utm_content=theme-integrations).


If you want to replace your search bar in another theme, please [contact our support team](https://fibosearch.com/contact/?utm_source=readme&utm_medium=referral&utm_campaign=asfw&utm_content=contact&utm_gen=utmdc).
We will assist with replacing the search bar in your theme for free after you upgrade to the Pro version.

= Can I add the search bar as a WordPress menu item? =
**Yes, you can!** Go to `Appearance → Menu`. You will see a new menu item called “FiboSearch”. Select it and click “Add to menu”. Done!

= How can I ask a question? =
You can submit a ticket on the plugin [website](https://fibosearch.com/contact/?utm_source=readme&utm_medium=referral&utm_campaign=asfw&utm_content=contact&utm_gen=utmdc) and the support team will get in touch with you shortly. We also answer questions on the [WordPress Support Forum](https://wordpress.org/support/plugin/ajax-search-for-woocommerce/).

= Do you offer customization support? =
Depending on the theme you use, sometimes the search bar requires minor improvements in appearance. We guarantee fast CSS corrections for all Pro plugin users, but we also help Free plugin users.

= Where can I find plugin settings? =
In your WordPress dashboard, go to `WooCommerce → FiboSearch`. The FiboSearch settings page is a submenu of the WooCommerce menu.

= Who is the Pro plugin version for? =
The Pro plugin version is for all online sellers looking to **increase sales** by providing an ultra-fast smart search engine to their clients.

The main difference between the Pro and Free versions is search speed and search scope. The Pro version has a new fast smart search engine. For some online stores that offer a lot of products for sale, search speed can be increased **up to 10×**, providing a whole new experience to end users.

All in all, the Pro version is dedicated to all WooCommerce shops where autocomplete suggestions work too slowly.

You can read more and compare Pro and Free features here: [Full comparison - Pro vs Free](https://fibosearch.com/pro-vs-free/).

== Screenshots ==

1. Search suggestions with a details panel
2. Search suggestions
3. Search suggestions with a details panel
4. Search suggestions (Pirx search style)
5. Search suggestions (Pirx compact search style)
6. Sample settings page (Starting tab)
7. Sample settings page (Search bar tab)
8. Sample settings page (Autocomplete tab)
9. Sample settings page (Search Analytics tab)

== Changelog ==


= 1.30.1, January 29, 2025 =
* FIXED: Errors related to index rebuilding. In some cases, the index rebuild failed, requiring a manual rebuild to complete the process
* FIXED: There was an error in the SQL syntax that occurred during the plugin uninstallation process


= 1.30.0, January 27, 2025 =
* ADDED: Ability to search in **[custom post types](https://fibosearch.com/documentation/features/searching-for-custom-post-types/)**
* ADDED: Troubleshooting – add a test for slow querying of searchable custom fields and provide the ability to disable this query
* ADDED: Search in “**[Global Unique Identifier](https://fibosearch.com/documentation/features/searching-by-gtin-upc-ean-or-isbn/)**” (GTIN, UPC, EAN or ISBN)
* ADDED: New “**meta**” field in index for taxonomy terms
* ADDED: “**Bricks theme**” integration – support for “Products” element on the search results page
* ADDED: “**Bricks theme**” integration – incorrect order of results on the search results page
* ADDED: Integration with the “**Discontinued Product Stock Status for WooCommerce**” plugin
* ADDED: The link to edit the FiboSearch bar in Customizer
* ADDED: The `x` button was added to the review request notice
* FIXED: Missing data in the “**Details Panel**” for product variations
* FIXED: Resolved an error when attempting to insert FiboSearch blocks in the block editor
* FIXED: Eliminated duplicate search results in autocomplete
* FIXED: Enabled searching for products whose variations are all out of stock but have the “**allow backorders**” status 
* FIXED: **WCAG** “Links do not have a discernible name”
* FIXED: **WPML** integration – no results when option "use translation if available or fallback to default language" is used
* FIXED: **Flatsome** theme integration – can't search in mobile overlay view when search is activated from the mobile menu
* FIXED: Incorrect display of the FiboSearch form when it is embedded in the shop page description
* FIXED: Mobile search in the menu does not work when the Divi Mobile plugin is active
* FIXED: Unnecessary header “Search results for...” when there are no results for post types other than products
* FIXED: Google PageSpeed Insights – avoid non-composited animations
* FIXED: Search icon padding when the search icon is a part of the main menu
* FIXED: Index build error caused by a long SKU
* FIXED: Unable to search for a variation as a single product when searching by its attributes
* FIXED: Duplicate search results in autocomplete (active duplicate removal)
* TWEAK: Include variations with a zero price by default
* TWEAK: Navigate to the first variation from the results on submit only when exact SKU matching is active
* TWEAK: Cleaning up after refactoring of product variations indexing
* TWEAK: Theme integration is not loaded when the minimal version condition is not met
* TWEAK: Improved clearing of plugin data on uninstall
* TWEAK: Hiding unwanted banner on the settings page
* TWEAK: Remove the “**(beta)**” suffix from the “User search history” option
* REFACTOR: Remove the “**Grouped results**” option
* UPDATED: The `.pot` file
* UPDATED: Freemius SDK

= 1.29.0, October 29, 2024 =
* ADDED: Integration with the **Listeo theme**
* ADDED: New troubleshooting test – warning when “**Ajax Search Lite**” or “**Ajax Search Pro**” plugins are active
* ADDED: **WCAG improvements** – possibility to select and open a search icon using the keyboard
* ADDED: Search icon preloader. In some rare cases, a user can wait longer to display the search icon or search bar. Instead of an empty place, a placeholder is displayed
* ADDED: Improved variations indexing for variable products
* ADDED: Integration with “**WooCommerce Show Single Variations**” by Iconic plugin
* ADDED: Support for brands feature included in WooCommerce core since v9.4
* ADDED: Debug page – ability to debug taxonomy terms in the search index
* ADDED: Filter to change the character map when converting Greeklish to Latin
* FIXED: **Generatepress theme** integration – incorrect mobile overlay on the checkout in the Generatepress theme
* FIXED: A better way of calculating window width when the breakpoint is checked
* FIXED: **WPML** plugin integration – incorrect translations of variations
* FIXED: Skip indexing variable products (parent) if no variations are available
* FIXED: **MultiVendorX** – missing vendors when an index is built on schedule or via WP-CLI
* TWEAK: Hiding the **XStore** theme documentation button on the settings page
* UPDATED: The `.pot` file.
* UPDATED: Freemius SDK

= 1.28.1, June 28, 2024 =
* FIXED: Removed the phrase “**polyfill.io**” from the JavaScript code comment. FiboSearch has never linked to this compromised library, but some security tools recognize this JavaScript comment as a potential link to malware. All reports are **false positive**.
* FIXED: PHP deprecated notice in `\DgoraWcas\Helpers::keyIsValid`
* FIXED: Unnecessary display of warning in **Troubleshooting** when products are displayed using a widget from “**JetSmartFilters**”

= 1.28.0, May 27, 2024 =
* ADDED: New search bar style - a compact version of a “Pirx” style
* ADDED: Integration with the “Cartzilla theme”
* ADDED: Integration with the “Rey theme”
* ADDED: Placeholders to display custom content for new suggestion types like taxonomy, posts, pages, and product variation
* ADDED: Multilingual - allowing longer language codes (or slugs in TranslatePress)
* ADDED: TranslatePress - possibility to skip product translation
* ADDED: Allowing indexing of variants that have zero price
* ADDED: Debugger - catalog visibility and stock status checker
* ADDED: Debugger - products visibility checker
* ADDED: Possibility to generate product data variants in the index without spaces
* FIXED: “Woodmart theme” - unable to close the mobile menu after exiting the mobile search overlay
* FIXED: “Flatsome theme” - disappearing search bar on mobile phones
* FIXED: “Flatsome” - cannot change search bar style to Pirx
* FIXED: “Divi theme” - shortcodes are not rendered in the description in the Details Panel for pages
* FIXED: “XStore theme” - the integration doesn't replace all search forms
* FIXED: Force disabling transition effect on search input to avoid unexpected layout bouncing
* FIXED: Allowing to calculate score including one and two-character words
* FIXED: Better recognition of iOS
* FIXED: Uncode theme - the search icon doesn't show on the header
* FIXED: Indexing error due to too long HTML prices of variations
* FIXED: Indexing error when product attribute is empty
* FIXED: No results with “WPML” and “WooCommerce Wholesale Prices” plugins
* FIXED: Incorrect comparison in the tokenizer. Make stopwords lowercase in the tokenizer before calling `array_diff`
* FIXED: Possibility to pass the language when debugging the product in the index
* TWEAK: Removed OPcache invalidation for the shortcode template file
* TWEAK: Reverting test in Troubleshooting module for newer versions of “HUSKY - Products Filter Professional for WooCommerce” plugin
* UPDATED: The .pot file
* UPDATED: Freemius SDK to v2.7.2

= 1.27.1, February 01, 2024 =
* FIXED: “B2BKing plugin” - better support for searching in terms

= 1.27.0, January 31, 2024 =
* ADDED: Integration with the “Betheme theme”
* ADDED: Highlight words in search results with Greek letters regardless of accent
* ADDED: Support for “Full-width Search” in the “XStore theme”
* FIXED: Multiple search containers on mobile in the “Astra theme” integration
* FIXED: No focus on search input for mobile devices in the “Astra theme” integration
* FIXED: Allow an HTML `&lt;i&gt;` tag in suggestion titles and headlines
* FIXED: Multilingual support is active even for one language
* FIXED: Overriding the search icon and form in the header was not working properly in the “WoodMart integration”
* FIXED: Missing filters from “Advanced AJAX Product Filters” plugin in the “Divi theme”
* FIXED: Replace `&#37` for more stable format `%%` in a `sprintf` function
* FIXED: An unwanted modal after closing the search overlay on mobile in the “Flatsome theme”
* FIXED: Missing colors after updating the “Bloksy theme” to 2.x
* FIXED: Incorrect calculation of a product's position in search results when it contains Greek letters
* FIXED: Incorrect term language detection in the WPML plugin. Replacing `term_id` with `term_taxonomy_id`
* FIXED: Unwanted ampersand entity in the product description of search results
* FIXED: No search results in Turkish when the phrase starts with a capital dotted `i`
* FIXED: No results when the search phrase contains Latin and Greek letters
* FIXED: Typo in an HTML class name related to variations
* FIXED: The search index could not be built due to a missing table in some rare cases
* FIXED: Missing vendor image in search results in the “MultivendorX plugin”
* FIXED: Disappearing filters in the “JetSmartFilters plugin”
* FIXED: PHP warning when using the Elementor widget “FiboSearch Posts Search Results”
* FIXED: Visible products and categories against the rules in the category view in the Details Panel in the “B2BKing plugin”
* FIXED: A fatal error when we return no results for a custom post using a filter
* FIXED: Don't save `html_price` in the readable index when dynamic prices are enabled
* TWEAK: Do not run the search engine on the search page when the phrase is empty
* REFACTOR: Improved index structure creation (better error detection)
* REFACTOR: Integrations related to hiding products - storing product IDs using Transient API instead of PHP sessions
* UPDATED: Requires PHP: 7.4
* UPDATED: The `.pot` file
* UPDATED: Polish translation
* UPDATED: Freemius SDK v2.6.2

= 1.26.1, October 19, 2023 =
* FIXED: Details panel - wrong HTML format of stock status element 

= 1.26.0, October 17, 2023 =
* ADDED: Integration with “Bricks builder”
* ADDED: Integration with “Brizy builder”
* ADDED: Improved Greeklish support
* ADDED: Automatic disabling of the mechanism for blocking data writing to the database when it is not supported by the server
* FIXED: Calc score by comparing every word of the search phrase instead of all search phrase
* FIXED: WooCommerce Wholesale Prices plugin - invalid search results e.g. not hidden products and categories in the search results
* FIXED: Flatsome - when there are more search icons, only one is replaced
* FIXED: WPRocket - in some cases search fields/icons are not replaced immediately after the page load
* FIXED: Highlight matched words instead of the whole search phrase
* FIXED: WooCommerceB2B by Addify - remove undefined function
* FIXED: Error while viewing the index build failure report
* FIXED: Index build fails due to missing `getmypid()` function call
* FIXED: TranslatePress - excluding products by category causes the index to be empty
* FIXED: qTranslate-XT - excluding products by category causes the index to be empty
* FIXED: TranslatePress - untranslated product title when it contains a hyphen
* FIXED: B2BKing - no results when the WPML plugin is also active
* FIXED: Wrong variation URLs when WPML is active
* FIXED: The index does not build when the product image URL is in the wrong format
* FIXED: Table missing error when editing/deleting taxonomy term (multilingual sites only)
* FIXED: JetSmartFilters plugin filter values disappear on the search results page when the TranslatePress plugin is active
* TWEAK: Allowing access to the `Personalization` class via `DGWT_WCAS()` function
* TWEAK: HUSKY - Products Filter Professional for WooCommerce plugin - disable the test in the Troubleshooting module for newer versions of this plugin
* TWEAK: Search speed optimization
* TWEAK: Support for language codes like `xx_XX`
* REFACTOR: Replace `.click()` with `trigger('click')`, `.focus()` with `trigger('focus')`, `.blur()` with `trigger('blur')`
* REFACTOR: Replace `jQuery.fn.mouseup()` with `$(document).on('mouseup')`
* REFACTOR: Replace `jQuery.isFunction()` with `typeof fn === 'function'`
* UPDATED: Freemius SDK v2.5.12

= 1.25.0, July 06, 2023 =
* ADDED: Possibility to search for taxonomy terms regardless of accents in a phrase or term name
* ADDED: Added some new filters to change URLs of results in autocomplete and details panel
* ADDED: Compatibility with 5.x of the “WooCommerce Visibility” plugin
* ADDED: Shortcode to display search results for post types
* ADDED: Indexing images for other post types than product
* ADDED: Integration with “WooCommerceB2B” by Addify
* ADDED: Integration with “WooCommerce B2B plugin” by Code4Life
* ADDED: Stopping the search after detecting an illegal phrase
* ADDED: Troubleshooting - warning against limiting the length of database queries in the “WP Engine” environment
* FIXED: Warnings due to `open_basedir` restrictions
* FIXED: Integration with the Impreza theme - broken AJAX pagination for Grid element
* FIXED: Integration with the TheGem theme - missing search results when the “Layout Type” option is set to “Products Grid”
* FIXED: Integration with the Divi theme - mobile overlay not showing up
* FIXED: Stronger sanitization of the details panel output
* FIXED: Indexer error due to too invalid cookie
* FIXED: Elementor - no image height alignment in the “FiboSearch Posts Search Results” widget
* FIXED: Support for dynamic prices for the plugin “YITH Multi Currency Switcher for WooCommerce”
* TWEAK: New filter to manipulate a term output
* TWEAK: Improved recognition if the “B2BKing plugin” is active (under SHORTINIT mode)
* TWEAK: `DGWT_WCAS()->searchPosts()` returns empty results if index was invalid
* UPDATED: Freemius SDK v2.5.10
* UPDATED: Polish translation

= 1.24.0, May 25, 2023 =
* ADDED: Integration with the “Minimog” theme
* ADDED: Posts, pages, and taxonomy terms are included in the FiboSearch Analytics module
* ADDED: Taking into account a new feature of the dark theme in the Nave theme
* ADDED: Possibility to change the color of a search bar underlay. Only for the Pirx style
* ADDED: New search widget and extended search results for Elementor
* ADDED: TheGem theme - “Header Builder” support
* ADDED: Searching interface usable from within PHP
* FIXED: Wrong position of search icons in the history search module
* FIXED: Broken suggestions layout and detailed panel visibility when the “Minimum characters” option is set to less than 1
* FIXED: Compatibility with PHP 8.1
* FIXED: Hide unnecessary modules when constant `DGWT_WCAS_ANALYTICS_ONLY_CRITICAL` is set to true in the FiboSearch Analytics module
* FIXED: Incorrect display of information about constants on the debug page
* FIXED: Other minor bugs in the FiboSearch Analytics module
* FIXED: Integration with the Astra theme - support for version 4.1.0 of the Astra Addon
* FIXED: Integration with the Minimog theme - wrong position of the search history wrapper
* FIXED: Integration with the Enfold theme - the search engine icon disappears when the page finishes loading
* FIXED: A HTML tag `<br>` was unnecessarily stripped in the description in the details panel
* FIXED: The voice search feature - overlapping icons and disabling functionality on Safari
* FIXED: Broken integrations with filter plugins when “home_url” was empty
* FIXED: Incorrect log file in failed index build reports
* FIXED: Index build failed because of a missing wp_cache_flush_group() function
* FIXED: Indexer error “[Searchable index] Database error “Duplicate entry '16777215'...”
* FIXED: Indexer error because a column was too short in the database
* FIXED: Uncode theme - incorrect results on the search results page
* FIXED: Slow index building when the TranslatePress plugin is active
* FIXED: PHP exceptions were thrown from the Redis Object Cache plugin and it stopped the indexer-building process
* TWEAK: New filter to manipulate taxonomy term data that are indexed
* UPDATED: French translation
* UPDATED: Freemius SDK v2.5.8
* TESTS: Two integration tests that check saving phrases in a database table
* TESTS: Fix assertion in “Analytics/Critical searches without result”
* REFACTOR: Change order if set settings defaults. Now the defaults are set after calling the `dgwt/wcas/settings` filter
* SECURITY: Added escaping for a “Search input placeholder” option

= 1.23.0, April 05, 2023 =
* ADDED: Integration with the “Blocksy” theme
* ADDED: Integration with the “Qwery” theme
* ADDED: Integration with the “StoreBiz” theme
* ADDED: Allows the `Shop manager` role to manage the plugin settings by adding a constant to the `wp.config.php` file
* ADDED: Allows creating HTML templates instead of displaying simple “No results” message
* ADDED: Ability to search using “Greeklish” for Greek
* ADDED: Fuzzy search, synonyms, and other pro features available in searching for taxonomy terms.
* IMPROVED: Blocks calculating score if the phrase contains a single character
* FIXED: More accurate calculation of the order of products in search results. The extra score for an exact match of a sequence of words
* FIXED: Storefront theme - not working focus event while using a mobile overlay for iPhone devices
* FIXED: Mobile overlay on iPhone devices - didn't hide search results on a scroll event or after clicking the “done” button
* FIXED: iPhone devices - annoying auto zoom in search input on focus
* FIXED: Search icon mode and search history - a search bar was needlessly concealed on clicking the “Clear” button
* FIXED: Freemius SDK - added submenu slug
* FIXED: Flatsome theme - detecting incompatible settings and disappearing search form on hover
* FIXED: Layout option - hidden triangle icon when a layout is “icon” and style is “Pirx”
* FIXED: Unnecessary AJAX query on the settings page
* FIXED: Disabling the search cache using a PHP constant didn't completely disable it. Now it disables it completely
* FIXED: `Table doesn't exist` error during index building in some rare cases
* FIXED: Incorrect product links in search results with the “Permalink Manager for WooCommerce” plugin active
* FIXED: TranslatePress and qTranslate-XT - untranslated breadcrumbs in category results
* TWEAK: Replacing empty href tag with `#` in Storefront integration because of SEO
* TWEAK: Trivial CSS changes
* TWEAK: Ability to disable the mutex mechanism during indexing
* TWEAK: Multilingual - supporting language codes up to 10 characters
* UPDATED: Freemius SDK to v2.5.6
* UPDATED: Polish translation
* REFACTOR: Forcing mobile overlay breakpoint and in layout breakpoint in theme integrations
* REFACTOR: Variables names in the method `Helpers::calcScore()`

= 1.22.3, January 30, 2023 =
* FIXED: Some prices were not aligned properly

= 1.22.0, January 30, 2023 =
* ADDED: New feature - Search history. The current search history is presented when the user clicked/taped on the search bar, but hasn't yet typed the query.
* ADDED: FiboSearch Analytics - New widget in WordPress Dashboard with critical searches without result
* ADDED: Integration with Essentials theme
* ADDED: Make UI_FIXER object as global object
* ADDED: Ability to search for vendors by description and city
* ADDED: Ability to exclude critical phrases in the Analytics module
* ADDED: Custom JavaScript events during the search process
* ADDED: Ability to export search analytics data as CSV files
* FIXED: Integration with Flatsome theme - focus event didn't work with a search bar
* FIXED: Integration with WooCommerce Product Filter by WooBeWoo - “Undefined array key 'query'” notice
* FIXED: Integration with Jet Smart Menu - repair duplicated search bars IDs
* FIXED: Integration with Astra theme - support for version 4.0.0
* FIXED: Integration with Astra theme - cannot change the number of products on the cart page
* FIXED: Integration with XStore theme - support for search icon in mobile panel
* FIXED: Compatibility with PHP 8.1
* FIXED: RWD for FiboSearch Settings views including Analytics views
* FIXED: Search bar CSS, especially when Pirx style and Voice Search work together
* FIXED: A user with permission to edit plugin settings cannot see search analytics
* FIXED: Pages can not be searched when the database prefix is empty
* FIXED: Improved compatibility with other plugins on the search results page
* FIXED: Broken index when there are many variants. Speed up getting variants when building an index
* CHANGE: Updated French translation
* CHANGE: Hide the Voice Search icon when a user starts typing
* CHANGE: Updated Freemius SDK to v2.5.3
* CHANGE: Remove information that Analytics is a beta feature
* CHANGE: Remove information that Darkened Background is a beta feature
* CHANGE: Set "Pirx" as a default search bar style


= 1.21.1, November 24, 2022 =
* FIXED: Multisite: search does not work when the plugin is activated on a network-wide level
* FIXED: Rare database error “Duplicate entry...” error when building search index

= 1.21.0, November 21, 2022 =
* ADDED: Integration with Product GTIN (EAN, UPC, ISBN) for WooCommerce plugin
* ADDED: Integration with EAN for WooCommerce plugin
* ADDED: Troubleshooting - checks if products thumbnails need to be regenerated
* ADDED: Optional consent to submit bug reports when installing the plugin
* FIXED: Missing translation domain in some texts
* FIXED: Support variants of &lt;br&gt; tag in product names in autocomplete
* FIXED: Unable to embed search bar as a widget
* FIXED: Disable voice search for Chrome on iPhone or iPad
* FIXED: Integration with the Astra theme - unclosed  &lt;div&gt; tag
* FIXED: Exclude save phrases to analyze when the phrase is 'fibotests' or the user has a specific role.
* FIXED: UI_FIXER: check if event listeners were correctly added to search inputs. If no, reinitiate the search instance
* FIXED: UI_FIXER: rebuild all search bars without correct JS events
* FIXED: Redundant DB queries related to the existence of plugin tables
* FIXED: Database error while updating or deleting product category
* FIXED: “Warning: strpos(): Empty needle” when there is a no “s” parameter (free version)
* FIXED: Can't get terms in the "Exclude/include products" option
* FIXED: Unnecessary secondary connection with a database in the indexer
* FIXED: MySQL deadlock errors during index building
* FIXED: Integration with Booster Plus for WooCommerce - error during index building
* FIXED: The endpoint of the search engine responds when the plugin is disabled
* FIXED: Not indexing custom fields - this fixes an issue that occurred after integrating FiboSearch with some EAN-related plugins
* FIXED: Double results in the autocomplete
* FIXED: The index cannot be rebuilt with an empty DB prefix
* FIXED: Invalid index status even though the index was built correctly
* FIXED: Push the index-building process further after updating the plugin. The index wasn't started in many cases
* FIXED: Integration with WC Marketplace stopped working after it was rebranded to MultiVendorX
* CHANGE: Updated Freemius SDK to v2.5.2

[See changelog for all versions](https://fibosearch.com/changelog/).
