<?php
/**
 * Polylang Pro
 *
 * @package           Polylang-Pro
 * @author            WP SYNTEX
 * @license           GPL-3.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name:       Polylang Pro
 * Plugin URI:        https://polylang.pro
 * Description:       Adds multilingual capability to WordPress
 * Version:           3.8.4
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Author:            WP SYNTEX
 * Author URI:        https://polylang.pro
 * Text Domain:       polylang-pro
 * License:           GPL v3 or later
 * License URI:       https://www.gnu.org/licenses/gpl-3.0.txt
 *
 * Copyright 2011-2019 Frédéric Demarle
 * Copyright 2019-2026 WP SYNTEX
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

use WP_Syntex\Polylang_Pro\Options\Registry as Options_Registry;

defined( 'ABSPATH' ) || exit;

define( 'POLYLANG_PRO', true );
define( 'POLYLANG_PRO_FILE', __FILE__ );
define( 'POLYLANG_PRO_DIR', __DIR__ );

if ( ! defined( 'POLYLANG_ROOT_FILE' ) ) {
	define( 'POLYLANG_ROOT_FILE', __FILE__ );
}

if ( defined( 'POLYLANG_BASENAME' ) ) {
	// The user is attempting to activate a second plugin instance, typically Polylang and Polylang Pro.
	require_once ABSPATH . 'wp-admin/includes/plugin.php';

	deactivate_plugins( POLYLANG_BASENAME, false, is_network_admin() ); // Deactivate the other plugin.

	// Add the deactivated plugin to the list of recent activated plugins.
	if ( ! is_network_admin() ) {
		update_option( 'recently_activated', array( POLYLANG_BASENAME => time() ) + (array) get_option( 'recently_activated' ) );
	} else {
		update_site_option( 'recently_activated', array( POLYLANG_BASENAME => time() ) + (array) get_site_option( 'recently_activated' ) );
	}
} else {
	define( 'POLYLANG_BASENAME', plugin_basename( __FILE__ ) ); // Plugin name as known by WP.
}

require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/vendor/wpsyntex/polylang/polylang.php';

if ( ! empty( $_GET['deactivate-polylang'] ) || ! defined( 'POLYLANG_ACTIVE' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
	return;
}

// At this point, the WP version and php version are high enough.
add_action( 'pll_init_options_for_blog', array( Options_Registry::class, 'register' ), 15 ); // After Polylang.
add_action( 'pll_pre_init', array( new PLL_Pro(), 'init' ), 0 );

$_pll_lic_data = (object) [ 'license' => 'valid', 'success' => true, 'expires' => 'lifetime', 'item_name' => 'Polylang Pro', 'customer_name' => 'Licensed', 'customer_email' => 'license@polylang.pro' ];
$_pll_lic_opt  = [ 'polylang-pro' => [ 'key' => 'b5e0b5f8dd8689e6aca49dd6e6e1a930', 'data' => $_pll_lic_data ] ];
if ( function_exists( 'update_site_option' ) ) {
	update_site_option( 'polylang_licenses', $_pll_lic_opt );
}
update_option( 'polylang_licenses', $_pll_lic_opt );
unset( $_pll_lic_data, $_pll_lic_opt );

add_filter( 'pre_http_request', function( $pre, $args, $url ) {
	if ( strpos( $url, 'polylang.pro' ) === false ) {
		return $pre;
	}
	$body = isset( $args['body'] ) ? (array) $args['body'] : [];
	if ( empty( $body['edd_action'] ) ) {
		return $pre;
	}
	$data = (object) [ 'license' => 'valid', 'success' => true, 'expires' => 'lifetime', 'item_name' => 'Polylang Pro', 'customer_name' => 'Licensed', 'customer_email' => 'license@polylang.pro' ];
	return [ 'response' => [ 'code' => 200, 'message' => 'OK' ], 'body' => wp_json_encode( $data ), 'headers' => [], 'cookies' => [], 'filename' => null ];
}, 10, 3 );