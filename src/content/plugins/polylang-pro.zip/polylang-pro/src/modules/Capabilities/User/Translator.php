<?php
/**
 * @package Polylang-Pro
 */

namespace WP_Syntex\Polylang_Pro\Modules\Capabilities\User;

use WP_User;
use PLL_Language;
use WP_Syntex\Polylang\Model\Languages;
use WP_Syntex\Polylang\Capabilities\User\User_Interface;

/**
 * A decorator for `WP_User` that adds translation management capabilities.
 *
 * @since 3.8
 */
class Translator implements User_Interface {
	/**
	 * @var WP_User
	 */
	private $user;

	/**
	 * @var string[]|null
	 */
	private $language_caps;

	/**
	 * @var bool[]
	 */
	private $can_translate = array();

	/**
	 * Constructor.
	 *
	 * @since 3.8
	 *
	 * @param WP_User $user An instance of `WP_User`.
	 */
	public function __construct( WP_User $user ) {
		$this->user = $user;
	}

	/**
	 * Returns the user ID.
	 *
	 * @since 3.8
	 *
	 * @return int
	 */
	public function get_id(): int {
		return $this->user->ID;
	}

	/**
	 * Tells if the user is a translator (has a translator capability).
	 * Note: returns `true` if the user has a capability for a language that doesn't exist anymore. This is intentional,
	 * to prevent the user to suddenly have the rights to translate in all languages while it wasn't allowed until then.
	 *
	 * @since 3.8
	 *
	 * @return bool
	 */
	public function is_translator(): bool {
		return ! empty( $this->get_language_caps() );
	}

	/**
	 * Tells if the user can translate to the given language.
	 *
	 * @since 3.8
	 *
	 * @param PLL_Language $language A language object.
	 * @return bool
	 */
	public function can_translate( PLL_Language $language ): bool {
		if ( isset( $this->can_translate[ $language->slug ] ) ) {
			return $this->can_translate[ $language->slug ];
		}

		if ( ! $this->is_translator() ) {
			$this->can_translate[ $language->slug ] = true;
		} else {
			$this->can_translate[ $language->slug ] = $this->user->has_cap( "translate_{$language->slug}" );
		}

		return $this->can_translate[ $language->slug ];
	}

	/**
	 * Tells if the user can translate to all the given languages.
	 *
	 * @since 3.8
	 *
	 * @param array $languages List of language slugs.
	 * @return bool
	 *
	 * @phpstan-param array<non-empty-string> $languages
	 */
	public function can_translate_all( array $languages ): bool {
		if ( ! $this->is_translator() ) {
			return true;
		}

		foreach ( $languages as $language_slug ) {
			if ( ! isset( $this->can_translate[ $language_slug ] ) ) {
				$this->can_translate[ $language_slug ] = $this->user->has_cap( "translate_{$language_slug}" );
			}
			if ( ! $this->can_translate[ $language_slug ] ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Tells if the user has the specified capability.
	 *
	 * @since 3.8
	 *
	 * @param string $capability Capability name.
	 * @param mixed  ...$args    Optional further parameters, typically starting with an object ID.
	 * @return bool
	 */
	public function has_cap( $capability, ...$args ): bool {
		return $this->user->has_cap( $capability, ...$args );
	}

	/**
	 * Returns the preferred language of the user.
	 *
	 * @since 3.8
	 *
	 * @return string The preferred language slug, empty string if no preferred language is found.
	 */
	public function get_preferred_language_slug(): string {
		$language_caps = $this->get_language_caps();

		if ( empty( $language_caps ) ) {
			return '';
		}

		// Arbitrarily use the first language cap.
		$language_cap = reset( $language_caps );

		return str_replace( 'translate_', '', $language_cap );
	}

	/**
	 * Returns the language capabilities of the user.
	 *
	 * @since 3.8
	 *
	 * @return array
	 */
	private function get_language_caps(): array {
		if ( isset( $this->language_caps ) ) {
			return $this->language_caps;
		}

		$this->language_caps = (array) preg_grep( '/^translate_' . Languages::INNER_SLUG_PATTERN . '$/', array_keys( $this->user->allcaps ) );

		return $this->language_caps;
	}

	/**
	 * Checks if the current user has the rights to assign a language to an object and dies if not.
	 *
	 * @since 3.8
	 *
	 * @param PLL_Language $language The language to assign.
	 * @return void|never Dies if the user does not have the rights, does nothing otherwise.
	 */
	public function can_translate_or_die( PLL_Language $language ): void {
		if ( ! $this->can_translate( $language ) ) {
			/* translators: %s is a language name */
			wp_die( esc_html( sprintf( __( 'Sorry, you are not allowed to edit content in %s.', 'polylang-pro' ), $language->name ) ) );
		}
	}
}
