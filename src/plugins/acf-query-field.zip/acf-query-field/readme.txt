=== ACF Query Field Plugin ===
Contributors: Tolga
Tags: acf, custom fields, ajax, query
Requires at least: 5.0
Tested up to: 6.2
Requires PHP: 7.0
Stable tag: 1.0.0

Description:
A custom ACF field type to handle complex queries with AJAX support.

== Installation ==

1. Upload the `acf-query-field-plugin` directory to your `wp-content/plugins` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Use the ACF field type "query_field" in your ACF field groups.

== Changelog ==

= 1.0.0 =
* Initial release.
